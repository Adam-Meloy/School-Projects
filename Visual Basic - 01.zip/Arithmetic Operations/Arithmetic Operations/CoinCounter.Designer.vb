﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CoinCounter
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnBack = New System.Windows.Forms.Button()
        Me.lblTotalValue = New System.Windows.Forms.Label()
        Me.lbl5 = New System.Windows.Forms.Label()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.tbxCents = New System.Windows.Forms.TextBox()
        Me.lbl1 = New System.Windows.Forms.Label()
        Me.tbxNickels = New System.Windows.Forms.TextBox()
        Me.lbl2 = New System.Windows.Forms.Label()
        Me.tbxQuarters = New System.Windows.Forms.TextBox()
        Me.lbl4 = New System.Windows.Forms.Label()
        Me.tbxDimes = New System.Windows.Forms.TextBox()
        Me.lbl3 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btnBack
        '
        Me.btnBack.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBack.Location = New System.Drawing.Point(370, 423)
        Me.btnBack.Margin = New System.Windows.Forms.Padding(6)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(121, 84)
        Me.btnBack.TabIndex = 20
        Me.btnBack.Text = "Back"
        Me.btnBack.UseVisualStyleBackColor = True
        '
        'lblTotalValue
        '
        Me.lblTotalValue.AutoSize = True
        Me.lblTotalValue.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotalValue.Location = New System.Drawing.Point(403, 359)
        Me.lblTotalValue.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.lblTotalValue.Name = "lblTotalValue"
        Me.lblTotalValue.Size = New System.Drawing.Size(54, 24)
        Me.lblTotalValue.TabIndex = 19
        Me.lblTotalValue.Text = "xxxx"
        '
        'lbl5
        '
        Me.lbl5.AutoSize = True
        Me.lbl5.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl5.Location = New System.Drawing.Point(118, 359)
        Me.lbl5.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.lbl5.Name = "lbl5"
        Me.lbl5.Size = New System.Drawing.Size(247, 24)
        Me.lbl5.TabIndex = 18
        Me.lbl5.Text = "Total Value of The Coins:"
        '
        'btnCalculate
        '
        Me.btnCalculate.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCalculate.Location = New System.Drawing.Point(150, 423)
        Me.btnCalculate.Margin = New System.Windows.Forms.Padding(6)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(121, 84)
        Me.btnCalculate.TabIndex = 17
        Me.btnCalculate.Text = "Calculate"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'tbxCents
        '
        Me.tbxCents.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbxCents.Location = New System.Drawing.Point(352, 43)
        Me.tbxCents.Name = "tbxCents"
        Me.tbxCents.Size = New System.Drawing.Size(186, 38)
        Me.tbxCents.TabIndex = 16
        '
        'lbl1
        '
        Me.lbl1.AutoSize = True
        Me.lbl1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl1.Location = New System.Drawing.Point(118, 53)
        Me.lbl1.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.lbl1.Name = "lbl1"
        Me.lbl1.Size = New System.Drawing.Size(173, 24)
        Me.lbl1.TabIndex = 15
        Me.lbl1.Text = "How Many Cents:"
        '
        'tbxNickels
        '
        Me.tbxNickels.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbxNickels.Location = New System.Drawing.Point(352, 121)
        Me.tbxNickels.Name = "tbxNickels"
        Me.tbxNickels.Size = New System.Drawing.Size(186, 38)
        Me.tbxNickels.TabIndex = 22
        '
        'lbl2
        '
        Me.lbl2.AutoSize = True
        Me.lbl2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl2.Location = New System.Drawing.Point(118, 135)
        Me.lbl2.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.lbl2.Name = "lbl2"
        Me.lbl2.Size = New System.Drawing.Size(188, 24)
        Me.lbl2.TabIndex = 21
        Me.lbl2.Text = "How Many Nickels:"
        '
        'tbxQuarters
        '
        Me.tbxQuarters.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbxQuarters.Location = New System.Drawing.Point(352, 274)
        Me.tbxQuarters.Name = "tbxQuarters"
        Me.tbxQuarters.Size = New System.Drawing.Size(186, 38)
        Me.tbxQuarters.TabIndex = 26
        '
        'lbl4
        '
        Me.lbl4.AutoSize = True
        Me.lbl4.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl4.Location = New System.Drawing.Point(118, 288)
        Me.lbl4.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.lbl4.Name = "lbl4"
        Me.lbl4.Size = New System.Drawing.Size(200, 24)
        Me.lbl4.TabIndex = 25
        Me.lbl4.Text = "How Many Quarters:"
        '
        'tbxDimes
        '
        Me.tbxDimes.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbxDimes.Location = New System.Drawing.Point(352, 192)
        Me.tbxDimes.Name = "tbxDimes"
        Me.tbxDimes.Size = New System.Drawing.Size(186, 38)
        Me.tbxDimes.TabIndex = 24
        '
        'lbl3
        '
        Me.lbl3.AutoSize = True
        Me.lbl3.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl3.Location = New System.Drawing.Point(118, 206)
        Me.lbl3.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.lbl3.Name = "lbl3"
        Me.lbl3.Size = New System.Drawing.Size(178, 24)
        Me.lbl3.TabIndex = 23
        Me.lbl3.Text = "How Many Dimes:"
        '
        'CoinCounter
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(664, 533)
        Me.Controls.Add(Me.tbxQuarters)
        Me.Controls.Add(Me.lbl4)
        Me.Controls.Add(Me.tbxDimes)
        Me.Controls.Add(Me.lbl3)
        Me.Controls.Add(Me.tbxNickels)
        Me.Controls.Add(Me.lbl2)
        Me.Controls.Add(Me.btnBack)
        Me.Controls.Add(Me.lblTotalValue)
        Me.Controls.Add(Me.lbl5)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.tbxCents)
        Me.Controls.Add(Me.lbl1)
        Me.Name = "CoinCounter"
        Me.Text = "Coin Counter"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnBack As Button
    Friend WithEvents lblTotalValue As Label
    Friend WithEvents lbl5 As Label
    Friend WithEvents btnCalculate As Button
    Friend WithEvents tbxCents As TextBox
    Friend WithEvents lbl1 As Label
    Friend WithEvents tbxNickels As TextBox
    Friend WithEvents lbl2 As Label
    Friend WithEvents tbxQuarters As TextBox
    Friend WithEvents lbl4 As Label
    Friend WithEvents tbxDimes As TextBox
    Friend WithEvents lbl3 As Label
End Class
