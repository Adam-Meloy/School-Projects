﻿Public Class EggCounter
    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        Me.Hide()
        Main.Show()
    End Sub

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim totalEgg As Decimal = tbxEggs.Text
        Dim gross As Decimal = totalEgg \ 144
        Dim totalAfterG As Decimal = totalEgg Mod 144
        Dim dozen As Decimal = totalAfterG \ 12
        Dim totalAfterD As Decimal = totalAfterG Mod 12
        Dim leftover As Decimal = totalAfterD  Mod 12
        lblResult.Text = "You have " & gross & " Gross, " & dozen & " Dozens, " & leftover & " Eggs."
    End Sub

    Private Sub EggCounter_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        tbxEggs.Text = "0"
    End Sub
End Class