﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class InchesToFeetConverter
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnBack = New System.Windows.Forms.Button()
        Me.tbxFeet = New System.Windows.Forms.TextBox()
        Me.lblInches = New System.Windows.Forms.Label()
        Me.lblInchesHeading = New System.Windows.Forms.Label()
        Me.lblFeet = New System.Windows.Forms.Label()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnBack
        '
        Me.btnBack.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBack.Location = New System.Drawing.Point(427, 342)
        Me.btnBack.Margin = New System.Windows.Forms.Padding(6)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(121, 84)
        Me.btnBack.TabIndex = 11
        Me.btnBack.Text = "Back"
        Me.btnBack.UseVisualStyleBackColor = True
        '
        'tbxFeet
        '
        Me.tbxFeet.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbxFeet.Location = New System.Drawing.Point(362, 39)
        Me.tbxFeet.Name = "tbxFeet"
        Me.tbxFeet.Size = New System.Drawing.Size(186, 29)
        Me.tbxFeet.TabIndex = 10
        '
        'lblInches
        '
        Me.lblInches.AutoSize = True
        Me.lblInches.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblInches.Location = New System.Drawing.Point(358, 196)
        Me.lblInches.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.lblInches.Name = "lblInches"
        Me.lblInches.Size = New System.Drawing.Size(54, 24)
        Me.lblInches.TabIndex = 9
        Me.lblInches.Text = "xxxx"
        '
        'lblInchesHeading
        '
        Me.lblInchesHeading.AutoSize = True
        Me.lblInchesHeading.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblInchesHeading.Location = New System.Drawing.Point(146, 196)
        Me.lblInchesHeading.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.lblInchesHeading.Name = "lblInchesHeading"
        Me.lblInchesHeading.Size = New System.Drawing.Size(136, 24)
        Me.lblInchesHeading.TabIndex = 8
        Me.lblInchesHeading.Text = "Total inches: "
        '
        'lblFeet
        '
        Me.lblFeet.AutoSize = True
        Me.lblFeet.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFeet.Location = New System.Drawing.Point(136, 44)
        Me.lblFeet.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.lblFeet.Name = "lblFeet"
        Me.lblFeet.Size = New System.Drawing.Size(162, 24)
        Me.lblFeet.TabIndex = 7
        Me.lblFeet.Text = "Number of Feet:"
        '
        'btnCalculate
        '
        Me.btnCalculate.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCalculate.Location = New System.Drawing.Point(150, 342)
        Me.btnCalculate.Margin = New System.Windows.Forms.Padding(6)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(121, 84)
        Me.btnCalculate.TabIndex = 6
        Me.btnCalculate.Text = "Calculate"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'InchesToFeetConverter
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(685, 465)
        Me.Controls.Add(Me.btnBack)
        Me.Controls.Add(Me.tbxFeet)
        Me.Controls.Add(Me.lblInches)
        Me.Controls.Add(Me.lblInchesHeading)
        Me.Controls.Add(Me.lblFeet)
        Me.Controls.Add(Me.btnCalculate)
        Me.Name = "InchesToFeetConverter"
        Me.Text = "Inches to Feet Converter"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnBack As Button
    Friend WithEvents tbxFeet As TextBox
    Friend WithEvents lblInches As Label
    Friend WithEvents lblInchesHeading As Label
    Friend WithEvents lblFeet As Label
    Friend WithEvents btnCalculate As Button
End Class
