﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class HourlyWageCalculator
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.tbxHoursWorked = New System.Windows.Forms.TextBox()
        Me.lbl4 = New System.Windows.Forms.Label()
        Me.tbxWeeklyPay = New System.Windows.Forms.TextBox()
        Me.lbl3 = New System.Windows.Forms.Label()
        Me.btnBack = New System.Windows.Forms.Button()
        Me.lblHourlyWage = New System.Windows.Forms.Label()
        Me.lbl5 = New System.Windows.Forms.Label()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'tbxHoursWorked
        '
        Me.tbxHoursWorked.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbxHoursWorked.Location = New System.Drawing.Point(334, 182)
        Me.tbxHoursWorked.Name = "tbxHoursWorked"
        Me.tbxHoursWorked.Size = New System.Drawing.Size(186, 38)
        Me.tbxHoursWorked.TabIndex = 34
        '
        'lbl4
        '
        Me.lbl4.AutoSize = True
        Me.lbl4.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl4.Location = New System.Drawing.Point(103, 182)
        Me.lbl4.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.lbl4.Name = "lbl4"
        Me.lbl4.Size = New System.Drawing.Size(150, 24)
        Me.lbl4.TabIndex = 33
        Me.lbl4.Text = "Hours Worked:"
        '
        'tbxWeeklyPay
        '
        Me.tbxWeeklyPay.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbxWeeklyPay.Location = New System.Drawing.Point(334, 100)
        Me.tbxWeeklyPay.Name = "tbxWeeklyPay"
        Me.tbxWeeklyPay.Size = New System.Drawing.Size(186, 38)
        Me.tbxWeeklyPay.TabIndex = 32
        '
        'lbl3
        '
        Me.lbl3.AutoSize = True
        Me.lbl3.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl3.Location = New System.Drawing.Point(103, 100)
        Me.lbl3.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.lbl3.Name = "lbl3"
        Me.lbl3.Size = New System.Drawing.Size(124, 24)
        Me.lbl3.TabIndex = 31
        Me.lbl3.Text = "Weekly Pay:"
        '
        'btnBack
        '
        Me.btnBack.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBack.Location = New System.Drawing.Point(352, 331)
        Me.btnBack.Margin = New System.Windows.Forms.Padding(6)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(121, 84)
        Me.btnBack.TabIndex = 30
        Me.btnBack.Text = "Back"
        Me.btnBack.UseVisualStyleBackColor = True
        '
        'lblHourlyWage
        '
        Me.lblHourlyWage.AutoSize = True
        Me.lblHourlyWage.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHourlyWage.Location = New System.Drawing.Point(385, 267)
        Me.lblHourlyWage.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.lblHourlyWage.Name = "lblHourlyWage"
        Me.lblHourlyWage.Size = New System.Drawing.Size(54, 24)
        Me.lblHourlyWage.TabIndex = 29
        Me.lblHourlyWage.Text = "xxxx"
        '
        'lbl5
        '
        Me.lbl5.AutoSize = True
        Me.lbl5.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl5.Location = New System.Drawing.Point(103, 267)
        Me.lbl5.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.lbl5.Name = "lbl5"
        Me.lbl5.Size = New System.Drawing.Size(137, 24)
        Me.lbl5.TabIndex = 28
        Me.lbl5.Text = "Hourly Wage:"
        '
        'btnCalculate
        '
        Me.btnCalculate.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCalculate.Location = New System.Drawing.Point(132, 331)
        Me.btnCalculate.Margin = New System.Windows.Forms.Padding(6)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(121, 84)
        Me.btnCalculate.TabIndex = 27
        Me.btnCalculate.Text = "Calculate"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'HourlyWageCalculator
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(621, 515)
        Me.Controls.Add(Me.tbxHoursWorked)
        Me.Controls.Add(Me.lbl4)
        Me.Controls.Add(Me.tbxWeeklyPay)
        Me.Controls.Add(Me.lbl3)
        Me.Controls.Add(Me.btnBack)
        Me.Controls.Add(Me.lblHourlyWage)
        Me.Controls.Add(Me.lbl5)
        Me.Controls.Add(Me.btnCalculate)
        Me.Name = "HourlyWageCalculator"
        Me.Text = "HourlyWageCalculator"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents tbxHoursWorked As TextBox
    Friend WithEvents lbl4 As Label
    Friend WithEvents tbxWeeklyPay As TextBox
    Friend WithEvents lbl3 As Label
    Friend WithEvents btnBack As Button
    Friend WithEvents lblHourlyWage As Label
    Friend WithEvents lbl5 As Label
    Friend WithEvents btnCalculate As Button
End Class
