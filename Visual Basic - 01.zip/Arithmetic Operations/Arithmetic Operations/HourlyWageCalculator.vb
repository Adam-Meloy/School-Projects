﻿Public Class HourlyWageCalculator

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        Me.Hide()
        Main.Show()
    End Sub

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim hourlyWage As Decimal
        Dim weekyPay As Decimal
        Dim hoursWorked As Decimal
        weekyPay = tbxWeeklyPay.Text
        hoursWorked = tbxHoursWorked.Text
        hourlyWage = weekyPay / hoursWorked
        lblHourlyWage.Text = hourlyWage
    End Sub
End Class