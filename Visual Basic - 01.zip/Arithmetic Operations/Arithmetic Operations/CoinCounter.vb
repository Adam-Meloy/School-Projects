﻿Public Class CoinCounter
    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        Me.Hide()
        Main.Show()
    End Sub

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim penny As Decimal = 0.01
        Dim nickel As Decimal = 0.05
        Dim dime As Decimal = 0.1
        Dim quarter As Decimal = 0.25
        Dim nmbrPenny As String = tbxCents.Text
        Dim nmbrNickel As String = tbxNickels.Text
        Dim nmbrDime As String = tbxDimes.Text
        Dim nmbrQuarter As String = tbxQuarters.Text
        lblTotalValue.Text = (penny * nmbrPenny) + (nickel * nmbrNickel) + (dime * nmbrDime) + (quarter * nmbrQuarter)

    End Sub

    Private Sub CoinCounter_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        tbxCents.Text = "0"
        tbxNickels.Text = "0"
        tbxDimes.Text = "0"
        tbxQuarters.Text = "0"
    End Sub
End Class