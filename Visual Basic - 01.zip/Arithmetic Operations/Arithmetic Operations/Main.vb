﻿Public Class Main
    Private Sub rbInches_CheckedChanged(sender As Object, e As EventArgs) Handles rbInches.CheckedChanged
        Me.Hide()
        If rbInches.Checked = True Then
            InchesToFeetConverter.Show()

        End If
    End Sub

    Private Sub rbHourly_CheckedChanged(sender As Object, e As EventArgs) Handles rbHourly.CheckedChanged
        Me.Hide()
        If rbHourly.Checked = True Then
            HourlyWageCalculator.Show()
        End If
    End Sub

    Private Sub rbCoin_CheckedChanged(sender As Object, e As EventArgs) Handles rbCoin.CheckedChanged
        Me.Hide()
        If rbCoin.Checked = True Then
            CoinCounter.Show()
        End If
    End Sub

    Private Sub rbEgg_CheckedChanged(sender As Object, e As EventArgs) Handles rbEgg.CheckedChanged
        Me.Hide()
        If rbEgg.Checked = True Then
            EggCounter.Show()
        End If
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub
End Class
