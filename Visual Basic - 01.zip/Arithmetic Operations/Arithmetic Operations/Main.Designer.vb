﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Main
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.rbEgg = New System.Windows.Forms.RadioButton()
        Me.rbCoin = New System.Windows.Forms.RadioButton()
        Me.rbHourly = New System.Windows.Forms.RadioButton()
        Me.rbInches = New System.Windows.Forms.RadioButton()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.rbEgg)
        Me.GroupBox1.Controls.Add(Me.rbCoin)
        Me.GroupBox1.Controls.Add(Me.rbHourly)
        Me.GroupBox1.Controls.Add(Me.rbInches)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(82, 35)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(416, 277)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Options:"
        '
        'rbEgg
        '
        Me.rbEgg.AutoSize = True
        Me.rbEgg.Location = New System.Drawing.Point(19, 220)
        Me.rbEgg.Name = "rbEgg"
        Me.rbEgg.Size = New System.Drawing.Size(146, 28)
        Me.rbEgg.TabIndex = 3
        Me.rbEgg.Text = "Egg Counter"
        Me.rbEgg.UseVisualStyleBackColor = True
        '
        'rbCoin
        '
        Me.rbCoin.AutoSize = True
        Me.rbCoin.Location = New System.Drawing.Point(19, 162)
        Me.rbCoin.Name = "rbCoin"
        Me.rbCoin.Size = New System.Drawing.Size(151, 28)
        Me.rbCoin.TabIndex = 2
        Me.rbCoin.Text = "Coin Counter"
        Me.rbCoin.UseVisualStyleBackColor = True
        '
        'rbHourly
        '
        Me.rbHourly.AutoSize = True
        Me.rbHourly.Location = New System.Drawing.Point(19, 103)
        Me.rbHourly.Name = "rbHourly"
        Me.rbHourly.Size = New System.Drawing.Size(248, 28)
        Me.rbHourly.TabIndex = 1
        Me.rbHourly.Text = "Hourly Wage Calculator"
        Me.rbHourly.UseVisualStyleBackColor = True
        '
        'rbInches
        '
        Me.rbInches.AutoSize = True
        Me.rbInches.Location = New System.Drawing.Point(19, 52)
        Me.rbInches.Name = "rbInches"
        Me.rbInches.Size = New System.Drawing.Size(258, 28)
        Me.rbInches.TabIndex = 0
        Me.rbInches.Text = "Inches to Feet Converter"
        Me.rbInches.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.Location = New System.Drawing.Point(354, 323)
        Me.btnExit.Margin = New System.Windows.Forms.Padding(6)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(121, 84)
        Me.btnExit.TabIndex = 7
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'Main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(777, 422)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Main"
        Me.Text = "Arithmetic Operations"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents rbEgg As RadioButton
    Friend WithEvents rbCoin As RadioButton
    Friend WithEvents rbHourly As RadioButton
    Friend WithEvents rbInches As RadioButton
    Friend WithEvents btnExit As Button
End Class
