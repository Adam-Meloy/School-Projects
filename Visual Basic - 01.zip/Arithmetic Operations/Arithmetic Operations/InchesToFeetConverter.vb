﻿Public Class InchesToFeetConverter

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim inches As Decimal
        Dim feet As Decimal
        feet = tbxFeet.Text
        inches = feet * 12
        lblInches.Text = inches
    End Sub

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        Me.Hide()
        Main.Show()
    End Sub
End Class