﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Main
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnVerticalRace = New System.Windows.Forms.Button()
        Me.btnHorizontalRace = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnVerticalRace
        '
        Me.btnVerticalRace.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnVerticalRace.Location = New System.Drawing.Point(116, 263)
        Me.btnVerticalRace.Name = "btnVerticalRace"
        Me.btnVerticalRace.Size = New System.Drawing.Size(292, 82)
        Me.btnVerticalRace.TabIndex = 5
        Me.btnVerticalRace.Text = "Race (Vertical)"
        Me.btnVerticalRace.UseVisualStyleBackColor = True
        '
        'btnHorizontalRace
        '
        Me.btnHorizontalRace.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnHorizontalRace.Location = New System.Drawing.Point(116, 81)
        Me.btnHorizontalRace.Name = "btnHorizontalRace"
        Me.btnHorizontalRace.Size = New System.Drawing.Size(292, 82)
        Me.btnHorizontalRace.TabIndex = 4
        Me.btnHorizontalRace.Text = "Race (Horizontal)"
        Me.btnHorizontalRace.UseVisualStyleBackColor = True
        '
        'Main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(524, 426)
        Me.Controls.Add(Me.btnVerticalRace)
        Me.Controls.Add(Me.btnHorizontalRace)
        Me.Name = "Main"
        Me.Text = "Select Screen"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btnVerticalRace As Button
    Friend WithEvents btnHorizontalRace As Button
End Class
