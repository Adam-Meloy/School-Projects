﻿Public Class Main
    Private Sub btnHorizontalRace_Click(sender As Object, e As EventArgs) Handles btnHorizontalRace.Click
        HorizontalRace.Show()
        Me.Hide()
    End Sub

    Private Sub btnVerticalRace_Click(sender As Object, e As EventArgs) Handles btnVerticalRace.Click
        VerticalRace.Show()
        Me.Hide()
    End Sub
End Class
