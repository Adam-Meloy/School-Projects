﻿Public Class VerticalRace
    Private Sub btnTop2Bottom_Click(sender As Object, e As EventArgs) Handles btnTop2Bottom.Click
        pbxBall1.Top = 28
        RaceTimer.Enabled = True
        btnTop2Bottom.Enabled = False
        btnBottom2Top.Enabled = True
    End Sub

    Private Sub btnBottom2Top_Click(sender As Object, e As EventArgs) Handles btnBottom2Top.Click
        pbxBall2.Top = 526
        RaceTimer.Enabled = True
        btnBottom2Top.Enabled = False
        btnTop2Bottom.Enabled = True
    End Sub

    Private Sub RaceTimer_Tick(sender As Object, e As EventArgs) Handles RaceTimer.Tick
        If pbxBall1.Bottom >= finishLine1.Top Then
            RaceTimer.Enabled = False
            MsgBox("The Race Has Been Finished!")
            pbxBall1.Top = 31
            pbxBall1.Left = 199
        End If
        If btnBottom2Top.Enabled = False Then
            pbxBall2.Top = pbxBall2.Top - 5
        End If
        If btnTop2Bottom.Enabled = False Then
            pbxBall1.Top = pbxBall1.Top + 5
        ElseIf pbxBall2.Top <= finishLine2.Bottom Then
            RaceTimer.Enabled = False
            MsgBox("The Race Has Been Finished!")
            pbxBall2.Top = 526
            pbxBall2.Left = 566
        End If
    End Sub
End Class