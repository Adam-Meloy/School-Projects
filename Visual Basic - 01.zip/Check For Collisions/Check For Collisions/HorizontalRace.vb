﻿Public Class HorizontalRace
    Private Sub btnLeft2Right_Click(sender As Object, e As EventArgs) Handles btnLeft2Right.Click
        pbxBall1.Left = 31
        RaceTimer.Enabled = True
        btnLeft2Right.Enabled = False
        btnRight2Left.Enabled = True
    End Sub

    Private Sub btnRight2Left_Click(sender As Object, e As EventArgs) Handles btnRight2Left.Click
        pbxBall2.Left = 643
        RaceTimer.Enabled = True
        btnRight2Left.Enabled = False
        btnLeft2Right.Enabled = True
    End Sub

    Private Sub RaceTimer_Tick(sender As Object, e As EventArgs) Handles RaceTimer.Tick
        If btnLeft2Right.Enabled = False Then
            pbxBall1.Left = pbxBall1.Left + 5
        ElseIf btnRight2Left.Enabled = False Then
            pbxBall2.Left = pbxBall2.Left - 5
        End If
        If pbxBall1.Right >= finishLine1.Left Then
            RaceTimer.Enabled = False
            MsgBox("The Race Has Been Finished!")
            pbxBall1.Left = 31
        ElseIf pbxBall2.Left <= finishLine2.Right Then
            RaceTimer.Enabled = False
            MsgBox("The Race Has Been Finished!")
            pbxBall2.Left = 643
        End If
    End Sub
End Class