﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class VerticalRace
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(VerticalRace))
        Me.pbxBall2 = New System.Windows.Forms.PictureBox()
        Me.finishLine2 = New System.Windows.Forms.Label()
        Me.finishLine1 = New System.Windows.Forms.Label()
        Me.pbxBall1 = New System.Windows.Forms.PictureBox()
        Me.btnBottom2Top = New System.Windows.Forms.Button()
        Me.btnTop2Bottom = New System.Windows.Forms.Button()
        Me.RaceTimer = New System.Windows.Forms.Timer(Me.components)
        CType(Me.pbxBall2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbxBall1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'pbxBall2
        '
        Me.pbxBall2.Image = CType(resources.GetObject("pbxBall2.Image"), System.Drawing.Image)
        Me.pbxBall2.Location = New System.Drawing.Point(566, 526)
        Me.pbxBall2.Name = "pbxBall2"
        Me.pbxBall2.Size = New System.Drawing.Size(64, 64)
        Me.pbxBall2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbxBall2.TabIndex = 11
        Me.pbxBall2.TabStop = False
        '
        'finishLine2
        '
        Me.finishLine2.BackColor = System.Drawing.Color.Red
        Me.finishLine2.Location = New System.Drawing.Point(489, 9)
        Me.finishLine2.Name = "finishLine2"
        Me.finishLine2.Size = New System.Drawing.Size(200, 15)
        Me.finishLine2.TabIndex = 10
        '
        'finishLine1
        '
        Me.finishLine1.BackColor = System.Drawing.Color.Red
        Me.finishLine1.Location = New System.Drawing.Point(191, 578)
        Me.finishLine1.Name = "finishLine1"
        Me.finishLine1.Size = New System.Drawing.Size(200, 15)
        Me.finishLine1.TabIndex = 9
        '
        'pbxBall1
        '
        Me.pbxBall1.Image = CType(resources.GetObject("pbxBall1.Image"), System.Drawing.Image)
        Me.pbxBall1.Location = New System.Drawing.Point(230, 28)
        Me.pbxBall1.Name = "pbxBall1"
        Me.pbxBall1.Size = New System.Drawing.Size(64, 64)
        Me.pbxBall1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbxBall1.TabIndex = 8
        Me.pbxBall1.TabStop = False
        '
        'btnBottom2Top
        '
        Me.btnBottom2Top.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBottom2Top.Location = New System.Drawing.Point(12, 325)
        Me.btnBottom2Top.Name = "btnBottom2Top"
        Me.btnBottom2Top.Size = New System.Drawing.Size(158, 91)
        Me.btnBottom2Top.TabIndex = 7
        Me.btnBottom2Top.Text = "Race from Bottom to Top"
        Me.btnBottom2Top.UseVisualStyleBackColor = True
        '
        'btnTop2Bottom
        '
        Me.btnTop2Bottom.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnTop2Bottom.Location = New System.Drawing.Point(12, 163)
        Me.btnTop2Bottom.Name = "btnTop2Bottom"
        Me.btnTop2Bottom.Size = New System.Drawing.Size(158, 91)
        Me.btnTop2Bottom.TabIndex = 6
        Me.btnTop2Bottom.Text = "Race from Top to Bottom"
        Me.btnTop2Bottom.UseVisualStyleBackColor = True
        '
        'RaceTimer
        '
        Me.RaceTimer.Interval = 10
        '
        'VerticalRace
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(730, 602)
        Me.Controls.Add(Me.pbxBall2)
        Me.Controls.Add(Me.finishLine2)
        Me.Controls.Add(Me.finishLine1)
        Me.Controls.Add(Me.pbxBall1)
        Me.Controls.Add(Me.btnBottom2Top)
        Me.Controls.Add(Me.btnTop2Bottom)
        Me.Name = "VerticalRace"
        Me.Text = "VerticalRace"
        CType(Me.pbxBall2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbxBall1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents pbxBall2 As PictureBox
    Friend WithEvents finishLine2 As Label
    Friend WithEvents finishLine1 As Label
    Friend WithEvents pbxBall1 As PictureBox
    Friend WithEvents btnBottom2Top As Button
    Friend WithEvents btnTop2Bottom As Button
    Friend WithEvents RaceTimer As Timer
End Class
