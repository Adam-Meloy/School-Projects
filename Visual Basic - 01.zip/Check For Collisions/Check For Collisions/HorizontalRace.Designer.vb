﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class HorizontalRace
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(HorizontalRace))
        Me.btnLeft2Right = New System.Windows.Forms.Button()
        Me.btnRight2Left = New System.Windows.Forms.Button()
        Me.pbxBall1 = New System.Windows.Forms.PictureBox()
        Me.finishLine1 = New System.Windows.Forms.Label()
        Me.finishLine2 = New System.Windows.Forms.Label()
        Me.pbxBall2 = New System.Windows.Forms.PictureBox()
        Me.RaceTimer = New System.Windows.Forms.Timer(Me.components)
        CType(Me.pbxBall1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbxBall2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnLeft2Right
        '
        Me.btnLeft2Right.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLeft2Right.Location = New System.Drawing.Point(31, 32)
        Me.btnLeft2Right.Name = "btnLeft2Right"
        Me.btnLeft2Right.Size = New System.Drawing.Size(144, 74)
        Me.btnLeft2Right.TabIndex = 0
        Me.btnLeft2Right.Text = "Race from Left to Right"
        Me.btnLeft2Right.UseVisualStyleBackColor = True
        '
        'btnRight2Left
        '
        Me.btnRight2Left.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRight2Left.Location = New System.Drawing.Point(393, 32)
        Me.btnRight2Left.Name = "btnRight2Left"
        Me.btnRight2Left.Size = New System.Drawing.Size(144, 74)
        Me.btnRight2Left.TabIndex = 1
        Me.btnRight2Left.Text = "Race from Right to Left"
        Me.btnRight2Left.UseVisualStyleBackColor = True
        '
        'pbxBall1
        '
        Me.pbxBall1.Image = CType(resources.GetObject("pbxBall1.Image"), System.Drawing.Image)
        Me.pbxBall1.Location = New System.Drawing.Point(31, 199)
        Me.pbxBall1.Name = "pbxBall1"
        Me.pbxBall1.Size = New System.Drawing.Size(66, 64)
        Me.pbxBall1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbxBall1.TabIndex = 2
        Me.pbxBall1.TabStop = False
        '
        'finishLine1
        '
        Me.finishLine1.BackColor = System.Drawing.Color.Red
        Me.finishLine1.Location = New System.Drawing.Point(694, 162)
        Me.finishLine1.Name = "finishLine1"
        Me.finishLine1.Size = New System.Drawing.Size(15, 200)
        Me.finishLine1.TabIndex = 3
        '
        'finishLine2
        '
        Me.finishLine2.BackColor = System.Drawing.Color.Red
        Me.finishLine2.Location = New System.Drawing.Point(44, 393)
        Me.finishLine2.Name = "finishLine2"
        Me.finishLine2.Size = New System.Drawing.Size(15, 200)
        Me.finishLine2.TabIndex = 4
        '
        'pbxBall2
        '
        Me.pbxBall2.Image = CType(resources.GetObject("pbxBall2.Image"), System.Drawing.Image)
        Me.pbxBall2.Location = New System.Drawing.Point(643, 480)
        Me.pbxBall2.Name = "pbxBall2"
        Me.pbxBall2.Size = New System.Drawing.Size(64, 64)
        Me.pbxBall2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbxBall2.TabIndex = 5
        Me.pbxBall2.TabStop = False
        '
        'RaceTimer
        '
        Me.RaceTimer.Interval = 10
        '
        'HorizontalRace
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(730, 602)
        Me.Controls.Add(Me.pbxBall2)
        Me.Controls.Add(Me.finishLine2)
        Me.Controls.Add(Me.finishLine1)
        Me.Controls.Add(Me.pbxBall1)
        Me.Controls.Add(Me.btnRight2Left)
        Me.Controls.Add(Me.btnLeft2Right)
        Me.Name = "HorizontalRace"
        Me.Text = "HorizontalRace"
        CType(Me.pbxBall1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbxBall2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btnLeft2Right As Button
    Friend WithEvents btnRight2Left As Button
    Friend WithEvents pbxBall1 As PictureBox
    Friend WithEvents finishLine1 As Label
    Friend WithEvents finishLine2 As Label
    Friend WithEvents pbxBall2 As PictureBox
    Friend WithEvents RaceTimer As Timer
End Class
