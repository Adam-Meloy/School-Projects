﻿Public Class Form1
    Dim DiceRoll1, DiceRoll2, TotalMoney, BetMoney As Integer
    Private Sub Instructions_Click(sender As Object, e As EventArgs) Handles Instructions.Click
        MsgBox("To play this game you bet an amount of money, and if the dice both match, you get double the money you bet, If they do NOT match, you lose the money you bet. The game ends when you reach $0. Betting more money than you have is an instant loss.")
    End Sub
    Private Sub ExitButton_Click(sender As Object, e As EventArgs) Handles ExitButton.Click
        Close()
    End Sub
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        DiceRoll1 = 0
        DiceRoll2 = 0
        TotalMoney = 10
        BetMoney = 0
    End Sub
    Private Sub DiceRoll_Click(sender As Object, e As EventArgs) Handles DiceRoll.Click
        If DiceRoll.Text = "Roll Dice" Then
            DiceTimer.Enabled = True
            DiceRoll.Text = "Stop Dice"
        ElseIf DiceRoll.Text = "Stop Dice" Then
            DiceTimer.Enabled = False
            DiceRoll.Text = "Roll Dice"
            If DiceRoll1 = DiceRoll2 Then
                TotalMoney = TotalMoney + BetMoney * 2
                DollarCount.Text = "You Have " & TotalMoney & "$"
            ElseIf DiceRoll1 >= DiceRoll2 Or DiceRoll1 <= DiceRoll2 Then
                TotalMoney = TotalMoney - BetMoney
                DollarCount.Text = "You Have " & TotalMoney & "$"
            ElseIf BetMoney = 0 Then
                DiceTimer.Enabled = False
                MsgBox("You Lose!")
                Close()
            End If
        End If
    End Sub
    Private Sub DiceTimer_Tick(sender As Object, e As EventArgs) Handles DiceTimer.Tick
        If RollBet.Text = "" Or RollBet.Text = "Money To Bet" Or RollBet.Text = "0" Then
            DiceTimer.Enabled = False
            MsgBox("You Lose!")
            Close()
        ElseIf BetMoney > TotalMoney Then
            DiceTimer.Enabled = False
            MsgBox("You Lose!")
            Close()
        ElseIf TotalMoney = 0 Then
            DiceTimer.Enabled = False
            MsgBox("You Lose!")
            Close()
        Else
            BetMoney = RollBet.Text
            Randomize()
            DiceRoll1 = Int(Rnd() * 6) + 1
            Randomize()
            DiceRoll2 = Int(Rnd() * 6) + 1
            Dice1Roll.Text = "Dice 1 Rolls A " & DiceRoll1 & "!"
            Dice2Roll.Text = "Dice 2 Rolls A " & DiceRoll2 & "!"
            If DiceRoll1 = 1 Then
                Picture1.Image = My.Resources.D1
            ElseIf DiceRoll1 = 2 Then
                Picture1.Image = My.Resources.D2
            ElseIf DiceRoll1 = 3 Then
                Picture1.Image = My.Resources.D3
            ElseIf DiceRoll1 = 4 Then
                Picture1.Image = My.Resources.D4
            ElseIf DiceRoll1 = 5 Then
                Picture1.Image = My.Resources.D5
            ElseIf DiceRoll1 = 6 Then
                Picture1.Image = My.Resources.D6
            End If
            If DiceRoll2 = 1 Then
                Picture2.Image = My.Resources.D1
            ElseIf DiceRoll2 = 2 Then
                Picture2.Image = My.Resources.D2
            ElseIf DiceRoll2 = 3 Then
                Picture2.Image = My.Resources.D3
            ElseIf DiceRoll2 = 4 Then
                Picture2.Image = My.Resources.D4
            ElseIf DiceRoll2 = 5 Then
                Picture2.Image = My.Resources.D5
            ElseIf DiceRoll2 = 6 Then
                Picture2.Image = My.Resources.D6
            End If
        End If
    End Sub
End Class