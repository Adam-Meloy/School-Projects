﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.DiceRoll = New System.Windows.Forms.Button()
        Me.Instructions = New System.Windows.Forms.Button()
        Me.ExitButton = New System.Windows.Forms.Button()
        Me.RollBet = New System.Windows.Forms.TextBox()
        Me.DollarCount = New System.Windows.Forms.Label()
        Me.DiceTimer = New System.Windows.Forms.Timer(Me.components)
        Me.Greeting = New System.Windows.Forms.Label()
        Me.Dice1Roll = New System.Windows.Forms.Label()
        Me.Dice2Roll = New System.Windows.Forms.Label()
        Me.Picture2 = New System.Windows.Forms.PictureBox()
        Me.Picture1 = New System.Windows.Forms.PictureBox()
        CType(Me.Picture2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Picture1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DiceRoll
        '
        Me.DiceRoll.Location = New System.Drawing.Point(13, 243)
        Me.DiceRoll.Name = "DiceRoll"
        Me.DiceRoll.Size = New System.Drawing.Size(75, 75)
        Me.DiceRoll.TabIndex = 0
        Me.DiceRoll.Text = "Roll Dice"
        Me.DiceRoll.UseVisualStyleBackColor = True
        '
        'Instructions
        '
        Me.Instructions.Location = New System.Drawing.Point(300, 243)
        Me.Instructions.Name = "Instructions"
        Me.Instructions.Size = New System.Drawing.Size(75, 75)
        Me.Instructions.TabIndex = 1
        Me.Instructions.Text = "Instructions"
        Me.Instructions.UseVisualStyleBackColor = True
        '
        'ExitButton
        '
        Me.ExitButton.Location = New System.Drawing.Point(375, 243)
        Me.ExitButton.Name = "ExitButton"
        Me.ExitButton.Size = New System.Drawing.Size(75, 75)
        Me.ExitButton.TabIndex = 2
        Me.ExitButton.Text = "Exit"
        Me.ExitButton.UseVisualStyleBackColor = True
        '
        'RollBet
        '
        Me.RollBet.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RollBet.Location = New System.Drawing.Point(94, 243)
        Me.RollBet.Multiline = True
        Me.RollBet.Name = "RollBet"
        Me.RollBet.Size = New System.Drawing.Size(75, 75)
        Me.RollBet.TabIndex = 3
        Me.RollBet.Text = "Money To Bet"
        '
        'DollarCount
        '
        Me.DollarCount.AutoSize = True
        Me.DollarCount.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DollarCount.Location = New System.Drawing.Point(179, 241)
        Me.DollarCount.Name = "DollarCount"
        Me.DollarCount.Size = New System.Drawing.Size(110, 20)
        Me.DollarCount.TabIndex = 4
        Me.DollarCount.Text = "You Have 10$"
        '
        'DiceTimer
        '
        Me.DiceTimer.Interval = 1
        '
        'Greeting
        '
        Me.Greeting.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Greeting.Location = New System.Drawing.Point(168, 9)
        Me.Greeting.Name = "Greeting"
        Me.Greeting.Size = New System.Drawing.Size(126, 153)
        Me.Greeting.TabIndex = 8
        Me.Greeting.Text = "Welcome To Doubles, The game about testing your luck to get money!"
        '
        'Dice1Roll
        '
        Me.Dice1Roll.AutoSize = True
        Me.Dice1Roll.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Dice1Roll.Location = New System.Drawing.Point(12, 189)
        Me.Dice1Roll.Name = "Dice1Roll"
        Me.Dice1Roll.Size = New System.Drawing.Size(108, 20)
        Me.Dice1Roll.TabIndex = 9
        Me.Dice1Roll.Text = "Dice 1 Rolls A"
        '
        'Dice2Roll
        '
        Me.Dice2Roll.AutoSize = True
        Me.Dice2Roll.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Dice2Roll.Location = New System.Drawing.Point(296, 189)
        Me.Dice2Roll.Name = "Dice2Roll"
        Me.Dice2Roll.Size = New System.Drawing.Size(108, 20)
        Me.Dice2Roll.TabIndex = 10
        Me.Dice2Roll.Text = "Dice 2 Rolls A"
        '
        'Picture2
        '
        Me.Picture2.Location = New System.Drawing.Point(300, 12)
        Me.Picture2.Name = "Picture2"
        Me.Picture2.Size = New System.Drawing.Size(150, 150)
        Me.Picture2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Picture2.TabIndex = 7
        Me.Picture2.TabStop = False
        '
        'Picture1
        '
        Me.Picture1.Location = New System.Drawing.Point(12, 12)
        Me.Picture1.Name = "Picture1"
        Me.Picture1.Size = New System.Drawing.Size(150, 150)
        Me.Picture1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Picture1.TabIndex = 6
        Me.Picture1.TabStop = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(462, 330)
        Me.Controls.Add(Me.Dice2Roll)
        Me.Controls.Add(Me.Dice1Roll)
        Me.Controls.Add(Me.Greeting)
        Me.Controls.Add(Me.Picture2)
        Me.Controls.Add(Me.Picture1)
        Me.Controls.Add(Me.DollarCount)
        Me.Controls.Add(Me.RollBet)
        Me.Controls.Add(Me.ExitButton)
        Me.Controls.Add(Me.Instructions)
        Me.Controls.Add(Me.DiceRoll)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.Picture2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Picture1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents DiceRoll As Button
    Friend WithEvents Instructions As Button
    Friend WithEvents ExitButton As Button
    Friend WithEvents RollBet As TextBox
    Friend WithEvents DollarCount As Label
    Friend WithEvents DiceTimer As Timer
    Friend WithEvents Picture1 As PictureBox
    Friend WithEvents Picture2 As PictureBox
    Friend WithEvents Greeting As Label
    Friend WithEvents Dice1Roll As Label
    Friend WithEvents Dice2Roll As Label
End Class
