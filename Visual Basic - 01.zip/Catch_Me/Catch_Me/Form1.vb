﻿Public Class Form1
    Dim Pictures(19), Picture, Krabs As PictureBox
    Dim StartX, StartY, DoomCounter, LabelCount, XRandomizer, YRandomizer As Integer
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        StartX = 331
        StartY = 255
        For i = 0 To Pictures.Length - 1
            Picture = New PictureBox
            Picture.Name = i + 1
            Picture.Width = 69
            Picture.Height = 32
            Randomize()
            Picture.Top = Int(Rnd() * 500) + 50
            Randomize()
            Picture.Left = Int(Rnd() * 500) + 80
            Picture.SizeMode = PictureBoxSizeMode.StretchImage
            Picture.Image = My.Resources.dollar
            Picture.Tag = "E"
            Me.Controls.Add(Picture)
            Pictures(i) = Picture
        Next
        Krabs = New PictureBox
        Krabs.Width = 55
        Krabs.Height = 92
        Krabs.Left = StartX
        Krabs.Top = StartY
        Krabs.SizeMode = PictureBoxSizeMode.StretchImage
        Krabs.Image = My.Resources.MrKrabs
        Me.Controls.Add(Krabs)
        MoveTimer.Enabled = True
    End Sub
    Private Sub MoveTimer_Tick(sender As Object, e As EventArgs) Handles MoveTimer.Tick
        For p = 0 To Pictures.Length - 1
            If Krabs.Bounds.IntersectsWith(Pictures(p).Bounds) And Pictures(p).Tag = "E" Then
                Me.Controls.Remove(Pictures(p))
                Pictures(p).Tag = "D"
                LabelCount += 1
                Score.Text = "Score: " & LabelCount
            ElseIf Pictures(p).Right < 0 Or Pictures(p).Left > 750 Or Pictures(p).Top > 750 Or Pictures(p).Bottom < 0 And Pictures(p).Tag = "E" Then
                DoomCounter += 1
                Escaped.Text = "Escaped: " & DoomCounter
                Me.Controls.Remove(Pictures(p))
                Pictures(p).Tag = "D"
            End If
            If LabelCount = 20 Or LabelCount = 19 Or LabelCount = 18 Or LabelCount = 17 Then
                MoveTimer.Enabled = False
                Krabs.Enabled = False
                Krabs.Visible = False
                For o = 0 To Pictures.Length - 1
                    Pictures(o).Enabled = False
                    Pictures(o).Visible = False
                Next
                MsgBox("You Win!")
                Close()
            ElseIf DoomCounter = 5 Then
                MoveTimer.Enabled = False
                Krabs.Enabled = False
                Krabs.Visible = False
                For o = 0 To Pictures.Length - 1
                    Pictures(o).Enabled = False
                    Pictures(o).Visible = False
                Next
                MsgBox("You Lost.")
                Close()
            End If
            Randomize()
            XRandomizer = Int(Rnd() * 3) - 1
            Randomize()
            YRandomizer = Int(Rnd() * 3) - 1
            If XRandomizer = 2 Then
                Randomize()
                Pictures(p).Left += 1
            ElseIf XRandomizer = 1 Then
                Randomize()
                Pictures(p).Left -= 1
            End If
            If YRandomizer = 2 Then
                Randomize()
                Pictures(p).Top += 1
            ElseIf YRandomizer = 1 Then
                Randomize()
                Pictures(p).Top -= 1
            End If
        Next
    End Sub
    Private Sub Form1_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.W Then
            Krabs.Top -= 20
        ElseIf e.KeyCode = Keys.S Then
            Krabs.Top += 20
        ElseIf e.KeyCode = Keys.A Then
            Krabs.Left -= 20
        ElseIf e.KeyCode = Keys.D Then
            Krabs.Left += 20
        End If
    End Sub
End Class