﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnCreateButtons = New System.Windows.Forms.Button()
        Me.BtnHandle = New System.Windows.Forms.Button()
        Me.btnIterate = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnCreateButtons
        '
        Me.btnCreateButtons.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCreateButtons.Location = New System.Drawing.Point(57, 81)
        Me.btnCreateButtons.Name = "btnCreateButtons"
        Me.btnCreateButtons.Size = New System.Drawing.Size(160, 104)
        Me.btnCreateButtons.TabIndex = 0
        Me.btnCreateButtons.Text = "Create Buttons"
        Me.btnCreateButtons.UseVisualStyleBackColor = True
        '
        'BtnHandle
        '
        Me.BtnHandle.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnHandle.Location = New System.Drawing.Point(293, 81)
        Me.BtnHandle.Name = "BtnHandle"
        Me.BtnHandle.Size = New System.Drawing.Size(156, 104)
        Me.BtnHandle.TabIndex = 1
        Me.BtnHandle.Text = "Handle Multiple Labels"
        Me.BtnHandle.UseVisualStyleBackColor = True
        '
        'btnIterate
        '
        Me.btnIterate.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnIterate.Location = New System.Drawing.Point(172, 266)
        Me.btnIterate.Name = "btnIterate"
        Me.btnIterate.Size = New System.Drawing.Size(156, 104)
        Me.btnIterate.TabIndex = 2
        Me.btnIterate.Text = "Iterate Through UI Objects on the Form"
        Me.btnIterate.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(523, 445)
        Me.Controls.Add(Me.btnIterate)
        Me.Controls.Add(Me.BtnHandle)
        Me.Controls.Add(Me.btnCreateButtons)
        Me.Name = "Form1"
        Me.Text = "Create UI Objects Programmatically"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btnCreateButtons As Button
    Friend WithEvents BtnHandle As Button
    Friend WithEvents btnIterate As Button
End Class
