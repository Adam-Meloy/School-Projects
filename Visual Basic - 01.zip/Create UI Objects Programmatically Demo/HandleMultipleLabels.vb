﻿Public Class HandleMultipleLabels
    Dim Ladle, Ladles(9) As Label
    Dim x, y, ladlecreate As Integer
    Private Sub HandleMultipleLabels_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        x = 20
        y = 30
        For i = 0 To Ladles.Length - 1
            If ladlecreate Mod 5 = 0 Then
                x = 50
                y += 70
            End If
            ladlecreate += 1
            Ladle = New Label
            Ladle.Name = "labels are cool" & i + 1
            Ladle.Text = i + 1 & " number(s) and counting"
            Ladle.Width = 150
            Ladle.Height = 50
            Ladle.Left = x
            Ladle.Top = y
            Ladle.BorderStyle = BorderStyle.Fixed3D
            AddHandler Ladle.MouseHover, AddressOf CrazyColours
            AddHandler Ladle.Click, AddressOf LadleClick
            Me.Controls.Add(Ladle)
            Ladles(i) = Ladle
            x = x + 150
        Next
    End Sub
    Private Sub LadleClick(sender As Object, e As EventArgs)
        If sender.Text = "" Then
            sender.Text = "[Insert Text Here]"
        Else
            sender.Text = ""
        End If
    End Sub
    Private Sub CrazyColours(sender As Object, e As EventArgs)
        Dim R, G, B As Integer
        Randomize()
        R = Int(Rnd() * 255) + 0
        G = Int(Rnd() * 255) + 0
        B = Int(Rnd() * 255) + 0
        sender.BackColor = Color.FromArgb(R, G, B)
    End Sub
End Class