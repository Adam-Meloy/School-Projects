﻿Public Class CreateButtons
    Dim numOfButtons As Integer
    Dim btn As Button
    Dim xPos As Integer = 15
    Dim yPos As Integer = 20
    Dim btnArray() As Button
    Private Sub AddButtonHorizontallyToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AddButtonHorizontallyToolStripMenuItem.Click
        numOfButtons = InputBox("How many buttons do you want to create", "Enter a number")
        ReDim btnArray(numOfButtons - 1)
        For i = 0 To numOfButtons - 1
            btn = New Button
            btn.Name = "hi" & i
            btn.Text = "a" & i
            btn.Width = 15
            btn.Height = 15
            btn.Left = xPos
            btn.Top = yPos
            Me.Controls.Add(btn)
            btnArray(i) = btn
            xPos = xPos + 20
        Next
        xPos = 15
        yPos = 20
    End Sub
    Private Sub AddButtonsVerticallyToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AddButtonsVerticallyToolStripMenuItem.Click
        numOfButtons = InputBox("How many buttons do you want to create", "Enter a number")
        ReDim btnArray(numOfButtons - 1)
        For i = 0 To numOfButtons - 1
            btn = New Button
            btn.Name = "hi" & i
            btn.Text = "a" & i
            btn.Width = 15
            btn.Height = 15
            btn.Left = xPos
            btn.Top = yPos
            Me.Controls.Add(btn)
            btnArray(i) = btn
            yPos = yPos + 20
        Next
        xPos = 15
        yPos = 20
    End Sub
    Private Sub RemoveButtonsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RemoveButtonsToolStripMenuItem.Click
        removeButtons()
    End Sub
    Private Sub removeButtons()
        For i = 0 To numOfButtons - 1
            Me.Controls.Remove(btnArray(i))
        Next
    End Sub
    Private Sub CreateButtons_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        MsgBox("Make your selection by clicking on the menu bar items")
    End Sub
    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Me.Close()
    End Sub
End Class