﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class IterateThroughUIObjectsOnTheForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.CountOjbectsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CountObjectsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CountOjbectsToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Padding = New System.Windows.Forms.Padding(4, 2, 0, 2)
        Me.MenuStrip1.Size = New System.Drawing.Size(436, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'CountOjbectsToolStripMenuItem
        '
        Me.CountOjbectsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CountObjectsToolStripMenuItem})
        Me.CountOjbectsToolStripMenuItem.Name = "CountOjbectsToolStripMenuItem"
        Me.CountOjbectsToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.CountOjbectsToolStripMenuItem.Text = "File"
        '
        'CountObjectsToolStripMenuItem
        '
        Me.CountObjectsToolStripMenuItem.Name = "CountObjectsToolStripMenuItem"
        Me.CountObjectsToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.CountObjectsToolStripMenuItem.Text = "Count Objects"
        '
        'IterateThroughUIObjectsOnTheForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(436, 370)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "IterateThroughUIObjectsOnTheForm"
        Me.Text = "IterateThroughUIObjectsOnTheForm"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents CountOjbectsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CountObjectsToolStripMenuItem As ToolStripMenuItem
End Class
