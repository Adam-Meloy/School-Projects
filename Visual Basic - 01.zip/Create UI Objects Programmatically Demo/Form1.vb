﻿Public Class Form1
    Private Sub btnCreateButtons_Click(sender As Object, e As EventArgs) Handles btnCreateButtons.Click
        CreateButtons.Show()

    End Sub

    Private Sub BtnHandle_Click(sender As Object, e As EventArgs) Handles BtnHandle.Click
        HandleMultipleLabels.Show()

    End Sub

    Private Sub btnIterate_Click(sender As Object, e As EventArgs) Handles btnIterate.Click
        IterateThroughUIObjectsOnTheForm.Show()
    End Sub
End Class
