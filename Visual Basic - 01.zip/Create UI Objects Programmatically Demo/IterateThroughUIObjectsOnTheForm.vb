﻿Public Class IterateThroughUIObjectsOnTheForm
    Dim RButton(5), Button As Button
    Dim RLabel(2), Label As Label
    Dim bc, lc, oc As Integer
    Private Sub IterateThroughUIObjectsOnTheForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        For i = 0 To RLabel.Length - 1
            Label = New Label
            Label.BackColor = Color.FromArgb(Int(Rnd() * 255), Int(Rnd() * 255), Int(Rnd() * 255))
            Label.Text = "L" & i + 1
            Label.Height = 40
            Label.Width = 40
            Label.Left = Int(Rnd() * 400) + 1
            Randomize()
            Label.Top = Int(Rnd() * 350) + 25
            Randomize()
            Me.Controls.Add(Label)
            RLabel(i) = Label
            Button = New Button
            Button.BackColor = Color.FromArgb(Int(Rnd() * 255), Int(Rnd() * 255), Int(Rnd() * 255))
            Button.Text = "B" & i + 1 & ".1"
            Button.Height = 40
            Button.Width = 40
            Randomize()
            Button.Left = Int(Rnd() * 400) + 1
            Randomize()
            Button.Top = Int(Rnd() * 350) + 25
            Me.Controls.Add(Button)
            RButton(i) = Button
            Button = New Button
            Button.BackColor = Color.FromArgb(Int(Rnd() * 255), Int(Rnd() * 255), Int(Rnd() * 255))
            Button.Text = "B" & i + 1 & ".2"
            Button.Height = 40
            Button.Width = 40
            Randomize()
            Button.Left = Int(Rnd() * 400) + 1
            Randomize()
            Button.Top = Int(Rnd() * 350) + 25
            Me.Controls.Add(Button)
            RButton(i + 1) = Button
        Next
    End Sub
    Private Sub CountObjectsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CountObjectsToolStripMenuItem.Click
        For Each uiObject As Control In Me.Controls
            If TypeOf uiObject Is Button Then
                bc += 1
            ElseIf TypeOf uiObject Is Label Then
                lc += 1
            Else
                oc += 1
            End If
        Next
        MsgBox("The Total is " & bc + lc + oc & " Objects, " & bc & " Button(s), " & lc & " Label(s), " & oc & " Other Object(s)")
    End Sub
End Class