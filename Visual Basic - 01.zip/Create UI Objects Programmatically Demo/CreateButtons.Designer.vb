﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class CreateButtons
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.lblDisplay = New System.Windows.Forms.Label()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AddButtonHorizontallyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AddButtonsVerticallyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RemoveButtonsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblDisplay
        '
        Me.lblDisplay.AutoSize = True
        Me.lblDisplay.Location = New System.Drawing.Point(41, 355)
        Me.lblDisplay.Name = "lblDisplay"
        Me.lblDisplay.Size = New System.Drawing.Size(0, 13)
        Me.lblDisplay.TabIndex = 2
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(529, 24)
        Me.MenuStrip1.TabIndex = 3
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AddButtonHorizontallyToolStripMenuItem, Me.AddButtonsVerticallyToolStripMenuItem, Me.RemoveButtonsToolStripMenuItem, Me.ExitToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'AddButtonHorizontallyToolStripMenuItem
        '
        Me.AddButtonHorizontallyToolStripMenuItem.Name = "AddButtonHorizontallyToolStripMenuItem"
        Me.AddButtonHorizontallyToolStripMenuItem.Size = New System.Drawing.Size(207, 22)
        Me.AddButtonHorizontallyToolStripMenuItem.Text = "Add Buttons Horizontally"
        '
        'AddButtonsVerticallyToolStripMenuItem
        '
        Me.AddButtonsVerticallyToolStripMenuItem.Name = "AddButtonsVerticallyToolStripMenuItem"
        Me.AddButtonsVerticallyToolStripMenuItem.Size = New System.Drawing.Size(207, 22)
        Me.AddButtonsVerticallyToolStripMenuItem.Text = "Add Buttons  Vertically"
        '
        'RemoveButtonsToolStripMenuItem
        '
        Me.RemoveButtonsToolStripMenuItem.Name = "RemoveButtonsToolStripMenuItem"
        Me.RemoveButtonsToolStripMenuItem.Size = New System.Drawing.Size(207, 22)
        Me.RemoveButtonsToolStripMenuItem.Text = "Remove Buttons"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(207, 22)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'CreateButtons
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(529, 412)
        Me.Controls.Add(Me.lblDisplay)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "CreateButtons"
        Me.Text = "CreateButtons"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblDisplay As Label
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents FileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AddButtonHorizontallyToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AddButtonsVerticallyToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents RemoveButtonsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As ToolStripMenuItem
End Class
