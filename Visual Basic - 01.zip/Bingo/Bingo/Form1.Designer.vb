﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.CallNumbers = New System.Windows.Forms.Button()
        Me.Bingo_Picture = New System.Windows.Forms.PictureBox()
        Me.Bingo_Picture2 = New System.Windows.Forms.PictureBox()
        Me.Called_Label = New System.Windows.Forms.Label()
        Me.Name2 = New System.Windows.Forms.Label()
        Me.Name1 = New System.Windows.Forms.Label()
        CType(Me.Bingo_Picture, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Bingo_Picture2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'CallNumbers
        '
        Me.CallNumbers.Location = New System.Drawing.Point(349, 386)
        Me.CallNumbers.Name = "CallNumbers"
        Me.CallNumbers.Size = New System.Drawing.Size(75, 75)
        Me.CallNumbers.TabIndex = 0
        Me.CallNumbers.Text = "Call Number"
        Me.CallNumbers.UseVisualStyleBackColor = True
        '
        'Bingo_Picture
        '
        Me.Bingo_Picture.Image = Global.Bingo.My.Resources.Resources.images
        Me.Bingo_Picture.Location = New System.Drawing.Point(53, 0)
        Me.Bingo_Picture.Name = "Bingo_Picture"
        Me.Bingo_Picture.Size = New System.Drawing.Size(250, 45)
        Me.Bingo_Picture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Bingo_Picture.TabIndex = 1
        Me.Bingo_Picture.TabStop = False
        '
        'Bingo_Picture2
        '
        Me.Bingo_Picture2.Image = Global.Bingo.My.Resources.Resources.images
        Me.Bingo_Picture2.Location = New System.Drawing.Point(485, 0)
        Me.Bingo_Picture2.Name = "Bingo_Picture2"
        Me.Bingo_Picture2.Size = New System.Drawing.Size(250, 45)
        Me.Bingo_Picture2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Bingo_Picture2.TabIndex = 2
        Me.Bingo_Picture2.TabStop = False
        '
        'Called_Label
        '
        Me.Called_Label.Location = New System.Drawing.Point(342, 360)
        Me.Called_Label.Name = "Called_Label"
        Me.Called_Label.Size = New System.Drawing.Size(91, 23)
        Me.Called_Label.TabIndex = 3
        Me.Called_Label.Text = "Call Number"
        '
        'Name2
        '
        Me.Name2.Location = New System.Drawing.Point(485, 302)
        Me.Name2.Name = "Name2"
        Me.Name2.Size = New System.Drawing.Size(250, 45)
        Me.Name2.TabIndex = 4
        Me.Name2.Text = "Label1"
        '
        'Name1
        '
        Me.Name1.Location = New System.Drawing.Point(50, 302)
        Me.Name1.Name = "Name1"
        Me.Name1.Size = New System.Drawing.Size(250, 45)
        Me.Name1.TabIndex = 5
        Me.Name1.Text = "Label3"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(784, 461)
        Me.Controls.Add(Me.Name1)
        Me.Controls.Add(Me.Name2)
        Me.Controls.Add(Me.Called_Label)
        Me.Controls.Add(Me.Bingo_Picture2)
        Me.Controls.Add(Me.Bingo_Picture)
        Me.Controls.Add(Me.CallNumbers)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.Bingo_Picture, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Bingo_Picture2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents CallNumbers As Button
    Friend WithEvents Bingo_Picture As PictureBox
    Friend WithEvents Bingo_Picture2 As PictureBox
    Friend WithEvents Called_Label As Label
    Friend WithEvents Name2 As Label
    Friend WithEvents Name1 As Label
End Class
