﻿Public Class Form1
    Dim BINGO(,), BINGO2(,), Label, Label2 As Label
    Dim X, X2, Y, Y2, Row, Column, Called_Number, Count As Integer
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call Player_Names()
        Call Load_Game()
    End Sub
    Private Sub Load_Game()
        X = 50
        Y = 50
        Row = 4
        Column = 4
        ReDim BINGO(Row, Column)
        ReDim BINGO2(Row, Column)
        For i = 0 To Row
            For j = 0 To Column
                Count += 1
                Label = New Label
                With Label
                    .Name = j
                    .Tag = Count
                    .Width = 50
                    .Height = 50
                    .Left = X
                    .Top = Y
                    .BorderStyle = BorderStyle.FixedSingle
                    .BackColor = Color.White
                End With
                If Label.Name = 4 Then
                    Y += 50
                    X = 50
                Else
                    X += 50
                End If
                AddHandler Label.Click, AddressOf Cheat_Prevention
                AddHandler Label.Click, AddressOf Check_For_Win
                BINGO(i, j) = Label
                Me.Controls.Add(Label)
            Next
        Next
        X2 = 485
        Y2 = 50
        For h = 0 To Row
            For q = 0 To Column
                Count += 1
                Label2 = New Label
                With Label2
                    .Name = q
                    .Tag = Count
                    .Width = 50
                    .Height = 50
                    .Left = X2
                    .Top = Y2
                    .BorderStyle = BorderStyle.FixedSingle
                    .BackColor = Color.White
                End With
                If Label2.Name = 4 Then
                    Y2 += 50
                    X2 = 485
                Else
                    X2 += 50
                End If
                AddHandler Label2.Click, AddressOf Cheat_Prevention
                AddHandler Label2.Click, AddressOf Check_For_Win
                BINGO2(h, q) = Label2
                Me.Controls.Add(Label2)
            Next
        Next
        Call Randomize_Numbers()
        Call No_Duplicate_Numbers()
    End Sub
    Private Sub Player_Names()
        Name1.Text = InputBox("Enter A Name For P1") & "'s Card"
        Name2.Text = InputBox("Enter A Name For P2") & "'s Card"
    End Sub
    Private Sub Randomize_Numbers()
        For a = 0 To Column
            For b = 0 To 0
                Randomize()
                BINGO(a, b).Text = Int(Rnd() * 15) + 1
                If BINGO(a, b).Text = 16 Then
                    Randomize()
                    BINGO(a, b).Text = Int(Rnd() * 15) + 1
                End If
            Next
        Next
        For c = 0 To Column
            For d = 1 To 1
                Randomize()
                BINGO(c, d).Text = Int(Rnd() * 15) + 15
                If BINGO(c, d).Text = 0 Then
                    Randomize()
                    BINGO(c, d).Text = Int(Rnd() * 15) + 15
                End If
            Next
        Next
        For e = 0 To Column
            For f = 2 To 2
                Randomize()
                BINGO(e, f).Text = Int(Rnd() * 15) + 30
                If BINGO(e, f).Text = 0 Then
                    Randomize()
                    BINGO(e, f).Text = Int(Rnd() * 15) + 30
                End If
                BINGO(2, 2).Text = "Free Space"
                BINGO(2, 2).BackColor = Color.Gray
            Next
        Next
        For g = 0 To Column
            For h = 3 To 3
                Randomize()
                BINGO(g, h).Text = Int(Rnd() * 15) + 45
                If BINGO(g, h).Text = 0 Then
                    Randomize()
                    BINGO(g, h).Text = Int(Rnd() * 15) + 45
                End If
            Next
        Next
        For i = 0 To Column
            For j = 4 To 4
                Randomize()
                BINGO(i, j).Text = Int(Rnd() * 15) + 60
                If BINGO(i, j).Text = 0 Then
                    Randomize()
                    BINGO(i, j).Text = Int(Rnd() * 15) + 60
                End If
            Next
        Next
        For a = 0 To Column
            For b = 0 To 0
                Randomize()
                BINGO2(a, b).Text = Int(Rnd() * 15) + 1
                If BINGO2(a, b).Text = 16 Then
                    Randomize()
                    BINGO2(a, b).Text = Int(Rnd() * 15) + 1
                End If
            Next
        Next
        For c = 0 To Column
            For d = 1 To 1
                Randomize()
                BINGO2(c, d).Text = Int(Rnd() * 15) + 15
                If BINGO2(c, d).Text = 0 Then
                    Randomize()
                    BINGO2(c, d).Text = Int(Rnd() * 15) + 15
                End If
            Next
        Next
        For e = 0 To Column
            For f = 2 To 2
                Randomize()
                BINGO2(e, f).Text = Int(Rnd() * 15) + 30
                If BINGO2(e, f).Text = 0 Then
                    Randomize()
                    BINGO2(e, f).Text = Int(Rnd() * 15) + 30
                End If
                BINGO2(2, 2).Text = "Free Space"
                BINGO2(2, 2).BackColor = Color.Gray
            Next
        Next
        For g = 0 To Column
            For h = 3 To 3
                Randomize()
                BINGO2(g, h).Text = Int(Rnd() * 15) + 45
                If BINGO2(g, h).Text = 0 Then
                    Randomize()
                    BINGO2(g, h).Text = Int(Rnd() * 15) + 45
                End If
            Next
        Next
        For i = 0 To Column
            For j = 4 To 4
                Randomize()
                BINGO2(i, j).Text = Int(Rnd() * 15) + 60
                If BINGO2(i, j).Text = 0 Then
                    Randomize()
                    BINGO2(i, j).Text = Int(Rnd() * 15) + 60
                End If
            Next
        Next
    End Sub
    Private Sub No_Duplicate_Numbers()
        For j = 0 To BINGO(0, 0).Tag - 1
            If BINGO(0, j).Text = BINGO(0, 0).Text Then
                MsgBox("Test")
                Randomize()
                BINGO(0, j).Text = Int(Rnd() * 15)
            End If
        Next
    End Sub
    Private Sub Cheat_Prevention(sender As Object, e As EventArgs)
        If sender.text = "Free Space" Then
            MsgBox("Free Space")
        ElseIf sender.Text = Called_Number Then
            sender.backcolor = Color.Gray
        End If
    End Sub
    Private Sub Check_For_Win()
        For j = 0 To 4
            If BINGO(0, j).BackColor = Color.Gray And BINGO(1, j).BackColor = Color.Gray And BINGO(2, j).BackColor = Color.Gray And BINGO(3, j).BackColor = Color.Gray And BINGO(4, j).BackColor = Color.Gray Then
                MsgBox("Bingo!")
                Exit For
            End If
            If BINGO(j, 0).BackColor = Color.Gray And BINGO(j, 1).BackColor = Color.Gray And BINGO(j, 2).BackColor = Color.Gray And BINGO(j, 3).BackColor = Color.Gray And BINGO(j, 4).BackColor = Color.Gray Then
                MsgBox("Bingo!")
                Exit For
            End If
            If BINGO2(0, j).BackColor = Color.Gray And BINGO2(1, j).BackColor = Color.Gray And BINGO2(2, j).BackColor = Color.Gray And BINGO2(3, j).BackColor = Color.Gray And BINGO2(4, j).BackColor = Color.Gray Then
                MsgBox("Bingo!")
                Exit For
            End If
            If BINGO2(j, 0).BackColor = Color.Gray And BINGO2(j, 1).BackColor = Color.Gray And BINGO2(j, 2).BackColor = Color.Gray And BINGO2(j, 3).BackColor = Color.Gray And BINGO2(j, 4).BackColor = Color.Gray Then
                MsgBox("Bingo!")
                Exit For
            End If
            If BINGO(0, 0).BackColor = Color.Gray And BINGO(1, 1).BackColor = Color.Gray And BINGO(2, 2).BackColor = Color.Gray And BINGO(3, 3).BackColor = Color.Gray And BINGO(4, 4).BackColor = Color.Gray Then
                MsgBox("Bingo!")
                Exit For
            End If
            If BINGO(4, 0).BackColor = Color.Gray And BINGO(3, 1).BackColor = Color.Gray And BINGO(2, 2).BackColor = Color.Gray And BINGO(1, 3).BackColor = Color.Gray And BINGO(0, 4).BackColor = Color.Gray Then
                MsgBox("Bingo!")
                Exit For
            End If
            If BINGO2(0, 0).BackColor = Color.Gray And BINGO2(1, 1).BackColor = Color.Gray And BINGO2(2, 2).BackColor = Color.Gray And BINGO2(3, 3).BackColor = Color.Gray And BINGO2(4, 4).BackColor = Color.Gray Then
                MsgBox("Bingo!")
                Exit For
            End If
            If BINGO2(4, 0).BackColor = Color.Gray And BINGO2(3, 1).BackColor = Color.Gray And BINGO2(2, 2).BackColor = Color.Gray And BINGO2(1, 3).BackColor = Color.Gray And BINGO2(0, 4).BackColor = Color.Gray Then
                MsgBox("Bingo!")
                Exit For
            End If
        Next
    End Sub
    Private Sub CallNumbers_Click(sender As Object, e As EventArgs) Handles CallNumbers.Click
        Randomize()
        Called_Number = Int(Rnd() * 75)
        If Called_Number = 0 Then
            Randomize()
            Called_Number = Int(Rnd() * 75)
        End If
        Called_Label.Text = Called_Number & "  Was Called."
    End Sub
End Class