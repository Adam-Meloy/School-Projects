﻿Public Class Form1
    Dim Block(6), Course(6), Teacher(6), Required(6) As String
    Dim Timer As Integer = 0
    Dim RemainingClasses As Integer = 6
    Private Sub CourseAdd_Click(sender As Object, e As EventArgs) Handles CourseAdd.Click
        For Timer = 0 To 6
            Block(Timer) = InputBox("Enter Block Number")
            Course(Timer) = InputBox("Enter Course Name")
            Teacher(Timer) = InputBox("Enter Teacher Name")
            Required(Timer) = InputBox("Is This Course Required To Graduate?")
            CourseDisplay.Items.Add(Block(Timer) & vbTab & Course(Timer) & vbTab & Teacher(Timer) & vbTab & Required(Timer))
            MsgBox("You Have Added " & Timer + 1 & " Class(es). You Have " & RemainingClasses - Timer & " Class(es) Left To Enter.")
        Next
    End Sub
End Class