﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.CourseAdd = New System.Windows.Forms.Button()
        Me.CourseDisplay = New System.Windows.Forms.ListBox()
        Me.SuspendLayout()
        '
        'CourseAdd
        '
        Me.CourseAdd.Location = New System.Drawing.Point(12, 113)
        Me.CourseAdd.Name = "CourseAdd"
        Me.CourseAdd.Size = New System.Drawing.Size(276, 75)
        Me.CourseAdd.TabIndex = 0
        Me.CourseAdd.Text = "Add Courses"
        Me.CourseAdd.UseVisualStyleBackColor = True
        '
        'CourseDisplay
        '
        Me.CourseDisplay.FormattingEnabled = True
        Me.CourseDisplay.Location = New System.Drawing.Point(12, 12)
        Me.CourseDisplay.Name = "CourseDisplay"
        Me.CourseDisplay.Size = New System.Drawing.Size(276, 95)
        Me.CourseDisplay.TabIndex = 1
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(300, 224)
        Me.Controls.Add(Me.CourseDisplay)
        Me.Controls.Add(Me.CourseAdd)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents CourseAdd As Button
    Friend WithEvents CourseDisplay As ListBox
End Class
