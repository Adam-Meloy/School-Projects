﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class English_Chinese
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ECT = New System.Windows.Forms.ListBox()
        Me.ECT_LBL = New System.Windows.Forms.Label()
        Me.BTNBK = New System.Windows.Forms.Button()
        Me.ECT_CB = New System.Windows.Forms.ComboBox()
        Me.ECT_LBL2 = New System.Windows.Forms.Label()
        Me.___ = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'ECT
        '
        Me.ECT.FormattingEnabled = True
        Me.ECT.Location = New System.Drawing.Point(19, 155)
        Me.ECT.Name = "ECT"
        Me.ECT.Size = New System.Drawing.Size(120, 134)
        Me.ECT.TabIndex = 0
        '
        'ECT_LBL
        '
        Me.ECT_LBL.AutoSize = True
        Me.ECT_LBL.Font = New System.Drawing.Font("Modern No. 20", 27.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ECT_LBL.Location = New System.Drawing.Point(12, 70)
        Me.ECT_LBL.Name = "ECT_LBL"
        Me.ECT_LBL.Size = New System.Drawing.Size(145, 38)
        Me.ECT_LBL.TabIndex = 1
        Me.ECT_LBL.Text = "Category"
        '
        'BTNBK
        '
        Me.BTNBK.BackColor = System.Drawing.SystemColors.Control
        Me.BTNBK.Location = New System.Drawing.Point(194, 347)
        Me.BTNBK.Name = "BTNBK"
        Me.BTNBK.Size = New System.Drawing.Size(121, 102)
        Me.BTNBK.TabIndex = 2
        Me.BTNBK.Text = "Exit"
        Me.BTNBK.UseCompatibleTextRendering = True
        Me.BTNBK.UseVisualStyleBackColor = False
        '
        'ECT_CB
        '
        Me.ECT_CB.FormattingEnabled = True
        Me.ECT_CB.Items.AddRange(New Object() {"Greetings", "Family Members", "Numbers"})
        Me.ECT_CB.Location = New System.Drawing.Point(19, 111)
        Me.ECT_CB.Name = "ECT_CB"
        Me.ECT_CB.Size = New System.Drawing.Size(121, 21)
        Me.ECT_CB.TabIndex = 3
        '
        'ECT_LBL2
        '
        Me.ECT_LBL2.AutoSize = True
        Me.ECT_LBL2.Font = New System.Drawing.Font("Microsoft Sans Serif", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ECT_LBL2.Location = New System.Drawing.Point(145, 155)
        Me.ECT_LBL2.Name = "ECT_LBL2"
        Me.ECT_LBL2.Size = New System.Drawing.Size(216, 55)
        Me.ECT_LBL2.TabIndex = 7
        Me.ECT_LBL2.Text = "XXXXXX"
        '
        '___
        '
        Me.___.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.___.Location = New System.Drawing.Point(462, 13)
        Me.___.Name = "___"
        Me.___.Size = New System.Drawing.Size(10, 10)
        Me.___.TabIndex = 8
        Me.___.TabStop = False
        Me.___.Text = "_"
        Me.___.UseVisualStyleBackColor = True
        Me.___.Visible = False
        '
        'English_Chinese
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(484, 461)
        Me.Controls.Add(Me.___)
        Me.Controls.Add(Me.ECT_LBL2)
        Me.Controls.Add(Me.ECT_CB)
        Me.Controls.Add(Me.BTNBK)
        Me.Controls.Add(Me.ECT_LBL)
        Me.Controls.Add(Me.ECT)
        Me.Name = "English_Chinese"
        Me.Text = "English_Chinese"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents ECT As ListBox
    Friend WithEvents ECT_LBL As Label
    Friend WithEvents BTNBK As Button
    Friend WithEvents ECT_CB As ComboBox
    Friend WithEvents ECT_LBL2 As Label
    Friend WithEvents ___ As Button
End Class
