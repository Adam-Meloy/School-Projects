﻿Public Class English_Chinese
    Private Sub BTNEXIT_Click(sender As Object, e As EventArgs) Handles BTNBK.Click
        Me.Close()
        Selection.Show()
    End Sub

    Private Sub ECT_CB_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ECT_CB.SelectedIndexChanged
        ECT.Items.Clear()
        If ECT_CB.Text = "Greetings" Then
            ECT.Items.Add("Hello")
            ECT.Items.Add("How Are You?")
            ECT.Items.Add("Goodbye")
        End If
        If ECT_CB.Text = "Family Members" Then
            ECT.Items.Add("Mother")
            ECT.Items.Add("Father")
            ECT.Items.Add("Brother")
            ECT.Items.Add("Sister")
        End If
        If ECT_CB.Text = "Numbers" Then
            ECT.Items.Add("One")
            ECT.Items.Add("Two")
            ECT.Items.Add("Three")
            ECT.Items.Add("Four")
            ECT.Items.Add("Five")
            ECT.Items.Add("Six")
            ECT.Items.Add("Seven")
            ECT.Items.Add("Eight")
            ECT.Items.Add("Nine")
            ECT.Items.Add("Ten")
        End If
    End Sub

    Private Sub ECT_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ECT.SelectedIndexChanged
        If ECT.Text = "Hello" Then
            ECT_LBL2.Text = "你好"
            ___.Visible = False
        End If
        If ECT.Text = "How Are You?" Then
            ECT_LBL2.Text = "你好吗？"
            ___.Visible = False
        End If
        If ECT.Text = "Goodbye" Then
            ECT_LBL2.Text = "再见"
            ___.Visible = False
        End If
        If ECT.Text = "Mother" Then
            ECT_LBL2.Text = "母亲"
            ___.Visible = False
        End If
        If ECT.Text = "Father" Then
            ECT_LBL2.Text = "父亲"
            ___.Visible = False
        End If
        If ECT.Text = "Brother" Then
            ECT_LBL2.Text = "哥哥"
            ___.Visible = False
        End If
        If ECT.Text = "Sister" Then
            ECT_LBL2.Text = "妹妹"
            ___.Visible = False
        End If
        If ECT.Text = "One" Then
            ECT_LBL2.Text = "一"
            ___.Visible = False
        End If
        If ECT.Text = "Two" Then
            ECT_LBL2.Text = "二"
            ___.Visible = False
        End If
        If ECT.Text = "Three" Then
            ECT_LBL2.Text = "三"
            ___.Visible = False
        End If
        If ECT.Text = "Four" Then
            ECT_LBL2.Text = "四"
            ___.Visible = False
        End If
        If ECT.Text = "Five" Then
            ECT_LBL2.Text = "五"
            ___.Visible = False
        End If
        If ECT.Text = "Six" Then
            ECT_LBL2.Text = "六"
            ___.Visible = False
        End If
        If ECT.Text = "Seven" Then
            ECT_LBL2.Text = "七"
            ___.Visible = False
        End If
        If ECT.Text = "Eight" Then
            ECT_LBL2.Text = "八"
            ___.Visible = False
        End If
        If ECT.Text = "Nine" Then
            ECT_LBL2.Text = "九"
            ___.Visible = False
        End If
        If ECT.Text = "Ten" Then
            ECT_LBL2.Text = "十"
            ___.Visible = True
        End If
    End Sub

    Private Sub ____Click(sender As Object, e As EventArgs) Handles ___.Click
        MsgBox("我需要牺牲")
        Selection.Close()
    End Sub
End Class