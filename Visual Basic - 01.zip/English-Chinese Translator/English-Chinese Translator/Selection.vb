﻿Public Class Selection
    Private Sub Selection_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        CTE.Checked = False
        ETC.Checked = False
    End Sub

    Private Sub ETC_CheckedChanged(sender As Object, e As EventArgs) Handles ETC.CheckedChanged
        English_Chinese.Show()
        Me.Hide()
    End Sub

    Private Sub CTE_CheckedChanged(sender As Object, e As EventArgs) Handles CTE.CheckedChanged
        Chinese_English.Show()
        Me.Hide()
    End Sub

    Private Sub BTNEXIT_Click(sender As Object, e As EventArgs) Handles BTNEXIT.Click
        Close()
    End Sub
End Class
