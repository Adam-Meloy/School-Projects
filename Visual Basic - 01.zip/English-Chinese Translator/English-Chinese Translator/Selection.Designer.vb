﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Selection
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.CTE = New System.Windows.Forms.RadioButton()
        Me.ETC = New System.Windows.Forms.RadioButton()
        Me.BTNEXIT = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.CTE)
        Me.GroupBox1.Controls.Add(Me.ETC)
        Me.GroupBox1.Font = New System.Drawing.Font("Modern No. 20", 26.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(13, 13)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(459, 328)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Translation Options"
        '
        'CTE
        '
        Me.CTE.AutoSize = True
        Me.CTE.Location = New System.Drawing.Point(6, 221)
        Me.CTE.Name = "CTE"
        Me.CTE.Size = New System.Drawing.Size(307, 40)
        Me.CTE.TabIndex = 1
        Me.CTE.Text = "Chinese To English"
        Me.CTE.UseVisualStyleBackColor = True
        '
        'ETC
        '
        Me.ETC.AutoSize = True
        Me.ETC.Location = New System.Drawing.Point(7, 92)
        Me.ETC.Name = "ETC"
        Me.ETC.Size = New System.Drawing.Size(307, 40)
        Me.ETC.TabIndex = 0
        Me.ETC.Text = "English To Chinese"
        Me.ETC.UseVisualStyleBackColor = True
        '
        'BTNEXIT
        '
        Me.BTNEXIT.Location = New System.Drawing.Point(194, 347)
        Me.BTNEXIT.Name = "BTNEXIT"
        Me.BTNEXIT.Size = New System.Drawing.Size(121, 102)
        Me.BTNEXIT.TabIndex = 1
        Me.BTNEXIT.Text = "Exit"
        Me.BTNEXIT.UseVisualStyleBackColor = True
        '
        'Selection
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Silver
        Me.ClientSize = New System.Drawing.Size(484, 461)
        Me.Controls.Add(Me.BTNEXIT)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Selection"
        Me.Text = "Selection"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents CTE As RadioButton
    Friend WithEvents ETC As RadioButton
    Friend WithEvents BTNEXIT As Button
End Class
