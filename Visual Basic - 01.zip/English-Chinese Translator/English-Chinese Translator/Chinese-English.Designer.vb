﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Chinese_English
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.BTNBK = New System.Windows.Forms.Button()
        Me.CET_LBL = New System.Windows.Forms.Label()
        Me.CET = New System.Windows.Forms.ListBox()
        Me.CET_CB = New System.Windows.Forms.ComboBox()
        Me.CET_LBL2 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'BTNBK
        '
        Me.BTNBK.Location = New System.Drawing.Point(194, 347)
        Me.BTNBK.Name = "BTNBK"
        Me.BTNBK.Size = New System.Drawing.Size(121, 102)
        Me.BTNBK.TabIndex = 2
        Me.BTNBK.Text = "离开"
        Me.BTNBK.UseVisualStyleBackColor = True
        '
        'CET_LBL
        '
        Me.CET_LBL.AutoSize = True
        Me.CET_LBL.Font = New System.Drawing.Font("Modern No. 20", 27.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CET_LBL.Location = New System.Drawing.Point(47, 70)
        Me.CET_LBL.Name = "CET_LBL"
        Me.CET_LBL.Size = New System.Drawing.Size(65, 38)
        Me.CET_LBL.TabIndex = 3
        Me.CET_LBL.Text = "类别"
        '
        'CET
        '
        Me.CET.FormattingEnabled = True
        Me.CET.Location = New System.Drawing.Point(19, 155)
        Me.CET.Name = "CET"
        Me.CET.Size = New System.Drawing.Size(120, 134)
        Me.CET.TabIndex = 4
        '
        'CET_CB
        '
        Me.CET_CB.FormattingEnabled = True
        Me.CET_CB.Items.AddRange(New Object() {"问候", "家庭成员", "数字"})
        Me.CET_CB.Location = New System.Drawing.Point(19, 111)
        Me.CET_CB.Name = "CET_CB"
        Me.CET_CB.Size = New System.Drawing.Size(121, 21)
        Me.CET_CB.TabIndex = 5
        '
        'CET_LBL2
        '
        Me.CET_LBL2.AutoSize = True
        Me.CET_LBL2.Font = New System.Drawing.Font("Microsoft Sans Serif", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CET_LBL2.Location = New System.Drawing.Point(145, 155)
        Me.CET_LBL2.Name = "CET_LBL2"
        Me.CET_LBL2.Size = New System.Drawing.Size(216, 55)
        Me.CET_LBL2.TabIndex = 6
        Me.CET_LBL2.Text = "XXXXXX"
        '
        'Chinese_English
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(484, 461)
        Me.Controls.Add(Me.CET_LBL2)
        Me.Controls.Add(Me.CET_CB)
        Me.Controls.Add(Me.CET)
        Me.Controls.Add(Me.CET_LBL)
        Me.Controls.Add(Me.BTNBK)
        Me.Name = "Chinese_English"
        Me.Text = "Chinese_English"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents BTNBK As Button
    Friend WithEvents CET_LBL As Label
    Friend WithEvents CET As ListBox
    Friend WithEvents CET_CB As ComboBox
    Friend WithEvents CET_LBL2 As Label
End Class
