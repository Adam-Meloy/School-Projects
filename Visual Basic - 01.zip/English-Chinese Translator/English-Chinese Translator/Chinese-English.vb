﻿Public Class Chinese_English
    Private Sub BTNEXIT_Click(sender As Object, e As EventArgs) Handles BTNBK.Click
        Me.Close()
        Selection.Show()
    End Sub

    Private Sub CET_CB_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CET_CB.SelectedIndexChanged
        CET.Items.Clear()
        If CET_CB.Text = "问候" Then
            CET.Items.Add("你好")
            CET.Items.Add("你好吗？")
            CET.Items.Add("再见")
        End If
        If CET_CB.Text = "家庭成员" Then
            CET.Items.Add("母亲")
            CET.Items.Add("父亲")
            CET.Items.Add("哥哥")
            CET.Items.Add("妹妹")
        End If
        If CET_CB.Text = "数字" Then
            CET.Items.Add("一")
            CET.Items.Add("二")
            CET.Items.Add("三")
            CET.Items.Add("四")
            CET.Items.Add("五")
            CET.Items.Add("六")
            CET.Items.Add("七")
            CET.Items.Add("八")
            CET.Items.Add("九")
            CET.Items.Add("十")
        End If
    End Sub

    Private Sub CET_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CET.SelectedIndexChanged
        If CET.Text = "你好" Then
            CET_LBL2.Text = "Hello"
        End If
        If CET.Text = "你好吗？" Then
            CET_LBL2.Text = "How Are You?"
        End If
        If CET.Text = "再见" Then
            CET_LBL2.Text = "Goodbye"
        End If
        If CET.Text = "母亲" Then
            CET_LBL2.Text = "Mother"
        End If
        If CET.Text = "父亲" Then
            CET_LBL2.Text = "Father"
        End If
        If CET.Text = "哥哥" Then
            CET_LBL2.Text = "Brother"
        End If
        If CET.Text = "妹妹" Then
            CET_LBL2.Text = "Sister"
        End If
        If CET.Text = "一" Then
            CET_LBL2.Text = "One"
        End If
        If CET.Text = "二" Then
            CET_LBL2.Text = "Two"
        End If
        If CET.Text = "三" Then
            CET_LBL2.Text = "Three"
        End If
        If CET.Text = "四" Then
            CET_LBL2.Text = "Four"
        End If
        If CET.Text = "五" Then
            CET_LBL2.Text = "Five"
        End If
        If CET.Text = "六" Then
            CET_LBL2.Text = "Six"
        End If
        If CET.Text = "七" Then
            CET_LBL2.Text = "Seven"
        End If
        If CET.Text = "八" Then
            CET_LBL2.Text = "Eight"
        End If
        If CET.Text = "九" Then
            CET_LBL2.Text = "Nine"
        End If
        If CET.Text = "十" Then
            CET_LBL2.Text = "Ten"
        End If
    End Sub
End Class