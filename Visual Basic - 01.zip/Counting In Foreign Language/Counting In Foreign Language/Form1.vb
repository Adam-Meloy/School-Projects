﻿Public Class language
    Private Sub BTN1_Click(sender As Object, e As EventArgs) Handles BTN1.Click
        MsgBox("                             一")
        BTN1.Enabled = False
    End Sub

    Private Sub BTN2_Click(sender As Object, e As EventArgs) Handles BTN2.Click
        MsgBox("                             二")
        BTN2.Enabled = False
    End Sub

    Private Sub BTN3_Click(sender As Object, e As EventArgs) Handles BTN3.Click
        MsgBox("                             三")
        BTN3.Enabled = False
    End Sub

    Private Sub BTN4_Click(sender As Object, e As EventArgs) Handles BTN4.Click
        MsgBox("                             四")
        BTN4.Enabled = False
    End Sub

    Private Sub BTN5_Click(sender As Object, e As EventArgs) Handles BTN5.Click
        MsgBox("                             五")
        BTN5.Enabled = False
    End Sub

    Private Sub BTNEXIT_Click(sender As Object, e As EventArgs) Handles BTNEXIT.Click
        MsgBox("                           出口")
        Close()
    End Sub

    Private Sub BTNCLR_Click(sender As Object, e As EventArgs) Handles BTNCLR.Click
        MsgBox("                     澄んでいる")
        BTN1.Enabled = True
        BTN2.Enabled = True
        BTN3.Enabled = True
        BTN4.Enabled = True
        BTN5.Enabled = True
    End Sub
End Class
