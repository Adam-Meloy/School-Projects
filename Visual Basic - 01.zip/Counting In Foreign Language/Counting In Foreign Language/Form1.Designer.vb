﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class language
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.BTNEXIT = New System.Windows.Forms.Button()
        Me.BTN5 = New System.Windows.Forms.Button()
        Me.BTN4 = New System.Windows.Forms.Button()
        Me.BTN3 = New System.Windows.Forms.Button()
        Me.BTN2 = New System.Windows.Forms.Button()
        Me.BTN1 = New System.Windows.Forms.Button()
        Me.Words = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.BTNCLR = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'BTNEXIT
        '
        Me.BTNEXIT.Location = New System.Drawing.Point(308, 377)
        Me.BTNEXIT.Name = "BTNEXIT"
        Me.BTNEXIT.Size = New System.Drawing.Size(75, 67)
        Me.BTNEXIT.TabIndex = 6
        Me.BTNEXIT.Text = "Exit"
        Me.BTNEXIT.UseVisualStyleBackColor = True
        '
        'BTN5
        '
        Me.BTN5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.BTN5.Location = New System.Drawing.Point(404, 214)
        Me.BTN5.Name = "BTN5"
        Me.BTN5.Size = New System.Drawing.Size(75, 67)
        Me.BTN5.TabIndex = 7
        Me.BTN5.Text = "5"
        Me.BTN5.UseVisualStyleBackColor = True
        '
        'BTN4
        '
        Me.BTN4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.BTN4.Location = New System.Drawing.Point(308, 214)
        Me.BTN4.Name = "BTN4"
        Me.BTN4.Size = New System.Drawing.Size(75, 67)
        Me.BTN4.TabIndex = 8
        Me.BTN4.Text = "4"
        Me.BTN4.UseVisualStyleBackColor = True
        '
        'BTN3
        '
        Me.BTN3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.BTN3.Location = New System.Drawing.Point(206, 214)
        Me.BTN3.Name = "BTN3"
        Me.BTN3.Size = New System.Drawing.Size(75, 67)
        Me.BTN3.TabIndex = 9
        Me.BTN3.Text = "3"
        Me.BTN3.UseVisualStyleBackColor = True
        '
        'BTN2
        '
        Me.BTN2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.BTN2.Location = New System.Drawing.Point(112, 214)
        Me.BTN2.Name = "BTN2"
        Me.BTN2.Size = New System.Drawing.Size(75, 67)
        Me.BTN2.TabIndex = 10
        Me.BTN2.Text = "2"
        Me.BTN2.UseVisualStyleBackColor = True
        '
        'BTN1
        '
        Me.BTN1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.BTN1.Location = New System.Drawing.Point(12, 214)
        Me.BTN1.Name = "BTN1"
        Me.BTN1.Size = New System.Drawing.Size(75, 67)
        Me.BTN1.TabIndex = 11
        Me.BTN1.Text = "1"
        Me.BTN1.UseVisualStyleBackColor = True
        '
        'Words
        '
        Me.Words.AutoSize = True
        Me.Words.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!)
        Me.Words.Location = New System.Drawing.Point(54, 77)
        Me.Words.Name = "Words"
        Me.Words.Size = New System.Drawing.Size(414, 24)
        Me.Words.TabIndex = 12
        Me.Words.Text = "Do you know the Japanese numerals from 1 - 5?"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!)
        Me.Label1.Location = New System.Drawing.Point(133, 101)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(250, 24)
        Me.Label1.TabIndex = 13
        Me.Label1.Text = "Click the buttons to see them"
        '
        'BTNCLR
        '
        Me.BTNCLR.Location = New System.Drawing.Point(112, 377)
        Me.BTNCLR.Name = "BTNCLR"
        Me.BTNCLR.Size = New System.Drawing.Size(75, 67)
        Me.BTNCLR.TabIndex = 14
        Me.BTNCLR.Text = "Clear"
        Me.BTNCLR.UseVisualStyleBackColor = True
        '
        'language
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(491, 456)
        Me.Controls.Add(Me.BTNCLR)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Words)
        Me.Controls.Add(Me.BTN1)
        Me.Controls.Add(Me.BTN2)
        Me.Controls.Add(Me.BTN3)
        Me.Controls.Add(Me.BTN4)
        Me.Controls.Add(Me.BTN5)
        Me.Controls.Add(Me.BTNEXIT)
        Me.Name = "language"
        Me.Text = "1 - 5 In Japanese"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents BTNEXIT As Button
    Friend WithEvents BTN5 As Button
    Friend WithEvents BTN4 As Button
    Friend WithEvents BTN3 As Button
    Friend WithEvents BTN2 As Button
    Friend WithEvents BTN1 As Button
    Friend WithEvents Words As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents BTNCLR As Button
End Class
