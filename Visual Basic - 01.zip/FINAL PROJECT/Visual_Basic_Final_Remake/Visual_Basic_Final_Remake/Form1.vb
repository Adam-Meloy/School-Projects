﻿Public Class Form1
    Dim Battlefield(,), label As Label
    Dim X, Y, Count, PRow, PColumn, Selected, Selected2, eNEMY(,) As Integer
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        X = 50
        Y = 50
        Call Generate_BattleField()
        Call Place_Troops()
        MsgBox("Click On The Buttons To Perform An Action With Your Units. Just Remember, There Are No True Winners In War.")
        MsgBox("The Order To Move Units Is Left & Right First, Up & Down Second.")
    End Sub
    Private Sub Generate_BattleField()
        Dim row As Integer = 9
        Dim column As Integer = 12
        ReDim Battlefield(row, column)
        For i = 0 To row
            For j = 0 To column
                Count += 1
                label = New Label
                With label
                    .Name = j
                    .Tag = Count
                    .Width = 50
                    .Height = 50
                    .Left = X
                    .Top = Y
                    .BorderStyle = BorderStyle.FixedSingle
                    .BackColor = Color.Green
                End With
                If label.Name = 12 Then
                    Y += 50
                    X = 50
                Else
                    X += 50
                End If
                Battlefield(i, j) = label
                Me.Controls.Add(label)
            Next
        Next
    End Sub
    Private Sub Place_Troops()
        For X = 0 To 7
            Selected = InputBox("Input A Second Number To Put Soldier " & X + 1 & " At. Must Be 1-5") - 1
            If Selected > 5 Then
                Selected2 = InputBox("I Mean It, The Number MUST Be 1-5") - 1
            End If
            Selected2 = InputBox("Input A Number To Put Soldier " & X + 1 & " At. Must Be 1-10") - 1
            If Selected2 > 10 Then
                Selected = InputBox("I Mean It, The Number MUST Be 1-10") - 1
            End If
            Battlefield(Selected2, Selected).BackColor = Color.FromArgb(255, 0, 255, 255)
            Battlefield(Selected2, Selected).Text = "Soldier " & X + 1
        Next
        For Y = 0 To 7
            Randomize()
            Selected = Int(Rnd() * 8) + 8
            If Selected = 16 Then
                Randomize()
                Selected -= Int(Rnd() * 4) + 3
            ElseIf Selected = 15 Then
                Randomize()
                Selected -= Int(Rnd() * 3) + 3
            ElseIf Selected = 14 Then
                Randomize()
                Selected -= Int(Rnd() * 2) + 3
            ElseIf Selected = 13 Then
                Randomize()
                Selected -= Int(Rnd() * 2) + 3
            End If
            Randomize()
            Selected2 = Int(Rnd() * 9)
            Battlefield(Selected2, Selected).BackColor = Color.FromArgb(255, 255, 0, 0)
            Battlefield(Selected2, Selected).Text = "Soldier " & Y + 1

            Selected = 0
            Selected2 = 0
        Next
    End Sub
    Private Sub Pass_Turn_Click(sender As Object, e As EventArgs) Handles Pass_Turn.Click
        Call Pass()
    End Sub
    Private Sub Move_Up_Click(sender As Object, e As EventArgs) Handles Move_Up.Click
        Selected = InputBox("Enter The Row Of The Soldier You Want To Move") - 1
        Selected2 = InputBox("Enter The Column Of The Soldier You Want To Move") - 1
        If Battlefield(Selected, Selected2).BackColor = Color.FromArgb(255, 0, 255, 255) Then
            Battlefield(Selected - 1, Selected2).Text = Battlefield(Selected, Selected2).Text
            Battlefield(Selected - 1, Selected2).BackColor = Color.FromArgb(255, 0, 255, 255)
            Battlefield(Selected, Selected2).Text = ""
            Battlefield(Selected, Selected2).BackColor = Color.Green
            Call Pass()
        Else
            MsgBox("Invalid Move")
        End If
    End Sub
    Private Sub Move_Left_Click(sender As Object, e As EventArgs) Handles Move_Left.Click
        Selected = InputBox("Enter The Column Of The Soldier You Want To Move") - 1
        Selected2 = InputBox("Enter The Row Of The Soldier You Want To Move") - 1
        If Battlefield(Selected, Selected2).BackColor = Color.FromArgb(255, 0, 255, 255) Then
            Battlefield(Selected, Selected2 - 1).Text = Battlefield(Selected, Selected2).Text
            Battlefield(Selected, Selected2 - 1).BackColor = Color.FromArgb(255, 0, 255, 255)
            Battlefield(Selected, Selected2).Text = ""
            Battlefield(Selected, Selected2).BackColor = Color.Green
            Call Pass()
        Else
            MsgBox("Invalid Move")
        End If
    End Sub
    Private Sub Move_Down_Click(sender As Object, e As EventArgs) Handles Move_Down.Click
        Selected = InputBox("Enter The Column Of The Soldier You Want To Move") - 1
        Selected2 = InputBox("Enter The Row Of The Soldier You Want To Move") - 1
        If Battlefield(Selected, Selected2).BackColor = Color.FromArgb(255, 0, 255, 255) Then
            Battlefield(Selected + 1, Selected2).Text = Battlefield(Selected, Selected2).Text
            Battlefield(Selected + 1, Selected2).BackColor = Color.FromArgb(255, 0, 255, 255)
            Battlefield(Selected, Selected2).Text = ""
            Battlefield(Selected, Selected2).BackColor = Color.Green
            Call Pass()
        Else
            MsgBox("Invalid Move")
        End If
    End Sub
    Private Sub Move_Right_Click(sender As Object, e As EventArgs) Handles Move_Right.Click
        Selected = InputBox("Enter The Column Of The Soldier You Want To Move") - 1
        Selected2 = InputBox("Enter The Row Of The Soldier You Want To Move") - 1
        If Battlefield(Selected, Selected2).BackColor = Color.FromArgb(255, 0, 255, 255) Then
            Battlefield(Selected, Selected2 + 1).Text = Battlefield(Selected, Selected2).Text
            Battlefield(Selected, Selected2 + 1).BackColor = Color.FromArgb(255, 0, 255, 255)
            Battlefield(Selected, Selected2).Text = ""
            Battlefield(Selected, Selected2).BackColor = Color.Green
            Call Pass()
        Else
            MsgBox("Invalid Move")
        End If
    End Sub
    Private Sub Pass()
        MsgBox("Enemy's Turn")
        Randomize()
        Selected = Int(Rnd() * 9)
        Randomize()
        Selected2 = Int(Rnd() * 12)
        If Battlefield(Selected, Selected2).BackColor = Color.Red Then
            Battlefield(Selected, Selected2 - 1).Text = Battlefield(Selected, Selected2).Text
            Battlefield(Selected, Selected2 - 1).BackColor = Color.Red
            Battlefield(Selected, Selected2).Text = ""
            Battlefield(Selected, Selected2).BackColor = Color.Green
            Battlefield(Selected, Selected2 + 1).BackColor = Color.Green
        End If
        MsgBox("Your Turn")
    End Sub
End Class