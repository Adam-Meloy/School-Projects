﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Move_Down = New System.Windows.Forms.Button()
        Me.Move_Left = New System.Windows.Forms.Button()
        Me.Move_Up = New System.Windows.Forms.Button()
        Me.Move_Right = New System.Windows.Forms.Button()
        Me.Pass_Turn = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ZeroPoint = New System.Windows.Forms.Label()
        Me.OneV = New System.Windows.Forms.Label()
        Me.TwoV = New System.Windows.Forms.Label()
        Me.ThreeV = New System.Windows.Forms.Label()
        Me.FourV = New System.Windows.Forms.Label()
        Me.FiveV = New System.Windows.Forms.Label()
        Me.SixV = New System.Windows.Forms.Label()
        Me.SevenV = New System.Windows.Forms.Label()
        Me.EightV = New System.Windows.Forms.Label()
        Me.NineV = New System.Windows.Forms.Label()
        Me.TenV = New System.Windows.Forms.Label()
        Me.TenH = New System.Windows.Forms.Label()
        Me.OneH = New System.Windows.Forms.Label()
        Me.TwoH = New System.Windows.Forms.Label()
        Me.ThreeH = New System.Windows.Forms.Label()
        Me.FourH = New System.Windows.Forms.Label()
        Me.FiveH = New System.Windows.Forms.Label()
        Me.SixH = New System.Windows.Forms.Label()
        Me.SevenH = New System.Windows.Forms.Label()
        Me.EightH = New System.Windows.Forms.Label()
        Me.NineH = New System.Windows.Forms.Label()
        Me.TwelveH = New System.Windows.Forms.Label()
        Me.ElevenH = New System.Windows.Forms.Label()
        Me.ThirteenH = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Move_Down
        '
        Me.Move_Down.BackgroundImage = Global.Visual_Basic_Final_Remake.My.Resources.Resources.Down
        Me.Move_Down.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Move_Down.Location = New System.Drawing.Point(796, 569)
        Me.Move_Down.Name = "Move_Down"
        Me.Move_Down.Size = New System.Drawing.Size(60, 60)
        Me.Move_Down.TabIndex = 5
        Me.Move_Down.UseVisualStyleBackColor = True
        '
        'Move_Left
        '
        Me.Move_Left.BackgroundImage = Global.Visual_Basic_Final_Remake.My.Resources.Resources.Left
        Me.Move_Left.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Move_Left.Location = New System.Drawing.Point(730, 503)
        Me.Move_Left.Name = "Move_Left"
        Me.Move_Left.Size = New System.Drawing.Size(60, 60)
        Me.Move_Left.TabIndex = 4
        Me.Move_Left.UseVisualStyleBackColor = True
        '
        'Move_Up
        '
        Me.Move_Up.BackgroundImage = Global.Visual_Basic_Final_Remake.My.Resources.Resources.Up
        Me.Move_Up.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Move_Up.Location = New System.Drawing.Point(796, 437)
        Me.Move_Up.Name = "Move_Up"
        Me.Move_Up.Size = New System.Drawing.Size(60, 60)
        Me.Move_Up.TabIndex = 3
        Me.Move_Up.UseVisualStyleBackColor = True
        '
        'Move_Right
        '
        Me.Move_Right.BackgroundImage = Global.Visual_Basic_Final_Remake.My.Resources.Resources.Right
        Me.Move_Right.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Move_Right.Location = New System.Drawing.Point(862, 503)
        Me.Move_Right.Name = "Move_Right"
        Me.Move_Right.Size = New System.Drawing.Size(60, 60)
        Me.Move_Right.TabIndex = 1
        Me.Move_Right.UseVisualStyleBackColor = True
        '
        'Pass_Turn
        '
        Me.Pass_Turn.BackgroundImage = Global.Visual_Basic_Final_Remake.My.Resources.Resources.Shield
        Me.Pass_Turn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Pass_Turn.Location = New System.Drawing.Point(796, 503)
        Me.Pass_Turn.Name = "Pass_Turn"
        Me.Pass_Turn.Size = New System.Drawing.Size(60, 60)
        Me.Pass_Turn.TabIndex = 0
        Me.Pass_Turn.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(768, 359)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(111, 64)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "Player's Turn"
        '
        'ZeroPoint
        '
        Me.ZeroPoint.BackColor = System.Drawing.Color.Transparent
        Me.ZeroPoint.Font = New System.Drawing.Font("Microsoft Sans Serif", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ZeroPoint.ForeColor = System.Drawing.Color.White
        Me.ZeroPoint.Location = New System.Drawing.Point(0, 0)
        Me.ZeroPoint.Name = "ZeroPoint"
        Me.ZeroPoint.Size = New System.Drawing.Size(50, 50)
        Me.ZeroPoint.TabIndex = 7
        Me.ZeroPoint.Text = " 0"
        '
        'OneV
        '
        Me.OneV.BackColor = System.Drawing.Color.Transparent
        Me.OneV.Font = New System.Drawing.Font("Microsoft Sans Serif", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.OneV.ForeColor = System.Drawing.Color.White
        Me.OneV.Location = New System.Drawing.Point(0, 50)
        Me.OneV.Name = "OneV"
        Me.OneV.Size = New System.Drawing.Size(50, 50)
        Me.OneV.TabIndex = 8
        Me.OneV.Text = " 1"
        '
        'TwoV
        '
        Me.TwoV.BackColor = System.Drawing.Color.Transparent
        Me.TwoV.Font = New System.Drawing.Font("Microsoft Sans Serif", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TwoV.ForeColor = System.Drawing.Color.White
        Me.TwoV.Location = New System.Drawing.Point(0, 100)
        Me.TwoV.Name = "TwoV"
        Me.TwoV.Size = New System.Drawing.Size(50, 50)
        Me.TwoV.TabIndex = 9
        Me.TwoV.Text = " 2"
        '
        'ThreeV
        '
        Me.ThreeV.BackColor = System.Drawing.Color.Transparent
        Me.ThreeV.Font = New System.Drawing.Font("Microsoft Sans Serif", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ThreeV.ForeColor = System.Drawing.Color.White
        Me.ThreeV.Location = New System.Drawing.Point(0, 150)
        Me.ThreeV.Name = "ThreeV"
        Me.ThreeV.Size = New System.Drawing.Size(50, 50)
        Me.ThreeV.TabIndex = 10
        Me.ThreeV.Text = " 3"
        '
        'FourV
        '
        Me.FourV.BackColor = System.Drawing.Color.Transparent
        Me.FourV.Font = New System.Drawing.Font("Microsoft Sans Serif", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FourV.ForeColor = System.Drawing.Color.White
        Me.FourV.Location = New System.Drawing.Point(0, 200)
        Me.FourV.Name = "FourV"
        Me.FourV.Size = New System.Drawing.Size(50, 50)
        Me.FourV.TabIndex = 11
        Me.FourV.Text = " 4"
        '
        'FiveV
        '
        Me.FiveV.BackColor = System.Drawing.Color.Transparent
        Me.FiveV.Font = New System.Drawing.Font("Microsoft Sans Serif", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FiveV.ForeColor = System.Drawing.Color.White
        Me.FiveV.Location = New System.Drawing.Point(0, 250)
        Me.FiveV.Name = "FiveV"
        Me.FiveV.Size = New System.Drawing.Size(50, 50)
        Me.FiveV.TabIndex = 12
        Me.FiveV.Text = " 5"
        '
        'SixV
        '
        Me.SixV.BackColor = System.Drawing.Color.Transparent
        Me.SixV.Font = New System.Drawing.Font("Microsoft Sans Serif", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SixV.ForeColor = System.Drawing.Color.White
        Me.SixV.Location = New System.Drawing.Point(0, 300)
        Me.SixV.Name = "SixV"
        Me.SixV.Size = New System.Drawing.Size(50, 50)
        Me.SixV.TabIndex = 13
        Me.SixV.Text = " 6"
        '
        'SevenV
        '
        Me.SevenV.BackColor = System.Drawing.Color.Transparent
        Me.SevenV.Font = New System.Drawing.Font("Microsoft Sans Serif", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SevenV.ForeColor = System.Drawing.Color.White
        Me.SevenV.Location = New System.Drawing.Point(0, 350)
        Me.SevenV.Name = "SevenV"
        Me.SevenV.Size = New System.Drawing.Size(50, 50)
        Me.SevenV.TabIndex = 14
        Me.SevenV.Text = " 7"
        '
        'EightV
        '
        Me.EightV.BackColor = System.Drawing.Color.Transparent
        Me.EightV.Font = New System.Drawing.Font("Microsoft Sans Serif", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EightV.ForeColor = System.Drawing.Color.White
        Me.EightV.Location = New System.Drawing.Point(0, 400)
        Me.EightV.Name = "EightV"
        Me.EightV.Size = New System.Drawing.Size(50, 50)
        Me.EightV.TabIndex = 15
        Me.EightV.Text = " 8"
        '
        'NineV
        '
        Me.NineV.BackColor = System.Drawing.Color.Transparent
        Me.NineV.Font = New System.Drawing.Font("Microsoft Sans Serif", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NineV.ForeColor = System.Drawing.Color.White
        Me.NineV.Location = New System.Drawing.Point(0, 450)
        Me.NineV.Name = "NineV"
        Me.NineV.Size = New System.Drawing.Size(50, 50)
        Me.NineV.TabIndex = 16
        Me.NineV.Text = " 9"
        '
        'TenV
        '
        Me.TenV.BackColor = System.Drawing.Color.Transparent
        Me.TenV.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TenV.ForeColor = System.Drawing.Color.White
        Me.TenV.Location = New System.Drawing.Point(0, 500)
        Me.TenV.Name = "TenV"
        Me.TenV.Size = New System.Drawing.Size(50, 50)
        Me.TenV.TabIndex = 17
        Me.TenV.Text = "10"
        '
        'TenH
        '
        Me.TenH.BackColor = System.Drawing.Color.Transparent
        Me.TenH.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TenH.ForeColor = System.Drawing.Color.White
        Me.TenH.Location = New System.Drawing.Point(500, 0)
        Me.TenH.Name = "TenH"
        Me.TenH.Size = New System.Drawing.Size(50, 50)
        Me.TenH.TabIndex = 20
        Me.TenH.Text = "10"
        '
        'OneH
        '
        Me.OneH.BackColor = System.Drawing.Color.Transparent
        Me.OneH.Font = New System.Drawing.Font("Microsoft Sans Serif", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.OneH.ForeColor = System.Drawing.Color.White
        Me.OneH.Location = New System.Drawing.Point(50, 0)
        Me.OneH.Name = "OneH"
        Me.OneH.Size = New System.Drawing.Size(50, 50)
        Me.OneH.TabIndex = 21
        Me.OneH.Text = " 1"
        '
        'TwoH
        '
        Me.TwoH.BackColor = System.Drawing.Color.Transparent
        Me.TwoH.Font = New System.Drawing.Font("Microsoft Sans Serif", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TwoH.ForeColor = System.Drawing.Color.White
        Me.TwoH.Location = New System.Drawing.Point(100, 0)
        Me.TwoH.Name = "TwoH"
        Me.TwoH.Size = New System.Drawing.Size(50, 50)
        Me.TwoH.TabIndex = 22
        Me.TwoH.Text = " 2"
        '
        'ThreeH
        '
        Me.ThreeH.BackColor = System.Drawing.Color.Transparent
        Me.ThreeH.Font = New System.Drawing.Font("Microsoft Sans Serif", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ThreeH.ForeColor = System.Drawing.Color.White
        Me.ThreeH.Location = New System.Drawing.Point(150, 0)
        Me.ThreeH.Name = "ThreeH"
        Me.ThreeH.Size = New System.Drawing.Size(50, 50)
        Me.ThreeH.TabIndex = 23
        Me.ThreeH.Text = " 3"
        '
        'FourH
        '
        Me.FourH.BackColor = System.Drawing.Color.Transparent
        Me.FourH.Font = New System.Drawing.Font("Microsoft Sans Serif", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FourH.ForeColor = System.Drawing.Color.White
        Me.FourH.Location = New System.Drawing.Point(200, 0)
        Me.FourH.Name = "FourH"
        Me.FourH.Size = New System.Drawing.Size(50, 50)
        Me.FourH.TabIndex = 24
        Me.FourH.Text = " 4"
        '
        'FiveH
        '
        Me.FiveH.BackColor = System.Drawing.Color.Transparent
        Me.FiveH.Font = New System.Drawing.Font("Microsoft Sans Serif", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FiveH.ForeColor = System.Drawing.Color.White
        Me.FiveH.Location = New System.Drawing.Point(250, 0)
        Me.FiveH.Name = "FiveH"
        Me.FiveH.Size = New System.Drawing.Size(50, 50)
        Me.FiveH.TabIndex = 25
        Me.FiveH.Text = " 5"
        '
        'SixH
        '
        Me.SixH.BackColor = System.Drawing.Color.Transparent
        Me.SixH.Font = New System.Drawing.Font("Microsoft Sans Serif", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SixH.ForeColor = System.Drawing.Color.White
        Me.SixH.Location = New System.Drawing.Point(300, 0)
        Me.SixH.Name = "SixH"
        Me.SixH.Size = New System.Drawing.Size(50, 50)
        Me.SixH.TabIndex = 26
        Me.SixH.Text = " 6"
        '
        'SevenH
        '
        Me.SevenH.BackColor = System.Drawing.Color.Transparent
        Me.SevenH.Font = New System.Drawing.Font("Microsoft Sans Serif", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SevenH.ForeColor = System.Drawing.Color.White
        Me.SevenH.Location = New System.Drawing.Point(350, 0)
        Me.SevenH.Name = "SevenH"
        Me.SevenH.Size = New System.Drawing.Size(50, 50)
        Me.SevenH.TabIndex = 27
        Me.SevenH.Text = " 7"
        '
        'EightH
        '
        Me.EightH.BackColor = System.Drawing.Color.Transparent
        Me.EightH.Font = New System.Drawing.Font("Microsoft Sans Serif", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EightH.ForeColor = System.Drawing.Color.White
        Me.EightH.Location = New System.Drawing.Point(400, 0)
        Me.EightH.Name = "EightH"
        Me.EightH.Size = New System.Drawing.Size(50, 50)
        Me.EightH.TabIndex = 28
        Me.EightH.Text = " 8"
        '
        'NineH
        '
        Me.NineH.BackColor = System.Drawing.Color.Transparent
        Me.NineH.Font = New System.Drawing.Font("Microsoft Sans Serif", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NineH.ForeColor = System.Drawing.Color.White
        Me.NineH.Location = New System.Drawing.Point(450, 0)
        Me.NineH.Name = "NineH"
        Me.NineH.Size = New System.Drawing.Size(50, 50)
        Me.NineH.TabIndex = 29
        Me.NineH.Text = " 9"
        '
        'TwelveH
        '
        Me.TwelveH.BackColor = System.Drawing.Color.Transparent
        Me.TwelveH.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TwelveH.ForeColor = System.Drawing.Color.White
        Me.TwelveH.Location = New System.Drawing.Point(600, 0)
        Me.TwelveH.Name = "TwelveH"
        Me.TwelveH.Size = New System.Drawing.Size(50, 50)
        Me.TwelveH.TabIndex = 30
        Me.TwelveH.Text = "12"
        '
        'ElevenH
        '
        Me.ElevenH.BackColor = System.Drawing.Color.Transparent
        Me.ElevenH.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ElevenH.ForeColor = System.Drawing.Color.White
        Me.ElevenH.Location = New System.Drawing.Point(550, 0)
        Me.ElevenH.Name = "ElevenH"
        Me.ElevenH.Size = New System.Drawing.Size(50, 50)
        Me.ElevenH.TabIndex = 31
        Me.ElevenH.Text = "11"
        '
        'ThirteenH
        '
        Me.ThirteenH.BackColor = System.Drawing.Color.Transparent
        Me.ThirteenH.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ThirteenH.ForeColor = System.Drawing.Color.White
        Me.ThirteenH.Location = New System.Drawing.Point(650, 0)
        Me.ThirteenH.Name = "ThirteenH"
        Me.ThirteenH.Size = New System.Drawing.Size(50, 50)
        Me.ThirteenH.TabIndex = 32
        Me.ThirteenH.Text = "13"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Black
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(934, 641)
        Me.Controls.Add(Me.ThirteenH)
        Me.Controls.Add(Me.ElevenH)
        Me.Controls.Add(Me.TwelveH)
        Me.Controls.Add(Me.NineH)
        Me.Controls.Add(Me.EightH)
        Me.Controls.Add(Me.SevenH)
        Me.Controls.Add(Me.SixH)
        Me.Controls.Add(Me.FiveH)
        Me.Controls.Add(Me.FourH)
        Me.Controls.Add(Me.ThreeH)
        Me.Controls.Add(Me.TwoH)
        Me.Controls.Add(Me.OneH)
        Me.Controls.Add(Me.TenH)
        Me.Controls.Add(Me.TenV)
        Me.Controls.Add(Me.NineV)
        Me.Controls.Add(Me.EightV)
        Me.Controls.Add(Me.SevenV)
        Me.Controls.Add(Me.SixV)
        Me.Controls.Add(Me.FiveV)
        Me.Controls.Add(Me.FourV)
        Me.Controls.Add(Me.ThreeV)
        Me.Controls.Add(Me.TwoV)
        Me.Controls.Add(Me.OneV)
        Me.Controls.Add(Me.ZeroPoint)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Move_Down)
        Me.Controls.Add(Me.Move_Left)
        Me.Controls.Add(Me.Move_Up)
        Me.Controls.Add(Me.Move_Right)
        Me.Controls.Add(Me.Pass_Turn)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Pass_Turn As Button
    Friend WithEvents Move_Right As Button
    Friend WithEvents Move_Up As Button
    Friend WithEvents Move_Left As Button
    Friend WithEvents Move_Down As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents ZeroPoint As Label
    Friend WithEvents OneV As Label
    Friend WithEvents TwoV As Label
    Friend WithEvents ThreeV As Label
    Friend WithEvents FourV As Label
    Friend WithEvents FiveV As Label
    Friend WithEvents SixV As Label
    Friend WithEvents SevenV As Label
    Friend WithEvents EightV As Label
    Friend WithEvents NineV As Label
    Friend WithEvents TenV As Label
    Friend WithEvents TenH As Label
    Friend WithEvents OneH As Label
    Friend WithEvents TwoH As Label
    Friend WithEvents ThreeH As Label
    Friend WithEvents FourH As Label
    Friend WithEvents FiveH As Label
    Friend WithEvents SixH As Label
    Friend WithEvents SevenH As Label
    Friend WithEvents EightH As Label
    Friend WithEvents NineH As Label
    Friend WithEvents TwelveH As Label
    Friend WithEvents ElevenH As Label
    Friend WithEvents ThirteenH As Label
End Class
