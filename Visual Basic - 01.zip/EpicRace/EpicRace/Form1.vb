﻿Public Class Form1
    Dim P1P, P2P, P3P As Point
    Dim T1, T2, T3, P1S, P2S, P3S As Integer
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        P1S = 0
        P2S = 0
        P3S = 0
        P1P.X = BobbyRoss.Left
        P1P.Y = BobbyRoss.Top
        P2P.X = Trump.Left
        P2P.Y = Trump.Top
        P3P.X = Kerchoo.Left
        P3P.Y = Kerchoo.Top
    End Sub
    Private Sub ExitButton_Click(sender As Object, e As EventArgs) Handles ExitButton.Click
        Close()
    End Sub
    Private Sub Start_Click(sender As Object, e As EventArgs) Handles Start.Click
        If Start.Text = "Start" Then
            P1Timer.Enabled = True
            P2Timer.Enabled = True
            P3Timer.Enabled = True
            WinnerAnnouncer.Text = "Who Will Win?"
            Start.Text = "Reset"
        ElseIf Start.Text = "Reset" Then
            P1Timer.Enabled = False
            P2Timer.Enabled = False
            P3Timer.Enabled = False
            BobbyRoss.Left = P1P.X
            BobbyRoss.Top = P1P.Y
            Trump.Left = P2P.X
            Trump.Top = P2P.Y
            Kerchoo.Left = P3P.X
            Kerchoo.Top = P3P.Y
            WinnerAnnouncer.Text = "Who Will Win?"
            Start.Text = "Start"
        End If
    End Sub
    Private Sub P1Timer_Tick(sender As Object, e As EventArgs) Handles P1Timer.Tick
        If BobbyRoss.Right >= FinishLine.Left Then
            WinnerAnnouncer.Text = "Bob Ross Won The Race!"
            P3Timer.Enabled = False
            P2Timer.Enabled = False
            P1Timer.Enabled = False
            P1S = P1S + 1
            P1Wins.Text = P1S
        Else
            Randomize()
            T1 = Int(Rnd() * 21) + 1
            BobbyRoss.Left = BobbyRoss.Left + T1
        End If
    End Sub
    Private Sub P2Timer_Tick(sender As Object, e As EventArgs) Handles P2Timer.Tick
        If Trump.Right >= FinishLine.Left Then
            WinnerAnnouncer.Text = "Donald Trump Won The Race!"
            P1Timer.Enabled = False
            P3Timer.Enabled = False
            P2Timer.Enabled = False
            P2S = P2S + 1
            P2Wins.Text = P2S
        Else
            Randomize()
            T2 = Int(Rnd() * 21) + 1
            Trump.Left = Trump.Left + T2
        End If
    End Sub
    Private Sub P3Timer_Tick(sender As Object, e As EventArgs) Handles P3Timer.Tick
        If Kerchoo.Right >= FinishLine.Left Then
            WinnerAnnouncer.Text = "This Thing Has Won The Race!"
            P1Timer.Enabled = False
            P2Timer.Enabled = False
            P3Timer.Enabled = False
            P3S = P3S + 1
            P3Wins.Text = P3S
        Else
            Randomize()
            T3 = Int(Rnd() * 21) + 1
            Kerchoo.Left = Kerchoo.Left + T3
        End If
    End Sub
End Class