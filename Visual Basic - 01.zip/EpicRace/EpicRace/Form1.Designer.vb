﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.Start = New System.Windows.Forms.Button()
        Me.P1 = New System.Windows.Forms.Label()
        Me.P2 = New System.Windows.Forms.Label()
        Me.P3 = New System.Windows.Forms.Label()
        Me.WinnerAnnouncer = New System.Windows.Forms.Label()
        Me.ExitButton = New System.Windows.Forms.Button()
        Me.P1Timer = New System.Windows.Forms.Timer(Me.components)
        Me.P2Timer = New System.Windows.Forms.Timer(Me.components)
        Me.P3Timer = New System.Windows.Forms.Timer(Me.components)
        Me.Lane1 = New System.Windows.Forms.Label()
        Me.Lane2 = New System.Windows.Forms.Label()
        Me.Lane3 = New System.Windows.Forms.Label()
        Me.FinishLine = New System.Windows.Forms.Label()
        Me.BobbyRoss = New System.Windows.Forms.PictureBox()
        Me.Trump = New System.Windows.Forms.PictureBox()
        Me.Kerchoo = New System.Windows.Forms.PictureBox()
        Me.Lane4 = New System.Windows.Forms.Label()
        Me.P1Wins = New System.Windows.Forms.Label()
        Me.P2Wins = New System.Windows.Forms.Label()
        Me.P3Wins = New System.Windows.Forms.Label()
        CType(Me.BobbyRoss, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Trump, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Kerchoo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Start
        '
        Me.Start.Location = New System.Drawing.Point(12, 471)
        Me.Start.Name = "Start"
        Me.Start.Size = New System.Drawing.Size(75, 75)
        Me.Start.TabIndex = 0
        Me.Start.Text = "Start"
        Me.Start.UseVisualStyleBackColor = True
        '
        'P1
        '
        Me.P1.AutoSize = True
        Me.P1.Location = New System.Drawing.Point(13, 134)
        Me.P1.Margin = New System.Windows.Forms.Padding(0)
        Me.P1.Name = "P1"
        Me.P1.Size = New System.Drawing.Size(83, 13)
        Me.P1.TabIndex = 2
        Me.P1.Text = "Bob Ross Wins:"
        '
        'P2
        '
        Me.P2.AutoSize = True
        Me.P2.Location = New System.Drawing.Point(13, 198)
        Me.P2.Name = "P2"
        Me.P2.Size = New System.Drawing.Size(67, 13)
        Me.P2.TabIndex = 3
        Me.P2.Text = "Trump Wins:"
        '
        'P3
        '
        Me.P3.AutoSize = True
        Me.P3.Location = New System.Drawing.Point(13, 273)
        Me.P3.Name = "P3"
        Me.P3.Size = New System.Drawing.Size(64, 13)
        Me.P3.TabIndex = 4
        Me.P3.Text = "Thing Wins:"
        '
        'WinnerAnnouncer
        '
        Me.WinnerAnnouncer.AutoSize = True
        Me.WinnerAnnouncer.Location = New System.Drawing.Point(13, 379)
        Me.WinnerAnnouncer.Name = "WinnerAnnouncer"
        Me.WinnerAnnouncer.Size = New System.Drawing.Size(78, 13)
        Me.WinnerAnnouncer.TabIndex = 5
        Me.WinnerAnnouncer.Text = "Who Will Win?"
        '
        'ExitButton
        '
        Me.ExitButton.Location = New System.Drawing.Point(93, 471)
        Me.ExitButton.Name = "ExitButton"
        Me.ExitButton.Size = New System.Drawing.Size(75, 75)
        Me.ExitButton.TabIndex = 6
        Me.ExitButton.Text = "Exit"
        Me.ExitButton.UseVisualStyleBackColor = True
        '
        'P1Timer
        '
        '
        'P2Timer
        '
        '
        'P3Timer
        '
        '
        'Lane1
        '
        Me.Lane1.BackColor = System.Drawing.Color.Red
        Me.Lane1.Location = New System.Drawing.Point(258, 36)
        Me.Lane1.Name = "Lane1"
        Me.Lane1.Size = New System.Drawing.Size(548, 23)
        Me.Lane1.TabIndex = 7
        '
        'Lane2
        '
        Me.Lane2.BackColor = System.Drawing.Color.Red
        Me.Lane2.Location = New System.Drawing.Point(258, 175)
        Me.Lane2.Name = "Lane2"
        Me.Lane2.Size = New System.Drawing.Size(567, 23)
        Me.Lane2.TabIndex = 8
        '
        'Lane3
        '
        Me.Lane3.BackColor = System.Drawing.Color.Red
        Me.Lane3.Location = New System.Drawing.Point(258, 340)
        Me.Lane3.Name = "Lane3"
        Me.Lane3.Size = New System.Drawing.Size(580, 23)
        Me.Lane3.TabIndex = 9
        '
        'FinishLine
        '
        Me.FinishLine.BackColor = System.Drawing.Color.Red
        Me.FinishLine.Location = New System.Drawing.Point(804, 20)
        Me.FinishLine.Name = "FinishLine"
        Me.FinishLine.Size = New System.Drawing.Size(34, 506)
        Me.FinishLine.TabIndex = 10
        '
        'BobbyRoss
        '
        Me.BobbyRoss.Image = CType(resources.GetObject("BobbyRoss.Image"), System.Drawing.Image)
        Me.BobbyRoss.Location = New System.Drawing.Point(261, 82)
        Me.BobbyRoss.Name = "BobbyRoss"
        Me.BobbyRoss.Size = New System.Drawing.Size(75, 75)
        Me.BobbyRoss.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.BobbyRoss.TabIndex = 11
        Me.BobbyRoss.TabStop = False
        '
        'Trump
        '
        Me.Trump.Image = CType(resources.GetObject("Trump.Image"), System.Drawing.Image)
        Me.Trump.Location = New System.Drawing.Point(261, 230)
        Me.Trump.Name = "Trump"
        Me.Trump.Size = New System.Drawing.Size(75, 75)
        Me.Trump.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Trump.TabIndex = 12
        Me.Trump.TabStop = False
        '
        'Kerchoo
        '
        Me.Kerchoo.Image = CType(resources.GetObject("Kerchoo.Image"), System.Drawing.Image)
        Me.Kerchoo.Location = New System.Drawing.Point(261, 379)
        Me.Kerchoo.Name = "Kerchoo"
        Me.Kerchoo.Size = New System.Drawing.Size(75, 75)
        Me.Kerchoo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Kerchoo.TabIndex = 13
        Me.Kerchoo.TabStop = False
        '
        'Lane4
        '
        Me.Lane4.BackColor = System.Drawing.Color.Red
        Me.Lane4.Location = New System.Drawing.Point(258, 483)
        Me.Lane4.Name = "Lane4"
        Me.Lane4.Size = New System.Drawing.Size(580, 23)
        Me.Lane4.TabIndex = 14
        '
        'P1Wins
        '
        Me.P1Wins.AutoSize = True
        Me.P1Wins.Location = New System.Drawing.Point(96, 134)
        Me.P1Wins.Margin = New System.Windows.Forms.Padding(0)
        Me.P1Wins.Name = "P1Wins"
        Me.P1Wins.Size = New System.Drawing.Size(13, 13)
        Me.P1Wins.TabIndex = 15
        Me.P1Wins.Text = "0"
        '
        'P2Wins
        '
        Me.P2Wins.AutoSize = True
        Me.P2Wins.Location = New System.Drawing.Point(78, 198)
        Me.P2Wins.Name = "P2Wins"
        Me.P2Wins.Size = New System.Drawing.Size(13, 13)
        Me.P2Wins.TabIndex = 16
        Me.P2Wins.Text = "0"
        '
        'P3Wins
        '
        Me.P3Wins.AutoSize = True
        Me.P3Wins.Location = New System.Drawing.Point(74, 273)
        Me.P3Wins.Name = "P3Wins"
        Me.P3Wins.Size = New System.Drawing.Size(13, 13)
        Me.P3Wins.TabIndex = 17
        Me.P3Wins.Text = "0"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(850, 558)
        Me.Controls.Add(Me.P3Wins)
        Me.Controls.Add(Me.P2Wins)
        Me.Controls.Add(Me.P1Wins)
        Me.Controls.Add(Me.Lane4)
        Me.Controls.Add(Me.Kerchoo)
        Me.Controls.Add(Me.Trump)
        Me.Controls.Add(Me.BobbyRoss)
        Me.Controls.Add(Me.FinishLine)
        Me.Controls.Add(Me.Lane3)
        Me.Controls.Add(Me.Lane2)
        Me.Controls.Add(Me.Lane1)
        Me.Controls.Add(Me.ExitButton)
        Me.Controls.Add(Me.WinnerAnnouncer)
        Me.Controls.Add(Me.P3)
        Me.Controls.Add(Me.P2)
        Me.Controls.Add(Me.P1)
        Me.Controls.Add(Me.Start)
        Me.Name = "Form1"
        Me.Text = "Race Of Epic Memeage"
        CType(Me.BobbyRoss, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Trump, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Kerchoo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Start As Button
    Friend WithEvents P1 As Label
    Friend WithEvents P2 As Label
    Friend WithEvents P3 As Label
    Friend WithEvents WinnerAnnouncer As Label
    Friend WithEvents ExitButton As Button
    Friend WithEvents P1Timer As Timer
    Friend WithEvents P2Timer As Timer
    Friend WithEvents P3Timer As Timer
    Friend WithEvents Lane1 As Label
    Friend WithEvents Lane2 As Label
    Friend WithEvents Lane3 As Label
    Friend WithEvents FinishLine As Label
    Friend WithEvents BobbyRoss As PictureBox
    Friend WithEvents Trump As PictureBox
    Friend WithEvents Kerchoo As PictureBox
    Friend WithEvents Lane4 As Label
    Friend WithEvents P1Wins As Label
    Friend WithEvents P2Wins As Label
    Friend WithEvents P3Wins As Label
End Class
