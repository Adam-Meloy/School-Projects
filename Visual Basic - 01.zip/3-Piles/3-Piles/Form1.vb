﻿Public Class Form1
    Dim PileRemove, Removed As String
    Dim A, B, C As Integer
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        A = 5
        B = 5
        C = 5
        MsgBox("Click The Box To Start")
    End Sub
    Private Sub TextArea_Click(sender As Object, e As EventArgs) Handles TextArea.Click
        Do Until A + B + C = 0
            PileRemove = InputBox("Enter A Pile To Remove From")
            Removed = InputBox("Enter An Amount To Be Removed")
            If PileRemove = "A" Or PileRemove = "a" Then
                A -= Removed
            End If
            If PileRemove = "B" Or PileRemove = "b" Then
                B -= Removed
            End If
            If PileRemove = "C" Or PileRemove = "c" Then
                C -= Removed
            End If
            If PileRemove = "A" Or PileRemove = "a" Or PileRemove = "B" Or PileRemove = "b" Or PileRemove = "C" Or PileRemove = "c" Then
                TextArea.Items.Add("A: " & A & " B: " & B & " C: " & C & "  Pile Selected: " & PileRemove & " Number Removed: " & Removed)
            Else
                TextArea.Items.Add("Enter A Valid Pile Next Time")
                TextArea.Items.Add("A: " & A & " B: " & B & " C: " & C)
            End If
            If Removed >= 6 Then
                TextArea.Items.Add("Enter A Valid Number Next Time")
                TextArea.Items.Add("A: " & A & " B: " & B & " C: " & C)
            End If
            If A + B + C = 0 Then
                TextArea.Items.Add("Congrats! You Beat The Game!")
            End If
        Loop
    End Sub
End Class