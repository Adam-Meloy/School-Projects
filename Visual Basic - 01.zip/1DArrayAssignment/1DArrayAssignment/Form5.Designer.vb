﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form5
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.PhoneNumberChecker = New System.Windows.Forms.Button()
        Me.Leave = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'PhoneNumberChecker
        '
        Me.PhoneNumberChecker.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PhoneNumberChecker.Location = New System.Drawing.Point(12, 12)
        Me.PhoneNumberChecker.Name = "PhoneNumberChecker"
        Me.PhoneNumberChecker.Size = New System.Drawing.Size(100, 100)
        Me.PhoneNumberChecker.TabIndex = 0
        Me.PhoneNumberChecker.Text = "Look-Up Phone Number"
        Me.PhoneNumberChecker.UseVisualStyleBackColor = True
        '
        'Leave
        '
        Me.Leave.Location = New System.Drawing.Point(13, 119)
        Me.Leave.Name = "Leave"
        Me.Leave.Size = New System.Drawing.Size(99, 43)
        Me.Leave.TabIndex = 1
        Me.Leave.Text = "Exit"
        Me.Leave.UseVisualStyleBackColor = True
        '
        'Form5
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(125, 174)
        Me.Controls.Add(Me.Leave)
        Me.Controls.Add(Me.PhoneNumberChecker)
        Me.Name = "Form5"
        Me.Text = "Form5"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents PhoneNumberChecker As Button
    Friend WithEvents Leave As Button
End Class
