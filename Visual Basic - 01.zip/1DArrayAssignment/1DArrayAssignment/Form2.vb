﻿Public Class hii
    Dim Int(9) As Integer
    Dim Min, Max As Integer
    Private Sub lEAVE_Click(sender As Object, e As EventArgs) Handles lEAVE.Click
        Me.Hide()
        Form1.Show()
    End Sub
    Private Sub Clear_LB_Click(sender As Object, e As EventArgs) Handles ClearLB.Click
        LB.Items.Clear()
        Text.Text = 0
        For L = 0 To Int.Length - 1
            Int(L) = 0
        Next
    End Sub
    Private Sub InputInt_Click(sender As Object, e As EventArgs) Handles InputInt.Click
        For i = 0 To Int.Length - 1
            Int(i) = InputBox("Enter A Number Below")
            LB.Items.Add(Int(i))
        Next
    End Sub
    Private Sub MinMax_Click(sender As Object, e As EventArgs) Handles MinMax.Click
        Min = Int(0)
        Max = Int(0)
        For k = 0 To Int.Length - 1
            If Min >= Int(k) Then
                Min = Int(k)
            End If
            If Max <= Int(k) Then
                Max = Int(k)
            End If
        Next
        Text.Text = "The Max is " & Max & " and the Minimum is " & Min & "."
    End Sub
End Class