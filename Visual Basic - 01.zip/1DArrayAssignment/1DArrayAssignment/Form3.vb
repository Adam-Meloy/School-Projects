﻿Public Class Form3
    Dim Nouns(3), Verbs(3), Preposition(3), Adjectives(3), Articles(3) As String
    Dim I1, I2, I3, I4, I5, I6, I7, I8 As Integer
    Private Sub Clear_Click(sender As Object, e As EventArgs) Handles Clear.Click
        LB.Items.Clear()
    End Sub
    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Nouns = {"cat", "man", "pen", "bear"}
        Verbs = {"began", "drew", "built", "ate"}
        Preposition = {"after", "in", "on", "a"}
        Adjectives = {"calm", "happy", "hungry", "lazy"}
        Articles = {"he", "", "n", "y"}
    End Sub
    Private Sub Leave_Click(sender As Object, e As EventArgs) Handles Leave.Click
        Me.Hide()
        Form1.Show()
    End Sub
    Private Sub SentenceGenerator_Click(sender As Object, e As EventArgs) Handles SentenceGenerator.Click
        Randomize()
        I1 = Int(Rnd() * 4)
        Randomize()
        I2 = Int(Rnd() * 4)
        Randomize()
        I3 = Int(Rnd() * 4)
        Randomize()
        I4 = Int(Rnd() * 4)
        Randomize()
        I5 = Int(Rnd() * 4)
        Randomize()
        I6 = Int(Rnd() * 4)
        Randomize()
        I7 = Int(Rnd() * 4)
        Randomize()
        I8 = Int(Rnd() * 4)
        If Articles(I1) = "he" Then
            Articles(I1) = "The"
            Articles(I6) = "the"
        ElseIf Articles(I1) = "" Then
            Articles(I1) = "A"
            Articles(I6) = "a"
        ElseIf Articles(I1) = "n" Then
            Articles(I1) = "An"
            Articles(I6) = "an"
        ElseIf Articles(I1) = "y" Then
            Articles(I1) = "My"
            Articles(I6) = "my"
        End If
        LB.Items.Add(Articles(I1) & " " & Adjectives(I2) & " " & Nouns(I3) & " " & Verbs(I4) & " " & Preposition(I5) & " " & Articles(I6) & " " & Adjectives(I7) & " " & Nouns(I8) & ".")
    End Sub
End Class