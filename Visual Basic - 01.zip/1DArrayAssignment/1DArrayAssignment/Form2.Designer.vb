﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class hii
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.InputInt = New System.Windows.Forms.Button()
        Me.LB = New System.Windows.Forms.ListBox()
        Me.Text = New System.Windows.Forms.Label()
        Me.MinMax = New System.Windows.Forms.Button()
        Me.ClearLB = New System.Windows.Forms.Button()
        Me.lEAVE = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'InputInt
        '
        Me.InputInt.Location = New System.Drawing.Point(12, 12)
        Me.InputInt.Name = "InputInt"
        Me.InputInt.Size = New System.Drawing.Size(75, 23)
        Me.InputInt.TabIndex = 0
        Me.InputInt.Text = "Input"
        Me.InputInt.UseVisualStyleBackColor = True
        '
        'LB
        '
        Me.LB.FormattingEnabled = True
        Me.LB.Location = New System.Drawing.Point(93, 12)
        Me.LB.Name = "LB"
        Me.LB.Size = New System.Drawing.Size(125, 173)
        Me.LB.TabIndex = 1
        '
        'Text
        '
        Me.Text.Location = New System.Drawing.Point(3, 138)
        Me.Text.Name = "Text"
        Me.Text.Size = New System.Drawing.Size(84, 73)
        Me.Text.TabIndex = 2
        '
        'MinMax
        '
        Me.MinMax.Location = New System.Drawing.Point(12, 41)
        Me.MinMax.Name = "MinMax"
        Me.MinMax.Size = New System.Drawing.Size(75, 23)
        Me.MinMax.TabIndex = 3
        Me.MinMax.Text = "Min / Max"
        Me.MinMax.UseVisualStyleBackColor = True
        '
        'ClearLB
        '
        Me.ClearLB.Location = New System.Drawing.Point(12, 70)
        Me.ClearLB.Name = "ClearLB"
        Me.ClearLB.Size = New System.Drawing.Size(75, 23)
        Me.ClearLB.TabIndex = 4
        Me.ClearLB.Text = "Clear"
        Me.ClearLB.UseVisualStyleBackColor = True
        '
        'lEAVE
        '
        Me.lEAVE.Location = New System.Drawing.Point(12, 99)
        Me.lEAVE.Name = "lEAVE"
        Me.lEAVE.Size = New System.Drawing.Size(75, 23)
        Me.lEAVE.TabIndex = 5
        Me.lEAVE.Text = "eXIT"
        Me.lEAVE.UseVisualStyleBackColor = True
        '
        'hii
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(238, 220)
        Me.Controls.Add(Me.lEAVE)
        Me.Controls.Add(Me.ClearLB)
        Me.Controls.Add(Me.MinMax)
        Me.Controls.Add(Me.Text)
        Me.Controls.Add(Me.LB)
        Me.Controls.Add(Me.InputInt)
        Me.Name = "hii"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents InputInt As Button
    Friend WithEvents LB As ListBox
    Friend WithEvents Text As Label
    Friend WithEvents MinMax As Button
    Friend WithEvents ClearLB As Button
    Friend WithEvents lEAVE As Button
End Class
