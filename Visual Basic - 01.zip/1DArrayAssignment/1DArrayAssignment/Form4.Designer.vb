﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form4
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.A1 = New System.Windows.Forms.TextBox()
        Me.A2 = New System.Windows.Forms.TextBox()
        Me.A3 = New System.Windows.Forms.TextBox()
        Me.A4 = New System.Windows.Forms.TextBox()
        Me.A5 = New System.Windows.Forms.TextBox()
        Me.A6 = New System.Windows.Forms.TextBox()
        Me.A7 = New System.Windows.Forms.TextBox()
        Me.CheckPin = New System.Windows.Forms.Button()
        Me.ClearTB = New System.Windows.Forms.Button()
        Me.Leave = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'A1
        '
        Me.A1.Location = New System.Drawing.Point(12, 22)
        Me.A1.Name = "A1"
        Me.A1.Size = New System.Drawing.Size(29, 20)
        Me.A1.TabIndex = 0
        '
        'A2
        '
        Me.A2.Location = New System.Drawing.Point(47, 22)
        Me.A2.Name = "A2"
        Me.A2.Size = New System.Drawing.Size(29, 20)
        Me.A2.TabIndex = 1
        '
        'A3
        '
        Me.A3.Location = New System.Drawing.Point(82, 22)
        Me.A3.Name = "A3"
        Me.A3.Size = New System.Drawing.Size(29, 20)
        Me.A3.TabIndex = 2
        '
        'A4
        '
        Me.A4.Location = New System.Drawing.Point(117, 22)
        Me.A4.Name = "A4"
        Me.A4.Size = New System.Drawing.Size(29, 20)
        Me.A4.TabIndex = 3
        '
        'A5
        '
        Me.A5.Location = New System.Drawing.Point(152, 22)
        Me.A5.Name = "A5"
        Me.A5.Size = New System.Drawing.Size(29, 20)
        Me.A5.TabIndex = 4
        '
        'A6
        '
        Me.A6.Location = New System.Drawing.Point(187, 22)
        Me.A6.Name = "A6"
        Me.A6.Size = New System.Drawing.Size(29, 20)
        Me.A6.TabIndex = 5
        '
        'A7
        '
        Me.A7.Location = New System.Drawing.Point(222, 22)
        Me.A7.Name = "A7"
        Me.A7.Size = New System.Drawing.Size(29, 20)
        Me.A7.TabIndex = 6
        '
        'CheckPin
        '
        Me.CheckPin.Location = New System.Drawing.Point(12, 48)
        Me.CheckPin.Name = "CheckPin"
        Me.CheckPin.Size = New System.Drawing.Size(75, 23)
        Me.CheckPin.TabIndex = 7
        Me.CheckPin.Text = "Check Pin"
        Me.CheckPin.UseVisualStyleBackColor = True
        '
        'ClearTB
        '
        Me.ClearTB.Location = New System.Drawing.Point(93, 48)
        Me.ClearTB.Name = "ClearTB"
        Me.ClearTB.Size = New System.Drawing.Size(75, 23)
        Me.ClearTB.TabIndex = 8
        Me.ClearTB.Text = "Clear"
        Me.ClearTB.UseVisualStyleBackColor = True
        '
        'Leave
        '
        Me.Leave.Location = New System.Drawing.Point(174, 48)
        Me.Leave.Name = "Leave"
        Me.Leave.Size = New System.Drawing.Size(75, 23)
        Me.Leave.TabIndex = 9
        Me.Leave.Text = "Exit"
        Me.Leave.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(12, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(156, 19)
        Me.Label1.TabIndex = 10
        Me.Label1.Text = "Enter Pin To Be Verified"
        '
        'Form4
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(264, 82)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Leave)
        Me.Controls.Add(Me.ClearTB)
        Me.Controls.Add(Me.CheckPin)
        Me.Controls.Add(Me.A7)
        Me.Controls.Add(Me.A6)
        Me.Controls.Add(Me.A5)
        Me.Controls.Add(Me.A4)
        Me.Controls.Add(Me.A3)
        Me.Controls.Add(Me.A2)
        Me.Controls.Add(Me.A1)
        Me.Name = "Form4"
        Me.Text = "Pin Verification"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents A1 As TextBox
    Friend WithEvents A2 As TextBox
    Friend WithEvents A3 As TextBox
    Friend WithEvents A4 As TextBox
    Friend WithEvents A5 As TextBox
    Friend WithEvents A6 As TextBox
    Friend WithEvents A7 As TextBox
    Friend WithEvents CheckPin As Button
    Friend WithEvents ClearTB As Button
    Friend WithEvents Leave As Button
    Friend WithEvents Label1 As Label
End Class
