﻿Public Class Form5
    Dim PeopleNames() As String = {"Rob", "Joshua", "Max", "Bill", "Joey", "Seth", "Greg"}
    Dim PhoneNumber() As String = {"845-324-8766", "657-445-3478", "998-421-4521", "556-735-5655", "435-976-6678", "112-345-4545", "232-433-9831"}
    Dim NameHolder As String
    Private Sub Leave_Click(sender As Object, e As EventArgs) Handles Leave.Click
        Me.Hide()
        Form1.Show()
    End Sub
    Private Sub PhoneNumberChecker_Click(sender As Object, e As EventArgs) Handles PhoneNumberChecker.Click
        NameHolder = InputBox("Enter One Of Your Friends Names To Get Their Phone Number.")
        For i = 0 To PeopleNames.Length - 1
            If NameHolder = PeopleNames(i) Then
                MsgBox("Your Friend's Phone Number Is " & PhoneNumber(i))
                Exit For
            Else
                MsgBox("Incorrect Name Entered")
                Exit For
            End If
        Next
    End Sub
End Class