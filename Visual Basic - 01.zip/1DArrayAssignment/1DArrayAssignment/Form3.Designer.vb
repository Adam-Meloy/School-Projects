﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form3
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.SentenceGenerator = New System.Windows.Forms.Button()
        Me.Leave = New System.Windows.Forms.Button()
        Me.LB = New System.Windows.Forms.ListBox()
        Me.Clear = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'SentenceGenerator
        '
        Me.SentenceGenerator.Location = New System.Drawing.Point(12, 12)
        Me.SentenceGenerator.Name = "SentenceGenerator"
        Me.SentenceGenerator.Size = New System.Drawing.Size(93, 25)
        Me.SentenceGenerator.TabIndex = 0
        Me.SentenceGenerator.Text = "Generate"
        Me.SentenceGenerator.UseVisualStyleBackColor = True
        '
        'Leave
        '
        Me.Leave.Location = New System.Drawing.Point(197, 12)
        Me.Leave.Name = "Leave"
        Me.Leave.Size = New System.Drawing.Size(75, 25)
        Me.Leave.TabIndex = 1
        Me.Leave.Text = "Exit"
        Me.Leave.UseVisualStyleBackColor = True
        '
        'LB
        '
        Me.LB.FormattingEnabled = True
        Me.LB.Location = New System.Drawing.Point(12, 43)
        Me.LB.Name = "LB"
        Me.LB.Size = New System.Drawing.Size(260, 160)
        Me.LB.TabIndex = 2
        '
        'Clear
        '
        Me.Clear.Location = New System.Drawing.Point(111, 12)
        Me.Clear.Name = "Clear"
        Me.Clear.Size = New System.Drawing.Size(80, 25)
        Me.Clear.TabIndex = 3
        Me.Clear.Text = "Clear"
        Me.Clear.UseVisualStyleBackColor = True
        '
        'Form3
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 211)
        Me.Controls.Add(Me.Clear)
        Me.Controls.Add(Me.LB)
        Me.Controls.Add(Me.Leave)
        Me.Controls.Add(Me.SentenceGenerator)
        Me.Name = "Form3"
        Me.Text = "Generate-A-Sentence"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents SentenceGenerator As Button
    Friend WithEvents Leave As Button
    Friend WithEvents LB As ListBox
    Friend WithEvents Clear As Button
End Class
