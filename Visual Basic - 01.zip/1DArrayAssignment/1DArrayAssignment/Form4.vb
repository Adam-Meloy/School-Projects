﻿Public Class Form4
    Dim Digits(6) As Integer
    Dim MinDigit() As Integer = {7, 5, 0, 0, 6, 3, 4}
    Dim MaxDigit() As Integer = {9, 7, 4, 9, 9, 6, 8}
    Private Sub Leave_Click(sender As Object, e As EventArgs) Handles Leave.Click
        Me.Hide()
        Form1.Show()
    End Sub
    Private Sub ClearTB_Click(sender As Object, e As EventArgs) Handles ClearTB.Click
        A1.Text = ""
        A2.Text = ""
        A3.Text = ""
        A4.Text = ""
        A5.Text = ""
        A6.Text = ""
        A7.Text = ""
        Digits = {0, 0, 0, 0, 0, 0, 0}
    End Sub
    Private Sub CheckPin_Click(sender As Object, e As EventArgs) Handles CheckPin.Click
        Digits(0) = A1.Text
        Digits(1) = A2.Text
        Digits(2) = A3.Text
        Digits(3) = A4.Text
        Digits(4) = A5.Text
        Digits(5) = A6.Text
        Digits(6) = A7.Text
        For i = 0 To Digits.Length - 1
            If Digits(i) < MinDigit(i) Or Digits(i) > MaxDigit(i) Then
                MsgBox("The Digit " & Digits(i) & " Is Incorrect")
            End If
        Next
    End Sub
End Class