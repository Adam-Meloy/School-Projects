﻿Public Class Home
    Private Sub Num1_Click(sender As Object, e As EventArgs) Handles Num1.Click
        Me.Hide()
        NumberLine.Show()
    End Sub
    Private Sub Num2_Click(sender As Object, e As EventArgs) Handles Num2.Click
        Me.Hide()
        RandomIntAdd.Show()
    End Sub
    Private Sub Num3_Click(sender As Object, e As EventArgs) Handles Num3.Click
        Me.Hide()
        SecNum.Show()
    End Sub
    Private Sub Num4_Click(sender As Object, e As EventArgs) Handles Num4.Click
        Me.Hide()
        ExpList.Show()
    End Sub
End Class
