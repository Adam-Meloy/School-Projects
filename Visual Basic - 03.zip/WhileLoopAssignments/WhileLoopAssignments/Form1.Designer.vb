﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Home
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Num1 = New System.Windows.Forms.Button()
        Me.Num2 = New System.Windows.Forms.Button()
        Me.Num3 = New System.Windows.Forms.Button()
        Me.Num4 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Num1
        '
        Me.Num1.Location = New System.Drawing.Point(12, 12)
        Me.Num1.Name = "Num1"
        Me.Num1.Size = New System.Drawing.Size(130, 120)
        Me.Num1.TabIndex = 0
        Me.Num1.Text = "#1"
        Me.Num1.UseVisualStyleBackColor = True
        '
        'Num2
        '
        Me.Num2.Location = New System.Drawing.Point(142, 12)
        Me.Num2.Name = "Num2"
        Me.Num2.Size = New System.Drawing.Size(130, 120)
        Me.Num2.TabIndex = 1
        Me.Num2.Text = "#2"
        Me.Num2.UseVisualStyleBackColor = True
        '
        'Num3
        '
        Me.Num3.Location = New System.Drawing.Point(12, 129)
        Me.Num3.Name = "Num3"
        Me.Num3.Size = New System.Drawing.Size(130, 120)
        Me.Num3.TabIndex = 2
        Me.Num3.Text = "#3"
        Me.Num3.UseVisualStyleBackColor = True
        '
        'Num4
        '
        Me.Num4.Location = New System.Drawing.Point(142, 129)
        Me.Num4.Name = "Num4"
        Me.Num4.Size = New System.Drawing.Size(130, 120)
        Me.Num4.TabIndex = 3
        Me.Num4.Text = "#4"
        Me.Num4.UseVisualStyleBackColor = True
        '
        'Home
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 261)
        Me.Controls.Add(Me.Num4)
        Me.Controls.Add(Me.Num3)
        Me.Controls.Add(Me.Num2)
        Me.Controls.Add(Me.Num1)
        Me.Name = "Home"
        Me.Text = "Home"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Num1 As Button
    Friend WithEvents Num2 As Button
    Friend WithEvents Num3 As Button
    Friend WithEvents Num4 As Button
End Class
