﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class NumberLine
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ListNumbers = New System.Windows.Forms.ListBox()
        Me.CheckIt = New System.Windows.Forms.Button()
        Me.ReturnHome = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'ListNumbers
        '
        Me.ListNumbers.FormattingEnabled = True
        Me.ListNumbers.Location = New System.Drawing.Point(12, 12)
        Me.ListNumbers.Name = "ListNumbers"
        Me.ListNumbers.Size = New System.Drawing.Size(120, 108)
        Me.ListNumbers.TabIndex = 0
        '
        'CheckIt
        '
        Me.CheckIt.Location = New System.Drawing.Point(139, 13)
        Me.CheckIt.Name = "CheckIt"
        Me.CheckIt.Size = New System.Drawing.Size(50, 50)
        Me.CheckIt.TabIndex = 1
        Me.CheckIt.Text = "Start"
        Me.CheckIt.UseVisualStyleBackColor = True
        '
        'ReturnHome
        '
        Me.ReturnHome.Location = New System.Drawing.Point(138, 69)
        Me.ReturnHome.Name = "ReturnHome"
        Me.ReturnHome.Size = New System.Drawing.Size(50, 50)
        Me.ReturnHome.TabIndex = 2
        Me.ReturnHome.Text = "Return"
        Me.ReturnHome.UseVisualStyleBackColor = True
        '
        'NumberLine
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(202, 129)
        Me.Controls.Add(Me.ReturnHome)
        Me.Controls.Add(Me.CheckIt)
        Me.Controls.Add(Me.ListNumbers)
        Me.Name = "NumberLine"
        Me.Text = "1-10 To 20"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents ListNumbers As ListBox
    Friend WithEvents CheckIt As Button
    Friend WithEvents ReturnHome As Button
End Class
