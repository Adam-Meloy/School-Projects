﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class RandomIntAdd
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.NumberList = New System.Windows.Forms.ListBox()
        Me.NumberGen = New System.Windows.Forms.Button()
        Me.ReturnHome = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'NumberList
        '
        Me.NumberList.FormattingEnabled = True
        Me.NumberList.Location = New System.Drawing.Point(12, 12)
        Me.NumberList.Name = "NumberList"
        Me.NumberList.Size = New System.Drawing.Size(212, 108)
        Me.NumberList.TabIndex = 0
        '
        'NumberGen
        '
        Me.NumberGen.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NumberGen.Location = New System.Drawing.Point(230, 14)
        Me.NumberGen.Name = "NumberGen"
        Me.NumberGen.Size = New System.Drawing.Size(50, 50)
        Me.NumberGen.TabIndex = 1
        Me.NumberGen.Text = "Generate Numbers"
        Me.NumberGen.UseVisualStyleBackColor = True
        '
        'ReturnHome
        '
        Me.ReturnHome.Location = New System.Drawing.Point(230, 70)
        Me.ReturnHome.Name = "ReturnHome"
        Me.ReturnHome.Size = New System.Drawing.Size(50, 50)
        Me.ReturnHome.TabIndex = 2
        Me.ReturnHome.Text = "Home"
        Me.ReturnHome.UseVisualStyleBackColor = True
        '
        'RandomIntAdd
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(292, 124)
        Me.Controls.Add(Me.ReturnHome)
        Me.Controls.Add(Me.NumberGen)
        Me.Controls.Add(Me.NumberList)
        Me.Name = "RandomIntAdd"
        Me.Text = "Random Int Add"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents NumberList As ListBox
    Friend WithEvents NumberGen As Button
    Friend WithEvents ReturnHome As Button
End Class
