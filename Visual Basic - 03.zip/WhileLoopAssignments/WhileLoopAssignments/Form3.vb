﻿Public Class RandomIntAdd
    Dim Number, RandomNumber As Integer
    Private Sub ReturnHome_Click(sender As Object, e As EventArgs) Handles ReturnHome.Click
        Me.Hide()
        Home.Show()
    End Sub
    Private Sub NumberGen_Click(sender As Object, e As EventArgs) Handles NumberGen.Click
        Number = 0
        RandomNumber = 0
        NumberList.Items.Clear()
        Do Until Number >= 17
            Randomize()
            RandomNumber = Int(Rnd() * 6) + 3
            Number += RandomNumber
            NumberList.Items.Add("Random Number is " & RandomNumber & ". The Sum is " & Number & ".")
        Loop
    End Sub
End Class