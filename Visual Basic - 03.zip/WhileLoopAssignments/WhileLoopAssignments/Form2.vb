﻿Public Class NumberLine
    Dim Number As Integer
    Private Sub ReturnHome_Click(sender As Object, e As EventArgs) Handles ReturnHome.Click
        Me.Hide()
        Home.Show()
    End Sub
    Private Sub CheckIt_Click(sender As Object, e As EventArgs) Handles CheckIt.Click
        ListNumbers.Items.Clear()
        Number = InputBox("Enter A Number Between 1 And 10")
        ListNumbers.Items.Add("Number Entered: " & Number)
        If Number < 11 Then
            Do While Number <= 20
                ListNumbers.Items.Add(Number)
                Number += 1
            Loop
        End If
    End Sub
End Class