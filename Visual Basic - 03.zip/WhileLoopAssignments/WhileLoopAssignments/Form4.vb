﻿Public Class SecNum
    Dim Guess, RealNumber, Score As Integer
    Private Sub ReturnHome_Click(sender As Object, e As EventArgs) Handles ReturnHome.Click
        Me.Hide()
        Home.Show()
    End Sub
    Private Sub GuessButton_Click(sender As Object, e As EventArgs) Handles GuessButton.Click
        NumberList.Items.Clear()
        Randomize()
        RealNumber = Int(Rnd() * 99) + 1
        Do While RealNumber = RealNumber
            NumberList.Items.Add("Guess A Number")
            Guess = InputBox("Enter A Number Between 1 And 100")
            NumberList.Items.Add("You Guessed " & Guess)
            Score += 1
            If Guess < RealNumber Then
                NumberList.Items.Add("Number Is Too Low")
            ElseIf Guess > RealNumber Then
                NumberList.Items.Add("Number Is Too High")
            End If
            If RealNumber = Guess Then
                NumberList.Items.Add("Congratulations! You Took " & Score & " Tries!")
                Exit Do
            End If
        Loop
    End Sub
End Class