﻿Public Class ExpList
    Dim Exponent As Integer
    Dim Number As Integer = 0
    Private Sub ReturnHome_Click(sender As Object, e As EventArgs) Handles ReturnHome.Click
        Me.Hide()
        Home.Show()
    End Sub
    Private Sub Exponents_Click(sender As Object, e As EventArgs) Handles Exponents.Click
        NumberList.Items.Clear()
        Number = 0
        Exponent = Number
        Do While Number <= 15
            Exponent = 2 ^ Number
            NumberList.Items.Add("2 ^ " & Number & " = " & Exponent)
            Number += 1
        Loop
    End Sub
End Class