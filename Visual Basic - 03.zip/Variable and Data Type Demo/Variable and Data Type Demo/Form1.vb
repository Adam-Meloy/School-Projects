﻿Public Class Form1
    Private Sub btn1_Click(sender As Object, e As EventArgs) Handles btn1.Click
        If tbxInput1.Text = "" Or tbxInput2.Text = "" Then
            MsgBox("Enter an old score in Textbox 1")
            MsgBox("Enter a new score in Textbox 2")
            Exit Sub
        End If
        MsgBox("Please enter a score (1-100)")
        Dim myOldScore As Integer = tbxInput1.Text
        Dim myNewScore As Integer = 1
        myOldScore = myNewScore
        MsgBox("My old score is " & myOldScore & ".")
        MsgBox("My new score is " & myNewScore & ".")
    End Sub

    Private Sub btn2_Click(sender As Object, e As EventArgs) Handles btn2.Click
        If tbxInput1.Text = "" Or tbxInput2.Text = "" Then
            MsgBox("Enter a price in Textbox 1")
            MsgBox("Enter a second price in Textbox 2")
            Exit Sub
        End If
        MsgBox("Please enter the price for the Sprint's premier data plan.")
        Dim sprintDataPlanPrice As Decimal = tbxInput1.Text
        Dim verizonDataPlanPrice As Decimal = tbxInput2.Text
        Dim cheapestPrice As Decimal
        If sprintDataPlanPrice > verizonDataPlanPrice Then
            cheapestPrice = verizonDataPlanPrice
        Else
            cheapestPrice = sprintDataPlanPrice
        End If
        MsgBox("The cheapest price is " & cheapestPrice)
    End Sub

    Private Sub btn3_Click(sender As Object, e As EventArgs) Handles btn3.Click
        If tbxInput1.Text = "" Or tbxInput2.Text = "" Then
            MsgBox("Enter a famous person's name in Textbox 1")
            MsgBox("Enter a second famous person's name in Textbox 2")
            Exit Sub
        End If
        Dim strRichestMan As String = tbxInput1.Text
        Dim strRichestWoman As String = tbxInput2.Text
        Dim decRichestManNetWorth As Decimal = 99999.99
        Dim decRichestWomanNetWorth As Decimal = 99998.99
        Dim strRichestPerson As String
        If decRichestManNetWorth > decRichestWomanNetWorth Then
            strRichestPerson = strRichestMan
        Else
            strRichestPerson = strRichestWoman
        End If
        MsgBox("The Richest Person is " & strRichestPerson & ".")
    End Sub

    Private Sub btn4_Click(sender As Object, e As EventArgs) Handles btn4.Click
        If tbxInput1.Text = "" Or tbxInput2.Text = "" Then
            MsgBox("Enter a  in Textbox 1")
            MsgBox("Enter a second famous person's name in Textbox 2")
            Exit Sub
        End If
        Dim isHealthyWeight As Boolean
        Dim BMI As Decimal = tbxInput2.Text
        Dim yourName As String = tbxInput1.Text
        If BMI > 18.5 & BMI < 24.9 Then
            isHealthyWeight = True
            MsgBox("Your weight is in a healthy range, " & yourName & ".")
        Else
            isHealthyWeight = False Then
                MsgBox("Your weight is not in a healthy range, " & yourName & ".")
        End If
    End Sub
End Class