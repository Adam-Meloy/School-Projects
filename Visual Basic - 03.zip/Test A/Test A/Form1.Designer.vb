﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.btnGo = New System.Windows.Forms.Button()
        Me.lblComputerNum1 = New System.Windows.Forms.Label()
        Me.lblComputerNum2 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.tbxUserNum3 = New System.Windows.Forms.TextBox()
        Me.tbxUserNum2 = New System.Windows.Forms.TextBox()
        Me.tbxUserNum1 = New System.Windows.Forms.TextBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.lblUser = New System.Windows.Forms.Label()
        Me.lblComputer = New System.Windows.Forms.Label()
        Me.lblUserWinningCount = New System.Windows.Forms.Label()
        Me.lblComputerWinningCount = New System.Windows.Forms.Label()
        Me.btnEndGame = New System.Windows.Forms.Button()
        Me.AI_Number = New System.Windows.Forms.Timer(Me.components)
        Me.VariableConnector = New System.Windows.Forms.Timer(Me.components)
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnGo
        '
        Me.btnGo.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.btnGo.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnGo.Font = New System.Drawing.Font("Microsoft Sans Serif", 27.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnGo.Location = New System.Drawing.Point(144, 291)
        Me.btnGo.Name = "btnGo"
        Me.btnGo.Size = New System.Drawing.Size(146, 71)
        Me.btnGo.TabIndex = 3
        Me.btnGo.Text = "Go"
        Me.btnGo.UseVisualStyleBackColor = False
        '
        'lblComputerNum1
        '
        Me.lblComputerNum1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblComputerNum1.Font = New System.Drawing.Font("Microsoft Sans Serif", 48.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblComputerNum1.Location = New System.Drawing.Point(44, 17)
        Me.lblComputerNum1.Name = "lblComputerNum1"
        Me.lblComputerNum1.Size = New System.Drawing.Size(71, 80)
        Me.lblComputerNum1.TabIndex = 4
        Me.lblComputerNum1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblComputerNum2
        '
        Me.lblComputerNum2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblComputerNum2.Font = New System.Drawing.Font("Microsoft Sans Serif", 48.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblComputerNum2.Location = New System.Drawing.Point(151, 17)
        Me.lblComputerNum2.Name = "lblComputerNum2"
        Me.lblComputerNum2.Size = New System.Drawing.Size(71, 80)
        Me.lblComputerNum2.TabIndex = 5
        Me.lblComputerNum2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.tbxUserNum3)
        Me.GroupBox1.Controls.Add(Me.tbxUserNum2)
        Me.GroupBox1.Controls.Add(Me.tbxUserNum1)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(32, 100)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(392, 100)
        Me.GroupBox1.TabIndex = 6
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Enter 3 numbers (between 1 and 5):"
        '
        'tbxUserNum3
        '
        Me.tbxUserNum3.Location = New System.Drawing.Point(275, 37)
        Me.tbxUserNum3.Multiline = True
        Me.tbxUserNum3.Name = "tbxUserNum3"
        Me.tbxUserNum3.Size = New System.Drawing.Size(96, 42)
        Me.tbxUserNum3.TabIndex = 2
        '
        'tbxUserNum2
        '
        Me.tbxUserNum2.Location = New System.Drawing.Point(138, 37)
        Me.tbxUserNum2.Multiline = True
        Me.tbxUserNum2.Name = "tbxUserNum2"
        Me.tbxUserNum2.Size = New System.Drawing.Size(96, 42)
        Me.tbxUserNum2.TabIndex = 1
        '
        'tbxUserNum1
        '
        Me.tbxUserNum1.Location = New System.Drawing.Point(6, 37)
        Me.tbxUserNum1.Multiline = True
        Me.tbxUserNum1.Name = "tbxUserNum1"
        Me.tbxUserNum1.Size = New System.Drawing.Size(96, 42)
        Me.tbxUserNum1.TabIndex = 0
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.lblComputerNum1)
        Me.GroupBox2.Controls.Add(Me.lblComputerNum2)
        Me.GroupBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.Location = New System.Drawing.Point(456, 100)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(294, 100)
        Me.GroupBox2.TabIndex = 7
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Computer's pick (between 1 and 9):"
        '
        'lblUser
        '
        Me.lblUser.AutoSize = True
        Me.lblUser.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblUser.ForeColor = System.Drawing.Color.DarkRed
        Me.lblUser.Location = New System.Drawing.Point(35, 32)
        Me.lblUser.Name = "lblUser"
        Me.lblUser.Size = New System.Drawing.Size(140, 16)
        Me.lblUser.TabIndex = 8
        Me.lblUser.Text = "Your winning count:"
        '
        'lblComputer
        '
        Me.lblComputer.AutoSize = True
        Me.lblComputer.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblComputer.ForeColor = System.Drawing.Color.DarkRed
        Me.lblComputer.Location = New System.Drawing.Point(453, 32)
        Me.lblComputer.Name = "lblComputer"
        Me.lblComputer.Size = New System.Drawing.Size(186, 16)
        Me.lblComputer.TabIndex = 9
        Me.lblComputer.Text = "Computer's winning count:"
        '
        'lblUserWinningCount
        '
        Me.lblUserWinningCount.AutoSize = True
        Me.lblUserWinningCount.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblUserWinningCount.ForeColor = System.Drawing.Color.DarkRed
        Me.lblUserWinningCount.Location = New System.Drawing.Point(181, 32)
        Me.lblUserWinningCount.Name = "lblUserWinningCount"
        Me.lblUserWinningCount.Size = New System.Drawing.Size(16, 16)
        Me.lblUserWinningCount.TabIndex = 10
        Me.lblUserWinningCount.Text = "0"
        '
        'lblComputerWinningCount
        '
        Me.lblComputerWinningCount.AutoSize = True
        Me.lblComputerWinningCount.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblComputerWinningCount.ForeColor = System.Drawing.Color.DarkRed
        Me.lblComputerWinningCount.Location = New System.Drawing.Point(645, 32)
        Me.lblComputerWinningCount.Name = "lblComputerWinningCount"
        Me.lblComputerWinningCount.Size = New System.Drawing.Size(16, 16)
        Me.lblComputerWinningCount.TabIndex = 11
        Me.lblComputerWinningCount.Text = "0"
        '
        'btnEndGame
        '
        Me.btnEndGame.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.btnEndGame.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnEndGame.Font = New System.Drawing.Font("Microsoft Sans Serif", 27.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEndGame.Location = New System.Drawing.Point(456, 291)
        Me.btnEndGame.Name = "btnEndGame"
        Me.btnEndGame.Size = New System.Drawing.Size(224, 71)
        Me.btnEndGame.TabIndex = 12
        Me.btnEndGame.Text = "End Game"
        Me.btnEndGame.UseVisualStyleBackColor = False
        '
        'AI_Number
        '
        Me.AI_Number.Interval = 10
        '
        'VariableConnector
        '
        Me.VariableConnector.Interval = 1
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(772, 418)
        Me.Controls.Add(Me.btnEndGame)
        Me.Controls.Add(Me.lblComputerWinningCount)
        Me.Controls.Add(Me.lblUserWinningCount)
        Me.Controls.Add(Me.lblComputer)
        Me.Controls.Add(Me.lblUser)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.btnGo)
        Me.Name = "Form1"
        Me.Text = "Number Game"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnGo As Button
    Friend WithEvents lblComputerNum1 As Label
    Friend WithEvents lblComputerNum2 As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents tbxUserNum3 As TextBox
    Friend WithEvents tbxUserNum2 As TextBox
    Friend WithEvents tbxUserNum1 As TextBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents lblUser As Label
    Friend WithEvents lblComputer As Label
    Friend WithEvents lblUserWinningCount As Label
    Friend WithEvents lblComputerWinningCount As Label
    Friend WithEvents btnEndGame As Button
    Friend WithEvents AI_Number As Timer
    Friend WithEvents VariableConnector As Timer
End Class
