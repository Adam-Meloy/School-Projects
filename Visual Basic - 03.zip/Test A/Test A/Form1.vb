﻿Public Class Form1
    Dim AI1, AI2, P1, P2, P3, PS, AIS As Integer
    Private Sub btnEndGame_Click(sender As Object, e As EventArgs) Handles btnEndGame.Click
        Close()
    End Sub
    Private Sub btnGo_Click(sender As Object, e As EventArgs) Handles btnGo.Click
        AI_Number.Enabled = True
        If tbxUserNum1.Text = "" Then
            MsgBox("You Must Enter A Number Between 1 And 5")
        ElseIf tbxUserNum2.Text = "" Then
            MsgBox("You Must Enter A Number Between 1 And 5")
        ElseIf tbxUserNum3.Text = "" Then
            MsgBox("You Must Enter A Number Between 1 And 5")
        ElseIf tbxUserNum1.Text > 5 Or tbxUserNum1.Text < 1 Then
            MsgBox("You Must Enter A Number Between 1 And 5")
        ElseIf tbxUserNum2.Text > 5 Or tbxUserNum2.Text < 1 Then
            MsgBox("You Must Enter A Number Between 1 And 5")
        ElseIf tbxUserNum3.Text > 5 Or tbxUserNum3.Text < 1 Then
            MsgBox("You Must Enter A Number Between 1 And 5")
        End If
        lblComputerNum1.Text = AI1
        lblComputerNum2.Text = AI2
        If (P1 + P2) + P3 > AI1 + AI2 Then
            MsgBox("You Won!")
            PS = PS + 1
            lblUserWinningCount.Text = PS
        ElseIf (P1 + P2) + P3 < AI1 + AI2 Then
            MsgBox("You Lost.")
            AIS = AIS + 1
            lblComputerWinningCount.Text = AIS
        End If
    End Sub
    Private Sub VariableConnector_Tick(sender As Object, e As EventArgs) Handles VariableConnector.Tick
        P1 = tbxUserNum1.Text
        P2 = tbxUserNum2.Text
        P3 = tbxUserNum3.Text
    End Sub
    Private Sub AI_Number_Tick(sender As Object, e As EventArgs) Handles AI_Number.Tick
        Randomize()
        AI1 = Int(Rnd() * 9) + 1
        Randomize()
        AI2 = Int(Rnd() * 9) + 1
    End Sub
End Class
