﻿Public Class UseTheseThing

    Private Sub cboPet_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboPet.SelectedIndexChanged
        If cboPet.Text = "Dog" Then
            lblYouSelected1.Text = "Dog"
        End If
        If cboPet.Text = "Cat" Then
            lblYouSelected1.Text = "Cat"
        End If
        If cboPet.Text = "Fish" Then
            lblYouSelected1.Text = "Fish"
        End If
        If cboPet.Text = "Other" Then
            lblYouSelected1.Text = "Other"
        End If
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Close()
    End Sub

    Private Sub chkCheckOrNot_CheckedChanged(sender As Object, e As EventArgs) Handles chkCheckOrNot.CheckedChanged
        If chkCheckOrNot.Checked = True Then
            chkCheckOrNot.Text = "The Check Box is checked"
        End If
        If chkCheckOrNot.Checked = False Then
            chkCheckOrNot.Text = "The Check Box is un-checked"
        End If
    End Sub

    Private Sub lstVegetables_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lstVegetables.SelectedIndexChanged
        If lstVegetables.Text = "Carrot" Then
            lblYouSelected2.Text = "Carrot"
        End If
        If lstVegetables.Text = "Brocoli" Then
            lblYouSelected2.Text = "Brocoli"
        End If
        If lstVegetables.Text = "Spinach" Then
            lblYouSelected2.Text = "Spinach"
        End If
        If lstVegetables.Text = "Potato" Then
            lblYouSelected2.Text = "Potato"
        End If
    End Sub

    Private Sub rbThin_CheckedChanged(sender As Object, e As EventArgs) Handles rbThin.CheckedChanged
        If rbThin.Checked = True Then
            lblYouSelected3.Text = "Thin Crust"
        End If
    End Sub

    Private Sub rbHandTossed_CheckedChanged(sender As Object, e As EventArgs) Handles rbHandTossed.CheckedChanged
        If rbHandTossed.Checked = True Then
            lblYouSelected3.Text = "Hand Tossed"
        End If
    End Sub

    Private Sub rbDeepDish_CheckedChanged(sender As Object, e As EventArgs) Handles rbDeepDish.CheckedChanged
        If rbDeepDish.Checked = True Then
            lblYouSelected3.Text = "Deep Dish"
        End If
    End Sub

    Private Sub hsbHorizontal_Scroll(sender As Object, e As ScrollEventArgs) Handles hsbHorizontal.Scroll
        lblMoveBar1.Text = "Value: " & hsbHorizontal.Value
    End Sub

    Private Sub vsbVertical_Scroll(sender As Object, e As ScrollEventArgs) Handles vsbVertical.Scroll
        lblMoveBar2.Text = "Value: " & vsbVertical.Value
    End Sub
End Class
