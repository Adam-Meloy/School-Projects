﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class UseTheseThing
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.cboPet = New System.Windows.Forms.ComboBox()
        Me.gbo1 = New System.Windows.Forms.GroupBox()
        Me.gbo2 = New System.Windows.Forms.GroupBox()
        Me.chkCheckOrNot = New System.Windows.Forms.CheckBox()
        Me.gbo3 = New System.Windows.Forms.GroupBox()
        Me.lstVegetables = New System.Windows.Forms.ListBox()
        Me.gbo4 = New System.Windows.Forms.GroupBox()
        Me.rbDeepDish = New System.Windows.Forms.RadioButton()
        Me.rbHandTossed = New System.Windows.Forms.RadioButton()
        Me.rbThin = New System.Windows.Forms.RadioButton()
        Me.gbo5 = New System.Windows.Forms.GroupBox()
        Me.vsbVertical = New System.Windows.Forms.VScrollBar()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.hsbHorizontal = New System.Windows.Forms.HScrollBar()
        Me.gbo6 = New System.Windows.Forms.GroupBox()
        Me.lblMoveBar1 = New System.Windows.Forms.Label()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.lblYouSelectedHeading1 = New System.Windows.Forms.Label()
        Me.lblYouSelectedHeading2 = New System.Windows.Forms.Label()
        Me.lblYouSelectedHeading3 = New System.Windows.Forms.Label()
        Me.lblYouSelected1 = New System.Windows.Forms.Label()
        Me.lblYouSelected2 = New System.Windows.Forms.Label()
        Me.lblYouSelected3 = New System.Windows.Forms.Label()
        Me.lblMoveBar2 = New System.Windows.Forms.Label()
        Me.gbo1.SuspendLayout()
        Me.gbo2.SuspendLayout()
        Me.gbo3.SuspendLayout()
        Me.gbo4.SuspendLayout()
        Me.gbo5.SuspendLayout()
        Me.gbo6.SuspendLayout()
        Me.SuspendLayout()
        '
        'cboPet
        '
        Me.cboPet.FormattingEnabled = True
        Me.cboPet.Items.AddRange(New Object() {"Dog", "Cat", "Fish", "Other"})
        Me.cboPet.Location = New System.Drawing.Point(6, 29)
        Me.cboPet.Name = "cboPet"
        Me.cboPet.Size = New System.Drawing.Size(121, 21)
        Me.cboPet.TabIndex = 0
        '
        'gbo1
        '
        Me.gbo1.Controls.Add(Me.cboPet)
        Me.gbo1.Location = New System.Drawing.Point(12, 87)
        Me.gbo1.Name = "gbo1"
        Me.gbo1.Size = New System.Drawing.Size(134, 73)
        Me.gbo1.TabIndex = 1
        Me.gbo1.TabStop = False
        Me.gbo1.Text = "ComboBox"
        '
        'gbo2
        '
        Me.gbo2.Controls.Add(Me.chkCheckOrNot)
        Me.gbo2.Location = New System.Drawing.Point(152, 87)
        Me.gbo2.Name = "gbo2"
        Me.gbo2.Size = New System.Drawing.Size(180, 73)
        Me.gbo2.TabIndex = 2
        Me.gbo2.TabStop = False
        Me.gbo2.Text = "CheckBox"
        '
        'chkCheckOrNot
        '
        Me.chkCheckOrNot.AutoSize = True
        Me.chkCheckOrNot.Location = New System.Drawing.Point(6, 33)
        Me.chkCheckOrNot.Name = "chkCheckOrNot"
        Me.chkCheckOrNot.Size = New System.Drawing.Size(170, 17)
        Me.chkCheckOrNot.TabIndex = 0
        Me.chkCheckOrNot.Text = "The Check Box is un-checked" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.chkCheckOrNot.UseVisualStyleBackColor = True
        '
        'gbo3
        '
        Me.gbo3.Controls.Add(Me.lstVegetables)
        Me.gbo3.Location = New System.Drawing.Point(339, 87)
        Me.gbo3.Name = "gbo3"
        Me.gbo3.Size = New System.Drawing.Size(128, 101)
        Me.gbo3.TabIndex = 3
        Me.gbo3.TabStop = False
        Me.gbo3.Text = "ListBox"
        '
        'lstVegetables
        '
        Me.lstVegetables.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstVegetables.FormattingEnabled = True
        Me.lstVegetables.ItemHeight = 18
        Me.lstVegetables.Items.AddRange(New Object() {"Carrot", "Brocoli", "Spinach", "Potato"})
        Me.lstVegetables.Location = New System.Drawing.Point(7, 20)
        Me.lstVegetables.Name = "lstVegetables"
        Me.lstVegetables.Size = New System.Drawing.Size(115, 76)
        Me.lstVegetables.TabIndex = 0
        '
        'gbo4
        '
        Me.gbo4.Controls.Add(Me.rbDeepDish)
        Me.gbo4.Controls.Add(Me.rbHandTossed)
        Me.gbo4.Controls.Add(Me.rbThin)
        Me.gbo4.Location = New System.Drawing.Point(12, 206)
        Me.gbo4.Name = "gbo4"
        Me.gbo4.Size = New System.Drawing.Size(200, 100)
        Me.gbo4.TabIndex = 4
        Me.gbo4.TabStop = False
        Me.gbo4.Text = "Radio Buttons"
        '
        'rbDeepDish
        '
        Me.rbDeepDish.AutoSize = True
        Me.rbDeepDish.Location = New System.Drawing.Point(7, 68)
        Me.rbDeepDish.Name = "rbDeepDish"
        Me.rbDeepDish.Size = New System.Drawing.Size(75, 17)
        Me.rbDeepDish.TabIndex = 2
        Me.rbDeepDish.TabStop = True
        Me.rbDeepDish.Text = "Deep Dish"
        Me.rbDeepDish.UseVisualStyleBackColor = True
        '
        'rbHandTossed
        '
        Me.rbHandTossed.AutoSize = True
        Me.rbHandTossed.Location = New System.Drawing.Point(6, 44)
        Me.rbHandTossed.Name = "rbHandTossed"
        Me.rbHandTossed.Size = New System.Drawing.Size(89, 17)
        Me.rbHandTossed.TabIndex = 1
        Me.rbHandTossed.TabStop = True
        Me.rbHandTossed.Text = "Hand Tossed"
        Me.rbHandTossed.UseVisualStyleBackColor = True
        '
        'rbThin
        '
        Me.rbThin.AutoSize = True
        Me.rbThin.Location = New System.Drawing.Point(7, 20)
        Me.rbThin.Name = "rbThin"
        Me.rbThin.Size = New System.Drawing.Size(73, 17)
        Me.rbThin.TabIndex = 0
        Me.rbThin.TabStop = True
        Me.rbThin.Text = "Thin Crust"
        Me.rbThin.UseVisualStyleBackColor = True
        '
        'gbo5
        '
        Me.gbo5.Controls.Add(Me.vsbVertical)
        Me.gbo5.Location = New System.Drawing.Point(12, 341)
        Me.gbo5.Name = "gbo5"
        Me.gbo5.Size = New System.Drawing.Size(74, 114)
        Me.gbo5.TabIndex = 5
        Me.gbo5.TabStop = False
        Me.gbo5.Text = "VScrollbar"
        '
        'vsbVertical
        '
        Me.vsbVertical.Location = New System.Drawing.Point(28, 16)
        Me.vsbVertical.Name = "vsbVertical"
        Me.vsbVertical.Size = New System.Drawing.Size(17, 80)
        Me.vsbVertical.TabIndex = 0
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(413, 387)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(105, 94)
        Me.btnClose.TabIndex = 6
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'hsbHorizontal
        '
        Me.hsbHorizontal.Location = New System.Drawing.Point(61, 20)
        Me.hsbHorizontal.Name = "hsbHorizontal"
        Me.hsbHorizontal.Size = New System.Drawing.Size(80, 17)
        Me.hsbHorizontal.TabIndex = 7
        '
        'gbo6
        '
        Me.gbo6.Controls.Add(Me.hsbHorizontal)
        Me.gbo6.Controls.Add(Me.lblMoveBar1)
        Me.gbo6.Location = New System.Drawing.Point(267, 219)
        Me.gbo6.Name = "gbo6"
        Me.gbo6.Size = New System.Drawing.Size(200, 61)
        Me.gbo6.TabIndex = 5
        Me.gbo6.TabStop = False
        Me.gbo6.Text = "HScrollbar"
        '
        'lblMoveBar1
        '
        Me.lblMoveBar1.AutoSize = True
        Me.lblMoveBar1.Location = New System.Drawing.Point(51, 45)
        Me.lblMoveBar1.Name = "lblMoveBar1"
        Me.lblMoveBar1.Size = New System.Drawing.Size(104, 13)
        Me.lblMoveBar1.TabIndex = 14
        Me.lblMoveBar1.Text = "Move The Scroll Bar"
        '
        'lblTitle
        '
        Me.lblTitle.AutoSize = True
        Me.lblTitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.Location = New System.Drawing.Point(16, 34)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(477, 33)
        Me.lblTitle.TabIndex = 7
        Me.lblTitle.Text = "Experiment With These UI Projects!"
        '
        'lblYouSelectedHeading1
        '
        Me.lblYouSelectedHeading1.AutoSize = True
        Me.lblYouSelectedHeading1.Location = New System.Drawing.Point(9, 163)
        Me.lblYouSelectedHeading1.Name = "lblYouSelectedHeading1"
        Me.lblYouSelectedHeading1.Size = New System.Drawing.Size(74, 13)
        Me.lblYouSelectedHeading1.TabIndex = 8
        Me.lblYouSelectedHeading1.Text = "You Selected:"
        '
        'lblYouSelectedHeading2
        '
        Me.lblYouSelectedHeading2.AutoSize = True
        Me.lblYouSelectedHeading2.Location = New System.Drawing.Point(343, 191)
        Me.lblYouSelectedHeading2.Name = "lblYouSelectedHeading2"
        Me.lblYouSelectedHeading2.Size = New System.Drawing.Size(74, 13)
        Me.lblYouSelectedHeading2.TabIndex = 9
        Me.lblYouSelectedHeading2.Text = "You Selected:"
        '
        'lblYouSelectedHeading3
        '
        Me.lblYouSelectedHeading3.AutoSize = True
        Me.lblYouSelectedHeading3.Location = New System.Drawing.Point(12, 309)
        Me.lblYouSelectedHeading3.Name = "lblYouSelectedHeading3"
        Me.lblYouSelectedHeading3.Size = New System.Drawing.Size(74, 13)
        Me.lblYouSelectedHeading3.TabIndex = 10
        Me.lblYouSelectedHeading3.Text = "You Selected:"
        '
        'lblYouSelected1
        '
        Me.lblYouSelected1.AutoSize = True
        Me.lblYouSelected1.Location = New System.Drawing.Point(89, 163)
        Me.lblYouSelected1.Name = "lblYouSelected1"
        Me.lblYouSelected1.Size = New System.Drawing.Size(0, 13)
        Me.lblYouSelected1.TabIndex = 11
        '
        'lblYouSelected2
        '
        Me.lblYouSelected2.AutoSize = True
        Me.lblYouSelected2.Location = New System.Drawing.Point(422, 191)
        Me.lblYouSelected2.Name = "lblYouSelected2"
        Me.lblYouSelected2.Size = New System.Drawing.Size(0, 13)
        Me.lblYouSelected2.TabIndex = 12
        '
        'lblYouSelected3
        '
        Me.lblYouSelected3.AutoSize = True
        Me.lblYouSelected3.Location = New System.Drawing.Point(89, 309)
        Me.lblYouSelected3.Name = "lblYouSelected3"
        Me.lblYouSelected3.Size = New System.Drawing.Size(0, 13)
        Me.lblYouSelected3.TabIndex = 13
        '
        'lblMoveBar2
        '
        Me.lblMoveBar2.AutoSize = True
        Me.lblMoveBar2.Location = New System.Drawing.Point(9, 458)
        Me.lblMoveBar2.Name = "lblMoveBar2"
        Me.lblMoveBar2.Size = New System.Drawing.Size(104, 13)
        Me.lblMoveBar2.TabIndex = 15
        Me.lblMoveBar2.Text = "Move The Scroll Bar"
        '
        'UseTheseThing
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(530, 493)
        Me.Controls.Add(Me.lblMoveBar2)
        Me.Controls.Add(Me.lblYouSelected3)
        Me.Controls.Add(Me.lblYouSelected2)
        Me.Controls.Add(Me.lblYouSelected1)
        Me.Controls.Add(Me.lblYouSelectedHeading3)
        Me.Controls.Add(Me.lblYouSelectedHeading2)
        Me.Controls.Add(Me.lblYouSelectedHeading1)
        Me.Controls.Add(Me.lblTitle)
        Me.Controls.Add(Me.gbo6)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.gbo5)
        Me.Controls.Add(Me.gbo4)
        Me.Controls.Add(Me.gbo3)
        Me.Controls.Add(Me.gbo2)
        Me.Controls.Add(Me.gbo1)
        Me.Name = "UseTheseThing"
        Me.Text = "Use These Thing"
        Me.gbo1.ResumeLayout(False)
        Me.gbo2.ResumeLayout(False)
        Me.gbo2.PerformLayout()
        Me.gbo3.ResumeLayout(False)
        Me.gbo4.ResumeLayout(False)
        Me.gbo4.PerformLayout()
        Me.gbo5.ResumeLayout(False)
        Me.gbo6.ResumeLayout(False)
        Me.gbo6.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents cboPet As ComboBox
    Friend WithEvents gbo1 As GroupBox
    Friend WithEvents gbo2 As GroupBox
    Friend WithEvents chkCheckOrNot As CheckBox
    Friend WithEvents gbo3 As GroupBox
    Friend WithEvents gbo4 As GroupBox
    Friend WithEvents gbo5 As GroupBox
    Friend WithEvents btnClose As Button
    Friend WithEvents lstVegetables As ListBox
    Friend WithEvents rbDeepDish As RadioButton
    Friend WithEvents rbHandTossed As RadioButton
    Friend WithEvents rbThin As RadioButton
    Friend WithEvents vsbVertical As VScrollBar
    Friend WithEvents hsbHorizontal As HScrollBar
    Friend WithEvents gbo6 As GroupBox
    Friend WithEvents lblTitle As Label
    Friend WithEvents lblYouSelectedHeading1 As Label
    Friend WithEvents lblYouSelectedHeading2 As Label
    Friend WithEvents lblYouSelectedHeading3 As Label
    Friend WithEvents lblYouSelected1 As Label
    Friend WithEvents lblYouSelected2 As Label
    Friend WithEvents lblYouSelected3 As Label
    Friend WithEvents lblMoveBar1 As Label
    Friend WithEvents lblMoveBar2 As Label
End Class
