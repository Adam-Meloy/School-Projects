﻿Public Class Form1
    Dim IRNDM1, IRNDM2, IRNDM3, IRNDM4, IRNDM5, IRNDM7, IRNDM8, IRNDM9, IRNDM10, IRNDM11, PBALL1, PBALL2 As Integer
    Dim Matching As Integer = 0
    Dim GEN1 As Integer = 5
    Dim Gen2 As Integer = 1
    Dim PGen As Integer = 10
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        MsgBox("This is the Powerball simulator. To begin, press randomize or read the instructions.")
    End Sub
    Private Sub ClearTimer_Tick(sender As Object, e As EventArgs) Handles ClearTimer.Tick
        RNDM1.Text = "0"
        RNDM2.Text = "0"
        RNDM3.Text = "0"
        RNDM4.Text = "0"
        RNDM5.Text = "0"
        RNDM6.Text = "0"
        RNDM7.Text = "0"
        RNDM8.Text = "0"
        RNDM9.Text = "0"
        RNDM10.Text = "0"
        RNDM11.Text = "0"
        RNDM12.Text = "0"
        LBLMATCHING.Text = "0"
        Matching = Matching - Matching
    End Sub
    Private Sub BTNEXIT_Click(sender As Object, e As EventArgs) Handles BTNEXIT.Click
        Close()
    End Sub
    Private Sub BTNINSTRUCT_Click(sender As Object, e As EventArgs) Handles BTNINSTRUCT.Click
        MsgBox("If you matched all five numbers and the Powerball, you win the jackpot.
If you matched all five numbers without the Powerball, you win $1,000,000.
If you matched four numbers and the Powerball, you win $10,000.
If you matched four numbers without the Powerball, you win $100.
If you matched three numbers and the Powerball, you win $100.
If you matched three numbers without the Powerball, you win $7.
If you matched two numbers and the Powerball, you win $7.
If you matched one number and the Powerball, you win $4.
If you matched just the Powerball, you win $4.")
    End Sub
    Private Sub BTNGEN_Click(sender As Object, e As EventArgs) Handles BTNGEN.Click
        ClearTimer.Enabled = False
        Randomize()
        IRNDM1 = Int(Rnd() * GEN1) + Gen2
        RNDM1.Text = IRNDM1
        IRNDM2 = Int(Rnd() * GEN1) + Gen2
        RNDM2.Text = IRNDM2
        IRNDM3 = Int(Rnd() * GEN1) + Gen2
        RNDM3.Text = IRNDM3
        IRNDM4 = Int(Rnd() * GEN1) + Gen2
        RNDM4.Text = IRNDM4
        IRNDM5 = Int(Rnd() * GEN1) + Gen2
        RNDM5.Text = IRNDM5
        PBALL1 = Int(Rnd() * PGen) + Gen2
        RNDM6.Text = PBALL1
        IRNDM7 = Int(Rnd() * GEN1) + Gen2
        RNDM7.Text = IRNDM7
        IRNDM8 = Int(Rnd() * GEN1) + Gen2
        RNDM8.Text = IRNDM8
        IRNDM9 = Int(Rnd() * GEN1) + Gen2
        RNDM9.Text = IRNDM9
        IRNDM10 = Int(Rnd() * GEN1) + Gen2
        RNDM10.Text = IRNDM10
        IRNDM11 = Int(Rnd() * GEN1) + Gen2
        RNDM11.Text = IRNDM11
        PBALL2 = Int(Rnd() * PGen) + Gen2
        RNDM12.Text = PBALL2
        If RNDM1.Text = RNDM7.Text Then
            Matching = Matching + 1
            LBLMATCHING.Text = Matching
        ElseIf RNDM2.Text = RNDM8.Text Then
            Matching = Matching + 1
            LBLMATCHING.Text = Matching
        ElseIf RNDM3.Text = RNDM9.Text Then
            Matching = Matching + 1
            LBLMATCHING.Text = Matching
        ElseIf RNDM4.Text = RNDM10.Text Then
            Matching = Matching + 1
            LBLMATCHING.Text = Matching
        ElseIf RNDM5.Text = RNDM11.Text Then
            Matching = Matching + 1
            LBLMATCHING.Text = Matching
        ElseIf RNDM6.Text = RNDM12.Text Then
            Matching = Matching + 1
            LBLMATCHING.Text = Matching
        End If
        If RNDM1.Text = RNDM7.Text & RNDM2.Text = RNDM8.Text & RNDM3.Text = RNDM9.Text & RNDM4.Text = RNDM10.Text & RNDM5.Text = RNDM11.Text & RNDM6.Text = RNDM12.Text Then
            MsgBox("You Won The Jackpot!")
            ClearTimer.Enabled = True
        ElseIf RNDM1.Text = RNDM7.Text & RNDM2.Text = RNDM8.Text & RNDM3.Text = RNDM9.Text & RNDM4.Text = RNDM10.Text & RNDM5.Text = RNDM11.Text Then
            MsgBox("You Won $1,000,000!")
            ClearTimer.Enabled = True
        ElseIf RNDM1.Text = RNDM7.Text & RNDM2.Text = RNDM8.Text & RNDM3.Text = RNDM9.Text & RNDM6.Text = RNDM12.Text Or RNDM1.Text = RNDM7.Text & RNDM2.Text = RNDM8.Text & RNDM4.Text = RNDM10.Text & RNDM6.Text = RNDM12.Text Or RNDM1.Text = RNDM7.Text & RNDM2.Text = RNDM8.Text & RNDM5.Text = RNDM11.Text & RNDM6.Text = RNDM12.Text Or RNDM1.Text = RNDM7.Text & RNDM3.Text = RNDM9.Text & RNDM4.Text = RNDM10.Text & RNDM6.Text = RNDM12.Text Or RNDM1.Text = RNDM7.Text & RNDM3.Text = RNDM9.Text & RNDM5.Text = RNDM11.Text & RNDM6.Text = RNDM12.Text Or RNDM2.Text = RNDM8.Text & RNDM3.Text = RNDM9.Text & RNDM4.Text = RNDM10.Text & RNDM6.Text = RNDM12.Text Or RNDM2.Text = RNDM8.Text & RNDM4.Text = RNDM10.Text & RNDM5.Text = RNDM11.Text & RNDM6.Text = RNDM12.Text Or RNDM3.Text = RNDM9.Text & RNDM4.Text = RNDM10.Text & RNDM5.Text = RNDM11.Text & RNDM6.Text = RNDM12.Text Then
            MsgBox("You Won $10,000!")
            ClearTimer.Enabled = True
        ElseIf RNDM2.Text = RNDM8.Text & RNDM3.Text = RNDM9.Text & RNDM4.Text = RNDM10.Text & RNDM5.Text = RNDM11.Text Or RNDM1.Text = RNDM7.Text & RNDM2.Text = RNDM8.Text & RNDM4.Text = RNDM10.Text & RNDM5.Text = RNDM11.Text Or RNDM1.Text = RNDM7.Text & RNDM3.Text = RNDM9.Text & RNDM4.Text = RNDM10.Text & RNDM5.Text = RNDM11.Text Or RNDM1.Text = RNDM7.Text & RNDM2.Text = RNDM8.Text & RNDM3.Text = RNDM9.Text & RNDM5.Text = RNDM11.Text Or RNDM1.Text = RNDM7.Text & RNDM2.Text = RNDM8.Text & RNDM3.Text = RNDM9.Text & RNDM4.Text = RNDM10.Text Or RNDM1.Text = RNDM7.Text & RNDM2.Text = RNDM8.Text & RNDM6.Text = RNDM12.Text Or RNDM1.Text = RNDM7.Text & RNDM3.Text = RNDM9.Text & RNDM6.Text = RNDM12.Text Or RNDM1.Text = RNDM7.Text & RNDM4.Text = RNDM10.Text & RNDM6.Text = RNDM12.Text Or RNDM1.Text = RNDM7.Text & RNDM5.Text = RNDM11.Text & RNDM6.Text = RNDM12.Text Or RNDM2.Text = RNDM8.Text & RNDM3.Text = RNDM9.Text & RNDM6.Text = RNDM12.Text Or RNDM2.Text = RNDM8.Text & RNDM4.Text = RNDM10.Text & RNDM6.Text = RNDM12.Text Or RNDM2.Text = RNDM8.Text & RNDM5.Text = RNDM11.Text & RNDM6.Text = RNDM12.Text Or RNDM3.Text = RNDM9.Text & RNDM4.Text = RNDM10.Text & RNDM6.Text = RNDM12.Text Or RNDM3.Text = RNDM9.Text & RNDM5.Text = RNDM11.Text & RNDM6.Text = RNDM12.Text Or RNDM4.Text = RNDM10.Text & RNDM5.Text = RNDM11.Text & RNDM6.Text = RNDM12.Text Then
            MsgBox("You Won $100!")
            ClearTimer.Enabled = True
        ElseIf RNDM1.Text = RNDM7.Text & RNDM2.Text = RNDM8.Text Or RNDM1.Text = RNDM7.Text & RNDM3.Text = RNDM9.Text Or RNDM1.Text = RNDM7.Text & RNDM4.Text = RNDM10.Text Or RNDM1.Text = RNDM7.Text & RNDM5.Text = RNDM11.Text Or RNDM2.Text = RNDM8.Text & RNDM3.Text = RNDM9.Text Or RNDM2.Text = RNDM8.Text & RNDM4.Text = RNDM10.Text Or RNDM2.Text = RNDM8.Text & RNDM5.Text = RNDM11.Text Or RNDM3.Text = RNDM9.Text & RNDM4.Text = RNDM10.Text Or RNDM3.Text = RNDM9.Text & RNDM5.Text = RNDM11.Text Or RNDM4.Text = RNDM10.Text & RNDM5.Text = RNDM11.Text Or RNDM1.Text = RNDM7.Text & RNDM2.Text = RNDM8.Text & RNDM6.Text = RNDM12.Text Or RNDM1.Text = RNDM7.Text & RNDM3.Text = RNDM9.Text & RNDM6.Text = RNDM12.Text Or RNDM1.Text = RNDM7.Text & RNDM4.Text = RNDM10.Text & RNDM6.Text = RNDM12.Text Or RNDM1.Text = RNDM7.Text & RNDM5.Text = RNDM11.Text & RNDM6.Text = RNDM12.Text Or RNDM2.Text = RNDM8.Text & RNDM3.Text = RNDM9.Text & RNDM6.Text = RNDM12.Text Or RNDM2.Text = RNDM8.Text & RNDM4.Text = RNDM10.Text & RNDM6.Text = RNDM12.Text Or RNDM2.Text = RNDM8.Text & RNDM5.Text = RNDM11.Text & RNDM6.Text = RNDM12.Text Or RNDM3.Text = RNDM9.Text & RNDM4.Text = RNDM10.Text & RNDM6.Text = RNDM12.Text Or RNDM3.Text = RNDM9.Text & RNDM5.Text = RNDM11.Text & RNDM6.Text = RNDM12.Text Or RNDM4.Text = RNDM10.Text & RNDM5.Text = RNDM11.Text & RNDM6.Text = RNDM12.Text Then
            MsgBox("You Won $7, Better Luck Next Time.")
            ClearTimer.Enabled = True
        ElseIf RNDM1.Text = RNDM7.Text & RNDM6.Text = RNDM12.Text Or RNDM2.Text = RNDM8.Text & RNDM6.Text = RNDM12.Text Or RNDM3.Text = RNDM9.Text & RNDM6.Text = RNDM12.Text Or RNDM4.Text = RNDM10.Text & RNDM6.Text = RNDM12.Text Or RNDM5.Text = RNDM11.Text & RNDM6.Text = RNDM12.Text Then
            MsgBox("You Won $4, Better Luck Next Time.")
            ClearTimer.Enabled = True
        ElseIf RNDM1.Text < RNDM7.Text Or RNDM1.Text > RNDM7.Text Or RNDM2.Text < RNDM8.Text Or RNDM2.Text > RNDM8.Text Or RNDM3.Text < RNDM9.Text Or RNDM3.Text > RNDM9.Text Or RNDM4.Text < RNDM10.Text Or RNDM4.Text > RNDM10.Text Or RNDM5.Text < RNDM11.Text Or RNDM5.Text > RNDM11.Text Then
            MsgBox("You Won Nothing. Try Again Later!")
            ClearTimer.Enabled = True
        ElseIf RNDM1.Text = RNDM7.Text Or RNDM2.Text = RNDM8.Text Or RNDM3.Text = RNDM9.Text Or RNDM4.Text = RNDM10.Text Or RNDM5.Text = RNDM11.Text Then
            MsgBox("You Won Nothing. Try Again Later!")
            ClearTimer.Enabled = True
        End If
    End Sub
End Class