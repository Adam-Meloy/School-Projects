﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.RNDM1 = New System.Windows.Forms.Label()
        Me.BTNINSTRUCT = New System.Windows.Forms.Button()
        Me.POWERBALL = New System.Windows.Forms.PictureBox()
        Me.RNDM2 = New System.Windows.Forms.Label()
        Me.RNDM3 = New System.Windows.Forms.Label()
        Me.RNDM4 = New System.Windows.Forms.Label()
        Me.RNDM5 = New System.Windows.Forms.Label()
        Me.RNDM6 = New System.Windows.Forms.Label()
        Me.RNDM7 = New System.Windows.Forms.Label()
        Me.RNDM8 = New System.Windows.Forms.Label()
        Me.RNDM9 = New System.Windows.Forms.Label()
        Me.RNDM10 = New System.Windows.Forms.Label()
        Me.RNDM11 = New System.Windows.Forms.Label()
        Me.RNDM12 = New System.Windows.Forms.Label()
        Me.LBLM = New System.Windows.Forms.Label()
        Me.BTNGEN = New System.Windows.Forms.Button()
        Me.BTNCLEAR = New System.Windows.Forms.Button()
        Me.BTNEXIT = New System.Windows.Forms.Button()
        Me.LBLMATCHING = New System.Windows.Forms.Label()
        Me.ClearTimer = New System.Windows.Forms.Timer(Me.components)
        CType(Me.POWERBALL, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'RNDM1
        '
        Me.RNDM1.AutoSize = True
        Me.RNDM1.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RNDM1.Location = New System.Drawing.Point(12, 168)
        Me.RNDM1.Name = "RNDM1"
        Me.RNDM1.Size = New System.Drawing.Size(26, 29)
        Me.RNDM1.TabIndex = 0
        Me.RNDM1.Text = "0"
        '
        'BTNINSTRUCT
        '
        Me.BTNINSTRUCT.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTNINSTRUCT.Location = New System.Drawing.Point(17, 236)
        Me.BTNINSTRUCT.Name = "BTNINSTRUCT"
        Me.BTNINSTRUCT.Size = New System.Drawing.Size(75, 81)
        Me.BTNINSTRUCT.TabIndex = 1
        Me.BTNINSTRUCT.Text = "Instructions"
        Me.BTNINSTRUCT.UseVisualStyleBackColor = True
        '
        'POWERBALL
        '
        Me.POWERBALL.Image = Global.PowerBallSimulator.My.Resources.Resources.images
        Me.POWERBALL.Location = New System.Drawing.Point(13, 13)
        Me.POWERBALL.Name = "POWERBALL"
        Me.POWERBALL.Size = New System.Drawing.Size(382, 87)
        Me.POWERBALL.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.POWERBALL.TabIndex = 2
        Me.POWERBALL.TabStop = False
        '
        'RNDM2
        '
        Me.RNDM2.AutoSize = True
        Me.RNDM2.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RNDM2.Location = New System.Drawing.Point(71, 168)
        Me.RNDM2.Name = "RNDM2"
        Me.RNDM2.Size = New System.Drawing.Size(26, 29)
        Me.RNDM2.TabIndex = 3
        Me.RNDM2.Text = "0"
        '
        'RNDM3
        '
        Me.RNDM3.AutoSize = True
        Me.RNDM3.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RNDM3.Location = New System.Drawing.Point(138, 168)
        Me.RNDM3.Name = "RNDM3"
        Me.RNDM3.Size = New System.Drawing.Size(26, 29)
        Me.RNDM3.TabIndex = 4
        Me.RNDM3.Text = "0"
        '
        'RNDM4
        '
        Me.RNDM4.AutoSize = True
        Me.RNDM4.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RNDM4.Location = New System.Drawing.Point(208, 168)
        Me.RNDM4.Name = "RNDM4"
        Me.RNDM4.Size = New System.Drawing.Size(26, 29)
        Me.RNDM4.TabIndex = 5
        Me.RNDM4.Text = "0"
        '
        'RNDM5
        '
        Me.RNDM5.AutoSize = True
        Me.RNDM5.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RNDM5.Location = New System.Drawing.Point(287, 168)
        Me.RNDM5.Name = "RNDM5"
        Me.RNDM5.Size = New System.Drawing.Size(26, 29)
        Me.RNDM5.TabIndex = 6
        Me.RNDM5.Text = "0"
        '
        'RNDM6
        '
        Me.RNDM6.AutoSize = True
        Me.RNDM6.BackColor = System.Drawing.Color.Red
        Me.RNDM6.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RNDM6.ForeColor = System.Drawing.Color.Black
        Me.RNDM6.Location = New System.Drawing.Point(356, 168)
        Me.RNDM6.Name = "RNDM6"
        Me.RNDM6.Size = New System.Drawing.Size(26, 29)
        Me.RNDM6.TabIndex = 7
        Me.RNDM6.Text = "0"
        '
        'RNDM7
        '
        Me.RNDM7.AutoSize = True
        Me.RNDM7.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RNDM7.Location = New System.Drawing.Point(12, 332)
        Me.RNDM7.Name = "RNDM7"
        Me.RNDM7.Size = New System.Drawing.Size(26, 29)
        Me.RNDM7.TabIndex = 8
        Me.RNDM7.Text = "0"
        '
        'RNDM8
        '
        Me.RNDM8.AutoSize = True
        Me.RNDM8.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RNDM8.Location = New System.Drawing.Point(71, 332)
        Me.RNDM8.Name = "RNDM8"
        Me.RNDM8.Size = New System.Drawing.Size(26, 29)
        Me.RNDM8.TabIndex = 9
        Me.RNDM8.Text = "0"
        '
        'RNDM9
        '
        Me.RNDM9.AutoSize = True
        Me.RNDM9.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RNDM9.Location = New System.Drawing.Point(138, 332)
        Me.RNDM9.Name = "RNDM9"
        Me.RNDM9.Size = New System.Drawing.Size(26, 29)
        Me.RNDM9.TabIndex = 10
        Me.RNDM9.Text = "0"
        '
        'RNDM10
        '
        Me.RNDM10.AutoSize = True
        Me.RNDM10.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RNDM10.Location = New System.Drawing.Point(208, 332)
        Me.RNDM10.Name = "RNDM10"
        Me.RNDM10.Size = New System.Drawing.Size(26, 29)
        Me.RNDM10.TabIndex = 11
        Me.RNDM10.Text = "0"
        '
        'RNDM11
        '
        Me.RNDM11.AutoSize = True
        Me.RNDM11.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RNDM11.Location = New System.Drawing.Point(287, 332)
        Me.RNDM11.Name = "RNDM11"
        Me.RNDM11.Size = New System.Drawing.Size(26, 29)
        Me.RNDM11.TabIndex = 12
        Me.RNDM11.Text = "0"
        '
        'RNDM12
        '
        Me.RNDM12.AutoSize = True
        Me.RNDM12.BackColor = System.Drawing.Color.Red
        Me.RNDM12.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RNDM12.Location = New System.Drawing.Point(356, 332)
        Me.RNDM12.Name = "RNDM12"
        Me.RNDM12.Size = New System.Drawing.Size(26, 29)
        Me.RNDM12.TabIndex = 13
        Me.RNDM12.Text = "0"
        '
        'LBLM
        '
        Me.LBLM.AutoSize = True
        Me.LBLM.Location = New System.Drawing.Point(23, 103)
        Me.LBLM.Name = "LBLM"
        Me.LBLM.Size = New System.Drawing.Size(54, 13)
        Me.LBLM.TabIndex = 14
        Me.LBLM.Text = "Matching:"
        '
        'BTNGEN
        '
        Me.BTNGEN.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTNGEN.Location = New System.Drawing.Point(116, 236)
        Me.BTNGEN.Name = "BTNGEN"
        Me.BTNGEN.Size = New System.Drawing.Size(75, 81)
        Me.BTNGEN.TabIndex = 15
        Me.BTNGEN.Text = "Generate"
        Me.BTNGEN.UseVisualStyleBackColor = True
        '
        'BTNCLEAR
        '
        Me.BTNCLEAR.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTNCLEAR.Location = New System.Drawing.Point(213, 236)
        Me.BTNCLEAR.Name = "BTNCLEAR"
        Me.BTNCLEAR.Size = New System.Drawing.Size(75, 81)
        Me.BTNCLEAR.TabIndex = 16
        Me.BTNCLEAR.Text = "Clear"
        Me.BTNCLEAR.UseVisualStyleBackColor = True
        '
        'BTNEXIT
        '
        Me.BTNEXIT.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTNEXIT.Location = New System.Drawing.Point(307, 236)
        Me.BTNEXIT.Name = "BTNEXIT"
        Me.BTNEXIT.Size = New System.Drawing.Size(75, 81)
        Me.BTNEXIT.TabIndex = 17
        Me.BTNEXIT.Text = "Exit"
        Me.BTNEXIT.UseVisualStyleBackColor = True
        '
        'LBLMATCHING
        '
        Me.LBLMATCHING.AutoSize = True
        Me.LBLMATCHING.Location = New System.Drawing.Point(73, 103)
        Me.LBLMATCHING.Name = "LBLMATCHING"
        Me.LBLMATCHING.Size = New System.Drawing.Size(13, 13)
        Me.LBLMATCHING.TabIndex = 18
        Me.LBLMATCHING.Text = "0"
        '
        'ClearTimer
        '
        Me.ClearTimer.Interval = 1
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(407, 430)
        Me.Controls.Add(Me.LBLMATCHING)
        Me.Controls.Add(Me.BTNEXIT)
        Me.Controls.Add(Me.BTNCLEAR)
        Me.Controls.Add(Me.BTNGEN)
        Me.Controls.Add(Me.LBLM)
        Me.Controls.Add(Me.RNDM12)
        Me.Controls.Add(Me.RNDM11)
        Me.Controls.Add(Me.RNDM10)
        Me.Controls.Add(Me.RNDM9)
        Me.Controls.Add(Me.RNDM8)
        Me.Controls.Add(Me.RNDM7)
        Me.Controls.Add(Me.RNDM6)
        Me.Controls.Add(Me.RNDM5)
        Me.Controls.Add(Me.RNDM4)
        Me.Controls.Add(Me.RNDM3)
        Me.Controls.Add(Me.RNDM2)
        Me.Controls.Add(Me.POWERBALL)
        Me.Controls.Add(Me.BTNINSTRUCT)
        Me.Controls.Add(Me.RNDM1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.POWERBALL, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents RNDM1 As Label
    Friend WithEvents BTNINSTRUCT As Button
    Friend WithEvents POWERBALL As PictureBox
    Friend WithEvents RNDM2 As Label
    Friend WithEvents RNDM3 As Label
    Friend WithEvents RNDM4 As Label
    Friend WithEvents RNDM5 As Label
    Friend WithEvents RNDM6 As Label
    Friend WithEvents RNDM7 As Label
    Friend WithEvents RNDM8 As Label
    Friend WithEvents RNDM9 As Label
    Friend WithEvents RNDM10 As Label
    Friend WithEvents RNDM11 As Label
    Friend WithEvents RNDM12 As Label
    Friend WithEvents LBLM As Label
    Friend WithEvents BTNGEN As Button
    Friend WithEvents BTNCLEAR As Button
    Friend WithEvents BTNEXIT As Button
    Friend WithEvents LBLMATCHING As Label
    Friend WithEvents ClearTimer As Timer
End Class
