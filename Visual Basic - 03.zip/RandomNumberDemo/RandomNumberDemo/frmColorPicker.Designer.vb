﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmColorPicker
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lsbColors = New System.Windows.Forms.ListBox()
        Me.lblPickFromList = New System.Windows.Forms.Label()
        Me.btnGenRandColor = New System.Windows.Forms.Button()
        Me.lblGenRandColor = New System.Windows.Forms.Label()
        Me.btnLeave = New System.Windows.Forms.Button()
        Me.SeizureTimer = New System.Windows.Forms.Timer(Me.components)
        Me.btnTimer = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lsbColors
        '
        Me.lsbColors.BackColor = System.Drawing.SystemColors.InfoText
        Me.lsbColors.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lsbColors.ForeColor = System.Drawing.SystemColors.Info
        Me.lsbColors.FormattingEnabled = True
        Me.lsbColors.ItemHeight = 24
        Me.lsbColors.Items.AddRange(New Object() {"Red", "Blue", "Green", "Yellow", "Black", "Pink"})
        Me.lsbColors.Location = New System.Drawing.Point(79, 64)
        Me.lsbColors.Name = "lsbColors"
        Me.lsbColors.Size = New System.Drawing.Size(174, 148)
        Me.lsbColors.TabIndex = 2
        '
        'lblPickFromList
        '
        Me.lblPickFromList.AutoSize = True
        Me.lblPickFromList.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPickFromList.ForeColor = System.Drawing.SystemColors.Control
        Me.lblPickFromList.Location = New System.Drawing.Point(80, 36)
        Me.lblPickFromList.Name = "lblPickFromList"
        Me.lblPickFromList.Size = New System.Drawing.Size(274, 25)
        Me.lblPickFromList.TabIndex = 3
        Me.lblPickFromList.Text = "Pick a color from the list:"
        '
        'btnGenRandColor
        '
        Me.btnGenRandColor.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.btnGenRandColor.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnGenRandColor.ForeColor = System.Drawing.SystemColors.Control
        Me.btnGenRandColor.Location = New System.Drawing.Point(85, 360)
        Me.btnGenRandColor.Name = "btnGenRandColor"
        Me.btnGenRandColor.Size = New System.Drawing.Size(214, 97)
        Me.btnGenRandColor.TabIndex = 9
        Me.btnGenRandColor.Text = "Generate a random color"
        Me.btnGenRandColor.UseVisualStyleBackColor = False
        '
        'lblGenRandColor
        '
        Me.lblGenRandColor.AutoSize = True
        Me.lblGenRandColor.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGenRandColor.ForeColor = System.Drawing.SystemColors.Control
        Me.lblGenRandColor.Location = New System.Drawing.Point(80, 309)
        Me.lblGenRandColor.Name = "lblGenRandColor"
        Me.lblGenRandColor.Size = New System.Drawing.Size(536, 25)
        Me.lblGenRandColor.TabIndex = 10
        Me.lblGenRandColor.Text = "Click the button below to generate a random color"
        '
        'btnLeave
        '
        Me.btnLeave.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.btnLeave.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLeave.ForeColor = System.Drawing.SystemColors.Control
        Me.btnLeave.Location = New System.Drawing.Point(402, 351)
        Me.btnLeave.Name = "btnLeave"
        Me.btnLeave.Size = New System.Drawing.Size(214, 97)
        Me.btnLeave.TabIndex = 11
        Me.btnLeave.Text = "Leave"
        Me.btnLeave.UseVisualStyleBackColor = False
        '
        'SeizureTimer
        '
        Me.SeizureTimer.Interval = 1
        '
        'btnTimer
        '
        Me.btnTimer.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.btnTimer.ForeColor = System.Drawing.SystemColors.Control
        Me.btnTimer.Location = New System.Drawing.Point(12, 523)
        Me.btnTimer.Name = "btnTimer"
        Me.btnTimer.Size = New System.Drawing.Size(75, 23)
        Me.btnTimer.TabIndex = 12
        Me.btnTimer.Text = "Timer"
        Me.btnTimer.UseVisualStyleBackColor = False
        '
        'frmColorPicker
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.ClientSize = New System.Drawing.Size(685, 558)
        Me.Controls.Add(Me.btnTimer)
        Me.Controls.Add(Me.btnLeave)
        Me.Controls.Add(Me.lblGenRandColor)
        Me.Controls.Add(Me.btnGenRandColor)
        Me.Controls.Add(Me.lblPickFromList)
        Me.Controls.Add(Me.lsbColors)
        Me.Name = "frmColorPicker"
        Me.Text = "Random Color"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lsbColors As System.Windows.Forms.ListBox
    Friend WithEvents lblPickFromList As System.Windows.Forms.Label
    Friend WithEvents btnGenRandColor As System.Windows.Forms.Button
    Friend WithEvents lblGenRandColor As System.Windows.Forms.Label
    Friend WithEvents btnLeave As Button
    Friend WithEvents SeizureTimer As Timer
    Friend WithEvents btnTimer As Button
End Class
