﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class main
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.rbGenNumFromRange = New System.Windows.Forms.RadioButton()
        Me.rbColorPicker = New System.Windows.Forms.RadioButton()
        Me.rbDiceRoll = New System.Windows.Forms.RadioButton()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.rbGenNumFromRange)
        Me.GroupBox1.Controls.Add(Me.rbColorPicker)
        Me.GroupBox1.Controls.Add(Me.rbDiceRoll)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(39, 53)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox1.Size = New System.Drawing.Size(433, 225)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Random Number Demo Options:"
        '
        'rbGenNumFromRange
        '
        Me.rbGenNumFromRange.AutoSize = True
        Me.rbGenNumFromRange.Location = New System.Drawing.Point(22, 53)
        Me.rbGenNumFromRange.Margin = New System.Windows.Forms.Padding(2)
        Me.rbGenNumFromRange.Name = "rbGenNumFromRange"
        Me.rbGenNumFromRange.Size = New System.Drawing.Size(390, 28)
        Me.rbGenNumFromRange.TabIndex = 4
        Me.rbGenNumFromRange.Text = "Generate a number from a given range"
        Me.rbGenNumFromRange.UseVisualStyleBackColor = True
        '
        'rbColorPicker
        '
        Me.rbColorPicker.AutoSize = True
        Me.rbColorPicker.Location = New System.Drawing.Point(22, 151)
        Me.rbColorPicker.Margin = New System.Windows.Forms.Padding(2)
        Me.rbColorPicker.Name = "rbColorPicker"
        Me.rbColorPicker.Size = New System.Drawing.Size(142, 28)
        Me.rbColorPicker.TabIndex = 3
        Me.rbColorPicker.Text = "Color Picker"
        Me.rbColorPicker.UseVisualStyleBackColor = True
        '
        'rbDiceRoll
        '
        Me.rbDiceRoll.AutoSize = True
        Me.rbDiceRoll.Location = New System.Drawing.Point(22, 100)
        Me.rbDiceRoll.Margin = New System.Windows.Forms.Padding(2)
        Me.rbDiceRoll.Name = "rbDiceRoll"
        Me.rbDiceRoll.Size = New System.Drawing.Size(112, 28)
        Me.rbDiceRoll.TabIndex = 1
        Me.rbDiceRoll.Text = "Dice Roll"
        Me.rbDiceRoll.UseVisualStyleBackColor = True
        '
        'main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(501, 392)
        Me.Controls.Add(Me.GroupBox1)
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "main"
        Me.Text = "main"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents rbDiceRoll As System.Windows.Forms.RadioButton
    Friend WithEvents rbColorPicker As System.Windows.Forms.RadioButton
    Friend WithEvents rbGenNumFromRange As System.Windows.Forms.RadioButton
End Class
