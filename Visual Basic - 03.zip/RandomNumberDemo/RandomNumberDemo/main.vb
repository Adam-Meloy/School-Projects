﻿Public Class main

    Private Sub btnDiceRoll_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles rbDiceRoll.CheckedChanged
        If rbDiceRoll.Checked = True Then
            Me.Hide()
            frmDiceRoll.Show()
        End If
    End Sub

    Private Sub rbGenNumFromRange_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles rbGenNumFromRange.CheckedChanged
        If rbGenNumFromRange.Checked = True Then
            Me.Hide()
            frmGenerateNumberFromRange.Show()
        End If
    End Sub

    Private Sub rbColorPicker_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles rbColorPicker.CheckedChanged
        If rbColorPicker.Checked = True Then
            Me.Hide()
            frmColorPicker.Show()
        End If
    End Sub

End Class