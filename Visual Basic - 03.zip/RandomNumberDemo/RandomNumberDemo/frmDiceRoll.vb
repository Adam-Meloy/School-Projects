﻿Public Class frmDiceRoll
    Dim Lowest As Integer = 1
    Dim Highest As Integer = 6
    Dim IntRandom As Integer
    Dim intCount1, intCount2, intCount3, intCount4, intCount5, intCount6 As Integer

    Private Sub btnLeave_Click(sender As Object, e As EventArgs) Handles btnLeave.Click
        Me.Close()
        main.Show()
    End Sub

    Private Sub btnRoll_Click(sender As System.Object, e As System.EventArgs) Handles btnRoll.Click
        IntRandom = Int(Rnd() * Highest) + Lowest
        MsgBox(IntRandom)
        If IntRandom = 1 Then
            intCount1 = intCount1 + 1
            lblCount1.Text = intCount1
            pbxDie.Image = My.Resources.One
        ElseIf IntRandom = 2 Then
            intCount2 = intCount2 + 1
            lblCount2.Text = intCount2
            pbxDie.Image = My.Resources.Two
        ElseIf IntRandom = 3 Then
            intCount3 = intCount3 + 1
            lblCount3.Text = intCount3
            pbxDie.Image = My.Resources.Three
        ElseIf IntRandom = 4 Then
            intCount4 = intCount4 + 1
            lblCount4.Text = intCount4
            pbxDie.Image = My.Resources.Four
        ElseIf IntRandom = 5 Then
            intCount5 = intCount5 + 1
            lblCount5.Text = intCount5
            pbxDie.Image = My.Resources.Five
        ElseIf IntRandom = 6 Then
            intCount6 = intCount6 + 1
            lblCount6.Text = intCount6
            pbxDie.Image = My.Resources.Six
        End If

    End Sub

End Class
