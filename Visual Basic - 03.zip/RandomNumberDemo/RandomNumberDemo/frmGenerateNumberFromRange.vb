﻿Public Class frmGenerateNumberFromRange

    Private Sub btnLeave_Click(sender As Object, e As EventArgs) Handles btnLeave.Click
        Me.Close()
        main.Show()
    End Sub

    Private Sub btnClear_Click(sender As System.Object, e As System.EventArgs) Handles btnClear.Click
        tbxHighestNumber.Clear()
        tbxLowestNumber.Clear()
        lblDisplayRandomNumber.Text = ""
    End Sub

    Private Sub btnPickNumber_Click(sender As System.Object, e As System.EventArgs) Handles btnPickNumber.Click
        Dim Lowest As Decimal = tbxLowestNumber.Text
        Dim Highest As Decimal = tbxHighestNumber.Text
        If tbxLowestNumber.Text = "" Then
            MsgBox("Enter a number into the textbox!")
        ElseIf Lowest > Highest Then
            MsgBox("THE NUMBERS ARE IN THE WRONG SPOT!")
        Else
            Dim HowMany As Decimal = (Highest - Lowest) + 1
            Dim IntRandom As Decimal = Int(Rnd() * HowMany) + Lowest
            lblDisplayRandomNumber.Text = IntRandom
        End If
    End Sub

End Class