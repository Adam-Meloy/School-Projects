﻿Public Class frmColorPicker
    Dim randomColor As Color
    Dim intRandomForRed, intRandomForGreen, intRandomForBlue As Integer

    Private Sub Btnleave_Click(sender As Object, e As EventArgs) Handles btnLeave.Click
        Me.Close()
        main.Show()
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles SeizureTimer.Tick
        Randomize()
        intRandomForRed = Int(Rnd() * 255) + 0
        Randomize()
        intRandomForGreen = Int(Rnd() * 255) + 0
        Randomize()
        intRandomForBlue = Int(Rnd() * 255) + 0
        randomColor = Color.FromArgb(intRandomForRed, intRandomForGreen, intRandomForBlue)
        Me.BackColor = randomColor
    End Sub

    Private Sub btnTimer_Click(sender As Object, e As EventArgs) Handles btnTimer.Click
        SeizureTimer.Enabled = True
    End Sub

    Private Sub lsbColors_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lsbColors.SelectedIndexChanged
        If lsbColors.Text = "Red" Then
            Me.BackColor = Color.Red
        ElseIf lsbColors.Text = "Green" Then
            Me.BackColor = Color.Green
        ElseIf lsbColors.Text = "Blue" Then
            Me.BackColor = Color.Blue
        ElseIf lsbColors.Text = "Yellow" Then
            Me.BackColor = Color.Yellow
        ElseIf lsbColors.Text = "Black" Then
            Me.BackColor = Color.Black
        ElseIf lsbColors.Text = "Pink" Then
            Me.BackColor = Color.Pink
        End If
    End Sub

    Private Sub btnGenRandColor_Click(sender As Object, e As EventArgs) Handles btnGenRandColor.Click
        Randomize()
        intRandomForRed = Int(Rnd() * 255) + 0
        Randomize()
        intRandomForGreen = Int(Rnd() * 255) + 0
        Randomize()
        intRandomForBlue = Int(Rnd() * 255) + 0
        randomColor = Color.FromArgb(intRandomForRed, intRandomForGreen, intRandomForBlue)
        Me.BackColor = randomColor
    End Sub

End Class