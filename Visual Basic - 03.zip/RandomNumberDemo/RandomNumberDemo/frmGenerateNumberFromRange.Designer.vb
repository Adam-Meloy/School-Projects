﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmGenerateNumberFromRange
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnPickNumber = New System.Windows.Forms.Button()
        Me.lblLowestNumber = New System.Windows.Forms.Label()
        Me.tbxLowestNumber = New System.Windows.Forms.TextBox()
        Me.tbxHighestNumber = New System.Windows.Forms.TextBox()
        Me.lblHighestNumber = New System.Windows.Forms.Label()
        Me.lblRandomNumber = New System.Windows.Forms.Label()
        Me.lblDisplayRandomNumber = New System.Windows.Forms.Label()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnLeave = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnPickNumber
        '
        Me.btnPickNumber.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPickNumber.Location = New System.Drawing.Point(77, 311)
        Me.btnPickNumber.Name = "btnPickNumber"
        Me.btnPickNumber.Size = New System.Drawing.Size(229, 78)
        Me.btnPickNumber.TabIndex = 1
        Me.btnPickNumber.Text = "Pick a number from the above range"
        Me.btnPickNumber.UseVisualStyleBackColor = True
        '
        'lblLowestNumber
        '
        Me.lblLowestNumber.AutoSize = True
        Me.lblLowestNumber.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLowestNumber.Location = New System.Drawing.Point(81, 56)
        Me.lblLowestNumber.Name = "lblLowestNumber"
        Me.lblLowestNumber.Size = New System.Drawing.Size(174, 25)
        Me.lblLowestNumber.TabIndex = 2
        Me.lblLowestNumber.Text = "Lowest Number"
        '
        'tbxLowestNumber
        '
        Me.tbxLowestNumber.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbxLowestNumber.Location = New System.Drawing.Point(308, 56)
        Me.tbxLowestNumber.Name = "tbxLowestNumber"
        Me.tbxLowestNumber.Size = New System.Drawing.Size(134, 31)
        Me.tbxLowestNumber.TabIndex = 3
        '
        'tbxHighestNumber
        '
        Me.tbxHighestNumber.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbxHighestNumber.Location = New System.Drawing.Point(308, 148)
        Me.tbxHighestNumber.Name = "tbxHighestNumber"
        Me.tbxHighestNumber.Size = New System.Drawing.Size(134, 31)
        Me.tbxHighestNumber.TabIndex = 5
        '
        'lblHighestNumber
        '
        Me.lblHighestNumber.AutoSize = True
        Me.lblHighestNumber.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHighestNumber.Location = New System.Drawing.Point(81, 148)
        Me.lblHighestNumber.Name = "lblHighestNumber"
        Me.lblHighestNumber.Size = New System.Drawing.Size(180, 25)
        Me.lblHighestNumber.TabIndex = 4
        Me.lblHighestNumber.Text = "Highest Number"
        '
        'lblRandomNumber
        '
        Me.lblRandomNumber.AutoSize = True
        Me.lblRandomNumber.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRandomNumber.Location = New System.Drawing.Point(81, 234)
        Me.lblRandomNumber.Name = "lblRandomNumber"
        Me.lblRandomNumber.Size = New System.Drawing.Size(225, 25)
        Me.lblRandomNumber.TabIndex = 6
        Me.lblRandomNumber.Text = "Random Number is: "
        '
        'lblDisplayRandomNumber
        '
        Me.lblDisplayRandomNumber.AutoSize = True
        Me.lblDisplayRandomNumber.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDisplayRandomNumber.Location = New System.Drawing.Point(312, 234)
        Me.lblDisplayRandomNumber.Name = "lblDisplayRandomNumber"
        Me.lblDisplayRandomNumber.Size = New System.Drawing.Size(48, 25)
        Me.lblDisplayRandomNumber.TabIndex = 7
        Me.lblDisplayRandomNumber.Text = "xxx"
        '
        'btnClear
        '
        Me.btnClear.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClear.Location = New System.Drawing.Point(328, 311)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(229, 78)
        Me.btnClear.TabIndex = 8
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnLeave
        '
        Me.btnLeave.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold)
        Me.btnLeave.Location = New System.Drawing.Point(191, 396)
        Me.btnLeave.Name = "btnLeave"
        Me.btnLeave.Size = New System.Drawing.Size(242, 76)
        Me.btnLeave.TabIndex = 9
        Me.btnLeave.Text = "Leave"
        Me.btnLeave.UseVisualStyleBackColor = True
        '
        'frmGenerateNumberFromRange
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(601, 484)
        Me.Controls.Add(Me.btnLeave)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.lblDisplayRandomNumber)
        Me.Controls.Add(Me.lblRandomNumber)
        Me.Controls.Add(Me.tbxHighestNumber)
        Me.Controls.Add(Me.lblHighestNumber)
        Me.Controls.Add(Me.tbxLowestNumber)
        Me.Controls.Add(Me.lblLowestNumber)
        Me.Controls.Add(Me.btnPickNumber)
        Me.Name = "frmGenerateNumberFromRange"
        Me.Text = "Pick a Number from a range"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnPickNumber As System.Windows.Forms.Button
    Friend WithEvents lblLowestNumber As System.Windows.Forms.Label
    Friend WithEvents tbxLowestNumber As System.Windows.Forms.TextBox
    Friend WithEvents tbxHighestNumber As System.Windows.Forms.TextBox
    Friend WithEvents lblHighestNumber As System.Windows.Forms.Label
    Friend WithEvents lblRandomNumber As System.Windows.Forms.Label
    Friend WithEvents lblDisplayRandomNumber As System.Windows.Forms.Label
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents btnLeave As Button
End Class
