﻿Public Class FrmCalculator
    Dim decResult, decNum1, decNum2 As Decimal
    Dim strNum1, strNum2 As String

    Private Sub FrmCalculator_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        MsgBox("Please Enter Numbers In Textboxes 1 And 2 Before Selecting An Operation!")
        lblOperation.Text = " "
        lblResult.Text = " "
    End Sub

    Private Sub btnAdd_Click(sender As System.Object, e As System.EventArgs) Handles btnAdd.Click
        lblOperation.Text = "  +"
        If TbxNumber1.Text = "" Then
            MsgBox("FIll in Textboxes")
        Else
            Dim AddOne As Decimal = TbxNumber1.Text
            Dim AddTwo As Decimal = TbxNumber2.Text
            lblResult.Text = AddOne + AddTwo
        End If
    End Sub

    Private Sub btnSubtract_Click(sender As System.Object, e As System.EventArgs) Handles btnSubtract.Click
        lblOperation.Text = "  -"
        If TbxNumber1.Text = "" Then
            MsgBox("FIll in Textboxes")
        Else
            Dim SubOne As Decimal = TbxNumber1.Text
            Dim SubTwo As Decimal = TbxNumber2.Text
            lblResult.Text = SubTwo - SubOne
        End If
    End Sub

    Private Sub btnMultiply_Click(sender As System.Object, e As System.EventArgs) Handles btnMultiply.Click
        lblOperation.Text = "  x"
        If TbxNumber1.Text = "" Then
            MsgBox("FIll in Textboxes")
        Else
            Dim MultOne As Decimal = TbxNumber1.Text
            Dim MultTwo As Decimal = TbxNumber2.Text
            lblResult.Text = MultOne * MultTwo
        End If
    End Sub

    Private Sub btnExponent_Click(sender As System.Object, e As System.EventArgs) Handles btnExponent.Click
        lblOperation.Text = "  ^"
        If TbxNumber1.Text = "" Then
            MsgBox("FIll in Textboxes")
        Else
            Dim ExpOne As Decimal = TbxNumber1.Text
            Dim ExpTwo As Decimal = TbxNumber2.Text
            lblResult.Text = ExpOne ^ ExpTwo
        End If
    End Sub

    Private Sub btnDivide_Click(sender As System.Object, e As System.EventArgs) Handles btnDivide.Click
        lblOperation.Text = "  /"
        If TbxNumber1.Text = "" Then
            MsgBox("FIll in Textboxes")
        Else
            Dim DivOne As Decimal = TbxNumber1.Text
            Dim DivTwo As Decimal = TbxNumber2.Text
            lblResult.Text = DivOne / DivTwo
        End If
    End Sub

    Private Sub btnIntDiv_Click(sender As System.Object, e As System.EventArgs) Handles btnIntDiv.Click
        lblOperation.Text = "  \"
        If TbxNumber1.Text = "" Then
            MsgBox("FIll in Textboxes")
        Else
            Dim IntDivOne As Decimal = TbxNumber1.Text
            Dim IntDivTwo As Decimal = TbxNumber2.Text
            lblResult.Text = IntDivOne \ IntDivTwo
        End If
    End Sub

    Private Sub btnMod_Click(sender As System.Object, e As System.EventArgs) Handles btnMod.Click
        lblOperation.Text = "Mod"
        If TbxNumber1.Text = "" Then
            MsgBox("FIll in Textboxes")
        Else
            Dim ModOne As Decimal = TbxNumber1.Text
            Dim ModTwo As Decimal = TbxNumber2.Text
            lblResult.Text = ModOne Mod ModTwo
        End If
    End Sub

    Private Sub btnClear_Click(sender As System.Object, e As System.EventArgs) Handles btnClear.Click
        TbxNumber2.Text = " "
        TbxNumber1.Text = " "
        lblOperation.Text = " "
        lblResult.Text = " "
    End Sub

    Private Sub btnExit_Click(sender As System.Object, e As System.EventArgs) Handles btnExit.Click
        MsgBox("The Program Is Closing.")
        Close()
    End Sub
End Class