﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FlappyBird
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Play_Button = New System.Windows.Forms.Button()
        Me.TextLabel = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Play_Button
        '
        Me.Play_Button.BackColor = System.Drawing.Color.Black
        Me.Play_Button.Font = New System.Drawing.Font("Microsoft Sans Serif", 48.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Play_Button.ForeColor = System.Drawing.Color.White
        Me.Play_Button.Location = New System.Drawing.Point(63, 99)
        Me.Play_Button.Name = "Play_Button"
        Me.Play_Button.Size = New System.Drawing.Size(250, 250)
        Me.Play_Button.TabIndex = 0
        Me.Play_Button.Text = "Play Flappy Birb"
        Me.Play_Button.UseVisualStyleBackColor = False
        '
        'TextLabel
        '
        Me.TextLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextLabel.Location = New System.Drawing.Point(12, 9)
        Me.TextLabel.Name = "TextLabel"
        Me.TextLabel.Size = New System.Drawing.Size(360, 114)
        Me.TextLabel.TabIndex = 1
        Me.TextLabel.Text = "Flappy Birb, A Game Inspired By Flappy Bird"
        '
        'FlappyBirb
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(384, 361)
        Me.Controls.Add(Me.Play_Button)
        Me.Controls.Add(Me.TextLabel)
        Me.Name = "FlappyBirb"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Play_Button As Button
    Friend WithEvents TextLabel As Label
End Class
