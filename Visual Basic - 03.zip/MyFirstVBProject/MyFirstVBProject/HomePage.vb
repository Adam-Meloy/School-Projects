﻿Public Class FlappyBird
    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles TextLabel.Click

    End Sub

    Private Sub Play_Button_Click(sender As Object, e As EventArgs) Handles Play_Button.Click
        Me.Hide()
        FlappyBirb.Show()
    End Sub
End Class
