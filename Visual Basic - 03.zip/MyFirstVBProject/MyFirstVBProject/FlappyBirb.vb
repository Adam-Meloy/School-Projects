﻿Public Class FlappyBirb
    Dim BirdStart, P1R1S, P2R1S, P1R2S, P2R2S, P1R3S, P2R3S, P1R4S, P2R4S, PR1C, PR2C, PR3C, PR4C, TopStart, BottomStart, Coin1S, Coin2S, Coin3S, Coin4S, XPoint, YPoint As Point
    Dim Score As Integer
    Private Sub FlappyBirb_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        BirdStart = Birb.Location
        P1R1S = P1R1.Location
        P2R1S = P2R1.Location
        P1R2S = P1R2.Location
        P2R2S = P2R2.Location
        P1R3S = P1R3.Location
        P2R3S = P2R3.Location
        P1R4S = P1R4.Location
        P2R4S = P2R4.Location
        PR1C = Coin1.Location
        PR2C = Coin2.Location
        PR3C = Coin3.Location
        PR4C = Coin4.Location
        Coin4S = Coin4.Location
        TopStart = Top.Location
        BottomStart = Bottom.Location
        Score = 200
        XPoint.X = -5
        YPoint.Y = 525
        MsgBox("Hit Enter To Start, Space To Move Up, And Escape To Quit.")
    End Sub
    Private Sub FlappyBirb_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.Enter Then
            Bird_Score_Timer.Enabled = True
            Pipe_Timer.Enabled = True
            Score_Timer.Enabled = True
        ElseIf e.KeyCode = Keys.Space Then
            Birb.Top = Birb.Top - 16
        ElseIf e.KeyCode = Keys.Escape Then
            Bird_Score_Timer.Enabled = False
            Pipe_Timer.Enabled = False
            Score_Timer.Enabled = False
            MsgBox("GoodBye")
            FlappyBird.Close()
        End If
    End Sub
    Private Sub Bird_Score_Timer_Tick(sender As Object, e As EventArgs) Handles Bird_Score_Timer.Tick
        Birb.Top = Birb.Top + 6
        Point_Label.Text = "Points: " & Score
        If Birb.Bottom > YPoint.Y Then
            Call GameOver()
        ElseIf Score <= 0 Then
            Call GameOver()
        End If
    End Sub
    Private Sub Pipe_Timer_Tick(sender As Object, e As EventArgs) Handles Pipe_Timer.Tick
        P1R1.Left = P1R1.Left - 10
        P2R1.Left = P2R1.Left - 10
        P1R2.Left = P1R2.Left - 10
        P2R2.Left = P2R2.Left - 10
        P1R3.Left = P1R3.Left - 10
        P2R3.Left = P2R3.Left - 10
        P1R4.Left = P1R4.Left - 10
        P2R4.Left = P2R4.Left - 10
        Coin1.Left = Coin1.Left - 10
        Coin2.Left = Coin2.Left - 10
        Coin3.Left = Coin3.Left - 10
        Coin4.Left = Coin4.Left - 10
        If P1R1.Right < XPoint.X Then
            P1R1.Location = TopStart
        End If
        If P1R2.Right < XPoint.X Then
            P1R2.Location = TopStart
        End If
        If P1R3.Right < XPoint.X Then
            P1R3.Location = TopStart
        End If
        If P1R4.Right < XPoint.X Then
            P1R4.Location = TopStart
        End If
        If P2R1.Right < XPoint.X Then
            P2R1.Location = BottomStart
        End If
        If P2R2.Right < XPoint.X Then
            P2R2.Location = BottomStart
        End If
        If P2R3.Right < XPoint.X Then
            P2R3.Location = BottomStart
        End If
        If P2R4.Left < XPoint.X Then
            P2R4.Location = BottomStart
        End If
        If Coin1.Left < XPoint.X Then
            Coin1.Location = C1S.Location
        End If
        If Coin2.Left < XPoint.X Then
            Coin2.Location = C2S.Location
        End If
        If Coin3.Left < XPoint.X Then
            Coin3.Location = C3S.Location
        End If
        If Coin4.Left < XPoint.X Then
            Coin4.Location = C4S.Location
        End If
    End Sub
    Private Sub Score_Timer_Tick(sender As Object, e As EventArgs) Handles Score_Timer.Tick
        If Birb.Bounds.IntersectsWith(P1R1.Bounds) Or Birb.Bounds.IntersectsWith(P2R1.Bounds) Or Birb.Bounds.IntersectsWith(P1R2.Bounds) Or Birb.Bounds.IntersectsWith(P2R2.Bounds) Or Birb.Bounds.IntersectsWith(P1R3.Bounds) Or Birb.Bounds.IntersectsWith(P2R3.Bounds) Or Birb.Bounds.IntersectsWith(P1R4.Bounds) Or Birb.Bounds.IntersectsWith(P2R4.Bounds) Then
            Score = Score - 10
        ElseIf Birb.Bounds.IntersectsWith(Coin1.Bounds) Or Birb.Bounds.IntersectsWith(Coin2.Bounds) Or Birb.Bounds.IntersectsWith(Coin3.Bounds) Or Birb.Bounds.IntersectsWith(Coin4.Bounds) Then
            Score = Score + 20
        End If
    End Sub
    Private Sub GameOver()
        Bird_Score_Timer.Enabled = False
        Pipe_Timer.Enabled = False
        Score_Timer.Enabled = False
        MsgBox("Game Over")
        Birb.Location = BirdStart
        P1R1.Location = P1R1S
        P2R1.Location = P2R1S
        P1R2.Location = P1R2S
        P2R2.Location = P2R2S
        P1R3.Location = P1R3S
        P2R3.Location = P2R3S
        P1R4.Location = P1R4S
        P2R4.Location = P2R4S
        Score = 200
    End Sub
End Class