﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FlappyBirb
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Birb = New System.Windows.Forms.PictureBox()
        Me.P1R1 = New System.Windows.Forms.PictureBox()
        Me.P2R2 = New System.Windows.Forms.PictureBox()
        Me.P2R1 = New System.Windows.Forms.PictureBox()
        Me.P1R4 = New System.Windows.Forms.PictureBox()
        Me.P2R4 = New System.Windows.Forms.PictureBox()
        Me.P1R2 = New System.Windows.Forms.PictureBox()
        Me.P2R3 = New System.Windows.Forms.PictureBox()
        Me.P1R3 = New System.Windows.Forms.PictureBox()
        Me.Point_Label = New System.Windows.Forms.Label()
        Me.Bird_Score_Timer = New System.Windows.Forms.Timer(Me.components)
        Me.Pipe_Timer = New System.Windows.Forms.Timer(Me.components)
        Me.Coin1 = New System.Windows.Forms.PictureBox()
        Me.Coin4 = New System.Windows.Forms.PictureBox()
        Me.Coin3 = New System.Windows.Forms.PictureBox()
        Me.Coin2 = New System.Windows.Forms.PictureBox()
        Me.Score_Timer = New System.Windows.Forms.Timer(Me.components)
        Me.Top = New System.Windows.Forms.PictureBox()
        Me.Bottom = New System.Windows.Forms.PictureBox()
        Me.C2S = New System.Windows.Forms.PictureBox()
        Me.C4S = New System.Windows.Forms.PictureBox()
        Me.C3S = New System.Windows.Forms.PictureBox()
        Me.C1S = New System.Windows.Forms.PictureBox()
        CType(Me.Birb, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.P1R1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.P2R2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.P2R1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.P1R4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.P2R4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.P1R2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.P2R3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.P1R3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Coin1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Coin4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Coin3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Coin2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Top, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Bottom, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.C2S, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.C4S, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.C3S, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.C1S, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Birb
        '
        Me.Birb.Image = Global.MyFirstVBProject.My.Resources.Resources.birb
        Me.Birb.Location = New System.Drawing.Point(27, 251)
        Me.Birb.Name = "Birb"
        Me.Birb.Size = New System.Drawing.Size(40, 40)
        Me.Birb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Birb.TabIndex = 0
        Me.Birb.TabStop = False
        '
        'P1R1
        '
        Me.P1R1.Image = Global.MyFirstVBProject.My.Resources.Resources.pipe
        Me.P1R1.Location = New System.Drawing.Point(103, -5)
        Me.P1R1.Name = "P1R1"
        Me.P1R1.Size = New System.Drawing.Size(47, 248)
        Me.P1R1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.P1R1.TabIndex = 1
        Me.P1R1.TabStop = False
        '
        'P2R2
        '
        Me.P2R2.Image = Global.MyFirstVBProject.My.Resources.Resources.pipe
        Me.P2R2.Location = New System.Drawing.Point(247, 294)
        Me.P2R2.Name = "P2R2"
        Me.P2R2.Size = New System.Drawing.Size(47, 203)
        Me.P2R2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.P2R2.TabIndex = 2
        Me.P2R2.TabStop = False
        '
        'P2R1
        '
        Me.P2R1.Image = Global.MyFirstVBProject.My.Resources.Resources.pipe
        Me.P2R1.Location = New System.Drawing.Point(103, 328)
        Me.P2R1.Name = "P2R1"
        Me.P2R1.Size = New System.Drawing.Size(47, 169)
        Me.P2R1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.P2R1.TabIndex = 3
        Me.P2R1.TabStop = False
        '
        'P1R4
        '
        Me.P1R4.Image = Global.MyFirstVBProject.My.Resources.Resources.pipe
        Me.P1R4.Location = New System.Drawing.Point(575, -5)
        Me.P1R4.Name = "P1R4"
        Me.P1R4.Size = New System.Drawing.Size(47, 177)
        Me.P1R4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.P1R4.TabIndex = 4
        Me.P1R4.TabStop = False
        '
        'P2R4
        '
        Me.P2R4.Image = Global.MyFirstVBProject.My.Resources.Resources.pipe
        Me.P2R4.Location = New System.Drawing.Point(575, 328)
        Me.P2R4.Name = "P2R4"
        Me.P2R4.Size = New System.Drawing.Size(47, 169)
        Me.P2R4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.P2R4.TabIndex = 5
        Me.P2R4.TabStop = False
        '
        'P1R2
        '
        Me.P1R2.Image = Global.MyFirstVBProject.My.Resources.Resources.pipe
        Me.P1R2.Location = New System.Drawing.Point(247, -5)
        Me.P1R2.Name = "P1R2"
        Me.P1R2.Size = New System.Drawing.Size(47, 193)
        Me.P1R2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.P1R2.TabIndex = 6
        Me.P1R2.TabStop = False
        '
        'P2R3
        '
        Me.P2R3.Image = Global.MyFirstVBProject.My.Resources.Resources.pipe
        Me.P2R3.Location = New System.Drawing.Point(430, 328)
        Me.P2R3.Name = "P2R3"
        Me.P2R3.Size = New System.Drawing.Size(47, 169)
        Me.P2R3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.P2R3.TabIndex = 7
        Me.P2R3.TabStop = False
        '
        'P1R3
        '
        Me.P1R3.Image = Global.MyFirstVBProject.My.Resources.Resources.pipe
        Me.P1R3.Location = New System.Drawing.Point(430, -5)
        Me.P1R3.Name = "P1R3"
        Me.P1R3.Size = New System.Drawing.Size(47, 268)
        Me.P1R3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.P1R3.TabIndex = 8
        Me.P1R3.TabStop = False
        '
        'Point_Label
        '
        Me.Point_Label.BackColor = System.Drawing.Color.Black
        Me.Point_Label.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Point_Label.ForeColor = System.Drawing.Color.White
        Me.Point_Label.Location = New System.Drawing.Point(311, 9)
        Me.Point_Label.Name = "Point_Label"
        Me.Point_Label.Size = New System.Drawing.Size(100, 23)
        Me.Point_Label.TabIndex = 9
        Me.Point_Label.Text = "Points:"
        '
        'Bird_Score_Timer
        '
        '
        'Pipe_Timer
        '
        '
        'Coin1
        '
        Me.Coin1.BackColor = System.Drawing.Color.Transparent
        Me.Coin1.Location = New System.Drawing.Point(149, 232)
        Me.Coin1.Name = "Coin1"
        Me.Coin1.Size = New System.Drawing.Size(1, 109)
        Me.Coin1.TabIndex = 10
        Me.Coin1.TabStop = False
        '
        'Coin4
        '
        Me.Coin4.BackColor = System.Drawing.Color.Transparent
        Me.Coin4.Location = New System.Drawing.Point(621, 156)
        Me.Coin4.Name = "Coin4"
        Me.Coin4.Size = New System.Drawing.Size(1, 191)
        Me.Coin4.TabIndex = 11
        Me.Coin4.TabStop = False
        '
        'Coin3
        '
        Me.Coin3.BackColor = System.Drawing.Color.Transparent
        Me.Coin3.Location = New System.Drawing.Point(476, 246)
        Me.Coin3.Name = "Coin3"
        Me.Coin3.Size = New System.Drawing.Size(1, 104)
        Me.Coin3.TabIndex = 12
        Me.Coin3.TabStop = False
        '
        'Coin2
        '
        Me.Coin2.BackColor = System.Drawing.Color.Transparent
        Me.Coin2.Location = New System.Drawing.Point(293, 173)
        Me.Coin2.Name = "Coin2"
        Me.Coin2.Size = New System.Drawing.Size(1, 148)
        Me.Coin2.TabIndex = 13
        Me.Coin2.TabStop = False
        '
        'Score_Timer
        '
        Me.Score_Timer.Interval = 850
        '
        'Top
        '
        Me.Top.BackColor = System.Drawing.Color.Transparent
        Me.Top.Location = New System.Drawing.Point(589, -5)
        Me.Top.Name = "Top"
        Me.Top.Size = New System.Drawing.Size(10, 10)
        Me.Top.TabIndex = 14
        Me.Top.TabStop = False
        '
        'Bottom
        '
        Me.Bottom.BackColor = System.Drawing.Color.Transparent
        Me.Bottom.Location = New System.Drawing.Point(589, 328)
        Me.Bottom.Name = "Bottom"
        Me.Bottom.Size = New System.Drawing.Size(10, 10)
        Me.Bottom.TabIndex = 15
        Me.Bottom.TabStop = False
        '
        'C2S
        '
        Me.C2S.BackColor = System.Drawing.Color.Transparent
        Me.C2S.Location = New System.Drawing.Point(628, 182)
        Me.C2S.Name = "C2S"
        Me.C2S.Size = New System.Drawing.Size(1, 113)
        Me.C2S.TabIndex = 16
        Me.C2S.TabStop = False
        '
        'C4S
        '
        Me.C4S.BackColor = System.Drawing.Color.Transparent
        Me.C4S.Location = New System.Drawing.Point(628, 169)
        Me.C4S.Name = "C4S"
        Me.C4S.Size = New System.Drawing.Size(1, 162)
        Me.C4S.TabIndex = 17
        Me.C4S.TabStop = False
        '
        'C3S
        '
        Me.C3S.BackColor = System.Drawing.Color.Transparent
        Me.C3S.Location = New System.Drawing.Point(628, 260)
        Me.C3S.Name = "C3S"
        Me.C3S.Size = New System.Drawing.Size(1, 71)
        Me.C3S.TabIndex = 18
        Me.C3S.TabStop = False
        '
        'C1S
        '
        Me.C1S.BackColor = System.Drawing.Color.Transparent
        Me.C1S.Location = New System.Drawing.Point(628, 240)
        Me.C1S.Name = "C1S"
        Me.C1S.Size = New System.Drawing.Size(1, 91)
        Me.C1S.TabIndex = 19
        Me.C1S.TabStop = False
        '
        'FlappyBirb
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(634, 486)
        Me.Controls.Add(Me.C1S)
        Me.Controls.Add(Me.C3S)
        Me.Controls.Add(Me.C4S)
        Me.Controls.Add(Me.C2S)
        Me.Controls.Add(Me.P2R4)
        Me.Controls.Add(Me.Coin2)
        Me.Controls.Add(Me.Coin3)
        Me.Controls.Add(Me.Coin4)
        Me.Controls.Add(Me.Coin1)
        Me.Controls.Add(Me.Point_Label)
        Me.Controls.Add(Me.P1R3)
        Me.Controls.Add(Me.P2R3)
        Me.Controls.Add(Me.P1R2)
        Me.Controls.Add(Me.P1R4)
        Me.Controls.Add(Me.P2R1)
        Me.Controls.Add(Me.P2R2)
        Me.Controls.Add(Me.P1R1)
        Me.Controls.Add(Me.Birb)
        Me.Controls.Add(Me.Bottom)
        Me.Controls.Add(Me.Top)
        Me.Name = "FlappyBirb"
        Me.Text = "FlappyBirb"
        CType(Me.Birb, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.P1R1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.P2R2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.P2R1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.P1R4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.P2R4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.P1R2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.P2R3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.P1R3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Coin1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Coin4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Coin3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Coin2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Top, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Bottom, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.C2S, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.C4S, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.C3S, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.C1S, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Birb As PictureBox
    Friend WithEvents P1R1 As PictureBox
    Friend WithEvents P2R2 As PictureBox
    Friend WithEvents P2R1 As PictureBox
    Friend WithEvents P1R4 As PictureBox
    Friend WithEvents P2R4 As PictureBox
    Friend WithEvents P1R2 As PictureBox
    Friend WithEvents P2R3 As PictureBox
    Friend WithEvents P1R3 As PictureBox
    Friend WithEvents Point_Label As Label
    Friend WithEvents Bird_Score_Timer As Timer
    Friend WithEvents Pipe_Timer As Timer
    Friend WithEvents Coin1 As PictureBox
    Friend WithEvents Coin4 As PictureBox
    Friend WithEvents Coin3 As PictureBox
    Friend WithEvents Coin2 As PictureBox
    Friend WithEvents Score_Timer As Timer
    Friend WithEvents Top As PictureBox
    Friend WithEvents Bottom As PictureBox
    Friend WithEvents C2S As PictureBox
    Friend WithEvents C4S As PictureBox
    Friend WithEvents C3S As PictureBox
    Friend WithEvents C1S As PictureBox
End Class
