﻿Public Class Form1
    Dim StartingNumber As Integer = 0

    Private Sub btnCounting_Click(sender As Object, e As EventArgs) Handles btnCounting.Click
        If tbxStartingNumber.Text = "" Then
            MsgBox("Enter In A Number Next Time")
            Close()
        ElseIf tbxIncrement.Text = "" Then
            MsgBox("Enter In A Number Next Time")
            Close()
        ElseIf btnCounting.Text = "Start Counting" Then
            StartingNumber = tbxStartingNumber.Text
            COUNTTIMER.Enabled = True
            btnCounting.Text = "Stop Counting"
        ElseIf btnCounting.Text = "Stop Counting" Then
            COUNTTIMER.Enabled = False
            btnCounting.Text = "Start Counting"
        End If
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        COUNTTIMER.Enabled = False
        tbxIncrement.Text = ""
        tbxStartingNumber.Text = ""
        lblNumber.Text = "xxxx"
        StartingNumber = 0
    End Sub

    Private Sub COUNTTIMER_Tick(sender As Object, e As EventArgs) Handles COUNTTIMER.Tick
        COUNTTIMER.Interval = tbxIncrement.Text
        StartingNumber = StartingNumber + 1
        lblNumber.Text = StartingNumber
    End Sub
End Class
