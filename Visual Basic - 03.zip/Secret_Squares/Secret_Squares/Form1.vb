﻿Public Class Form1
    Dim Squares(80), SC As Label
    Dim x, y, q, z, RandomNumber, Count As Integer
    Dim RandomColor As Color
    Private Sub MasterButton_Click(sender As Object, e As EventArgs) Handles MasterButton.Click
        Randomize()
        RandomNumber = Int(Rnd() * 81) + 1
        MasterButton.Visible = False
        For i = 0 To Squares.Length - 1
            Count += 1
            SC = New Label
            SC.BackColor = Drawing.Color.Red
            SC.Name = i + 1
            SC.Width = 90
            SC.Height = 90
            SC.Left = x
            SC.Top = y
            SC.BorderStyle = BorderStyle.Fixed3D
            Me.Controls.Add(SC)
            Squares(i) = SC
            Call Colour()
            AddHandler SC.MouseClick, AddressOf MouseClicks

            If Count Mod 9 = 0 Then
                y += 90
                x = 0
            Else
                x += 90
            End If
        Next
    End Sub
    Private Sub Colour()
        If SC.Name = 2 Or SC.Name = 4 Or SC.Name = 6 Or SC.Name = 8 Then
            SC.BackColor = Drawing.Color.White
        ElseIf SC.Name = 20 Or SC.Name = 22 Or SC.Name = 24 Or SC.Name = 26 Then
            SC.BackColor = Drawing.Color.White
        ElseIf SC.Name = 38 Or SC.Name = 40 Or SC.Name = 42 Or SC.Name = 44 Then
            SC.BackColor = Drawing.Color.White
        ElseIf SC.Name = 56 Or SC.Name = 58 Or SC.Name = 60 Or SC.Name = 62 Then
            SC.BackColor = Drawing.Color.White
        ElseIf SC.Name = 74 Or SC.Name = 76 Or SC.Name = 78 Or SC.Name = 80 Then
            SC.BackColor = Drawing.Color.White
        End If
    End Sub
    Private Sub MouseClicks(sender As Object, e As EventArgs)
        sender.text = sender.name
        If sender.name = RandomNumber Then
            For j = 0 To 1
                Call ViRuS()
            Next
        End If
    End Sub
    Private Sub ViRuS()
        For z = 0 To Squares.Length - 1
            Squares(z).Enabled = False
            Squares(z).Visible = False
            For q = 0 To 999
                Randomize()
                Me.BackColor = Drawing.Color.FromArgb(Int(Rnd() * 255), Int(Rnd() * 255), Int(Rnd() * 255))
                If z = 81 Then
                    Exit For
                End If
            Next
        Next
    End Sub
End Class