﻿Public Class Cleanup
    Private Sub BTNEASY_Click(sender As Object, e As EventArgs) Handles BTNEASY.Click
        zed.Text = "0"
        ScoreScroll.Value = 0
        Coin1.Visible = False
        Coin2REDONE.Visible = False
        Coin3.Visible = False
        Coin4.Visible = False
        Coin5.Visible = False
        Coin6.Visible = False
        Coin7.Visible = False
        Coin8.Visible = False
        Coin9.Visible = False
        Coin10.Visible = False
        Coin11.Visible = False
        Coin12.Visible = False
        Coin13.Visible = False
        Coin14.Visible = False
        Coin15.Visible = False
        Coin1.Enabled = True
        Coin2REDONE.Enabled = True
        Coin3.Enabled = True
        Coin4.Enabled = True
        Coin5.Enabled = True
        Coin6.Enabled = True
        Coin7.Enabled = True
        Coin8.Enabled = True
        Coin9.Enabled = True
        Coin10.Enabled = True
        Coin11.Enabled = True
        Coin12.Enabled = True
        Coin13.Enabled = True
        Coin14.Enabled = True
        Coin15.Enabled = True
        BLS1.Visible = False
        BLS2.Visible = False
        BLS3.Visible = False
        BLS4.Visible = False
        BLS5.Visible = False
        BLS6.Visible = False
        BLS7.Visible = False
        BLS8.Visible = False
        BLS9.Visible = False
        BLS10.Visible = False
        BLS11.Visible = False
        BLS12.Visible = False
        BLS13.Visible = False
        BLS14.Visible = False
        BLS15.Visible = False
        BLS1.Enabled = True
        BLS2.Enabled = True
        BLS3.Enabled = True
        BLS4.Enabled = True
        BLS5.Enabled = True
        BLS6.Enabled = True
        BLS7.Enabled = True
        BLS8.Enabled = True
        BLS9.Enabled = True
        BLS10.Enabled = True
        BLS11.Enabled = True
        BLS12.Enabled = True
        BLS13.Enabled = True
        BLS14.Enabled = True
        BLS15.Enabled = True
        REDS1.Visible = True
        REDS2.Visible = True
        REDS3.Visible = True
        REDS4.Visible = True
        REDS5.Visible = True
        REDS6.Visible = True
        REDS7.Visible = True
        REDS8.Visible = True
        REDS9.Visible = True
        REDS10.Visible = True
        REDS11.Visible = True
        REDS12.Visible = True
        REDS13.Visible = True
        REDS14.Visible = True
        REDS15.Visible = True
        REDS1.Enabled = True
        REDS2.Enabled = True
        REDS3.Enabled = True
        REDS4.Enabled = True
        REDS5.Enabled = True
        REDS6.Enabled = True
        REDS7.Enabled = True
        REDS8.Enabled = True
        REDS9.Enabled = True
        REDS10.Enabled = True
        REDS11.Enabled = True
        REDS12.Enabled = True
        REDS13.Enabled = True
        REDS14.Enabled = True
        REDS15.Enabled = True
    End Sub

    Private Sub BTNMEDIUM_Click(sender As Object, e As EventArgs) Handles BTNMEDIUM.Click
        zed.Text = "0"
        ScoreScroll.Value = 0
        Coin1.Visible = False
        Coin2REDONE.Visible = False
        Coin3.Visible = False
        Coin4.Visible = False
        Coin5.Visible = False
        Coin6.Visible = False
        Coin7.Visible = False
        Coin8.Visible = False
        Coin9.Visible = False
        Coin10.Visible = False
        Coin11.Visible = False
        Coin12.Visible = False
        Coin13.Visible = False
        Coin14.Visible = False
        Coin15.Visible = False
        Coin1.Enabled = True
        Coin2REDONE.Enabled = True
        Coin3.Enabled = True
        Coin4.Enabled = True
        Coin5.Enabled = True
        Coin6.Enabled = True
        Coin7.Enabled = True
        Coin8.Enabled = True
        Coin9.Enabled = True
        Coin10.Enabled = True
        Coin11.Enabled = True
        Coin12.Enabled = True
        Coin13.Enabled = True
        Coin14.Enabled = True
        Coin15.Enabled = True
        BLS1.Visible = True
        BLS2.Visible = True
        BLS3.Visible = True
        BLS4.Visible = True
        BLS5.Visible = True
        BLS6.Visible = True
        BLS7.Visible = True
        BLS8.Visible = True
        BLS9.Visible = True
        BLS10.Visible = True
        BLS11.Visible = True
        BLS12.Visible = True
        BLS13.Visible = True
        BLS14.Visible = True
        BLS15.Visible = True
        BLS1.Enabled = True
        BLS2.Enabled = True
        BLS3.Enabled = True
        BLS4.Enabled = True
        BLS5.Enabled = True
        BLS6.Enabled = True
        BLS7.Enabled = True
        BLS8.Enabled = True
        BLS9.Enabled = True
        BLS10.Enabled = True
        BLS11.Enabled = True
        BLS12.Enabled = True
        BLS13.Enabled = True
        BLS14.Enabled = True
        BLS15.Enabled = True
        REDS1.Visible = True
        REDS2.Visible = True
        REDS3.Visible = True
        REDS4.Visible = True
        REDS5.Visible = True
        REDS6.Visible = True
        REDS7.Visible = True
        REDS8.Visible = True
        REDS9.Visible = True
        REDS10.Visible = True
        REDS11.Visible = True
        REDS12.Visible = True
        REDS13.Visible = True
        REDS14.Visible = True
        REDS15.Visible = True
        REDS1.Enabled = True
        REDS2.Enabled = True
        REDS3.Enabled = True
        REDS4.Enabled = True
        REDS5.Enabled = True
        REDS6.Enabled = True
        REDS7.Enabled = True
        REDS8.Enabled = True
        REDS9.Enabled = True
        REDS10.Enabled = True
        REDS11.Enabled = True
        REDS12.Enabled = True
        REDS13.Enabled = True
        REDS14.Enabled = True
        REDS15.Enabled = True
    End Sub

    Private Sub BTNHARD_Click(sender As Object, e As EventArgs) Handles BTNHARD.Click
        zed.Text = "0"
        ScoreScroll.Value = 0
        Coin1.Visible = True
        Coin2REDONE.Visible = True
        Coin3.Visible = True
        Coin4.Visible = True
        Coin5.Visible = True
        Coin6.Visible = True
        Coin7.Visible = True
        Coin8.Visible = True
        Coin9.Visible = True
        Coin10.Visible = True
        Coin11.Visible = True
        Coin12.Visible = True
        Coin13.Visible = True
        Coin14.Visible = True
        Coin15.Visible = True
        Coin1.Enabled = True
        Coin2REDONE.Enabled = True
        Coin3.Enabled = True
        Coin4.Enabled = True
        Coin5.Enabled = True
        Coin6.Enabled = True
        Coin7.Enabled = True
        Coin8.Enabled = True
        Coin9.Enabled = True
        Coin10.Enabled = True
        Coin11.Enabled = True
        Coin12.Enabled = True
        Coin13.Enabled = True
        Coin14.Enabled = True
        Coin15.Enabled = True
        BLS1.Visible = True
        BLS2.Visible = True
        BLS3.Visible = True
        BLS4.Visible = True
        BLS5.Visible = True
        BLS6.Visible = True
        BLS7.Visible = True
        BLS8.Visible = True
        BLS9.Visible = True
        BLS10.Visible = True
        BLS11.Visible = True
        BLS12.Visible = True
        BLS13.Visible = True
        BLS14.Visible = True
        BLS15.Visible = True
        BLS1.Enabled = True
        BLS2.Enabled = True
        BLS3.Enabled = True
        BLS4.Enabled = True
        BLS5.Enabled = True
        BLS6.Enabled = True
        BLS7.Enabled = True
        BLS8.Enabled = True
        BLS9.Enabled = True
        BLS10.Enabled = True
        BLS11.Enabled = True
        BLS12.Enabled = True
        BLS13.Enabled = True
        BLS14.Enabled = True
        BLS15.Enabled = True
        REDS1.Visible = True
        REDS2.Visible = True
        REDS3.Visible = True
        REDS4.Visible = True
        REDS5.Visible = True
        REDS6.Visible = True
        REDS7.Visible = True
        REDS8.Visible = True
        REDS9.Visible = True
        REDS10.Visible = True
        REDS11.Visible = True
        REDS12.Visible = True
        REDS13.Visible = True
        REDS14.Visible = True
        REDS15.Visible = True
        REDS1.Enabled = True
        REDS2.Enabled = True
        REDS3.Enabled = True
        REDS4.Enabled = True
        REDS5.Enabled = True
        REDS6.Enabled = True
        REDS7.Enabled = True
        REDS8.Enabled = True
        REDS9.Enabled = True
        REDS10.Enabled = True
        REDS11.Enabled = True
        REDS12.Enabled = True
        REDS13.Enabled = True
        REDS14.Enabled = True
        REDS15.Enabled = True
    End Sub

    Private Sub BTNEXIT_Click(sender As Object, e As EventArgs) Handles BTNEXIT.Click
        MsgBox("Goodbye!")

        Close()
    End Sub

    Private Sub Coin1_Click(sender As Object, e As EventArgs) Handles Coin1.Click
        ScoreScroll.Value = ScoreScroll.Value + 1
        zed.Text = ScoreScroll.Value
        Coin1.Enabled = False
        Coin1.Visible = False
    End Sub

    Private Sub Coin2REDONE_Click(sender As Object, e As EventArgs) Handles Coin2REDONE.Click
        ScoreScroll.Value = ScoreScroll.Value + 1
        zed.Text = ScoreScroll.Value
        Coin2REDONE.Enabled = False
        Coin2REDONE.Visible = False
    End Sub

    Private Sub Coin3_Click(sender As Object, e As EventArgs) Handles Coin3.Click
        ScoreScroll.Value = ScoreScroll.Value + 1
        zed.Text = ScoreScroll.Value
        Coin3.Enabled = False
        Coin3.Visible = False
    End Sub

    Private Sub Coin4_Click(sender As Object, e As EventArgs) Handles Coin4.Click
        ScoreScroll.Value = ScoreScroll.Value + 1
        zed.Text = ScoreScroll.Value
        Coin4.Enabled = False
        Coin4.Visible = False
    End Sub

    Private Sub Coin5_Click(sender As Object, e As EventArgs) Handles Coin5.Click
        ScoreScroll.Value = ScoreScroll.Value + 1
        zed.Text = ScoreScroll.Value
        Coin5.Enabled = False
        Coin5.Visible = False
    End Sub

    Private Sub Coin6_Click(sender As Object, e As EventArgs) Handles Coin6.Click
        ScoreScroll.Value = ScoreScroll.Value + 1
        zed.Text = ScoreScroll.Value
        Coin6.Enabled = False
        Coin6.Visible = False
    End Sub

    Private Sub Coin7_Click(sender As Object, e As EventArgs) Handles Coin7.Click
        ScoreScroll.Value = ScoreScroll.Value + 1
        zed.Text = ScoreScroll.Value
        Coin7.Enabled = False
        Coin7.Visible = False
    End Sub

    Private Sub Coin8_Click(sender As Object, e As EventArgs) Handles Coin8.Click
        ScoreScroll.Value = ScoreScroll.Value + 1
        zed.Text = ScoreScroll.Value
        Coin8.Enabled = False
        Coin8.Visible = False
    End Sub

    Private Sub Coin9_Click(sender As Object, e As EventArgs) Handles Coin9.Click
        ScoreScroll.Value = ScoreScroll.Value + 1
        zed.Text = ScoreScroll.Value
        Coin9.Enabled = False
        Coin9.Visible = False
    End Sub

    Private Sub Coin10_Click(sender As Object, e As EventArgs) Handles Coin10.Click
        ScoreScroll.Value = ScoreScroll.Value + 1
        zed.Text = ScoreScroll.Value
        Coin10.Enabled = False
        Coin10.Visible = False
    End Sub

    Private Sub Coin11_Click(sender As Object, e As EventArgs) Handles Coin11.Click
        ScoreScroll.Value = ScoreScroll.Value + 1
        zed.Text = ScoreScroll.Value
        Coin11.Enabled = False
        Coin11.Visible = False
    End Sub

    Private Sub Coin12_Click(sender As Object, e As EventArgs) Handles Coin12.Click
        ScoreScroll.Value = ScoreScroll.Value + 1
        zed.Text = ScoreScroll.Value
        Coin12.Enabled = False
        Coin12.Visible = False
    End Sub

    Private Sub Coin13_Click(sender As Object, e As EventArgs) Handles Coin13.Click
        ScoreScroll.Value = ScoreScroll.Value + 1
        zed.Text = ScoreScroll.Value
        Coin13.Enabled = False
        Coin13.Visible = False
    End Sub

    Private Sub Coin14_Click(sender As Object, e As EventArgs) Handles Coin14.Click
        ScoreScroll.Value = ScoreScroll.Value + 1
        zed.Text = ScoreScroll.Value
        Coin14.Enabled = False
        Coin14.Visible = False
    End Sub

    Private Sub Coin15_Click(sender As Object, e As EventArgs) Handles Coin15.Click
        ScoreScroll.Value = ScoreScroll.Value + 1
        zed.Text = ScoreScroll.Value
        Coin15.Enabled = False
        Coin15.Visible = False
        If ScoreScroll.Value = 45 Then
            MsgBox("All Pictures Have Been Clicked ")
        End If
    End Sub

    Private Sub BLS1_Click(sender As Object, e As EventArgs) Handles BLS1.Click
        ScoreScroll.Value = ScoreScroll.Value + 1
        zed.Text = ScoreScroll.Value
        BLS1.Visible = False
        BLS1.Enabled = False
    End Sub

    Private Sub BLS2_Click(sender As Object, e As EventArgs) Handles BLS2.Click
        ScoreScroll.Value = ScoreScroll.Value + 1
        zed.Text = ScoreScroll.Value
        BLS2.Visible = False
        BLS2.Enabled = False
    End Sub

    Private Sub BLS3_Click(sender As Object, e As EventArgs) Handles BLS3.Click
        ScoreScroll.Value = ScoreScroll.Value + 1
        zed.Text = ScoreScroll.Value
        BLS3.Visible = False
        BLS3.Enabled = False
    End Sub

    Private Sub BLS4_Click(sender As Object, e As EventArgs) Handles BLS4.Click
        ScoreScroll.Value = ScoreScroll.Value + 1
        zed.Text = ScoreScroll.Value
        BLS4.Visible = False
        BLS4.Enabled = False
    End Sub

    Private Sub BLS5_Click(sender As Object, e As EventArgs) Handles BLS5.Click
        ScoreScroll.Value = ScoreScroll.Value + 1
        zed.Text = ScoreScroll.Value
        BLS5.Visible = False
        BLS5.Enabled = False
    End Sub

    Private Sub BLS6_Click(sender As Object, e As EventArgs) Handles BLS6.Click
        ScoreScroll.Value = ScoreScroll.Value + 1
        zed.Text = ScoreScroll.Value
        BLS6.Visible = False
        BLS6.Enabled = False
    End Sub

    Private Sub BLS7_Click(sender As Object, e As EventArgs) Handles BLS7.Click
        ScoreScroll.Value = ScoreScroll.Value + 1
        zed.Text = ScoreScroll.Value
        BLS7.Visible = False
        BLS7.Enabled = False
    End Sub

    Private Sub BLS8_Click(sender As Object, e As EventArgs) Handles BLS8.Click
        ScoreScroll.Value = ScoreScroll.Value + 1
        zed.Text = ScoreScroll.Value
        BLS8.Visible = False
        BLS8.Enabled = False
    End Sub

    Private Sub BLS9_Click(sender As Object, e As EventArgs) Handles BLS9.Click
        ScoreScroll.Value = ScoreScroll.Value + 1
        zed.Text = ScoreScroll.Value
        BLS9.Visible = False
        BLS9.Enabled = False
    End Sub

    Private Sub BLS10_Click(sender As Object, e As EventArgs) Handles BLS10.Click
        ScoreScroll.Value = ScoreScroll.Value + 1
        zed.Text = ScoreScroll.Value
        BLS10.Visible = False
        BLS10.Enabled = False
    End Sub

    Private Sub BLS11_Click(sender As Object, e As EventArgs) Handles BLS11.Click
        ScoreScroll.Value = ScoreScroll.Value + 1
        zed.Text = ScoreScroll.Value
        BLS11.Visible = False
        BLS11.Enabled = False
    End Sub

    Private Sub BLS12_Click(sender As Object, e As EventArgs) Handles BLS12.Click
        ScoreScroll.Value = ScoreScroll.Value + 1
        zed.Text = ScoreScroll.Value
        BLS12.Visible = False
        BLS12.Enabled = False
    End Sub

    Private Sub BLS13_Click(sender As Object, e As EventArgs) Handles BLS13.Click
        ScoreScroll.Value = ScoreScroll.Value + 1
        zed.Text = ScoreScroll.Value
        BLS13.Visible = False
        BLS13.Enabled = False
    End Sub

    Private Sub BLS14_Click(sender As Object, e As EventArgs) Handles BLS14.Click
        ScoreScroll.Value = ScoreScroll.Value + 1
        zed.Text = ScoreScroll.Value
        BLS14.Visible = False
        BLS14.Enabled = False
    End Sub

    Private Sub BLS15_Click(sender As Object, e As EventArgs) Handles BLS15.Click
        ScoreScroll.Value = ScoreScroll.Value + 1
        zed.Text = ScoreScroll.Value
        BLS15.Visible = False
        BLS15.Enabled = False
    End Sub

    Private Sub REDS1_Click(sender As Object, e As EventArgs) Handles REDS1.Click
        ScoreScroll.Value = ScoreScroll.Value + 1
        zed.Text = ScoreScroll.Value
        REDS1.Visible = False
        REDS1.Enabled = False
    End Sub

    Private Sub REDS2_Click(sender As Object, e As EventArgs) Handles REDS2.Click
        ScoreScroll.Value = ScoreScroll.Value + 1
        zed.Text = ScoreScroll.Value
        REDS2.Visible = False
        REDS2.Enabled = False
    End Sub

    Private Sub REDS3_Click(sender As Object, e As EventArgs) Handles REDS3.Click
        ScoreScroll.Value = ScoreScroll.Value + 1
        zed.Text = ScoreScroll.Value
        REDS3.Visible = False
        REDS3.Enabled = False
    End Sub

    Private Sub REDS4_Click(sender As Object, e As EventArgs) Handles REDS4.Click
        ScoreScroll.Value = ScoreScroll.Value + 1
        zed.Text = ScoreScroll.Value
        REDS4.Visible = False
        REDS4.Enabled = False
    End Sub

    Private Sub REDS5_Click(sender As Object, e As EventArgs) Handles REDS5.Click
        ScoreScroll.Value = ScoreScroll.Value + 1
        zed.Text = ScoreScroll.Value
        REDS5.Visible = False
        REDS5.Enabled = False
    End Sub

    Private Sub REDS6_Click(sender As Object, e As EventArgs) Handles REDS6.Click
        ScoreScroll.Value = ScoreScroll.Value + 1
        zed.Text = ScoreScroll.Value
        REDS6.Visible = False
        REDS6.Enabled = False
    End Sub

    Private Sub REDS7_Click(sender As Object, e As EventArgs) Handles REDS7.Click
        ScoreScroll.Value = ScoreScroll.Value + 1
        zed.Text = ScoreScroll.Value
        REDS7.Visible = False
        REDS7.Enabled = False
    End Sub

    Private Sub REDS8_Click(sender As Object, e As EventArgs) Handles REDS8.Click
        ScoreScroll.Value = ScoreScroll.Value + 1
        zed.Text = ScoreScroll.Value
        REDS8.Visible = False
        REDS8.Enabled = False
    End Sub

    Private Sub REDS9_Click(sender As Object, e As EventArgs) Handles REDS9.Click
        ScoreScroll.Value = ScoreScroll.Value + 1
        zed.Text = ScoreScroll.Value
        REDS9.Visible = False
        REDS9.Enabled = False
    End Sub

    Private Sub REDS10_Click(sender As Object, e As EventArgs) Handles REDS10.Click
        ScoreScroll.Value = ScoreScroll.Value + 1
        zed.Text = ScoreScroll.Value
        REDS10.Visible = False
        REDS10.Enabled = False
    End Sub

    Private Sub REDS11_Click(sender As Object, e As EventArgs) Handles REDS11.Click
        ScoreScroll.Value = ScoreScroll.Value + 1
        zed.Text = ScoreScroll.Value
        REDS11.Visible = False
        REDS11.Enabled = False
    End Sub

    Private Sub REDS12_Click(sender As Object, e As EventArgs) Handles REDS12.Click
        ScoreScroll.Value = ScoreScroll.Value + 1
        zed.Text = ScoreScroll.Value
        REDS12.Visible = False
        REDS12.Enabled = False
    End Sub

    Private Sub REDS13_Click(sender As Object, e As EventArgs) Handles REDS13.Click
        ScoreScroll.Value = ScoreScroll.Value + 1
        zed.Text = ScoreScroll.Value
        REDS13.Visible = False
        REDS13.Enabled = False
    End Sub

    Private Sub REDS14_Click(sender As Object, e As EventArgs) Handles REDS14.Click
        ScoreScroll.Value = ScoreScroll.Value + 1
        zed.Text = ScoreScroll.Value
        REDS14.Visible = False
        REDS14.Enabled = False
    End Sub

    Private Sub REDS15_Click(sender As Object, e As EventArgs) Handles REDS15.Click
        ScoreScroll.Value = ScoreScroll.Value + 1
        zed.Text = ScoreScroll.Value
        REDS15.Visible = False
        REDS15.Enabled = False
    End Sub

End Class