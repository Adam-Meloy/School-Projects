﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Cleanup
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.BTNEASY = New System.Windows.Forms.Button()
        Me.score = New System.Windows.Forms.Label()
        Me.zed = New System.Windows.Forms.Label()
        Me.BTNMEDIUM = New System.Windows.Forms.Button()
        Me.BTNHARD = New System.Windows.Forms.Button()
        Me.REDS1 = New System.Windows.Forms.PictureBox()
        Me.BLS1 = New System.Windows.Forms.PictureBox()
        Me.ScoreScroll = New System.Windows.Forms.HScrollBar()
        Me.BLS2 = New System.Windows.Forms.PictureBox()
        Me.BLS3 = New System.Windows.Forms.PictureBox()
        Me.BLS4 = New System.Windows.Forms.PictureBox()
        Me.BLS5 = New System.Windows.Forms.PictureBox()
        Me.BLS6 = New System.Windows.Forms.PictureBox()
        Me.BLS7 = New System.Windows.Forms.PictureBox()
        Me.BLS8 = New System.Windows.Forms.PictureBox()
        Me.BLS9 = New System.Windows.Forms.PictureBox()
        Me.BLS10 = New System.Windows.Forms.PictureBox()
        Me.BLS11 = New System.Windows.Forms.PictureBox()
        Me.BLS12 = New System.Windows.Forms.PictureBox()
        Me.BLS13 = New System.Windows.Forms.PictureBox()
        Me.BLS14 = New System.Windows.Forms.PictureBox()
        Me.BLS15 = New System.Windows.Forms.PictureBox()
        Me.REDS2 = New System.Windows.Forms.PictureBox()
        Me.REDS3 = New System.Windows.Forms.PictureBox()
        Me.REDS4 = New System.Windows.Forms.PictureBox()
        Me.REDS5 = New System.Windows.Forms.PictureBox()
        Me.REDS6 = New System.Windows.Forms.PictureBox()
        Me.REDS7 = New System.Windows.Forms.PictureBox()
        Me.REDS8 = New System.Windows.Forms.PictureBox()
        Me.REDS9 = New System.Windows.Forms.PictureBox()
        Me.REDS10 = New System.Windows.Forms.PictureBox()
        Me.REDS11 = New System.Windows.Forms.PictureBox()
        Me.REDS12 = New System.Windows.Forms.PictureBox()
        Me.REDS13 = New System.Windows.Forms.PictureBox()
        Me.REDS14 = New System.Windows.Forms.PictureBox()
        Me.REDS15 = New System.Windows.Forms.PictureBox()
        Me.Coin3 = New System.Windows.Forms.PictureBox()
        Me.Coin4 = New System.Windows.Forms.PictureBox()
        Me.Coin5 = New System.Windows.Forms.PictureBox()
        Me.Coin6 = New System.Windows.Forms.PictureBox()
        Me.Coin7 = New System.Windows.Forms.PictureBox()
        Me.Coin8 = New System.Windows.Forms.PictureBox()
        Me.Coin9 = New System.Windows.Forms.PictureBox()
        Me.Coin10 = New System.Windows.Forms.PictureBox()
        Me.Coin11 = New System.Windows.Forms.PictureBox()
        Me.Coin12 = New System.Windows.Forms.PictureBox()
        Me.Coin13 = New System.Windows.Forms.PictureBox()
        Me.Coin14 = New System.Windows.Forms.PictureBox()
        Me.Coin15 = New System.Windows.Forms.PictureBox()
        Me.Coin1 = New System.Windows.Forms.PictureBox()
        Me.Coin2REDONE = New System.Windows.Forms.PictureBox()
        Me.BTNEXIT = New System.Windows.Forms.Button()
        CType(Me.REDS1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BLS1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BLS2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BLS3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BLS4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BLS5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BLS6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BLS7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BLS8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BLS9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BLS10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BLS11, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BLS12, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BLS13, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BLS14, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BLS15, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.REDS2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.REDS3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.REDS4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.REDS5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.REDS6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.REDS7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.REDS8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.REDS9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.REDS10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.REDS11, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.REDS12, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.REDS13, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.REDS14, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.REDS15, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Coin3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Coin4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Coin5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Coin6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Coin7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Coin8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Coin9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Coin10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Coin11, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Coin12, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Coin13, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Coin14, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Coin15, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Coin1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Coin2REDONE, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'BTNEASY
        '
        Me.BTNEASY.Location = New System.Drawing.Point(16, 519)
        Me.BTNEASY.Name = "BTNEASY"
        Me.BTNEASY.Size = New System.Drawing.Size(75, 63)
        Me.BTNEASY.TabIndex = 0
        Me.BTNEASY.Text = "Easy"
        Me.BTNEASY.UseVisualStyleBackColor = True
        '
        'score
        '
        Me.score.AutoSize = True
        Me.score.Location = New System.Drawing.Point(13, 13)
        Me.score.Name = "score"
        Me.score.Size = New System.Drawing.Size(38, 13)
        Me.score.TabIndex = 1
        Me.score.Text = "Score:"
        '
        'zed
        '
        Me.zed.AutoSize = True
        Me.zed.Location = New System.Drawing.Point(59, 13)
        Me.zed.Name = "zed"
        Me.zed.Size = New System.Drawing.Size(13, 13)
        Me.zed.TabIndex = 2
        Me.zed.Text = "0"
        '
        'BTNMEDIUM
        '
        Me.BTNMEDIUM.Location = New System.Drawing.Point(209, 519)
        Me.BTNMEDIUM.Name = "BTNMEDIUM"
        Me.BTNMEDIUM.Size = New System.Drawing.Size(75, 63)
        Me.BTNMEDIUM.TabIndex = 3
        Me.BTNMEDIUM.Text = "Medium"
        Me.BTNMEDIUM.UseVisualStyleBackColor = True
        '
        'BTNHARD
        '
        Me.BTNHARD.Location = New System.Drawing.Point(389, 519)
        Me.BTNHARD.Name = "BTNHARD"
        Me.BTNHARD.Size = New System.Drawing.Size(75, 63)
        Me.BTNHARD.TabIndex = 4
        Me.BTNHARD.Text = "Hard"
        Me.BTNHARD.UseVisualStyleBackColor = True
        '
        'REDS1
        '
        Me.REDS1.BackgroundImage = Global.VB_Game___Cleanup.My.Resources.Resources.red_star
        Me.REDS1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.REDS1.Location = New System.Drawing.Point(184, 346)
        Me.REDS1.Name = "REDS1"
        Me.REDS1.Size = New System.Drawing.Size(54, 50)
        Me.REDS1.TabIndex = 7
        Me.REDS1.TabStop = False
        '
        'BLS1
        '
        Me.BLS1.BackgroundImage = Global.VB_Game___Cleanup.My.Resources.Resources.black_star
        Me.BLS1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BLS1.Location = New System.Drawing.Point(439, 404)
        Me.BLS1.Name = "BLS1"
        Me.BLS1.Size = New System.Drawing.Size(54, 50)
        Me.BLS1.TabIndex = 5
        Me.BLS1.TabStop = False
        Me.BLS1.Visible = False
        '
        'ScoreScroll
        '
        Me.ScoreScroll.Location = New System.Drawing.Point(9, 9)
        Me.ScoreScroll.Maximum = 45
        Me.ScoreScroll.Name = "ScoreScroll"
        Me.ScoreScroll.Size = New System.Drawing.Size(80, 17)
        Me.ScoreScroll.TabIndex = 8
        Me.ScoreScroll.UseWaitCursor = True
        Me.ScoreScroll.Visible = False
        '
        'BLS2
        '
        Me.BLS2.BackgroundImage = Global.VB_Game___Cleanup.My.Resources.Resources.black_star
        Me.BLS2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BLS2.Location = New System.Drawing.Point(62, 134)
        Me.BLS2.Name = "BLS2"
        Me.BLS2.Size = New System.Drawing.Size(54, 50)
        Me.BLS2.TabIndex = 9
        Me.BLS2.TabStop = False
        Me.BLS2.Visible = False
        '
        'BLS3
        '
        Me.BLS3.BackgroundImage = Global.VB_Game___Cleanup.My.Resources.Resources.black_star
        Me.BLS3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BLS3.Location = New System.Drawing.Point(266, 13)
        Me.BLS3.Name = "BLS3"
        Me.BLS3.Size = New System.Drawing.Size(54, 50)
        Me.BLS3.TabIndex = 10
        Me.BLS3.TabStop = False
        Me.BLS3.Visible = False
        '
        'BLS4
        '
        Me.BLS4.BackgroundImage = Global.VB_Game___Cleanup.My.Resources.Resources.black_star
        Me.BLS4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BLS4.Location = New System.Drawing.Point(595, 357)
        Me.BLS4.Name = "BLS4"
        Me.BLS4.Size = New System.Drawing.Size(54, 50)
        Me.BLS4.TabIndex = 11
        Me.BLS4.TabStop = False
        Me.BLS4.Visible = False
        '
        'BLS5
        '
        Me.BLS5.BackgroundImage = Global.VB_Game___Cleanup.My.Resources.Resources.black_star
        Me.BLS5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BLS5.Location = New System.Drawing.Point(161, 424)
        Me.BLS5.Name = "BLS5"
        Me.BLS5.Size = New System.Drawing.Size(54, 50)
        Me.BLS5.TabIndex = 12
        Me.BLS5.TabStop = False
        Me.BLS5.Visible = False
        '
        'BLS6
        '
        Me.BLS6.BackgroundImage = Global.VB_Game___Cleanup.My.Resources.Resources.black_star
        Me.BLS6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BLS6.Location = New System.Drawing.Point(341, 282)
        Me.BLS6.Name = "BLS6"
        Me.BLS6.Size = New System.Drawing.Size(54, 50)
        Me.BLS6.TabIndex = 14
        Me.BLS6.TabStop = False
        Me.BLS6.Visible = False
        '
        'BLS7
        '
        Me.BLS7.BackgroundImage = Global.VB_Game___Cleanup.My.Resources.Resources.black_star
        Me.BLS7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BLS7.Location = New System.Drawing.Point(470, 24)
        Me.BLS7.Name = "BLS7"
        Me.BLS7.Size = New System.Drawing.Size(54, 50)
        Me.BLS7.TabIndex = 15
        Me.BLS7.TabStop = False
        Me.BLS7.Visible = False
        '
        'BLS8
        '
        Me.BLS8.BackgroundImage = Global.VB_Game___Cleanup.My.Resources.Resources.black_star
        Me.BLS8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BLS8.Location = New System.Drawing.Point(83, 262)
        Me.BLS8.Name = "BLS8"
        Me.BLS8.Size = New System.Drawing.Size(54, 50)
        Me.BLS8.TabIndex = 16
        Me.BLS8.TabStop = False
        Me.BLS8.Visible = False
        '
        'BLS9
        '
        Me.BLS9.BackgroundImage = Global.VB_Game___Cleanup.My.Resources.Resources.black_star
        Me.BLS9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BLS9.Location = New System.Drawing.Point(590, 94)
        Me.BLS9.Name = "BLS9"
        Me.BLS9.Size = New System.Drawing.Size(54, 50)
        Me.BLS9.TabIndex = 17
        Me.BLS9.TabStop = False
        Me.BLS9.Visible = False
        '
        'BLS10
        '
        Me.BLS10.BackgroundImage = Global.VB_Game___Cleanup.My.Resources.Resources.black_star
        Me.BLS10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BLS10.Location = New System.Drawing.Point(18, 346)
        Me.BLS10.Name = "BLS10"
        Me.BLS10.Size = New System.Drawing.Size(54, 50)
        Me.BLS10.TabIndex = 18
        Me.BLS10.TabStop = False
        Me.BLS10.Visible = False
        '
        'BLS11
        '
        Me.BLS11.BackgroundImage = Global.VB_Game___Cleanup.My.Resources.Resources.black_star
        Me.BLS11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BLS11.Location = New System.Drawing.Point(266, 346)
        Me.BLS11.Name = "BLS11"
        Me.BLS11.Size = New System.Drawing.Size(54, 50)
        Me.BLS11.TabIndex = 19
        Me.BLS11.TabStop = False
        Me.BLS11.Visible = False
        '
        'BLS12
        '
        Me.BLS12.BackgroundImage = Global.VB_Game___Cleanup.My.Resources.Resources.black_star
        Me.BLS12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BLS12.Location = New System.Drawing.Point(266, 183)
        Me.BLS12.Name = "BLS12"
        Me.BLS12.Size = New System.Drawing.Size(54, 50)
        Me.BLS12.TabIndex = 20
        Me.BLS12.TabStop = False
        Me.BLS12.Visible = False
        '
        'BLS13
        '
        Me.BLS13.BackgroundImage = Global.VB_Game___Cleanup.My.Resources.Resources.black_star
        Me.BLS13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BLS13.Location = New System.Drawing.Point(470, 272)
        Me.BLS13.Name = "BLS13"
        Me.BLS13.Size = New System.Drawing.Size(54, 50)
        Me.BLS13.TabIndex = 21
        Me.BLS13.TabStop = False
        Me.BLS13.Visible = False
        '
        'BLS14
        '
        Me.BLS14.BackgroundImage = Global.VB_Game___Cleanup.My.Resources.Resources.black_star
        Me.BLS14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BLS14.Location = New System.Drawing.Point(313, 519)
        Me.BLS14.Name = "BLS14"
        Me.BLS14.Size = New System.Drawing.Size(54, 50)
        Me.BLS14.TabIndex = 22
        Me.BLS14.TabStop = False
        Me.BLS14.Visible = False
        '
        'BLS15
        '
        Me.BLS15.BackgroundImage = Global.VB_Game___Cleanup.My.Resources.Resources.black_star
        Me.BLS15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BLS15.Location = New System.Drawing.Point(410, 150)
        Me.BLS15.Name = "BLS15"
        Me.BLS15.Size = New System.Drawing.Size(54, 50)
        Me.BLS15.TabIndex = 27
        Me.BLS15.TabStop = False
        Me.BLS15.Visible = False
        '
        'REDS2
        '
        Me.REDS2.BackgroundImage = Global.VB_Game___Cleanup.My.Resources.Resources.red_star
        Me.REDS2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.REDS2.Location = New System.Drawing.Point(479, 80)
        Me.REDS2.Name = "REDS2"
        Me.REDS2.Size = New System.Drawing.Size(54, 50)
        Me.REDS2.TabIndex = 29
        Me.REDS2.TabStop = False
        '
        'REDS3
        '
        Me.REDS3.BackgroundImage = Global.VB_Game___Cleanup.My.Resources.Resources.red_star
        Me.REDS3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.REDS3.Location = New System.Drawing.Point(133, 115)
        Me.REDS3.Name = "REDS3"
        Me.REDS3.Size = New System.Drawing.Size(54, 50)
        Me.REDS3.TabIndex = 30
        Me.REDS3.TabStop = False
        '
        'REDS4
        '
        Me.REDS4.BackgroundImage = Global.VB_Game___Cleanup.My.Resources.Resources.red_star
        Me.REDS4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.REDS4.Location = New System.Drawing.Point(595, 13)
        Me.REDS4.Name = "REDS4"
        Me.REDS4.Size = New System.Drawing.Size(54, 50)
        Me.REDS4.TabIndex = 31
        Me.REDS4.TabStop = False
        '
        'REDS5
        '
        Me.REDS5.BackgroundImage = Global.VB_Game___Cleanup.My.Resources.Resources.red_star
        Me.REDS5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.REDS5.Location = New System.Drawing.Point(507, 164)
        Me.REDS5.Name = "REDS5"
        Me.REDS5.Size = New System.Drawing.Size(54, 50)
        Me.REDS5.TabIndex = 32
        Me.REDS5.TabStop = False
        '
        'REDS6
        '
        Me.REDS6.BackgroundImage = Global.VB_Game___Cleanup.My.Resources.Resources.red_star
        Me.REDS6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.REDS6.Location = New System.Drawing.Point(266, 290)
        Me.REDS6.Name = "REDS6"
        Me.REDS6.Size = New System.Drawing.Size(54, 50)
        Me.REDS6.TabIndex = 33
        Me.REDS6.TabStop = False
        '
        'REDS7
        '
        Me.REDS7.BackgroundImage = Global.VB_Game___Cleanup.My.Resources.Resources.red_star
        Me.REDS7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.REDS7.Location = New System.Drawing.Point(123, 519)
        Me.REDS7.Name = "REDS7"
        Me.REDS7.Size = New System.Drawing.Size(54, 50)
        Me.REDS7.TabIndex = 34
        Me.REDS7.TabStop = False
        '
        'REDS8
        '
        Me.REDS8.BackgroundImage = Global.VB_Game___Cleanup.My.Resources.Resources.red_star
        Me.REDS8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.REDS8.Location = New System.Drawing.Point(535, 448)
        Me.REDS8.Name = "REDS8"
        Me.REDS8.Size = New System.Drawing.Size(54, 50)
        Me.REDS8.TabIndex = 35
        Me.REDS8.TabStop = False
        '
        'REDS9
        '
        Me.REDS9.BackgroundImage = Global.VB_Game___Cleanup.My.Resources.Resources.red_star
        Me.REDS9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.REDS9.Location = New System.Drawing.Point(590, 282)
        Me.REDS9.Name = "REDS9"
        Me.REDS9.Size = New System.Drawing.Size(54, 50)
        Me.REDS9.TabIndex = 36
        Me.REDS9.TabStop = False
        '
        'REDS10
        '
        Me.REDS10.BackgroundImage = Global.VB_Game___Cleanup.My.Resources.Resources.red_star
        Me.REDS10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.REDS10.Location = New System.Drawing.Point(170, 282)
        Me.REDS10.Name = "REDS10"
        Me.REDS10.Size = New System.Drawing.Size(54, 50)
        Me.REDS10.TabIndex = 37
        Me.REDS10.TabStop = False
        '
        'REDS11
        '
        Me.REDS11.BackgroundImage = Global.VB_Game___Cleanup.My.Resources.Resources.red_star
        Me.REDS11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.REDS11.Location = New System.Drawing.Point(389, 346)
        Me.REDS11.Name = "REDS11"
        Me.REDS11.Size = New System.Drawing.Size(54, 50)
        Me.REDS11.TabIndex = 38
        Me.REDS11.TabStop = False
        '
        'REDS12
        '
        Me.REDS12.BackgroundImage = Global.VB_Game___Cleanup.My.Resources.Resources.red_star
        Me.REDS12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.REDS12.Location = New System.Drawing.Point(16, 262)
        Me.REDS12.Name = "REDS12"
        Me.REDS12.Size = New System.Drawing.Size(54, 50)
        Me.REDS12.TabIndex = 39
        Me.REDS12.TabStop = False
        '
        'REDS13
        '
        Me.REDS13.BackgroundImage = Global.VB_Game___Cleanup.My.Resources.Resources.red_star
        Me.REDS13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.REDS13.Location = New System.Drawing.Point(350, 94)
        Me.REDS13.Name = "REDS13"
        Me.REDS13.Size = New System.Drawing.Size(54, 50)
        Me.REDS13.TabIndex = 40
        Me.REDS13.TabStop = False
        '
        'REDS14
        '
        Me.REDS14.BackgroundImage = Global.VB_Game___Cleanup.My.Resources.Resources.red_star
        Me.REDS14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.REDS14.Location = New System.Drawing.Point(253, 463)
        Me.REDS14.Name = "REDS14"
        Me.REDS14.Size = New System.Drawing.Size(54, 50)
        Me.REDS14.TabIndex = 41
        Me.REDS14.TabStop = False
        '
        'REDS15
        '
        Me.REDS15.BackgroundImage = Global.VB_Game___Cleanup.My.Resources.Resources.red_star
        Me.REDS15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.REDS15.Location = New System.Drawing.Point(410, 262)
        Me.REDS15.Name = "REDS15"
        Me.REDS15.Size = New System.Drawing.Size(54, 50)
        Me.REDS15.TabIndex = 42
        Me.REDS15.TabStop = False
        '
        'Coin3
        '
        Me.Coin3.BackgroundImage = Global.VB_Game___Cleanup.My.Resources.Resources.coin
        Me.Coin3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Coin3.Location = New System.Drawing.Point(110, 330)
        Me.Coin3.Name = "Coin3"
        Me.Coin3.Size = New System.Drawing.Size(54, 50)
        Me.Coin3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Coin3.TabIndex = 45
        Me.Coin3.TabStop = False
        Me.Coin3.Visible = False
        '
        'Coin4
        '
        Me.Coin4.BackgroundImage = Global.VB_Game___Cleanup.My.Resources.Resources.coin
        Me.Coin4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Coin4.Location = New System.Drawing.Point(209, 206)
        Me.Coin4.Name = "Coin4"
        Me.Coin4.Size = New System.Drawing.Size(54, 50)
        Me.Coin4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Coin4.TabIndex = 46
        Me.Coin4.TabStop = False
        Me.Coin4.Visible = False
        '
        'Coin5
        '
        Me.Coin5.BackgroundImage = Global.VB_Game___Cleanup.My.Resources.Resources.coin
        Me.Coin5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Coin5.Location = New System.Drawing.Point(313, 404)
        Me.Coin5.Name = "Coin5"
        Me.Coin5.Size = New System.Drawing.Size(54, 50)
        Me.Coin5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Coin5.TabIndex = 47
        Me.Coin5.TabStop = False
        Me.Coin5.Visible = False
        '
        'Coin6
        '
        Me.Coin6.BackgroundImage = Global.VB_Game___Cleanup.My.Resources.Resources.coin
        Me.Coin6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Coin6.Location = New System.Drawing.Point(535, 45)
        Me.Coin6.Name = "Coin6"
        Me.Coin6.Size = New System.Drawing.Size(54, 50)
        Me.Coin6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Coin6.TabIndex = 48
        Me.Coin6.TabStop = False
        Me.Coin6.Visible = False
        '
        'Coin7
        '
        Me.Coin7.BackgroundImage = Global.VB_Game___Cleanup.My.Resources.Resources.coin
        Me.Coin7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Coin7.Location = New System.Drawing.Point(12, 65)
        Me.Coin7.Name = "Coin7"
        Me.Coin7.Size = New System.Drawing.Size(54, 50)
        Me.Coin7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Coin7.TabIndex = 49
        Me.Coin7.TabStop = False
        Me.Coin7.Visible = False
        '
        'Coin8
        '
        Me.Coin8.BackgroundImage = Global.VB_Game___Cleanup.My.Resources.Resources.coin
        Me.Coin8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Coin8.Location = New System.Drawing.Point(530, 318)
        Me.Coin8.Name = "Coin8"
        Me.Coin8.Size = New System.Drawing.Size(54, 50)
        Me.Coin8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Coin8.TabIndex = 50
        Me.Coin8.TabStop = False
        Me.Coin8.Visible = False
        '
        'Coin9
        '
        Me.Coin9.BackgroundImage = Global.VB_Game___Cleanup.My.Resources.Resources.coin
        Me.Coin9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Coin9.Location = New System.Drawing.Point(9, 193)
        Me.Coin9.Name = "Coin9"
        Me.Coin9.Size = New System.Drawing.Size(54, 50)
        Me.Coin9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Coin9.TabIndex = 51
        Me.Coin9.TabStop = False
        Me.Coin9.Visible = False
        '
        'Coin10
        '
        Me.Coin10.BackgroundImage = Global.VB_Game___Cleanup.My.Resources.Resources.coin
        Me.Coin10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Coin10.Location = New System.Drawing.Point(595, 150)
        Me.Coin10.Name = "Coin10"
        Me.Coin10.Size = New System.Drawing.Size(54, 50)
        Me.Coin10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Coin10.TabIndex = 52
        Me.Coin10.TabStop = False
        Me.Coin10.Visible = False
        '
        'Coin11
        '
        Me.Coin11.BackgroundImage = Global.VB_Game___Cleanup.My.Resources.Resources.coin
        Me.Coin11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Coin11.Location = New System.Drawing.Point(543, 220)
        Me.Coin11.Name = "Coin11"
        Me.Coin11.Size = New System.Drawing.Size(54, 50)
        Me.Coin11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Coin11.TabIndex = 53
        Me.Coin11.TabStop = False
        Me.Coin11.Visible = False
        '
        'Coin12
        '
        Me.Coin12.BackgroundImage = Global.VB_Game___Cleanup.My.Resources.Resources.coin
        Me.Coin12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Coin12.Location = New System.Drawing.Point(376, 206)
        Me.Coin12.Name = "Coin12"
        Me.Coin12.Size = New System.Drawing.Size(54, 50)
        Me.Coin12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Coin12.TabIndex = 54
        Me.Coin12.TabStop = False
        Me.Coin12.Visible = False
        '
        'Coin13
        '
        Me.Coin13.BackgroundImage = Global.VB_Game___Cleanup.My.Resources.Resources.coin
        Me.Coin13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Coin13.Location = New System.Drawing.Point(389, 13)
        Me.Coin13.Name = "Coin13"
        Me.Coin13.Size = New System.Drawing.Size(54, 50)
        Me.Coin13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Coin13.TabIndex = 55
        Me.Coin13.TabStop = False
        Me.Coin13.Visible = False
        '
        'Coin14
        '
        Me.Coin14.BackgroundImage = Global.VB_Game___Cleanup.My.Resources.Resources.coin
        Me.Coin14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Coin14.Location = New System.Drawing.Point(230, 65)
        Me.Coin14.Name = "Coin14"
        Me.Coin14.Size = New System.Drawing.Size(54, 50)
        Me.Coin14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Coin14.TabIndex = 56
        Me.Coin14.TabStop = False
        Me.Coin14.Visible = False
        '
        'Coin15
        '
        Me.Coin15.BackgroundImage = Global.VB_Game___Cleanup.My.Resources.Resources.coin
        Me.Coin15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Coin15.Location = New System.Drawing.Point(595, 413)
        Me.Coin15.Name = "Coin15"
        Me.Coin15.Size = New System.Drawing.Size(54, 50)
        Me.Coin15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Coin15.TabIndex = 57
        Me.Coin15.TabStop = False
        Me.Coin15.Visible = False
        '
        'Coin1
        '
        Me.Coin1.BackgroundImage = Global.VB_Game___Cleanup.My.Resources.Resources.coin
        Me.Coin1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Coin1.Location = New System.Drawing.Point(52, 448)
        Me.Coin1.Name = "Coin1"
        Me.Coin1.Size = New System.Drawing.Size(54, 50)
        Me.Coin1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Coin1.TabIndex = 58
        Me.Coin1.TabStop = False
        Me.Coin1.Visible = False
        '
        'Coin2REDONE
        '
        Me.Coin2REDONE.BackgroundImage = Global.VB_Game___Cleanup.My.Resources.Resources.coin
        Me.Coin2REDONE.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Coin2REDONE.Location = New System.Drawing.Point(495, 519)
        Me.Coin2REDONE.Name = "Coin2REDONE"
        Me.Coin2REDONE.Size = New System.Drawing.Size(54, 50)
        Me.Coin2REDONE.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Coin2REDONE.TabIndex = 59
        Me.Coin2REDONE.TabStop = False
        Me.Coin2REDONE.Visible = False
        '
        'BTNEXIT
        '
        Me.BTNEXIT.Location = New System.Drawing.Point(574, 519)
        Me.BTNEXIT.Name = "BTNEXIT"
        Me.BTNEXIT.Size = New System.Drawing.Size(75, 63)
        Me.BTNEXIT.TabIndex = 60
        Me.BTNEXIT.Text = "Exit"
        Me.BTNEXIT.UseVisualStyleBackColor = True
        '
        'Cleanup
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.ClientSize = New System.Drawing.Size(661, 594)
        Me.Controls.Add(Me.BTNEXIT)
        Me.Controls.Add(Me.Coin2REDONE)
        Me.Controls.Add(Me.Coin1)
        Me.Controls.Add(Me.Coin15)
        Me.Controls.Add(Me.Coin14)
        Me.Controls.Add(Me.Coin13)
        Me.Controls.Add(Me.Coin12)
        Me.Controls.Add(Me.Coin11)
        Me.Controls.Add(Me.Coin10)
        Me.Controls.Add(Me.Coin9)
        Me.Controls.Add(Me.Coin8)
        Me.Controls.Add(Me.Coin7)
        Me.Controls.Add(Me.Coin6)
        Me.Controls.Add(Me.Coin5)
        Me.Controls.Add(Me.Coin4)
        Me.Controls.Add(Me.Coin3)
        Me.Controls.Add(Me.REDS15)
        Me.Controls.Add(Me.REDS14)
        Me.Controls.Add(Me.REDS13)
        Me.Controls.Add(Me.REDS12)
        Me.Controls.Add(Me.REDS11)
        Me.Controls.Add(Me.REDS10)
        Me.Controls.Add(Me.REDS9)
        Me.Controls.Add(Me.REDS8)
        Me.Controls.Add(Me.REDS7)
        Me.Controls.Add(Me.REDS6)
        Me.Controls.Add(Me.REDS5)
        Me.Controls.Add(Me.REDS4)
        Me.Controls.Add(Me.REDS3)
        Me.Controls.Add(Me.REDS2)
        Me.Controls.Add(Me.BLS15)
        Me.Controls.Add(Me.BLS14)
        Me.Controls.Add(Me.BLS13)
        Me.Controls.Add(Me.BLS12)
        Me.Controls.Add(Me.BLS11)
        Me.Controls.Add(Me.BLS10)
        Me.Controls.Add(Me.BLS9)
        Me.Controls.Add(Me.BLS8)
        Me.Controls.Add(Me.BLS7)
        Me.Controls.Add(Me.BLS6)
        Me.Controls.Add(Me.BLS5)
        Me.Controls.Add(Me.BLS4)
        Me.Controls.Add(Me.BLS3)
        Me.Controls.Add(Me.BLS2)
        Me.Controls.Add(Me.ScoreScroll)
        Me.Controls.Add(Me.REDS1)
        Me.Controls.Add(Me.BLS1)
        Me.Controls.Add(Me.BTNHARD)
        Me.Controls.Add(Me.BTNMEDIUM)
        Me.Controls.Add(Me.zed)
        Me.Controls.Add(Me.score)
        Me.Controls.Add(Me.BTNEASY)
        Me.Name = "Cleanup"
        Me.Text = "Cleanup Game"
        CType(Me.REDS1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BLS1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BLS2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BLS3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BLS4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BLS5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BLS6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BLS7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BLS8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BLS9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BLS10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BLS11, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BLS12, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BLS13, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BLS14, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BLS15, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.REDS2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.REDS3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.REDS4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.REDS5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.REDS6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.REDS7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.REDS8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.REDS9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.REDS10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.REDS11, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.REDS12, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.REDS13, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.REDS14, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.REDS15, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Coin3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Coin4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Coin5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Coin6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Coin7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Coin8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Coin9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Coin10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Coin11, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Coin12, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Coin13, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Coin14, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Coin15, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Coin1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Coin2REDONE, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents BTNEASY As Button
    Friend WithEvents score As Label
    Friend WithEvents zed As Label
    Friend WithEvents BTNMEDIUM As Button
    Friend WithEvents BTNHARD As Button
    Friend WithEvents BLS1 As PictureBox
    Friend WithEvents Coin2 As PictureBox
    Friend WithEvents REDS1 As PictureBox
    Private WithEvents ScoreScroll As HScrollBar
    Friend WithEvents BLS2 As PictureBox
    Friend WithEvents BLS3 As PictureBox
    Friend WithEvents BLS4 As PictureBox
    Friend WithEvents BLS5 As PictureBox
    Friend WithEvents BLS6 As PictureBox
    Friend WithEvents BLS7 As PictureBox
    Friend WithEvents BLS8 As PictureBox
    Friend WithEvents BLS9 As PictureBox
    Friend WithEvents BLS10 As PictureBox
    Friend WithEvents BLS11 As PictureBox
    Friend WithEvents BLS12 As PictureBox
    Friend WithEvents BLS13 As PictureBox
    Friend WithEvents BLS14 As PictureBox
    Friend WithEvents BLS15 As PictureBox
    Friend WithEvents REDS2 As PictureBox
    Friend WithEvents REDS3 As PictureBox
    Friend WithEvents REDS4 As PictureBox
    Friend WithEvents REDS5 As PictureBox
    Friend WithEvents REDS6 As PictureBox
    Friend WithEvents REDS7 As PictureBox
    Friend WithEvents REDS8 As PictureBox
    Friend WithEvents REDS9 As PictureBox
    Friend WithEvents REDS10 As PictureBox
    Friend WithEvents REDS11 As PictureBox
    Friend WithEvents REDS12 As PictureBox
    Friend WithEvents REDS13 As PictureBox
    Friend WithEvents REDS14 As PictureBox
    Friend WithEvents REDS15 As PictureBox

    Friend WithEvents Coin3 As PictureBox
    Friend WithEvents Coin4 As PictureBox
    Friend WithEvents Coin5 As PictureBox
    Friend WithEvents Coin6 As PictureBox
    Friend WithEvents Coin7 As PictureBox
    Friend WithEvents Coin8 As PictureBox
    Friend WithEvents Coin9 As PictureBox
    Friend WithEvents Coin10 As PictureBox
    Friend WithEvents Coin11 As PictureBox
    Friend WithEvents Coin12 As PictureBox
    Friend WithEvents Coin13 As PictureBox
    Friend WithEvents Coin14 As PictureBox
    Friend WithEvents Coin15 As PictureBox
    Friend WithEvents Coin1 As PictureBox
    Friend WithEvents Coin2REDONE As PictureBox
    Friend WithEvents BTNEXIT As Button
End Class
