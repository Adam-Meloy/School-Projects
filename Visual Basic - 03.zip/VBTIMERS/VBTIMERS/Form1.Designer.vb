﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.somerandomtext = New System.Windows.Forms.Label()
        Me.BUTTON = New System.Windows.Forms.Button()
        Me.PICTURE = New System.Windows.Forms.PictureBox()
        Me.NUMBER = New System.Windows.Forms.Label()
        Me.COLOUR = New System.Windows.Forms.Label()
        Me.TICKZ = New System.Windows.Forms.Label()
        Me.NUMBERTIMER = New System.Windows.Forms.Timer(Me.components)
        Me.COINTIMER = New System.Windows.Forms.Timer(Me.components)
        Me.COLOURTIMER = New System.Windows.Forms.Timer(Me.components)
        CType(Me.PICTURE, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'somerandomtext
        '
        Me.somerandomtext.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.somerandomtext.Location = New System.Drawing.Point(12, 9)
        Me.somerandomtext.Name = "somerandomtext"
        Me.somerandomtext.Size = New System.Drawing.Size(313, 49)
        Me.somerandomtext.TabIndex = 1
        Me.somerandomtext.Text = "Ticks Since Timer Start:"
        '
        'BUTTON
        '
        Me.BUTTON.Font = New System.Drawing.Font("Microsoft Sans Serif", 72.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BUTTON.ForeColor = System.Drawing.SystemColors.WindowText
        Me.BUTTON.Location = New System.Drawing.Point(12, 234)
        Me.BUTTON.Name = "BUTTON"
        Me.BUTTON.Size = New System.Drawing.Size(522, 142)
        Me.BUTTON.TabIndex = 2
        Me.BUTTON.Text = "Start"
        Me.BUTTON.UseVisualStyleBackColor = True
        '
        'PICTURE
        '
        Me.PICTURE.Location = New System.Drawing.Point(188, 61)
        Me.PICTURE.Name = "PICTURE"
        Me.PICTURE.Size = New System.Drawing.Size(170, 170)
        Me.PICTURE.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PICTURE.TabIndex = 0
        Me.PICTURE.TabStop = False
        '
        'NUMBER
        '
        Me.NUMBER.Font = New System.Drawing.Font("Microsoft Sans Serif", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NUMBER.Location = New System.Drawing.Point(12, 58)
        Me.NUMBER.Name = "NUMBER"
        Me.NUMBER.Size = New System.Drawing.Size(170, 170)
        Me.NUMBER.TabIndex = 3
        Me.NUMBER.Text = "Random Number From 1-10"
        '
        'COLOUR
        '
        Me.COLOUR.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.COLOUR.Location = New System.Drawing.Point(364, 61)
        Me.COLOUR.Name = "COLOUR"
        Me.COLOUR.Size = New System.Drawing.Size(170, 170)
        Me.COLOUR.TabIndex = 4
        Me.COLOUR.Text = "Random Color"
        '
        'TICKZ
        '
        Me.TICKZ.Font = New System.Drawing.Font("Microsoft Sans Serif", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TICKZ.Location = New System.Drawing.Point(331, 9)
        Me.TICKZ.Name = "TICKZ"
        Me.TICKZ.Size = New System.Drawing.Size(205, 49)
        Me.TICKZ.TabIndex = 5
        Me.TICKZ.Text = "XXX"
        '
        'NUMBERTIMER
        '
        '
        'COINTIMER
        '
        '
        'COLOURTIMER
        '
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(548, 388)
        Me.Controls.Add(Me.TICKZ)
        Me.Controls.Add(Me.COLOUR)
        Me.Controls.Add(Me.NUMBER)
        Me.Controls.Add(Me.BUTTON)
        Me.Controls.Add(Me.somerandomtext)
        Me.Controls.Add(Me.PICTURE)
        Me.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.PICTURE, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents PICTURE As PictureBox
    Friend WithEvents somerandomtext As Label
    Friend WithEvents BUTTON As Button
    Friend WithEvents NUMBER As Label
    Friend WithEvents COLOUR As Label
    Friend WithEvents TICKZ As Label
    Friend WithEvents NUMBERTIMER As Timer
    Friend WithEvents COINTIMER As Timer
    Friend WithEvents COLOURTIMER As Timer
End Class
