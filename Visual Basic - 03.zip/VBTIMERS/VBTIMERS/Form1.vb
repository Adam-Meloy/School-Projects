﻿Public Class Form1
    Dim Tick, Coin, RandoNum As Integer
    Dim RGB As Color
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Tick = 0
        RandoNum = 0
        Coin = 0
    End Sub
    Private Sub BUTTON_Click(sender As Object, e As EventArgs) Handles BUTTON.Click
        If BUTTON.Text = "Start" Then
            NUMBERTIMER.Enabled = True
            COINTIMER.Enabled = True
            COLOURTIMER.Enabled = True
            BUTTON.Text = "Stop"
            COLOUR.BackColor = Color.White
            COLOUR.ForeColor = Color.Black
            somerandomtext.ForeColor = Color.Black
            TICKZ.ForeColor = Color.Black
            NUMBER.ForeColor = Color.Black
            BUTTON.ForeColor = Color.Black
            COLOUR.ForeColor = Color.Black
            Tick = 0
            TICKZ.Text = Tick
        ElseIf BUTTON.Text = "Stop" Then
            NUMBERTIMER.Enabled = False
            COINTIMER.Enabled = False
            COLOURTIMER.Enabled = False
            BUTTON.Text = "Start"
            COLOUR.BackColor = RGB
            COLOUR.ForeColor = RGB
        End If
    End Sub
    Private Sub NUMBERTIMER_Tick(sender As Object, e As EventArgs) Handles NUMBERTIMER.Tick
        Randomize()
        RandoNum = Int(Rnd() * 10) + 1
        If RandoNum = 1 Then
            NUMBER.ForeColor = Color.Red
            BUTTON.ForeColor = Color.Red
            COLOUR.ForeColor = Color.Red
            somerandomtext.ForeColor = Color.Red
            TICKZ.ForeColor = Color.Red
            COLOUR.Text = "Red"
            NUMBER.Text = 1
        ElseIf RandoNum = 2 Then
            NUMBER.ForeColor = Color.Green
            BUTTON.ForeColor = Color.Green
            COLOUR.ForeColor = Color.Green
            somerandomtext.ForeColor = Color.Green
            TICKZ.ForeColor = Color.Green
            COLOUR.Text = "Green"
            NUMBER.Text = 2
        ElseIf RandoNum = 3 Then
            NUMBER.ForeColor = Color.Blue
            BUTTON.ForeColor = Color.Blue
            COLOUR.ForeColor = Color.Blue
            somerandomtext.ForeColor = Color.Blue
            TICKZ.ForeColor = Color.Blue
            COLOUR.Text = "Blue"
            NUMBER.Text = 3
        ElseIf RandoNum = 4 Then
            NUMBER.ForeColor = Color.Black
            BUTTON.ForeColor = Color.Black
            COLOUR.ForeColor = Color.Black
            somerandomtext.ForeColor = Color.Black
            TICKZ.ForeColor = Color.Black
            COLOUR.Text = "Black"
            NUMBER.Text = 4
        ElseIf RandoNum = 5 Then
            NUMBER.ForeColor = Color.Yellow
            BUTTON.ForeColor = Color.Yellow
            COLOUR.ForeColor = Color.Yellow
            somerandomtext.ForeColor = Color.Yellow
            TICKZ.ForeColor = Color.Yellow
            COLOUR.Text = "Yellow"
            NUMBER.Text = 5
        ElseIf RandoNum = 6 Then
            NUMBER.ForeColor = Color.Orange
            BUTTON.ForeColor = Color.Orange
            COLOUR.ForeColor = Color.Orange
            somerandomtext.ForeColor = Color.Orange
            TICKZ.ForeColor = Color.Orange
            COLOUR.Text = "Orange"
            NUMBER.Text = 6
        ElseIf RandoNum = 7 Then
            NUMBER.ForeColor = Color.Purple
            BUTTON.ForeColor = Color.Purple
            COLOUR.ForeColor = Color.Purple
            somerandomtext.ForeColor = Color.Purple
            TICKZ.ForeColor = Color.Purple
            COLOUR.Text = "Purple"
            NUMBER.Text = 7
        ElseIf RandoNum = 8 Then
            NUMBER.ForeColor = Color.Brown
            BUTTON.ForeColor = Color.Brown
            COLOUR.ForeColor = Color.Brown
            somerandomtext.ForeColor = Color.Brown
            TICKZ.ForeColor = Color.Brown
            COLOUR.Text = "Brown"
            NUMBER.Text = 8
        ElseIf RandoNum = 9 Then
            NUMBER.ForeColor = Color.Lime
            BUTTON.ForeColor = Color.Lime
            COLOUR.ForeColor = Color.Lime
            somerandomtext.ForeColor = Color.Lime
            TICKZ.ForeColor = Color.Lime
            COLOUR.Text = "Lime"
            NUMBER.Text = 9
        ElseIf RandoNum = 10 Then
            NUMBER.ForeColor = Color.Turquoise
            BUTTON.ForeColor = Color.Turquoise
            COLOUR.ForeColor = Color.Turquoise
            somerandomtext.ForeColor = Color.Turquoise
            TICKZ.ForeColor = Color.Turquoise
            COLOUR.Text = "Turquoise"
            NUMBER.Text = 10
        End If
    End Sub
    Private Sub COINTIMER_Tick(sender As Object, e As EventArgs) Handles COINTIMER.Tick
        Randomize()
        Coin = Int(Rnd() * 2) + 1
        If Tick = 50 Then
            Tick = 0
            BUTTON.Text = "Start"
            COINTIMER.Enabled = False
            NUMBERTIMER.Enabled = False
            COLOURTIMER.Enabled = False +
            Tick = 0
            COLOUR.BackColor = RGB
            COLOUR.ForeColor = RGB
            somerandomtext.ForeColor = Color.Black
            TICKZ.ForeColor = Color.Black
        End If
        If Coin = 1 Then
            PICTURE.Image = My.Resources.sasas
            Tick = Tick + 1
            TICKZ.Text = Tick
        ElseIf Coin = 2 Then
            PICTURE.Image = My.Resources.dadad
            Tick = Tick + 1
            TICKZ.Text = Tick
        End If
    End Sub
    Private Sub COLOURTIMER_Tick(sender As Object, e As EventArgs) Handles COLOURTIMER.Tick
        RGB = Color.FromArgb(Int(Rnd() * 255), Int(Rnd() * 255), Int(Rnd() * 255))
        If COLOURTIMER.Enabled = False Then
        End If
    End Sub
End Class