﻿Public Class Game
    Dim CheckBoxes(62), Checkbox As CheckBox
    Dim RandomPick, PLAYER_TRACKER, CountifDone, X, Y As Integer
    Dim cpu As String
    Private Sub Game_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Y = 10
        X = 1
        Call Game_Setup()
    End Sub
    Private Sub RULES_Click(sender As Object, e As EventArgs) Handles RULES.Click
        MsgBox("The rules are as follows. 1. Every time you click a checked box, every box to the right, including itself, are unchecked. 2. The first person to uncheck all the boxes wins. P0: CPU, P1: P1, P2: P2.")
    End Sub
    Private Sub Game_Setup()
        cpu = InputBox("Do you want to play against an AI or another person?, AI for computer, P2 or another player.")
        PlayerLabel.Text = "Player One's Turn"
        PLAYER_TRACKER = 1
        For i = 0 To CheckBoxes.Length - 1
            Checkbox = New CheckBox
            Checkbox.Name = i
            Checkbox.Checked = True
            Checkbox.Width = 15
            Checkbox.Height = 15
            Checkbox.Left = X
            Checkbox.Top = Y
            If Checkbox.Name = 20 Or Checkbox.Name = 41 Then
                Y += 25
                X = 1
            Else
                X += 25
            End If
            AddHandler Checkbox.MouseClick, AddressOf EraseChecks
            AddHandler Checkbox.MouseClick, AddressOf Game_End
            Me.Controls.Add(Checkbox)
            CheckBoxes(i) = Checkbox
            If cpu = "AI" Or cpu = "ai" Then
                AddHandler Checkbox.MouseClick, AddressOf P_V_CPU
            ElseIf cpu = "P2" Or cpu = "p2" Then
                AddHandler Checkbox.MouseClick, AddressOf PLAYER_SWITCH
            End If
        Next
        GameEnd.Enabled = True
    End Sub
    Private Sub P_V_CPU(sender As Object, e As EventArgs)
        Randomize()
        RandomPick = Int(Rnd() * 63) - 1
        For l = 0 To CheckBoxes.Length - 1
            If CheckBoxes(RandomPick).Checked = False Then
                Randomize()
                RandomPick = Int(Rnd() * 63) - 1
            Else
                CheckBoxes(RandomPick).Checked = False
                For f = 0 To CheckBoxes.Length - 1
                    If CheckBoxes(f).Top = CheckBoxes(RandomPick).Top And CheckBoxes(f).Left > CheckBoxes(RandomPick).Left Then
                        CheckBoxes(f).Checked = False
                    End If
                Next
                Exit For
            End If
        Next
        PLAYER_TRACKER = 0
    End Sub
    Private Sub EraseChecks(sender As Object, e As EventArgs)
        For f = 0 To CheckBoxes.Length - 1
            If CheckBoxes(f).Top = sender.Top And CheckBoxes(f).Left > sender.Left Then
                CheckBoxes(f).Checked = False
            End If
        Next
    End Sub
    Private Sub PLAYER_SWITCH()
        If PlayerLabel.Text = "Player One's Turn" Then
            PlayerLabel.Text = "Player Two's Turn"
            PLAYER_TRACKER = 2
        Else
            PlayerLabel.Text = "Player One's Turn"
            PLAYER_TRACKER = 1
        End If
    End Sub
    Private Sub Game_End()
        CountifDone = 0
        For j = 0 To CheckBoxes.Length - 1
            If CheckBoxes(j).Checked = False Then
                CountifDone += 1
            End If
            If CountifDone = 63 Then
                Exit For
            End If
        Next
        If CountifDone = 63 Then
            GameEnd.Enabled = False
            MsgBox("Player " & PLAYER_TRACKER & " Wins The Game!")
            Close()
        End If
    End Sub
    Private Sub GameEnd_Tick(sender As Object, e As EventArgs) Handles GameEnd.Tick
        Call Game_End()
    End Sub
End Class