﻿Public Class Form1
    Private Sub ARTISTNAMES_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ARTISTNAMES.SelectedIndexChanged
        SCORE.Visible = True
        GB1.Visible = True
        If ARTISTNAMES.Text = "Eminem" Then
            PICTURES.Image = My.Resources.MNM
            RB1.Text = "Recovery"
            RB2.Text = "Infinite"
            RB3.Text = "The Re-Up"
            GB1.Text = "𝐸𝑚𝑖𝑛𝑒𝑚"
        End If
        If ARTISTNAMES.Text = "Hollywood Undead" Then
            PICTURES.Image = My.Resources.HOLLYWUDUNDED
            RB1.Text = "American Tragedy"
            RB2.Text = "Young"
            RB3.Text = "Day Of The Dead"
            GB1.Text = "𝐻𝑜𝑙𝑙𝑦𝑤𝑜𝑜𝑑 𝑈𝑛𝑑𝑒𝑎𝑑"
        End If
        If ARTISTNAMES.Text = "Michael Jackson" Then
            PICTURES.Image = My.Resources.MIKEL_JAKSO
            RB1.Text = "Smooth Criminal"
            RB2.Text = "Dangerous"
            RB3.Text = "Invincible"
            GB1.Text = "Michael 𝐽𝑎𝑐𝑘𝑠𝑜𝑛"
        End If
    End Sub

    Private Sub RadioButton1_CheckedChanged(sender As Object, e As EventArgs) Handles RB1.CheckedChanged
        If ARTISTNAMES.Text = "Eminem" Then
            PICTURES.Image = My.Resources.R1
            RATEME.Visible = True
            SUBMIT.Visible = True
        End If
        If ARTISTNAMES.Text = "Hollywood Undead" Then
            PICTURES.Image = My.Resources.AT1
            RATEME.Visible = True
            SUBMIT.Visible = True
        End If
        If ARTISTNAMES.Text = "Michael Jackson" Then
            PICTURES.Image = My.Resources.SMOOTHCRIMINAL1
            RATEME.Visible = True
            SUBMIT.Visible = True
        End If
    End Sub

    Private Sub RadioButton2_CheckedChanged(sender As Object, e As EventArgs) Handles RB2.CheckedChanged
        If ARTISTNAMES.Text = "Eminem" Then
            PICTURES.Image = My.Resources.I2
            RATEME.Visible = True
            SUBMIT.Visible = True
        End If
        If ARTISTNAMES.Text = "Hollywood Undead" Then
            PICTURES.Image = My.Resources.YOUNGCOVER
            RATEME.Visible = True
            SUBMIT.Visible = True
        End If
        If ARTISTNAMES.Text = "Michael Jackson" Then
            PICTURES.Image = My.Resources.D2
            RATEME.Visible = True
            SUBMIT.Visible = True
        End If
    End Sub

    Private Sub RadioButton3_CheckedChanged(sender As Object, e As EventArgs) Handles RB3.CheckedChanged
        If ARTISTNAMES.Text = "Eminem" Then
            PICTURES.Image = My.Resources.TR_U3
            RATEME.Visible = True
            SUBMIT.Visible = True
        End If
        If ARTISTNAMES.Text = "Hollywood Undead" Then
            PICTURES.Image = My.Resources.DOTD3
            RATEME.Visible = True
            SUBMIT.Visible = True
        End If
        If ARTISTNAMES.Text = "Michael Jackson" Then
            PICTURES.Image = My.Resources.I3
            RATEME.Visible = True
            SUBMIT.Visible = True
        End If
    End Sub

    Private Sub RATEME_Scroll(sender As Object, e As ScrollEventArgs) Handles RATEME.Scroll
        SCORE.Text = RATEME.Value
    End Sub

    Private Sub SUBMIT_Click(sender As Object, e As EventArgs) Handles SUBMIT.Click
        If RB1.Checked Then
            MsgBox("Thank you For submitting score Of " & SCORE.Text & " For " & ARTISTNAMES.Text & "'s " & RB1.Text)

        End If
        If RB2.Checked Then
            MsgBox("Thank you for submitting score of " & SCORE.Text & " for " & ARTISTNAMES.Text & "'s " & RB2.Text)
        End If
        If RB3.Checked Then
            MsgBox("Thank you for submitting score of " & SCORE.Text & " for " & ARTISTNAMES.Text & "'s " & RB3.Text)
        End If
        Close()
    End Sub
End Class
