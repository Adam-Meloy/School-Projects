﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.RB3 = New System.Windows.Forms.RadioButton()
        Me.RB2 = New System.Windows.Forms.RadioButton()
        Me.RB1 = New System.Windows.Forms.RadioButton()
        Me.DIRECTIONS = New System.Windows.Forms.Label()
        Me.ARTIST = New System.Windows.Forms.Label()
        Me.ARTISTNAMES = New System.Windows.Forms.ComboBox()
        Me.PICTURES = New System.Windows.Forms.PictureBox()
        Me.SUBMIT = New System.Windows.Forms.Button()
        Me.RATEME = New System.Windows.Forms.HScrollBar()
        Me.SCORE = New System.Windows.Forms.Label()
        Me.GB1 = New System.Windows.Forms.GroupBox()
        CType(Me.PICTURES, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GB1.SuspendLayout()
        Me.SuspendLayout()
        '
        'RB3
        '
        Me.RB3.AutoSize = True
        Me.RB3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RB3.Location = New System.Drawing.Point(6, 69)
        Me.RB3.Name = "RB3"
        Me.RB3.Size = New System.Drawing.Size(37, 19)
        Me.RB3.TabIndex = 5
        Me.RB3.TabStop = True
        Me.RB3.Text = "---"
        Me.RB3.UseVisualStyleBackColor = True
        '
        'RB2
        '
        Me.RB2.AutoSize = True
        Me.RB2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RB2.Location = New System.Drawing.Point(6, 44)
        Me.RB2.Name = "RB2"
        Me.RB2.Size = New System.Drawing.Size(37, 19)
        Me.RB2.TabIndex = 4
        Me.RB2.TabStop = True
        Me.RB2.Text = "---"
        Me.RB2.UseVisualStyleBackColor = True
        '
        'RB1
        '
        Me.RB1.AutoSize = True
        Me.RB1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RB1.Location = New System.Drawing.Point(6, 19)
        Me.RB1.Name = "RB1"
        Me.RB1.Size = New System.Drawing.Size(37, 19)
        Me.RB1.TabIndex = 3
        Me.RB1.TabStop = True
        Me.RB1.Text = "---"
        Me.RB1.UseVisualStyleBackColor = True
        '
        'DIRECTIONS
        '
        Me.DIRECTIONS.AutoSize = True
        Me.DIRECTIONS.Location = New System.Drawing.Point(114, 9)
        Me.DIRECTIONS.Name = "DIRECTIONS"
        Me.DIRECTIONS.Size = New System.Drawing.Size(280, 91)
        Me.DIRECTIONS.TabIndex = 0
        Me.DIRECTIONS.Text = resources.GetString("DIRECTIONS.Text")
        '
        'ARTIST
        '
        Me.ARTIST.AutoSize = True
        Me.ARTIST.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ARTIST.Location = New System.Drawing.Point(56, 163)
        Me.ARTIST.Name = "ARTIST"
        Me.ARTIST.Size = New System.Drawing.Size(78, 31)
        Me.ARTIST.TabIndex = 1
        Me.ARTIST.Text = "𝘈𝘳𝘵𝘪𝘴𝘵:"
        '
        'ARTISTNAMES
        '
        Me.ARTISTNAMES.FormattingEnabled = True
        Me.ARTISTNAMES.Items.AddRange(New Object() {"Eminem", "Hollywood Undead", "Michael Jackson"})
        Me.ARTISTNAMES.Location = New System.Drawing.Point(62, 194)
        Me.ARTISTNAMES.Name = "ARTISTNAMES"
        Me.ARTISTNAMES.Size = New System.Drawing.Size(120, 21)
        Me.ARTISTNAMES.TabIndex = 7
        '
        'PICTURES
        '
        Me.PICTURES.Location = New System.Drawing.Point(222, 194)
        Me.PICTURES.Name = "PICTURES"
        Me.PICTURES.Size = New System.Drawing.Size(280, 268)
        Me.PICTURES.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PICTURES.TabIndex = 8
        Me.PICTURES.TabStop = False
        '
        'SUBMIT
        '
        Me.SUBMIT.Location = New System.Drawing.Point(62, 408)
        Me.SUBMIT.Name = "SUBMIT"
        Me.SUBMIT.Size = New System.Drawing.Size(75, 23)
        Me.SUBMIT.TabIndex = 9
        Me.SUBMIT.Text = "Submit"
        Me.SUBMIT.UseVisualStyleBackColor = True
        Me.SUBMIT.Visible = False
        '
        'RATEME
        '
        Me.RATEME.LargeChange = 5
        Me.RATEME.Location = New System.Drawing.Point(222, 171)
        Me.RATEME.Maximum = 14
        Me.RATEME.Name = "RATEME"
        Me.RATEME.Size = New System.Drawing.Size(250, 20)
        Me.RATEME.TabIndex = 10
        Me.RATEME.Visible = False
        '
        'SCORE
        '
        Me.SCORE.AutoSize = True
        Me.SCORE.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SCORE.Location = New System.Drawing.Point(475, 171)
        Me.SCORE.Name = "SCORE"
        Me.SCORE.Size = New System.Drawing.Size(18, 20)
        Me.SCORE.TabIndex = 11
        Me.SCORE.Text = "0"
        '
        'GB1
        '
        Me.GB1.Controls.Add(Me.RB1)
        Me.GB1.Controls.Add(Me.RB3)
        Me.GB1.Controls.Add(Me.RB2)
        Me.GB1.Location = New System.Drawing.Point(62, 222)
        Me.GB1.Name = "GB1"
        Me.GB1.Size = New System.Drawing.Size(120, 100)
        Me.GB1.TabIndex = 12
        Me.GB1.TabStop = False
        Me.GB1.Text = "𝘈𝘳𝘵𝘪𝘴𝘵"
        Me.GB1.Visible = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(514, 474)
        Me.Controls.Add(Me.GB1)
        Me.Controls.Add(Me.SCORE)
        Me.Controls.Add(Me.RATEME)
        Me.Controls.Add(Me.SUBMIT)
        Me.Controls.Add(Me.PICTURES)
        Me.Controls.Add(Me.ARTISTNAMES)
        Me.Controls.Add(Me.ARTIST)
        Me.Controls.Add(Me.DIRECTIONS)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.PICTURES, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GB1.ResumeLayout(False)
        Me.GB1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents DIRECTIONS As Label
    Friend WithEvents ARTIST As Label
    Friend WithEvents RB1 As RadioButton
    Friend WithEvents RB2 As RadioButton
    Friend WithEvents RB3 As RadioButton
    Friend WithEvents ARTISTNAMES As ComboBox
    Friend WithEvents PICTURES As PictureBox
    Friend WithEvents SUBMIT As Button
    Friend WithEvents RATEME As HScrollBar
    Friend WithEvents SCORE As Label
    Friend WithEvents GB1 As GroupBox
End Class
