﻿Public Class frmMain
    Private Sub btnEnglish_Click(sender As Object, e As EventArgs) Handles btnEnglish.Click
        frmEnglish.Show()
        Me.Hide()
    End Sub

    Private Sub btnSpanish_Click(sender As Object, e As EventArgs) Handles btnSpanish.Click
        FRMSPANISH.Show()
        Me.Hide()
    End Sub
End Class
