﻿Public Class frmEnglish

    Private Sub frmEnglish_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        NameList.Items.Add("Katie")
        NameList.Items.Add("Robert")
        NameList.Items.Add("Adam")
        NameList.Items.Add("Cameron")
        NameList.Items.Add("Austin")
    End Sub

    Private Sub listNames_SelectedIndexChanged(sender As Object, e As EventArgs) Handles NameList.SelectedIndexChanged
        lblNameSelected.Text = "The name you selected is " & NameList.Text & "."
    End Sub

    Private Sub BACK_Click(sender As Object, e As EventArgs) Handles BACK.Click
        frmMain.Show()
        Me.Close()
    End Sub
End Class