﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FRMSPANISH
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.NameList = New System.Windows.Forms.ListBox()
        Me.lblNameSelected = New System.Windows.Forms.Label()
        Me.BACK = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'NameList
        '
        Me.NameList.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NameList.FormattingEnabled = True
        Me.NameList.ItemHeight = 20
        Me.NameList.Location = New System.Drawing.Point(36, 74)
        Me.NameList.Name = "NameList"
        Me.NameList.Size = New System.Drawing.Size(184, 144)
        Me.NameList.TabIndex = 1
        '
        'lblNameSelected
        '
        Me.lblNameSelected.AutoSize = True
        Me.lblNameSelected.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNameSelected.Location = New System.Drawing.Point(12, 275)
        Me.lblNameSelected.Name = "lblNameSelected"
        Me.lblNameSelected.Size = New System.Drawing.Size(434, 25)
        Me.lblNameSelected.TabIndex = 2
        Me.lblNameSelected.Text = "El nombre que ha seleccionado es  XXX" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'BACK
        '
        Me.BACK.Location = New System.Drawing.Point(561, 316)
        Me.BACK.Name = "BACK"
        Me.BACK.Size = New System.Drawing.Size(109, 93)
        Me.BACK.TabIndex = 5
        Me.BACK.Text = "Back"
        Me.BACK.UseVisualStyleBackColor = True
        '
        'FRMSPANISH
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(682, 421)
        Me.Controls.Add(Me.BACK)
        Me.Controls.Add(Me.lblNameSelected)
        Me.Controls.Add(Me.NameList)
        Me.Name = "FRMSPANISH"
        Me.Text = "Spanish Names"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents NameList As ListBox
    Friend WithEvents lblNameSelected As Label
    Friend WithEvents BACK As Button
End Class
