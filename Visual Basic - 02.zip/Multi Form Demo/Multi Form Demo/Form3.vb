﻿Public Class FRMSPANISH
    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        NameList.Items.Add("Juan")
        NameList.Items.Add("Jose")
        NameList.Items.Add("Carlos")
        NameList.Items.Add("Josef")
        NameList.Items.Add("Roberto")
    End Sub

    Private Sub NameList_SelectedIndexChanged(sender As Object, e As EventArgs) Handles NameList.SelectedIndexChanged
        lblNameSelected.Text = "El nombre que ha seleccionado es " & NameList.Text & "."
    End Sub

    Private Sub BACK_Click(sender As Object, e As EventArgs) Handles BACK.Click
        frmMain.Show()
        Me.Close()
    End Sub
End Class