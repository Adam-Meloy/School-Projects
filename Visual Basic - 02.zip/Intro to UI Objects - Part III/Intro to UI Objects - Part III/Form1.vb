﻿Public Class Form1

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        pbxFood.Visible = False
        gbxCuisine.Visible = False
        btnSubmit.Enabled = False
    End Sub

    Private Sub cboCuisineType_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboCuisineType.SelectedIndexChanged
        gbxCuisine.Visible = True
        pbxFood.Visible = True
        If cboCuisineType.Text = "Italian" Then
            pbxFood.Image = My.Resources.italian
            gbxCuisine.Text = "Italian Menu"
            rb1.Text = "Pizza"
            rb2.Text = "Calzone"
            rb3.Text = "Ravioli"
        End If
        If cboCuisineType.Text = "Chinese" Then
            pbxFood.Image = My.Resources.chinese
            gbxCuisine.Text = "Chinese Menu"
            rb1.Text = "Crab Rangoon"
            rb2.Text = "Kungpao Chicken"
            rb3.Text = "Eggroll"
            gbxCuisine.Visible = True
        End If
        If cboCuisineType.Text = "Mexican" Then
            pbxFood.Image = My.Resources.mexican
            gbxCuisine.Text = "Mexican Menu"
            rb1.Text = "Taco"
            rb2.Text = "Nacho"
            rb3.Text = "Fajita"
            gbxCuisine.Visible = True
        End If
    End Sub

    Private Sub rb1_CheckedChanged(sender As Object, e As EventArgs) Handles rb1.CheckedChanged
        If cboCuisineType.Text = "Italian" Then
            btnSubmit.Enabled = True
            pbxFood.Image = My.Resources.pizza
        End If
        If cboCuisineType.Text = "Chinese" Then
            btnSubmit.Enabled = True
            pbxFood.Image = My.Resources.crab_rangoon
        End If
        If cboCuisineType.Text = "Mexican" Then
            btnSubmit.Enabled = True
            pbxFood.Image = My.Resources.taco
        End If
    End Sub

    Private Sub rb2_CheckedChanged(sender As Object, e As EventArgs) Handles rb2.CheckedChanged
        If cboCuisineType.Text = "Italian" Then
            btnSubmit.Enabled = True
            pbxFood.Image = My.Resources.calzone
        End If
        If cboCuisineType.Text = "Chinese" Then
            btnSubmit.Enabled = True
            pbxFood.Image = My.Resources.kungpao_chicken
        End If
        If cboCuisineType.Text = "Mexican" Then
            btnSubmit.Enabled = True
            pbxFood.Image = My.Resources.nacho
        End If
    End Sub

    Private Sub rb3_CheckedChanged(sender As Object, e As EventArgs) Handles rb3.CheckedChanged
        If cboCuisineType.Text = "Italian" Then
            btnSubmit.Enabled = True
            pbxFood.Image = My.Resources.ravioli
        End If
        If cboCuisineType.Text = "Chinese" Then
            btnSubmit.Enabled = True
            pbxFood.Image = My.Resources.eggroll
        End If
        If cboCuisineType.Text = "Mexican" Then
            btnSubmit.Enabled = True
            pbxFood.Image = My.Resources.fajita
        End If
    End Sub

    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        If cboCuisineType.Text = "Italian" Then
            If rb1.Checked = True Then
                MsgBox("Thank You For Ordering " & rb1.Text)
            End If
        End If
        If cboCuisineType.Text = "Chinese" Then
            If rb1.Checked = True Then
                MsgBox("Thank You For Ordering " & rb1.Text)
            End If
        End If
        If cboCuisineType.Text = "Mexican" Then
            If rb1.Checked = True Then
                MsgBox("Thank You For Ordering " & rb1.Text)
            End If
        End If
        If cboCuisineType.Text = "Italian" Then
            If rb2.Checked = True Then
                MsgBox("Thank You For Ordering " & rb2.Text)
            End If
        End If
        If cboCuisineType.Text = "Chinese" Then
            If rb2.Checked = True Then
                MsgBox("Thank You For Ordering " & rb2.Text)
            End If
        End If
        If cboCuisineType.Text = "Mexican" Then
            If rb2.Checked = True Then
                MsgBox("Thank You For Ordering " & rb2.Text)
            End If
        End If
        If cboCuisineType.Text = "Italian" Then
            If rb3.Checked = True Then
                MsgBox("Thank You For Ordering " & rb3.Text)
            End If
        End If
        If cboCuisineType.Text = "Chinese" Then
            If rb3.Checked = True Then
                MsgBox("Thank You For Ordering " & rb3.Text)
            End If
        End If
        If cboCuisineType.Text = "Mexican" Then
            If rb3.Checked = True Then
                MsgBox("Thank You For Ordering " & rb3.Text)
            End If
        End If
        Close()
    End Sub
End Class
