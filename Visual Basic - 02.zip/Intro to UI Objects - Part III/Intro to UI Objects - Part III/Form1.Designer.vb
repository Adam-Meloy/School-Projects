﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnSubmit = New System.Windows.Forms.Button()
        Me.lblCuisineType = New System.Windows.Forms.Label()
        Me.gbxCuisine = New System.Windows.Forms.GroupBox()
        Me.rb3 = New System.Windows.Forms.RadioButton()
        Me.rb2 = New System.Windows.Forms.RadioButton()
        Me.rb1 = New System.Windows.Forms.RadioButton()
        Me.cboCuisineType = New System.Windows.Forms.ComboBox()
        Me.pbxFood = New System.Windows.Forms.PictureBox()
        Me.gbxCuisine.SuspendLayout()
        CType(Me.pbxFood, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnSubmit
        '
        Me.btnSubmit.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSubmit.Location = New System.Drawing.Point(319, 422)
        Me.btnSubmit.Name = "btnSubmit"
        Me.btnSubmit.Size = New System.Drawing.Size(120, 61)
        Me.btnSubmit.TabIndex = 10
        Me.btnSubmit.Text = "Submit"
        Me.btnSubmit.UseVisualStyleBackColor = True
        '
        'lblCuisineType
        '
        Me.lblCuisineType.AutoSize = True
        Me.lblCuisineType.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCuisineType.Location = New System.Drawing.Point(125, 92)
        Me.lblCuisineType.Name = "lblCuisineType"
        Me.lblCuisineType.Size = New System.Drawing.Size(126, 24)
        Me.lblCuisineType.TabIndex = 9
        Me.lblCuisineType.Text = "Cuisine Type:"
        '
        'gbxCuisine
        '
        Me.gbxCuisine.Controls.Add(Me.rb3)
        Me.gbxCuisine.Controls.Add(Me.rb2)
        Me.gbxCuisine.Controls.Add(Me.rb1)
        Me.gbxCuisine.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbxCuisine.Location = New System.Drawing.Point(116, 206)
        Me.gbxCuisine.Name = "gbxCuisine"
        Me.gbxCuisine.Size = New System.Drawing.Size(197, 150)
        Me.gbxCuisine.TabIndex = 8
        Me.gbxCuisine.TabStop = False
        Me.gbxCuisine.Text = "GroupBox1"
        '
        'rb3
        '
        Me.rb3.AutoSize = True
        Me.rb3.Location = New System.Drawing.Point(0, 96)
        Me.rb3.Name = "rb3"
        Me.rb3.Size = New System.Drawing.Size(152, 28)
        Me.rb3.TabIndex = 2
        Me.rb3.TabStop = True
        Me.rb3.Text = "RadioButton3"
        Me.rb3.UseVisualStyleBackColor = True
        '
        'rb2
        '
        Me.rb2.AutoSize = True
        Me.rb2.Location = New System.Drawing.Point(0, 62)
        Me.rb2.Name = "rb2"
        Me.rb2.Size = New System.Drawing.Size(152, 28)
        Me.rb2.TabIndex = 1
        Me.rb2.TabStop = True
        Me.rb2.Text = "RadioButton2"
        Me.rb2.UseVisualStyleBackColor = True
        '
        'rb1
        '
        Me.rb1.AutoSize = True
        Me.rb1.Location = New System.Drawing.Point(0, 28)
        Me.rb1.Name = "rb1"
        Me.rb1.Size = New System.Drawing.Size(152, 28)
        Me.rb1.TabIndex = 0
        Me.rb1.TabStop = True
        Me.rb1.Text = "RadioButton1"
        Me.rb1.UseVisualStyleBackColor = True
        '
        'cboCuisineType
        '
        Me.cboCuisineType.FormattingEnabled = True
        Me.cboCuisineType.Items.AddRange(New Object() {"Italian", "Chinese", "Mexican"})
        Me.cboCuisineType.Location = New System.Drawing.Point(128, 123)
        Me.cboCuisineType.Name = "cboCuisineType"
        Me.cboCuisineType.Size = New System.Drawing.Size(121, 21)
        Me.cboCuisineType.TabIndex = 7
        '
        'pbxFood
        '
        Me.pbxFood.Location = New System.Drawing.Point(394, 187)
        Me.pbxFood.Name = "pbxFood"
        Me.pbxFood.Size = New System.Drawing.Size(184, 167)
        Me.pbxFood.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbxFood.TabIndex = 6
        Me.pbxFood.TabStop = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(642, 490)
        Me.Controls.Add(Me.btnSubmit)
        Me.Controls.Add(Me.lblCuisineType)
        Me.Controls.Add(Me.gbxCuisine)
        Me.Controls.Add(Me.cboCuisineType)
        Me.Controls.Add(Me.pbxFood)
        Me.Name = "Form1"
        Me.Text = "Intro to UI Objects - Part III"
        Me.gbxCuisine.ResumeLayout(False)
        Me.gbxCuisine.PerformLayout()
        CType(Me.pbxFood, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnSubmit As System.Windows.Forms.Button
    Friend WithEvents lblCuisineType As System.Windows.Forms.Label
    Friend WithEvents gbxCuisine As System.Windows.Forms.GroupBox
    Friend WithEvents rb3 As System.Windows.Forms.RadioButton
    Friend WithEvents rb2 As System.Windows.Forms.RadioButton
    Friend WithEvents rb1 As System.Windows.Forms.RadioButton
    Friend WithEvents cboCuisineType As System.Windows.Forms.ComboBox
    Friend WithEvents pbxFood As System.Windows.Forms.PictureBox

End Class
