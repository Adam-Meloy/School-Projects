﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnLR = New System.Windows.Forms.Button()
        Me.btnLL = New System.Windows.Forms.Button()
        Me.btnUR = New System.Windows.Forms.Button()
        Me.btnUL = New System.Windows.Forms.Button()
        Me.lblTop = New System.Windows.Forms.Label()
        Me.lblLeft = New System.Windows.Forms.Label()
        Me.tbxTop = New System.Windows.Forms.TextBox()
        Me.tbxLeft = New System.Windows.Forms.TextBox()
        Me.btnGoTo = New System.Windows.Forms.Button()
        Me.btnBottom = New System.Windows.Forms.Button()
        Me.btnDown = New System.Windows.Forms.Button()
        Me.btnUp = New System.Windows.Forms.Button()
        Me.btnTop = New System.Windows.Forms.Button()
        Me.btnFarRight = New System.Windows.Forms.Button()
        Me.btnRight = New System.Windows.Forms.Button()
        Me.btnLeft = New System.Windows.Forms.Button()
        Me.btnFarLeft = New System.Windows.Forms.Button()
        Me.Picture = New System.Windows.Forms.PictureBox()
        CType(Me.Picture, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnLR
        '
        Me.btnLR.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLR.Location = New System.Drawing.Point(538, 459)
        Me.btnLR.Name = "btnLR"
        Me.btnLR.Size = New System.Drawing.Size(71, 61)
        Me.btnLR.TabIndex = 35
        Me.btnLR.Text = "Lower Right Corner"
        Me.btnLR.UseVisualStyleBackColor = True
        '
        'btnLL
        '
        Me.btnLL.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLL.Location = New System.Drawing.Point(428, 456)
        Me.btnLL.Name = "btnLL"
        Me.btnLL.Size = New System.Drawing.Size(68, 64)
        Me.btnLL.TabIndex = 34
        Me.btnLL.Text = "Lower Left Corner"
        Me.btnLL.UseVisualStyleBackColor = True
        '
        'btnUR
        '
        Me.btnUR.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnUR.Location = New System.Drawing.Point(538, 355)
        Me.btnUR.Name = "btnUR"
        Me.btnUR.Size = New System.Drawing.Size(71, 62)
        Me.btnUR.TabIndex = 33
        Me.btnUR.Text = "Upper Right Corner"
        Me.btnUR.UseVisualStyleBackColor = True
        '
        'btnUL
        '
        Me.btnUL.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnUL.Location = New System.Drawing.Point(428, 355)
        Me.btnUL.Name = "btnUL"
        Me.btnUL.Size = New System.Drawing.Size(68, 62)
        Me.btnUL.TabIndex = 32
        Me.btnUL.Text = "Upper Left Corner"
        Me.btnUL.UseVisualStyleBackColor = True
        '
        'lblTop
        '
        Me.lblTop.AutoSize = True
        Me.lblTop.Location = New System.Drawing.Point(503, 556)
        Me.lblTop.Name = "lblTop"
        Me.lblTop.Size = New System.Drawing.Size(29, 13)
        Me.lblTop.TabIndex = 31
        Me.lblTop.Text = "Top:"
        '
        'lblLeft
        '
        Me.lblLeft.AutoSize = True
        Me.lblLeft.Location = New System.Drawing.Point(504, 523)
        Me.lblLeft.Name = "lblLeft"
        Me.lblLeft.Size = New System.Drawing.Size(28, 13)
        Me.lblLeft.TabIndex = 30
        Me.lblLeft.Text = "Left:"
        '
        'tbxTop
        '
        Me.tbxTop.BackColor = System.Drawing.Color.Silver
        Me.tbxTop.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tbxTop.Location = New System.Drawing.Point(538, 556)
        Me.tbxTop.Multiline = True
        Me.tbxTop.Name = "tbxTop"
        Me.tbxTop.Size = New System.Drawing.Size(72, 24)
        Me.tbxTop.TabIndex = 29
        '
        'tbxLeft
        '
        Me.tbxLeft.BackColor = System.Drawing.Color.Silver
        Me.tbxLeft.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tbxLeft.Location = New System.Drawing.Point(537, 526)
        Me.tbxLeft.Multiline = True
        Me.tbxLeft.Name = "tbxLeft"
        Me.tbxLeft.Size = New System.Drawing.Size(72, 24)
        Me.tbxLeft.TabIndex = 28
        '
        'btnGoTo
        '
        Me.btnGoTo.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnGoTo.Location = New System.Drawing.Point(428, 523)
        Me.btnGoTo.Name = "btnGoTo"
        Me.btnGoTo.Size = New System.Drawing.Size(68, 57)
        Me.btnGoTo.TabIndex = 27
        Me.btnGoTo.Text = "Go To"
        Me.btnGoTo.UseVisualStyleBackColor = True
        '
        'btnBottom
        '
        Me.btnBottom.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBottom.Location = New System.Drawing.Point(502, 485)
        Me.btnBottom.Name = "btnBottom"
        Me.btnBottom.Size = New System.Drawing.Size(30, 35)
        Me.btnBottom.TabIndex = 26
        Me.btnBottom.Text = "vv"
        Me.btnBottom.UseVisualStyleBackColor = True
        '
        'btnDown
        '
        Me.btnDown.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDown.Location = New System.Drawing.Point(502, 449)
        Me.btnDown.Name = "btnDown"
        Me.btnDown.Size = New System.Drawing.Size(30, 30)
        Me.btnDown.TabIndex = 25
        Me.btnDown.Text = "v"
        Me.btnDown.UseVisualStyleBackColor = True
        '
        'btnUp
        '
        Me.btnUp.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnUp.Location = New System.Drawing.Point(502, 396)
        Me.btnUp.Name = "btnUp"
        Me.btnUp.Size = New System.Drawing.Size(30, 30)
        Me.btnUp.TabIndex = 24
        Me.btnUp.Text = "^"
        Me.btnUp.UseVisualStyleBackColor = True
        '
        'btnTop
        '
        Me.btnTop.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnTop.Location = New System.Drawing.Point(502, 355)
        Me.btnTop.Name = "btnTop"
        Me.btnTop.Size = New System.Drawing.Size(30, 35)
        Me.btnTop.TabIndex = 23
        Me.btnTop.Text = "^^"
        Me.btnTop.UseVisualStyleBackColor = True
        '
        'btnFarRight
        '
        Me.btnFarRight.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnFarRight.Location = New System.Drawing.Point(574, 423)
        Me.btnFarRight.Name = "btnFarRight"
        Me.btnFarRight.Size = New System.Drawing.Size(35, 30)
        Me.btnFarRight.TabIndex = 22
        Me.btnFarRight.Text = ">>"
        Me.btnFarRight.UseVisualStyleBackColor = True
        '
        'btnRight
        '
        Me.btnRight.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRight.Location = New System.Drawing.Point(538, 423)
        Me.btnRight.Name = "btnRight"
        Me.btnRight.Size = New System.Drawing.Size(30, 30)
        Me.btnRight.TabIndex = 21
        Me.btnRight.Text = ">"
        Me.btnRight.UseVisualStyleBackColor = True
        '
        'btnLeft
        '
        Me.btnLeft.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLeft.Location = New System.Drawing.Point(466, 423)
        Me.btnLeft.Name = "btnLeft"
        Me.btnLeft.Size = New System.Drawing.Size(30, 30)
        Me.btnLeft.TabIndex = 20
        Me.btnLeft.Text = "<"
        Me.btnLeft.UseVisualStyleBackColor = True
        '
        'btnFarLeft
        '
        Me.btnFarLeft.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnFarLeft.Location = New System.Drawing.Point(428, 423)
        Me.btnFarLeft.Margin = New System.Windows.Forms.Padding(0)
        Me.btnFarLeft.Name = "btnFarLeft"
        Me.btnFarLeft.Size = New System.Drawing.Size(35, 30)
        Me.btnFarLeft.TabIndex = 19
        Me.btnFarLeft.Text = "<<"
        Me.btnFarLeft.UseVisualStyleBackColor = True
        '
        'Picture
        '
        Me.Picture.BackColor = System.Drawing.Color.Red
        Me.Picture.Location = New System.Drawing.Point(50, 50)
        Me.Picture.Name = "Picture"
        Me.Picture.Size = New System.Drawing.Size(30, 30)
        Me.Picture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Picture.TabIndex = 18
        Me.Picture.TabStop = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlDark
        Me.ClientSize = New System.Drawing.Size(664, 641)
        Me.Controls.Add(Me.btnLR)
        Me.Controls.Add(Me.btnLL)
        Me.Controls.Add(Me.btnUR)
        Me.Controls.Add(Me.btnUL)
        Me.Controls.Add(Me.lblTop)
        Me.Controls.Add(Me.lblLeft)
        Me.Controls.Add(Me.tbxTop)
        Me.Controls.Add(Me.tbxLeft)
        Me.Controls.Add(Me.btnGoTo)
        Me.Controls.Add(Me.btnBottom)
        Me.Controls.Add(Me.btnDown)
        Me.Controls.Add(Me.btnUp)
        Me.Controls.Add(Me.btnTop)
        Me.Controls.Add(Me.btnFarRight)
        Me.Controls.Add(Me.btnRight)
        Me.Controls.Add(Me.btnLeft)
        Me.Controls.Add(Me.btnFarLeft)
        Me.Controls.Add(Me.Picture)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.Picture, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnLR As Button
    Friend WithEvents btnLL As Button
    Friend WithEvents btnUR As Button
    Friend WithEvents btnUL As Button
    Friend WithEvents lblTop As Label
    Friend WithEvents lblLeft As Label
    Friend WithEvents tbxTop As TextBox
    Friend WithEvents tbxLeft As TextBox
    Friend WithEvents btnGoTo As Button
    Friend WithEvents btnBottom As Button
    Friend WithEvents btnDown As Button
    Friend WithEvents btnUp As Button
    Friend WithEvents btnTop As Button
    Friend WithEvents btnFarRight As Button
    Friend WithEvents btnRight As Button
    Friend WithEvents btnLeft As Button
    Friend WithEvents btnFarLeft As Button
    Friend WithEvents Picture As PictureBox
End Class
