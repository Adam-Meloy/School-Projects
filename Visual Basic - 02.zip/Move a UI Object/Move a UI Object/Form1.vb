﻿Public Class Form1
    Dim Point2 As Point
    Dim Point1 As New Point
    Private Sub btnUp_Click(sender As Object, e As EventArgs) Handles btnUp.Click
        Picture.Top = Picture.Top - 5
    End Sub

    Private Sub btnTop_Click(sender As Object, e As EventArgs) Handles btnTop.Click
        Picture.Top = 0
    End Sub

    Private Sub btnLeft_Click(sender As Object, e As EventArgs) Handles btnLeft.Click
        Picture.Left = Picture.Left - 5
    End Sub

    Private Sub btnFarLeft_Click(sender As Object, e As EventArgs) Handles btnFarLeft.Click
        Picture.Left = 0
    End Sub

    Private Sub btnRight_Click(sender As Object, e As EventArgs) Handles btnRight.Click
        Picture.Left = Picture.Left + 5
    End Sub

    Private Sub btnFarRight_Click(sender As Object, e As EventArgs) Handles btnFarRight.Click
        Picture.Left = 635
    End Sub

    Private Sub btnDown_Click(sender As Object, e As EventArgs) Handles btnDown.Click
        Picture.Top = Picture.Top + 5
    End Sub

    Private Sub btnBottom_Click(sender As Object, e As EventArgs) Handles btnBottom.Click
        Picture.Top = 610
    End Sub

    Private Sub btnUL_Click(sender As Object, e As EventArgs) Handles btnUL.Click
        Point1.X = 0
        Point1.Y = 0
        Picture.Left = Point1.X
        Picture.Top = Point1.Y
    End Sub

    Private Sub btnUR_Click(sender As Object, e As EventArgs) Handles btnUR.Click
        Point1.X = 635
        Point1.Y = 0
        Picture.Left = Point1.X
        Picture.Top = Point1.Y
    End Sub

    Private Sub btnLL_Click(sender As Object, e As EventArgs) Handles btnLL.Click
        Point1.X = 0
        Point1.Y = 610
        Picture.Left = Point1.X
        Picture.Top = Point1.Y
    End Sub

    Private Sub btnLR_Click(sender As Object, e As EventArgs) Handles btnLR.Click
        Point1.X = 635
        Point1.Y = 610
        Picture.Left = Point1.X
        Picture.Top = Point1.Y
    End Sub

    Private Sub btnGoTo_Click(sender As Object, e As EventArgs) Handles btnGoTo.Click
        Picture.Left = tbxLeft.Text
        Picture.Top = tbxTop.Text
    End Sub
End Class
