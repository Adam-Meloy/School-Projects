﻿Public Class ReduceFraction
    Dim N, D, L, S, GCF, P, Number As Integer
    Private Sub ReturnHome_Click(sender As Object, e As EventArgs) Handles ReturnHome.Click
        Me.Hide()
        Home.Show()
    End Sub
    Private Sub Reduce_Click(sender As Object, e As EventArgs) Handles Reduce.Click
        N = TopInput.Text
        D = BottomInput.Text
        If TopInput.Text = "0" Or BottomInput.Text = "0" Or TopInput.Text = "" Or BottomInput.Text = "" Then
            MsgBox("ERROR: DIVIDE BY 0")
            Home.Show()
            Me.Close()
            Home.Close()
        End If
        If N > D Then
            L = N
            S = D
        ElseIf N < D Then
            L = D
            S = N
        End If
        For Number = L To S Step -1
            If S Mod L = 0 Then
                Exit For
            End If
        Next
        GCF = S
        If N < D Then
            TopOutput.Text = S / GCF
            BottomOutput.Text = L / GCF
        Else
            TopOutput.Text = L / GCF
            BottomOutput.Text = S / GCF
        End If
    End Sub
End Class