﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class RectangleGen
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ReturnHome = New System.Windows.Forms.Button()
        Me.Calculate = New System.Windows.Forms.Button()
        Me.MinWidth = New System.Windows.Forms.TextBox()
        Me.Length = New System.Windows.Forms.TextBox()
        Me.MaxWidth = New System.Windows.Forms.TextBox()
        Me.AreaList = New System.Windows.Forms.ListBox()
        Me.SuspendLayout()
        '
        'ReturnHome
        '
        Me.ReturnHome.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ReturnHome.Location = New System.Drawing.Point(187, 0)
        Me.ReturnHome.Name = "ReturnHome"
        Me.ReturnHome.Size = New System.Drawing.Size(75, 75)
        Me.ReturnHome.TabIndex = 2
        Me.ReturnHome.Text = "Return"
        Me.ReturnHome.UseVisualStyleBackColor = True
        '
        'Calculate
        '
        Me.Calculate.Location = New System.Drawing.Point(89, 0)
        Me.Calculate.Name = "Calculate"
        Me.Calculate.Size = New System.Drawing.Size(75, 75)
        Me.Calculate.TabIndex = 3
        Me.Calculate.Text = "Calculate"
        Me.Calculate.UseVisualStyleBackColor = True
        '
        'MinWidth
        '
        Me.MinWidth.Location = New System.Drawing.Point(7, 0)
        Me.MinWidth.Name = "MinWidth"
        Me.MinWidth.Size = New System.Drawing.Size(76, 20)
        Me.MinWidth.TabIndex = 4
        Me.MinWidth.Text = "Min. Width"
        '
        'Length
        '
        Me.Length.Location = New System.Drawing.Point(7, 52)
        Me.Length.Name = "Length"
        Me.Length.Size = New System.Drawing.Size(76, 20)
        Me.Length.TabIndex = 5
        Me.Length.Text = "Length"
        '
        'MaxWidth
        '
        Me.MaxWidth.Location = New System.Drawing.Point(7, 26)
        Me.MaxWidth.Name = "MaxWidth"
        Me.MaxWidth.Size = New System.Drawing.Size(76, 20)
        Me.MaxWidth.TabIndex = 6
        Me.MaxWidth.Text = "Max. Width"
        '
        'AreaList
        '
        Me.AreaList.FormattingEnabled = True
        Me.AreaList.Items.AddRange(New Object() {"Width (FT)             Length (FT)             Area (Sq. FT)"})
        Me.AreaList.Location = New System.Drawing.Point(7, 78)
        Me.AreaList.Name = "AreaList"
        Me.AreaList.Size = New System.Drawing.Size(255, 108)
        Me.AreaList.TabIndex = 7
        '
        'RectangleGen
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(264, 186)
        Me.Controls.Add(Me.AreaList)
        Me.Controls.Add(Me.MaxWidth)
        Me.Controls.Add(Me.Length)
        Me.Controls.Add(Me.MinWidth)
        Me.Controls.Add(Me.Calculate)
        Me.Controls.Add(Me.ReturnHome)
        Me.Name = "RectangleGen"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Rectangle Area Gen"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents ReturnHome As Button
    Friend WithEvents Calculate As Button
    Friend WithEvents MinWidth As TextBox
    Friend WithEvents Length As TextBox
    Friend WithEvents MaxWidth As TextBox
    Friend WithEvents AreaList As ListBox
End Class
