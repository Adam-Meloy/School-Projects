﻿Public Class RectangleGen
    Dim Area, CurrentWidth, MiniWidth, MaxiWidth As Integer
    Private Sub ReturnHome_Click(sender As Object, e As EventArgs) Handles ReturnHome.Click
        Me.Hide()
        Home.Show()
        AreaList.Items.Clear()
    End Sub
    Private Sub Calculate_Click(sender As Object, e As EventArgs) Handles Calculate.Click
        MiniWidth = MinWidth.Text
        MaxiWidth = MaxWidth.Text
        AreaList.Items.Clear()
        For MiniWidth = MinWidth.Text To MaxiWidth Step 1
            CurrentWidth = MiniWidth
            Area = CurrentWidth * Length.Text
            AreaList.Items.Add(CurrentWidth & "                          " & MaxiWidth & "                             " & Area)
        Next
    End Sub
End Class