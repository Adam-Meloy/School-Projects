﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ReduceFraction
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ReturnHome = New System.Windows.Forms.Button()
        Me.Reduce = New System.Windows.Forms.Button()
        Me.TopInput = New System.Windows.Forms.TextBox()
        Me.BottomInput = New System.Windows.Forms.TextBox()
        Me.Useless = New System.Windows.Forms.Label()
        Me.TopOutput = New System.Windows.Forms.Label()
        Me.BottomOutput = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'ReturnHome
        '
        Me.ReturnHome.Location = New System.Drawing.Point(97, 12)
        Me.ReturnHome.Name = "ReturnHome"
        Me.ReturnHome.Size = New System.Drawing.Size(25, 25)
        Me.ReturnHome.TabIndex = 1
        Me.ReturnHome.Text = "R"
        Me.ReturnHome.UseVisualStyleBackColor = True
        '
        'Reduce
        '
        Me.Reduce.Location = New System.Drawing.Point(13, 12)
        Me.Reduce.Name = "Reduce"
        Me.Reduce.Size = New System.Drawing.Size(75, 23)
        Me.Reduce.TabIndex = 2
        Me.Reduce.Text = "Reduce"
        Me.Reduce.UseVisualStyleBackColor = True
        '
        'TopInput
        '
        Me.TopInput.Location = New System.Drawing.Point(12, 68)
        Me.TopInput.Name = "TopInput"
        Me.TopInput.Size = New System.Drawing.Size(35, 20)
        Me.TopInput.TabIndex = 3
        '
        'BottomInput
        '
        Me.BottomInput.Location = New System.Drawing.Point(12, 108)
        Me.BottomInput.Name = "BottomInput"
        Me.BottomInput.Size = New System.Drawing.Size(36, 20)
        Me.BottomInput.TabIndex = 4
        '
        'Useless
        '
        Me.Useless.Location = New System.Drawing.Point(12, 91)
        Me.Useless.Name = "Useless"
        Me.Useless.Size = New System.Drawing.Size(110, 14)
        Me.Useless.TabIndex = 7
        Me.Useless.Text = "---------       =       ---------" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'TopOutput
        '
        Me.TopOutput.Location = New System.Drawing.Point(87, 68)
        Me.TopOutput.Name = "TopOutput"
        Me.TopOutput.Size = New System.Drawing.Size(35, 20)
        Me.TopOutput.TabIndex = 8
        '
        'BottomOutput
        '
        Me.BottomOutput.Location = New System.Drawing.Point(87, 108)
        Me.BottomOutput.Name = "BottomOutput"
        Me.BottomOutput.Size = New System.Drawing.Size(35, 20)
        Me.BottomOutput.TabIndex = 9
        '
        'ReduceFraction
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(134, 152)
        Me.Controls.Add(Me.BottomOutput)
        Me.Controls.Add(Me.TopOutput)
        Me.Controls.Add(Me.Useless)
        Me.Controls.Add(Me.BottomInput)
        Me.Controls.Add(Me.TopInput)
        Me.Controls.Add(Me.Reduce)
        Me.Controls.Add(Me.ReturnHome)
        Me.Name = "ReduceFraction"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Reduce The Fraction"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents ReturnHome As Button
    Friend WithEvents Reduce As Button
    Friend WithEvents TopInput As TextBox
    Friend WithEvents BottomInput As TextBox
    Friend WithEvents Useless As Label
    Friend WithEvents TopOutput As Label
    Friend WithEvents BottomOutput As Label
End Class
