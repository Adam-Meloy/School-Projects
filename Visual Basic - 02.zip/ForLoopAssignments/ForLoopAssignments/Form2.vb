﻿Public Class Inch2Feet
    Dim Inches, LeftoverInches, Feet As Integer
    Private Sub ReturnHome_Click(sender As Object, e As EventArgs) Handles ReturnHome.Click
        Me.Hide()
        Home.Show()
        Table.Items.Clear()
    End Sub
    Private Sub TableGen_Click(sender As Object, e As EventArgs) Handles TableGen.Click
        For Inches = 30 To 80
            Feet = Inches / 12
            LeftoverInches = Inches Mod 12
            Table.Items.Add(Inches & " = " & Feet & " Feet and " & LeftoverInches & " Inches")
        Next
    End Sub
End Class