﻿Public Class Home
    Private Sub Assignment1_Click(sender As Object, e As EventArgs) Handles Assignment1.Click
        Me.Hide()
        Inch2Feet.Show()
    End Sub
    Private Sub Assignment2_Click(sender As Object, e As EventArgs) Handles Assignment2.Click
        Me.Hide()
        ReduceFraction.Show()
    End Sub
    Private Sub Assignment3_Click(sender As Object, e As EventArgs) Handles Assignment3.Click
        Me.Hide()
        RectangleGen.Show()
    End Sub
End Class
