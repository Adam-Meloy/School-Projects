﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Home
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Assignment3 = New System.Windows.Forms.Button()
        Me.Assignment1 = New System.Windows.Forms.Button()
        Me.Assignment2 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Assignment3
        '
        Me.Assignment3.BackColor = System.Drawing.Color.Black
        Me.Assignment3.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Assignment3.ForeColor = System.Drawing.Color.White
        Me.Assignment3.Location = New System.Drawing.Point(12, 177)
        Me.Assignment3.Name = "Assignment3"
        Me.Assignment3.Size = New System.Drawing.Size(260, 72)
        Me.Assignment3.TabIndex = 2
        Me.Assignment3.Text = "Project 3"
        Me.Assignment3.UseVisualStyleBackColor = False
        '
        'Assignment1
        '
        Me.Assignment1.BackColor = System.Drawing.Color.Black
        Me.Assignment1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Assignment1.ForeColor = System.Drawing.Color.White
        Me.Assignment1.Location = New System.Drawing.Point(12, 12)
        Me.Assignment1.Name = "Assignment1"
        Me.Assignment1.Size = New System.Drawing.Size(260, 72)
        Me.Assignment1.TabIndex = 3
        Me.Assignment1.Text = "Project 1"
        Me.Assignment1.UseVisualStyleBackColor = False
        '
        'Assignment2
        '
        Me.Assignment2.BackColor = System.Drawing.Color.Black
        Me.Assignment2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Assignment2.ForeColor = System.Drawing.Color.White
        Me.Assignment2.Location = New System.Drawing.Point(12, 90)
        Me.Assignment2.Name = "Assignment2"
        Me.Assignment2.Size = New System.Drawing.Size(260, 81)
        Me.Assignment2.TabIndex = 4
        Me.Assignment2.Text = "Project 2"
        Me.Assignment2.UseVisualStyleBackColor = False
        '
        'Home
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Black
        Me.ClientSize = New System.Drawing.Size(284, 261)
        Me.Controls.Add(Me.Assignment2)
        Me.Controls.Add(Me.Assignment1)
        Me.Controls.Add(Me.Assignment3)
        Me.Name = "Home"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Home"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Assignment3 As Button
    Friend WithEvents Assignment1 As Button
    Friend WithEvents Assignment2 As Button
End Class
