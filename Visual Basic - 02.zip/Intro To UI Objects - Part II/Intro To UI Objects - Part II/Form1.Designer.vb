﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class fORM1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.NameFirst = New System.Windows.Forms.Label()
        Me.NameLast = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.NumberPhome = New System.Windows.Forms.Label()
        Me.PQ = New System.Windows.Forms.Label()
        Me.quote = New System.Windows.Forms.Label()
        Me.FN = New System.Windows.Forms.TextBox()
        Me.LN = New System.Windows.Forms.TextBox()
        Me.PN = New System.Windows.Forms.TextBox()
        Me.PersonalQuote = New System.Windows.Forms.TextBox()
        Me.btngreet = New System.Windows.Forms.Button()
        Me.clearbtn = New System.Windows.Forms.Button()
        Me.boxquote = New System.Windows.Forms.Button()
        Me.nmbrage = New System.Windows.Forms.Label()
        Me.AgeScroll = New System.Windows.Forms.HScrollBar()
        Me.exitbtn = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'NameFirst
        '
        Me.NameFirst.AutoSize = True
        Me.NameFirst.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.NameFirst.Location = New System.Drawing.Point(12, 9)
        Me.NameFirst.Name = "NameFirst"
        Me.NameFirst.Size = New System.Drawing.Size(80, 17)
        Me.NameFirst.TabIndex = 0
        Me.NameFirst.Text = "First Name:"
        '
        'NameLast
        '
        Me.NameLast.AutoSize = True
        Me.NameLast.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.NameLast.Location = New System.Drawing.Point(12, 49)
        Me.NameLast.Name = "NameLast"
        Me.NameLast.Size = New System.Drawing.Size(80, 17)
        Me.NameLast.TabIndex = 1
        Me.NameLast.Text = "Last Name:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.Label3.Location = New System.Drawing.Point(12, 92)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(37, 17)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Age:"
        '
        'NumberPhome
        '
        Me.NumberPhome.AutoSize = True
        Me.NumberPhome.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.NumberPhome.Location = New System.Drawing.Point(12, 133)
        Me.NumberPhome.Name = "NumberPhome"
        Me.NumberPhome.Size = New System.Drawing.Size(107, 17)
        Me.NumberPhome.TabIndex = 3
        Me.NumberPhome.Text = "Phone Number:"
        '
        'PQ
        '
        Me.PQ.AutoSize = True
        Me.PQ.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.PQ.Location = New System.Drawing.Point(12, 175)
        Me.PQ.Name = "PQ"
        Me.PQ.Size = New System.Drawing.Size(107, 17)
        Me.PQ.TabIndex = 4
        Me.PQ.Text = "Personal Quote"
        '
        'quote
        '
        Me.quote.AutoSize = True
        Me.quote.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.quote.Location = New System.Drawing.Point(12, 226)
        Me.quote.Name = "quote"
        Me.quote.Size = New System.Drawing.Size(14, 13)
        Me.quote.TabIndex = 5
        Me.quote.Text = "#"
        '
        'FN
        '
        Me.FN.Location = New System.Drawing.Point(358, 8)
        Me.FN.Name = "FN"
        Me.FN.Size = New System.Drawing.Size(100, 20)
        Me.FN.TabIndex = 6
        '
        'LN
        '
        Me.LN.Location = New System.Drawing.Point(358, 48)
        Me.LN.Name = "LN"
        Me.LN.Size = New System.Drawing.Size(100, 20)
        Me.LN.TabIndex = 7
        '
        'PN
        '
        Me.PN.Location = New System.Drawing.Point(358, 132)
        Me.PN.Name = "PN"
        Me.PN.Size = New System.Drawing.Size(100, 20)
        Me.PN.TabIndex = 8
        '
        'PersonalQuote
        '
        Me.PersonalQuote.Location = New System.Drawing.Point(358, 174)
        Me.PersonalQuote.Name = "PersonalQuote"
        Me.PersonalQuote.Size = New System.Drawing.Size(100, 20)
        Me.PersonalQuote.TabIndex = 9
        '
        'btngreet
        '
        Me.btngreet.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.btngreet.Location = New System.Drawing.Point(15, 267)
        Me.btngreet.Name = "btngreet"
        Me.btngreet.Size = New System.Drawing.Size(130, 23)
        Me.btngreet.TabIndex = 10
        Me.btngreet.Text = "Show Greeting In Label"
        Me.btngreet.UseVisualStyleBackColor = True
        '
        'clearbtn
        '
        Me.clearbtn.Location = New System.Drawing.Point(194, 267)
        Me.clearbtn.Name = "clearbtn"
        Me.clearbtn.Size = New System.Drawing.Size(75, 23)
        Me.clearbtn.TabIndex = 11
        Me.clearbtn.Text = "Clear"
        Me.clearbtn.UseVisualStyleBackColor = True
        '
        'boxquote
        '
        Me.boxquote.Location = New System.Drawing.Point(320, 267)
        Me.boxquote.Name = "boxquote"
        Me.boxquote.Size = New System.Drawing.Size(138, 23)
        Me.boxquote.TabIndex = 12
        Me.boxquote.Text = "Show Greeting In MsgBox"
        Me.boxquote.UseVisualStyleBackColor = True
        '
        'nmbrage
        '
        Me.nmbrage.AutoSize = True
        Me.nmbrage.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.nmbrage.Location = New System.Drawing.Point(355, 92)
        Me.nmbrage.Name = "nmbrage"
        Me.nmbrage.Size = New System.Drawing.Size(24, 17)
        Me.nmbrage.TabIndex = 13
        Me.nmbrage.Text = "##"
        '
        'AgeScroll
        '
        Me.AgeScroll.Location = New System.Drawing.Point(148, 92)
        Me.AgeScroll.Name = "AgeScroll"
        Me.AgeScroll.Size = New System.Drawing.Size(153, 17)
        Me.AgeScroll.TabIndex = 14
        '
        'exitbtn
        '
        Me.exitbtn.Location = New System.Drawing.Point(194, 296)
        Me.exitbtn.Name = "exitbtn"
        Me.exitbtn.Size = New System.Drawing.Size(75, 23)
        Me.exitbtn.TabIndex = 15
        Me.exitbtn.Text = "Exit"
        Me.exitbtn.UseVisualStyleBackColor = True
        '
        'fORM1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(470, 336)
        Me.Controls.Add(Me.exitbtn)
        Me.Controls.Add(Me.AgeScroll)
        Me.Controls.Add(Me.nmbrage)
        Me.Controls.Add(Me.boxquote)
        Me.Controls.Add(Me.clearbtn)
        Me.Controls.Add(Me.btngreet)
        Me.Controls.Add(Me.PersonalQuote)
        Me.Controls.Add(Me.PN)
        Me.Controls.Add(Me.LN)
        Me.Controls.Add(Me.FN)
        Me.Controls.Add(Me.quote)
        Me.Controls.Add(Me.PQ)
        Me.Controls.Add(Me.NumberPhome)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.NameLast)
        Me.Controls.Add(Me.NameFirst)
        Me.Name = "fORM1"
        Me.Text = "hI tHERE bUDDY"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents NameFirst As Label
    Friend WithEvents NameLast As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents NumberPhome As Label
    Friend WithEvents PQ As Label
    Friend WithEvents quote As Label
    Friend WithEvents FN As TextBox
    Friend WithEvents LN As TextBox
    Friend WithEvents PN As TextBox
    Friend WithEvents PersonalQuote As TextBox
    Friend WithEvents btngreet As Button
    Friend WithEvents clearbtn As Button
    Friend WithEvents boxquote As Button
    Friend WithEvents nmbrage As Label
    Friend WithEvents AgeScroll As HScrollBar
    Friend WithEvents exitbtn As Button
End Class
