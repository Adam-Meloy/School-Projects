﻿Public Class fORM1
    Private Sub fORM1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        MsgBox("Please Enter Your Profile Information...")
    End Sub

    Private Sub exitbtn_Click(sender As Object, e As EventArgs) Handles exitbtn.Click
        Close()

    End Sub

    Private Sub AgeScroll_Scroll(sender As Object, e As ScrollEventArgs) Handles AgeScroll.Scroll
        nmbrage.Text = AgeScroll.Value


    End Sub

    Private Sub btngreet_Click(sender As Object, e As EventArgs) Handles btngreet.Click
        quote.Text = "Your Name Is " & FN.Text & " " & LN.Text & "." & "You Are " & nmbrage.Text & " Years Old" & " and Your Phone Number Is " & PN.Text & "."









    End Sub

    Private Sub clearbtn_Click(sender As Object, e As EventArgs) Handles clearbtn.Click
        FN.Text = ""
        LN.Text = ""
        PN.Text = ""
        nmbrage.Text = "##"
        quote.Text = "#"
    End Sub
End Class
