﻿Public Class Form1
    Dim carLane1StartingPoint As Point
    Dim carLane2StartingPoint As Point
    Dim blueCarStartingPoint As Point
    Dim greenCarStaringPoint As Point
    Dim redCarStartingPoint As Point
    Dim frogStartingPoint As Point
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        carLane2StartingPoint = pbxRed.Location
        carLane1StartingPoint = pbxBlue.Location
        blueCarStartingPoint = pbxBlue.Location
        greenCarStaringPoint = pbxGreen.Location
        redCarStartingPoint = pbxRed.Location
        frogStartingPoint = pbxFrog.Location
    End Sub
    Private Sub L1_Tick(sender As Object, e As EventArgs) Handles L1.Tick
        pbxBlue.Left += 60
        pbxGreen.Left += 60
        If pbxGreen.Right >= Me.Right Then
            pbxGreen.Left = carLane1StartingPoint.X
        ElseIf pbxBlue.Right >= Me.Right Then
            pbxBlue.Left = carLane1StartingPoint.X
        ElseIf pbxFrog.Bounds.IntersectsWith(pbxBlue.Bounds) Or pbxFrog.Bounds.IntersectsWith(pbxGreen.Bounds) Or pbxFrog.Bounds.IntersectsWith(pbxRed.Bounds) Then
            Call YouAreFinished()
            MsgBox("Game Over")
            pbxFrog.Image = My.Resources.frog
        ElseIf pbxFrog.Bounds.IntersectsWith(grass.Bounds) Then
            Call YouAreFinished()
            MsgBox("You Win!")
        End If
    End Sub
    Private Sub L2_Tick(sender As Object, e As EventArgs) Handles L2.Tick
        pbxRed.Left -= 60
        If pbxRed.Right <= Me.Left Then
            pbxRed.Left = carLane2StartingPoint.X
        End If
    End Sub
    Private Sub Form1_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.Space Then
            pbxFrog.Image = My.Resources.Frog_clipart_clipart_cliparts_for_you
            L1.Enabled = True
            L2.Enabled = True
        ElseIf e.KeyCode = Keys.Up Then
            pbxFrog.Top -= 10
        ElseIf e.KeyCode = Keys.Down Then
            pbxFrog.Top += 10
        ElseIf e.KeyCode = Keys.Left Then
            pbxFrog.Left -= 10
        ElseIf e.KeyCode = Keys.Right Then
            pbxFrog.Left += 10
        ElseIf e.KeyCode = Keys.Escape Then
            Call YouAreFinished()
            MsgBox("Game Over")
            pbxFrog.Image = My.Resources.frog
        End If
    End Sub
    Private Sub YouAreFinished()
        L1.Enabled = False
        L2.Enabled = False
        pbxBlue.Left = blueCarStartingPoint.X
        pbxGreen.Left = greenCarStaringPoint.X
        pbxRed.Left = redCarStartingPoint.X
        pbxFrog.Left = frogStartingPoint.X
        pbxFrog.Top = frogStartingPoint.Y
    End Sub
End Class