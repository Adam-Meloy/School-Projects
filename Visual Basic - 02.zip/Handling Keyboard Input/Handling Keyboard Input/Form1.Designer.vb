﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.L1 = New System.Windows.Forms.Timer(Me.components)
        Me.L2 = New System.Windows.Forms.Timer(Me.components)
        Me.grass = New System.Windows.Forms.PictureBox()
        Me.pbxRed = New System.Windows.Forms.PictureBox()
        Me.pbxGreen = New System.Windows.Forms.PictureBox()
        Me.pbxBlue = New System.Windows.Forms.PictureBox()
        Me.pbxFrog = New System.Windows.Forms.PictureBox()
        CType(Me.grass, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbxRed, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbxGreen, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbxBlue, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbxFrog, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'L1
        '
        '
        'L2
        '
        '
        'grass
        '
        Me.grass.BackColor = System.Drawing.Color.Lime
        Me.grass.Location = New System.Drawing.Point(1, 2)
        Me.grass.Name = "grass"
        Me.grass.Size = New System.Drawing.Size(752, 48)
        Me.grass.TabIndex = 12
        Me.grass.TabStop = False
        '
        'pbxRed
        '
        Me.pbxRed.Image = CType(resources.GetObject("pbxRed.Image"), System.Drawing.Image)
        Me.pbxRed.Location = New System.Drawing.Point(663, 215)
        Me.pbxRed.Name = "pbxRed"
        Me.pbxRed.Size = New System.Drawing.Size(74, 40)
        Me.pbxRed.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbxRed.TabIndex = 11
        Me.pbxRed.TabStop = False
        '
        'pbxGreen
        '
        Me.pbxGreen.Image = CType(resources.GetObject("pbxGreen.Image"), System.Drawing.Image)
        Me.pbxGreen.Location = New System.Drawing.Point(381, 335)
        Me.pbxGreen.Name = "pbxGreen"
        Me.pbxGreen.Size = New System.Drawing.Size(74, 40)
        Me.pbxGreen.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbxGreen.TabIndex = 10
        Me.pbxGreen.TabStop = False
        '
        'pbxBlue
        '
        Me.pbxBlue.Image = CType(resources.GetObject("pbxBlue.Image"), System.Drawing.Image)
        Me.pbxBlue.Location = New System.Drawing.Point(12, 335)
        Me.pbxBlue.Name = "pbxBlue"
        Me.pbxBlue.Size = New System.Drawing.Size(74, 40)
        Me.pbxBlue.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbxBlue.TabIndex = 9
        Me.pbxBlue.TabStop = False
        '
        'pbxFrog
        '
        Me.pbxFrog.Image = Global.Handling_Keyboard_Input.My.Resources.Resources.Frog_clipart_clipart_cliparts_for_you
        Me.pbxFrog.Location = New System.Drawing.Point(357, 499)
        Me.pbxFrog.Name = "pbxFrog"
        Me.pbxFrog.Size = New System.Drawing.Size(57, 42)
        Me.pbxFrog.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbxFrog.TabIndex = 8
        Me.pbxFrog.TabStop = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(749, 553)
        Me.Controls.Add(Me.grass)
        Me.Controls.Add(Me.pbxRed)
        Me.Controls.Add(Me.pbxGreen)
        Me.Controls.Add(Me.pbxBlue)
        Me.Controls.Add(Me.pbxFrog)
        Me.Name = "Form1"
        Me.Text = "Handing Keyboard Input"
        CType(Me.grass, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbxRed, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbxGreen, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbxBlue, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbxFrog, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents pbxRed As PictureBox
    Friend WithEvents pbxGreen As PictureBox
    Friend WithEvents pbxBlue As PictureBox
    Friend WithEvents pbxFrog As PictureBox
    Friend WithEvents grass As PictureBox
    Friend WithEvents L1 As Timer
    Friend WithEvents L2 As Timer
End Class
