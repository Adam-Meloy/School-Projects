﻿Public Class Form1
    Dim counter, sum, input, input2 As Integer
    Dim continuation As Boolean
    Dim Answer As String
    Private Sub Exercise1_Click(sender As Object, e As EventArgs) Handles Exercise1.Click
        Call Reset()
        Do While sum <= 20
            ListNumbers.Items.Add(sum)
            sum += 1
        Loop
    End Sub
    Private Sub Exercise2_Click(sender As Object, e As EventArgs) Handles Exercise2.Click
        Call Reset()
        Do While counter <= 60
            ListNumbers.Items.Add(counter)
            counter += 1
        Loop
    End Sub
    Private Sub Exercise3_Click(sender As Object, e As EventArgs) Handles Exercise3.Click
        Call Reset()
        Do While sum < 100
            input = InputBox("Enter A Number")
            sum = input * 10
            ListNumbers.Items.Add(sum)
            If sum >= 10001 Then
                MsgBox("You Are Having TOO Much Fun")
                Close()
            End If
        Loop
    End Sub
    Private Sub Exercise4_Click(sender As Object, e As EventArgs) Handles Exercise4.Click
        Call Reset()
        Do While continuation = True
            input = InputBox("Number One")
            input2 = InputBox("Number Two")
            MsgBox("The Sum Is " & input + input2)
            Answer = InputBox("Continue? Y / N")
            If Answer = "Y" Then
                continuation = True
            ElseIf Answer = "N" Then
                continuation = False
            Else
                MsgBox("Follow Instructions!")
                continuation = False
            End If
        Loop
    End Sub
    Private Sub Exercise5_Click(sender As Object, e As EventArgs) Handles Exercise5.Click
        Call Reset()
        counter = 0
        For counter = 0 To 1000 Step 10
            ListNumbers.Items.Add("Counter = " & counter)
        Next
    End Sub
    Private Sub Exercise6_Click(sender As Object, e As EventArgs) Handles Exercise6.Click
        Call Reset()
        For counter = 1 To 10
            input = InputBox("Enter A Number")
            sum += input
            ListNumbers.Items.Add("Total is " & sum)
        Next
    End Sub
    Private Sub Exercise7_Click(sender As Object, e As EventArgs) Handles Exercise7.Click
        Call Reset()
        Do Until input <= 0
            input = InputBox("Enter A Number")
            input2 = CInt(input)
            ListNumbers.Items.Add(input2)
        Loop
    End Sub
    Private Sub Exercise8_Click(sender As Object, e As EventArgs) Handles Exercise8.Click
        Call Reset()
        Do Until Answer.ToUpper = "Y"
            Answer = InputBox("Do You Want To Quit?")
            If Answer = "Y" Then
                Close()
            End If
        Loop
    End Sub
    Private Sub Exercise9_Click(sender As Object, e As EventArgs) Handles Exercise9.Click
        Call Reset()
        For counter = 0 To 50
            ListNumbers.Items.Add(counter)
        Next
    End Sub
    Private Sub Exercise10_Click(sender As Object, e As EventArgs) Handles Exercise10.Click
        Call Reset()
        counter = 50
        Do While counter > 0
            counter -= 1
            ListNumbers.Items.Add(counter)
        Loop
    End Sub
    Private Sub Reset()
        ListNumbers.Items.Clear()
        sum = 1
        counter = 1
        input = 1
        input2 = 0
        continuation = True
        Answer = ""
    End Sub
End Class