﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Exercise1 = New System.Windows.Forms.Button()
        Me.ListNumbers = New System.Windows.Forms.ListBox()
        Me.Exercise2 = New System.Windows.Forms.Button()
        Me.Exercise3 = New System.Windows.Forms.Button()
        Me.Exercise5 = New System.Windows.Forms.Button()
        Me.Exercise4 = New System.Windows.Forms.Button()
        Me.Exercise6 = New System.Windows.Forms.Button()
        Me.Exercise7 = New System.Windows.Forms.Button()
        Me.Exercise8 = New System.Windows.Forms.Button()
        Me.Exercise9 = New System.Windows.Forms.Button()
        Me.Exercise10 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Exercise1
        '
        Me.Exercise1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Exercise1.Location = New System.Drawing.Point(-1, 170)
        Me.Exercise1.Name = "Exercise1"
        Me.Exercise1.Size = New System.Drawing.Size(45, 45)
        Me.Exercise1.TabIndex = 0
        Me.Exercise1.Text = "#1"
        Me.Exercise1.UseVisualStyleBackColor = True
        '
        'ListNumbers
        '
        Me.ListNumbers.FormattingEnabled = True
        Me.ListNumbers.Location = New System.Drawing.Point(12, 0)
        Me.ListNumbers.Name = "ListNumbers"
        Me.ListNumbers.Size = New System.Drawing.Size(224, 134)
        Me.ListNumbers.TabIndex = 1
        '
        'Exercise2
        '
        Me.Exercise2.Location = New System.Drawing.Point(41, 170)
        Me.Exercise2.Name = "Exercise2"
        Me.Exercise2.Size = New System.Drawing.Size(45, 45)
        Me.Exercise2.TabIndex = 2
        Me.Exercise2.Text = "#2"
        Me.Exercise2.UseVisualStyleBackColor = True
        '
        'Exercise3
        '
        Me.Exercise3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Exercise3.Location = New System.Drawing.Point(82, 170)
        Me.Exercise3.Name = "Exercise3"
        Me.Exercise3.Size = New System.Drawing.Size(45, 45)
        Me.Exercise3.TabIndex = 4
        Me.Exercise3.Text = "#3"
        Me.Exercise3.UseVisualStyleBackColor = True
        '
        'Exercise5
        '
        Me.Exercise5.Location = New System.Drawing.Point(166, 170)
        Me.Exercise5.Name = "Exercise5"
        Me.Exercise5.Size = New System.Drawing.Size(45, 45)
        Me.Exercise5.TabIndex = 5
        Me.Exercise5.Text = "#5"
        Me.Exercise5.UseVisualStyleBackColor = True
        '
        'Exercise4
        '
        Me.Exercise4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Exercise4.Location = New System.Drawing.Point(124, 170)
        Me.Exercise4.Name = "Exercise4"
        Me.Exercise4.Size = New System.Drawing.Size(45, 45)
        Me.Exercise4.TabIndex = 6
        Me.Exercise4.Text = "#4"
        Me.Exercise4.UseVisualStyleBackColor = True
        '
        'Exercise6
        '
        Me.Exercise6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Exercise6.Location = New System.Drawing.Point(208, 170)
        Me.Exercise6.Name = "Exercise6"
        Me.Exercise6.Size = New System.Drawing.Size(45, 45)
        Me.Exercise6.TabIndex = 7
        Me.Exercise6.Text = "#6"
        Me.Exercise6.UseVisualStyleBackColor = True
        '
        'Exercise7
        '
        Me.Exercise7.Location = New System.Drawing.Point(-1, 130)
        Me.Exercise7.Name = "Exercise7"
        Me.Exercise7.Size = New System.Drawing.Size(45, 45)
        Me.Exercise7.TabIndex = 8
        Me.Exercise7.Text = "#7"
        Me.Exercise7.UseVisualStyleBackColor = True
        '
        'Exercise8
        '
        Me.Exercise8.Location = New System.Drawing.Point(41, 130)
        Me.Exercise8.Name = "Exercise8"
        Me.Exercise8.Size = New System.Drawing.Size(45, 45)
        Me.Exercise8.TabIndex = 9
        Me.Exercise8.Text = "#8"
        Me.Exercise8.UseVisualStyleBackColor = True
        '
        'Exercise9
        '
        Me.Exercise9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Exercise9.Location = New System.Drawing.Point(82, 130)
        Me.Exercise9.Name = "Exercise9"
        Me.Exercise9.Size = New System.Drawing.Size(45, 45)
        Me.Exercise9.TabIndex = 10
        Me.Exercise9.Text = "#9"
        Me.Exercise9.UseVisualStyleBackColor = True
        '
        'Exercise10
        '
        Me.Exercise10.Location = New System.Drawing.Point(124, 130)
        Me.Exercise10.Name = "Exercise10"
        Me.Exercise10.Size = New System.Drawing.Size(45, 45)
        Me.Exercise10.TabIndex = 11
        Me.Exercise10.Text = "#10"
        Me.Exercise10.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(248, 211)
        Me.Controls.Add(Me.Exercise10)
        Me.Controls.Add(Me.Exercise9)
        Me.Controls.Add(Me.Exercise8)
        Me.Controls.Add(Me.Exercise7)
        Me.Controls.Add(Me.Exercise6)
        Me.Controls.Add(Me.Exercise4)
        Me.Controls.Add(Me.Exercise5)
        Me.Controls.Add(Me.Exercise3)
        Me.Controls.Add(Me.Exercise2)
        Me.Controls.Add(Me.ListNumbers)
        Me.Controls.Add(Me.Exercise1)
        Me.Name = "Form1"
        Me.Text = "Test123123"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Exercise1 As Button
    Friend WithEvents ListNumbers As ListBox
    Friend WithEvents Exercise2 As Button
    Friend WithEvents Exercise3 As Button
    Friend WithEvents Exercise5 As Button
    Friend WithEvents Exercise4 As Button
    Friend WithEvents Exercise6 As Button
    Friend WithEvents Exercise7 As Button
    Friend WithEvents Exercise8 As Button
    Friend WithEvents Exercise9 As Button
    Friend WithEvents Exercise10 As Button
End Class
