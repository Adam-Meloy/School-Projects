﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TipeInMe.TextChanged
        MeMeStAr.Text = TipeInMe.Text




    End Sub

    Private Sub Buttn2_Click(sender As Object, e As EventArgs) Handles ButtnShow.Click
        MeMeStAr.Visible = True
        ButtnShow.Enabled = False
        ButtnHide.Enabled = True
    End Sub

    Private Sub Buttn1_Click(sender As Object, e As EventArgs) Handles ButtnHide.Click
        MeMeStAr.Visible = False
        ButtnHide.Enabled = False
        ButtnShow.Enabled = True
    End Sub
End Class
