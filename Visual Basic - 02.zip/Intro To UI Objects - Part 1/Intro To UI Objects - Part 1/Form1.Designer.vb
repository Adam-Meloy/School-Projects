﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.Memes = New System.Windows.Forms.Label()
        Me.TipeInMe = New System.Windows.Forms.TextBox()
        Me.MeMeStAr = New System.Windows.Forms.Label()
        Me.ButtnHide = New System.Windows.Forms.Button()
        Me.ButtnShow = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Memes
        '
        Me.Memes.AutoSize = True
        Me.Memes.Location = New System.Drawing.Point(128, 115)
        Me.Memes.Name = "Memes"
        Me.Memes.Size = New System.Drawing.Size(0, 13)
        Me.Memes.TabIndex = 0
        '
        'TipeInMe
        '
        Me.TipeInMe.Location = New System.Drawing.Point(200, 316)
        Me.TipeInMe.Name = "TipeInMe"
        Me.TipeInMe.Size = New System.Drawing.Size(100, 20)
        Me.TipeInMe.TabIndex = 1
        '
        'MeMeStAr
        '
        Me.MeMeStAr.AutoSize = True
        Me.MeMeStAr.Location = New System.Drawing.Point(197, 174)
        Me.MeMeStAr.Name = "MeMeStAr"
        Me.MeMeStAr.Size = New System.Drawing.Size(0, 13)
        Me.MeMeStAr.TabIndex = 2
        '
        'ButtnHide
        '
        Me.ButtnHide.Location = New System.Drawing.Point(323, 368)
        Me.ButtnHide.Name = "ButtnHide"
        Me.ButtnHide.Size = New System.Drawing.Size(75, 23)
        Me.ButtnHide.TabIndex = 3
        Me.ButtnHide.Text = "Hide"
        Me.ButtnHide.UseVisualStyleBackColor = True
        '
        'ButtnShow
        '
        Me.ButtnShow.Location = New System.Drawing.Point(100, 368)
        Me.ButtnShow.Name = "ButtnShow"
        Me.ButtnShow.Size = New System.Drawing.Size(75, 23)
        Me.ButtnShow.TabIndex = 4
        Me.ButtnShow.Text = "Show"
        Me.ButtnShow.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(480, 414)
        Me.Controls.Add(Me.ButtnShow)
        Me.Controls.Add(Me.ButtnHide)
        Me.Controls.Add(Me.MeMeStAr)
        Me.Controls.Add(Me.TipeInMe)
        Me.Controls.Add(Me.Memes)
        Me.Name = "Form1"
        Me.Text = "Thing Of Epic Proportions"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Memes As Label
    Friend WithEvents TipeInMe As TextBox
    Friend WithEvents MeMeStAr As Label
    Friend WithEvents ButtnHide As Button
    Friend WithEvents ButtnShow As Button
End Class
