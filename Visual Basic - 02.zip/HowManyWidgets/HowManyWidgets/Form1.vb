﻿Public Class Form1

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        MsgBox("Type a weight before calculating!")
    End Sub

    Private Sub BTNCalculate_Click(sender As Object, e As EventArgs) Handles BTNCalculate.Click
        If TBXNumber.Text = "" Then
            MsgBox("Enter a weight into the textbox!")
        Else
            Dim TotalWeight As Decimal = TBXNumber.Text
            Dim PalletWeight As Decimal = TBXPalletWeight.Text
            Dim WidgetWeight As Decimal = TotalWeight - PalletWeight
            Dim WidgetNumber As Integer = WidgetWeight \ 9.2
            LBLWidgetNmbr.Text = WidgetNumber
            MsgBox("You Have " & WidgetNumber & " widgets.")
        End If
    End Sub

    Private Sub BTNInstruction_Click(sender As Object, e As EventArgs) Handles BTNInstruction.Click
        MsgBox("Type in a weight to see how many widgets there are.")
    End Sub

    Private Sub BTNExit_Click(sender As Object, e As EventArgs) Handles BTNExit.Click
        MsgBox("Goodbye!")
        Close()
    End Sub

End Class
