﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.BTNExit = New System.Windows.Forms.Button()
        Me.BTNCalculate = New System.Windows.Forms.Button()
        Me.BTNInstruction = New System.Windows.Forms.Button()
        Me.LBLWeight = New System.Windows.Forms.Label()
        Me.LBLNmbrWidget = New System.Windows.Forms.Label()
        Me.LBLWidgetNmbr = New System.Windows.Forms.Label()
        Me.TBXNumber = New System.Windows.Forms.TextBox()
        Me.TBXPalletWeight = New System.Windows.Forms.TextBox()
        Me.LBLPalletWeight = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'BTNExit
        '
        Me.BTNExit.Location = New System.Drawing.Point(283, 321)
        Me.BTNExit.Name = "BTNExit"
        Me.BTNExit.Size = New System.Drawing.Size(75, 23)
        Me.BTNExit.TabIndex = 0
        Me.BTNExit.Text = "Exit"
        Me.BTNExit.UseVisualStyleBackColor = True
        '
        'BTNCalculate
        '
        Me.BTNCalculate.Location = New System.Drawing.Point(13, 321)
        Me.BTNCalculate.Name = "BTNCalculate"
        Me.BTNCalculate.Size = New System.Drawing.Size(75, 23)
        Me.BTNCalculate.TabIndex = 1
        Me.BTNCalculate.Text = "Calculate"
        Me.BTNCalculate.UseVisualStyleBackColor = True
        '
        'BTNInstruction
        '
        Me.BTNInstruction.Location = New System.Drawing.Point(145, 321)
        Me.BTNInstruction.Name = "BTNInstruction"
        Me.BTNInstruction.Size = New System.Drawing.Size(75, 23)
        Me.BTNInstruction.TabIndex = 2
        Me.BTNInstruction.Text = "Instructions"
        Me.BTNInstruction.UseVisualStyleBackColor = True
        '
        'LBLWeight
        '
        Me.LBLWeight.AutoSize = True
        Me.LBLWeight.Location = New System.Drawing.Point(136, 54)
        Me.LBLWeight.Name = "LBLWeight"
        Me.LBLWeight.Size = New System.Drawing.Size(68, 13)
        Me.LBLWeight.TabIndex = 3
        Me.LBLWeight.Text = "Total Weight"
        '
        'LBLNmbrWidget
        '
        Me.LBLNmbrWidget.AutoSize = True
        Me.LBLNmbrWidget.Location = New System.Drawing.Point(128, 161)
        Me.LBLNmbrWidget.Name = "LBLNmbrWidget"
        Me.LBLNmbrWidget.Size = New System.Drawing.Size(100, 13)
        Me.LBLNmbrWidget.TabIndex = 4
        Me.LBLNmbrWidget.Text = "Number Of Widgets"
        '
        'LBLWidgetNmbr
        '
        Me.LBLWidgetNmbr.AutoSize = True
        Me.LBLWidgetNmbr.Location = New System.Drawing.Point(162, 193)
        Me.LBLWidgetNmbr.Name = "LBLWidgetNmbr"
        Me.LBLWidgetNmbr.Size = New System.Drawing.Size(0, 13)
        Me.LBLWidgetNmbr.TabIndex = 5
        '
        'TBXNumber
        '
        Me.TBXNumber.Location = New System.Drawing.Point(131, 70)
        Me.TBXNumber.Name = "TBXNumber"
        Me.TBXNumber.Size = New System.Drawing.Size(100, 20)
        Me.TBXNumber.TabIndex = 6
        '
        'TBXPalletWeight
        '
        Me.TBXPalletWeight.Location = New System.Drawing.Point(131, 126)
        Me.TBXPalletWeight.Name = "TBXPalletWeight"
        Me.TBXPalletWeight.Size = New System.Drawing.Size(100, 20)
        Me.TBXPalletWeight.TabIndex = 7
        '
        'LBLPalletWeight
        '
        Me.LBLPalletWeight.AutoSize = True
        Me.LBLPalletWeight.Location = New System.Drawing.Point(131, 107)
        Me.LBLPalletWeight.Name = "LBLPalletWeight"
        Me.LBLPalletWeight.Size = New System.Drawing.Size(70, 13)
        Me.LBLPalletWeight.TabIndex = 8
        Me.LBLPalletWeight.Text = "Pallet Weight"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(370, 356)
        Me.Controls.Add(Me.LBLPalletWeight)
        Me.Controls.Add(Me.TBXPalletWeight)
        Me.Controls.Add(Me.TBXNumber)
        Me.Controls.Add(Me.LBLWidgetNmbr)
        Me.Controls.Add(Me.LBLNmbrWidget)
        Me.Controls.Add(Me.LBLWeight)
        Me.Controls.Add(Me.BTNInstruction)
        Me.Controls.Add(Me.BTNCalculate)
        Me.Controls.Add(Me.BTNExit)
        Me.Name = "Form1"
        Me.Text = "Widget Weight Calculator"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents BTNExit As Button
    Friend WithEvents BTNCalculate As Button
    Friend WithEvents BTNInstruction As Button
    Friend WithEvents LBLWeight As Label
    Friend WithEvents LBLNmbrWidget As Label
    Friend WithEvents LBLWidgetNmbr As Label
    Friend WithEvents TBXNumber As TextBox
    Friend WithEvents TBXPalletWeight As TextBox
    Friend WithEvents LBLPalletWeight As Label
End Class
