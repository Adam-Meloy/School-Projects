﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class HTS
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.BTNSTANDARD = New System.Windows.Forms.Button()
        Me.lblUserInformation = New System.Windows.Forms.Label()
        Me.BTNSELECT = New System.Windows.Forms.Button()
        Me.BTNDELUXE = New System.Windows.Forms.Button()
        Me.BTNEXIT = New System.Windows.Forms.Button()
        Me.lblConfirmationMessage = New System.Windows.Forms.Label()
        Me.LblHeading = New System.Windows.Forms.Label()
        Me.pbxDelux = New System.Windows.Forms.PictureBox()
        Me.pbxStandard = New System.Windows.Forms.PictureBox()
        CType(Me.pbxDelux, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbxStandard, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'BTNSTANDARD
        '
        Me.BTNSTANDARD.Location = New System.Drawing.Point(12, 290)
        Me.BTNSTANDARD.Name = "BTNSTANDARD"
        Me.BTNSTANDARD.Size = New System.Drawing.Size(75, 47)
        Me.BTNSTANDARD.TabIndex = 0
        Me.BTNSTANDARD.Text = "Standard"
        Me.BTNSTANDARD.UseVisualStyleBackColor = True
        '
        'lblUserInformation
        '
        Me.lblUserInformation.AutoSize = True
        Me.lblUserInformation.BackColor = System.Drawing.Color.White
        Me.lblUserInformation.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.lblUserInformation.Location = New System.Drawing.Point(92, 361)
        Me.lblUserInformation.Name = "lblUserInformation"
        Me.lblUserInformation.Size = New System.Drawing.Size(339, 20)
        Me.lblUserInformation.TabIndex = 1
        Me.lblUserInformation.Text = "Choose a room type and click the select button"
        '
        'BTNSELECT
        '
        Me.BTNSELECT.Enabled = False
        Me.BTNSELECT.Location = New System.Drawing.Point(209, 290)
        Me.BTNSELECT.Name = "BTNSELECT"
        Me.BTNSELECT.Size = New System.Drawing.Size(75, 47)
        Me.BTNSELECT.TabIndex = 2
        Me.BTNSELECT.Text = "Select"
        Me.BTNSELECT.UseVisualStyleBackColor = True
        '
        'BTNDELUXE
        '
        Me.BTNDELUXE.Location = New System.Drawing.Point(393, 290)
        Me.BTNDELUXE.Name = "BTNDELUXE"
        Me.BTNDELUXE.Size = New System.Drawing.Size(75, 47)
        Me.BTNDELUXE.TabIndex = 3
        Me.BTNDELUXE.Text = "Deluxe"
        Me.BTNDELUXE.UseVisualStyleBackColor = True
        '
        'BTNEXIT
        '
        Me.BTNEXIT.Enabled = False
        Me.BTNEXIT.Location = New System.Drawing.Point(209, 404)
        Me.BTNEXIT.Name = "BTNEXIT"
        Me.BTNEXIT.Size = New System.Drawing.Size(75, 47)
        Me.BTNEXIT.TabIndex = 4
        Me.BTNEXIT.Text = "Exit"
        Me.BTNEXIT.UseVisualStyleBackColor = True
        '
        'lblConfirmationMessage
        '
        Me.lblConfirmationMessage.AutoSize = True
        Me.lblConfirmationMessage.BackColor = System.Drawing.Color.White
        Me.lblConfirmationMessage.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.lblConfirmationMessage.Location = New System.Drawing.Point(107, 361)
        Me.lblConfirmationMessage.Name = "lblConfirmationMessage"
        Me.lblConfirmationMessage.Size = New System.Drawing.Size(295, 20)
        Me.lblConfirmationMessage.TabIndex = 5
        Me.lblConfirmationMessage.Text = "You have completed your room selection"
        Me.lblConfirmationMessage.Visible = False
        '
        'LblHeading
        '
        Me.LblHeading.AutoSize = True
        Me.LblHeading.BackColor = System.Drawing.Color.White
        Me.LblHeading.Font = New System.Drawing.Font("CK Primary", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblHeading.Location = New System.Drawing.Point(134, 11)
        Me.LblHeading.Name = "LblHeading"
        Me.LblHeading.Size = New System.Drawing.Size(239, 21)
        Me.LblHeading.TabIndex = 6
        Me.LblHeading.Text = "Hotel Room Selection"
        '
        'pbxDelux
        '
        Me.pbxDelux.Image = Global.Hotel_Room_Selection.My.Resources.Resources.Screen_Shot_2015_09_07_at_18_03_04
        Me.pbxDelux.Location = New System.Drawing.Point(251, 35)
        Me.pbxDelux.Name = "pbxDelux"
        Me.pbxDelux.Size = New System.Drawing.Size(217, 249)
        Me.pbxDelux.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbxDelux.TabIndex = 8
        Me.pbxDelux.TabStop = False
        Me.pbxDelux.Visible = False
        '
        'pbxStandard
        '
        Me.pbxStandard.Image = Global.Hotel_Room_Selection.My.Resources.Resources.LHRPQ_Standard_Double_Room
        Me.pbxStandard.Location = New System.Drawing.Point(12, 35)
        Me.pbxStandard.Name = "pbxStandard"
        Me.pbxStandard.Size = New System.Drawing.Size(233, 249)
        Me.pbxStandard.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbxStandard.TabIndex = 7
        Me.pbxStandard.TabStop = False
        Me.pbxStandard.Visible = False
        '
        'HTS
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(480, 463)
        Me.Controls.Add(Me.pbxDelux)
        Me.Controls.Add(Me.pbxStandard)
        Me.Controls.Add(Me.LblHeading)
        Me.Controls.Add(Me.lblConfirmationMessage)
        Me.Controls.Add(Me.BTNEXIT)
        Me.Controls.Add(Me.BTNDELUXE)
        Me.Controls.Add(Me.BTNSELECT)
        Me.Controls.Add(Me.lblUserInformation)
        Me.Controls.Add(Me.BTNSTANDARD)
        Me.Name = "HTS"
        Me.Text = "Hugh Mungus Window"
        CType(Me.pbxDelux, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbxStandard, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents BTNSTANDARD As Button
    Friend WithEvents lblUserInformation As Label
    Friend WithEvents BTNSELECT As Button
    Friend WithEvents BTNDELUXE As Button
    Friend WithEvents BTNEXIT As Button
    Friend WithEvents lblConfirmationMessage As Label
    Friend WithEvents LblHeading As Label
    Friend WithEvents pbxStandard As PictureBox
    Friend WithEvents pbxDelux As PictureBox
End Class
