﻿Public Class HTS
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub BTNSTANDARD_Click(sender As Object, e As EventArgs) Handles BTNSTANDARD.Click
        BTNSTANDARD.Enabled = False
        BTNDELUXE.Enabled = True
        pbxDelux.Visible = False
        pbxStandard.Visible = True
        BTNSELECT.Enabled = True

    End Sub

    Private Sub BTNDELUXE_Click(sender As Object, e As EventArgs) Handles BTNDELUXE.Click
        BTNDELUXE.Enabled = False
        BTNSTANDARD.Enabled = True
        pbxDelux.Visible = True
        pbxStandard.Visible = False
        BTNSELECT.Enabled = True
    End Sub

    Private Sub BTNSELECT_Click(sender As Object, e As EventArgs) Handles BTNSELECT.Click
        BTNSELECT.Enabled = False
        BTNEXIT.Enabled = True
        BTNDELUXE.Enabled = False
        BTNSTANDARD.Enabled = False
        lblConfirmationMessage.Visible = True
        lblUserInformation.Visible = False
    End Sub

    Private Sub BTNEXIT_Click(sender As Object, e As EventArgs) Handles BTNEXIT.Click
        MsgBox("See you later!")
        Close()
    End Sub
End Class