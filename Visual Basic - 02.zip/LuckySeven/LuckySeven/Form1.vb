﻿Public Class Form1
    Dim N1, N2, N3, A1, A2 As Integer
    Private Sub SpinTimer_Tick(sender As Object, e As EventArgs) Handles SpinTimer.Tick
        A1 = 7
        A2 = 1
        Randomize()
        N1 = Int(Rnd() * A1) + A2
        Number1.Text = N1
        N2 = Int(Rnd() * A1) + A2
        Number2.Text = N2
        N3 = Int(Rnd() * A1) + A2
        Number3.Text = N3
    End Sub
    Private Sub Spin_Click(sender As Object, e As EventArgs) Handles Spin.Click
        SpinTimer.Enabled = True
    End Sub
    Private Sub St0p_Click(sender As Object, e As EventArgs) Handles St0p.Click
        SpinTimer.Enabled = False
        If Number1.Text & Number2.Text & Number3.Text = "7" Then
            Textbox.Enabled = True
            MsgBox("You Got All Three Sevens!")
            NumberOfSevens.Text = NumberOfSevens.Text + 3
        ElseIf Number1.Text & Number2.Text = "7" Or Number1.Text & Number3.Text = "7" Or Number2.Text & Number3.Text = "7" Then
            Textbox.Enabled = True
            MsgBox("You Got Two Sevens!")
            NumberOfSevens.Text = NumberOfSevens.Text + 2
        ElseIf Number1.Text = "7" Or Number2.Text = "7" Or Number3.Text = "7" Then
            Textbox.Enabled = True
            MsgBox("You Got A Seven!")
            NumberOfSevens.Text = NumberOfSevens.Text + 1
            Picture.Image = My.Resources.images1
        ElseIf Number1.Text IsNot "7" Or Number2.Text IsNot "7" Or Number3.Text IsNot "7" Then
            Picture.Image = My.Resources.photos_medleyphoto_13305337
        End If
    End Sub
    Private Sub Clear_Click(sender As Object, e As EventArgs) Handles Reset.Click
        NumberOfSevens.Text = "0"
        Number1.Text = "0"
        Number2.Text = "0"
        Number3.Text = "0"
        Picture.Image = My.Resources.whit
    End Sub
    Private Sub Ex1t_Click(sender As Object, e As EventArgs) Handles Ex1t.Click
        Close()
    End Sub
End Class