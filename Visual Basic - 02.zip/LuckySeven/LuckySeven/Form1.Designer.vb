﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.SpinTimer = New System.Windows.Forms.Timer(Me.components)
        Me.Number2 = New System.Windows.Forms.Label()
        Me.Spin = New System.Windows.Forms.Button()
        Me.St0p = New System.Windows.Forms.Button()
        Me.Reset = New System.Windows.Forms.Button()
        Me.Ex1t = New System.Windows.Forms.Button()
        Me.Number1 = New System.Windows.Forms.Label()
        Me.Number3 = New System.Windows.Forms.Label()
        Me.Textbox = New System.Windows.Forms.Label()
        Me.SevenCounter = New System.Windows.Forms.Label()
        Me.NumberOfSevens = New System.Windows.Forms.Label()
        Me.Picture = New System.Windows.Forms.PictureBox()
        CType(Me.Picture, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'SpinTimer
        '
        Me.SpinTimer.Interval = 1
        '
        'Number2
        '
        Me.Number2.AutoSize = True
        Me.Number2.Font = New System.Drawing.Font("Microsoft Sans Serif", 72.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Number2.Location = New System.Drawing.Point(283, 10)
        Me.Number2.Name = "Number2"
        Me.Number2.Size = New System.Drawing.Size(98, 108)
        Me.Number2.TabIndex = 0
        Me.Number2.Text = "0"
        '
        'Spin
        '
        Me.Spin.BackgroundImage = Global.LuckySeven.My.Resources.Resources.whit
        Me.Spin.Location = New System.Drawing.Point(12, 12)
        Me.Spin.Name = "Spin"
        Me.Spin.Size = New System.Drawing.Size(50, 50)
        Me.Spin.TabIndex = 1
        Me.Spin.Text = "Spin"
        Me.Spin.UseVisualStyleBackColor = True
        '
        'St0p
        '
        Me.St0p.BackgroundImage = Global.LuckySeven.My.Resources.Resources.whit
        Me.St0p.Location = New System.Drawing.Point(12, 68)
        Me.St0p.Name = "St0p"
        Me.St0p.Size = New System.Drawing.Size(50, 50)
        Me.St0p.TabIndex = 3
        Me.St0p.Text = "Stop"
        Me.St0p.UseVisualStyleBackColor = True
        '
        'Reset
        '
        Me.Reset.BackgroundImage = Global.LuckySeven.My.Resources.Resources.whit
        Me.Reset.Image = Global.LuckySeven.My.Resources.Resources.whit
        Me.Reset.Location = New System.Drawing.Point(68, 12)
        Me.Reset.Name = "Reset"
        Me.Reset.Size = New System.Drawing.Size(50, 50)
        Me.Reset.TabIndex = 4
        Me.Reset.Text = "Reset"
        Me.Reset.UseVisualStyleBackColor = True
        '
        'Ex1t
        '
        Me.Ex1t.BackgroundImage = Global.LuckySeven.My.Resources.Resources.whit
        Me.Ex1t.Location = New System.Drawing.Point(68, 68)
        Me.Ex1t.Name = "Ex1t"
        Me.Ex1t.Size = New System.Drawing.Size(50, 50)
        Me.Ex1t.TabIndex = 5
        Me.Ex1t.Text = "Exit"
        Me.Ex1t.UseVisualStyleBackColor = True
        '
        'Number1
        '
        Me.Number1.AutoSize = True
        Me.Number1.Font = New System.Drawing.Font("Microsoft Sans Serif", 72.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Number1.Location = New System.Drawing.Point(149, 9)
        Me.Number1.Name = "Number1"
        Me.Number1.Size = New System.Drawing.Size(98, 108)
        Me.Number1.TabIndex = 6
        Me.Number1.Text = "0"
        '
        'Number3
        '
        Me.Number3.AutoSize = True
        Me.Number3.Font = New System.Drawing.Font("Microsoft Sans Serif", 72.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Number3.Location = New System.Drawing.Point(431, 9)
        Me.Number3.Name = "Number3"
        Me.Number3.Size = New System.Drawing.Size(98, 108)
        Me.Number3.TabIndex = 7
        Me.Number3.Text = "0"
        '
        'Textbox
        '
        Me.Textbox.AutoSize = True
        Me.Textbox.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Textbox.Location = New System.Drawing.Point(12, 123)
        Me.Textbox.Name = "Textbox"
        Me.Textbox.Size = New System.Drawing.Size(184, 31)
        Me.Textbox.TabIndex = 8
        Me.Textbox.Text = "Lucky Sevens"
        '
        'SevenCounter
        '
        Me.SevenCounter.AutoSize = True
        Me.SevenCounter.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SevenCounter.Location = New System.Drawing.Point(8, 223)
        Me.SevenCounter.Name = "SevenCounter"
        Me.SevenCounter.Size = New System.Drawing.Size(141, 24)
        Me.SevenCounter.TabIndex = 9
        Me.SevenCounter.Text = "Seven Counter:"
        '
        'NumberOfSevens
        '
        Me.NumberOfSevens.AutoSize = True
        Me.NumberOfSevens.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NumberOfSevens.Location = New System.Drawing.Point(146, 223)
        Me.NumberOfSevens.Name = "NumberOfSevens"
        Me.NumberOfSevens.Size = New System.Drawing.Size(20, 24)
        Me.NumberOfSevens.TabIndex = 10
        Me.NumberOfSevens.Text = "0"
        '
        'Picture
        '
        Me.Picture.Image = Global.LuckySeven.My.Resources.Resources.images2
        Me.Picture.Location = New System.Drawing.Point(402, 127)
        Me.Picture.Name = "Picture"
        Me.Picture.Size = New System.Drawing.Size(127, 124)
        Me.Picture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Picture.TabIndex = 2
        Me.Picture.TabStop = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(541, 260)
        Me.Controls.Add(Me.NumberOfSevens)
        Me.Controls.Add(Me.SevenCounter)
        Me.Controls.Add(Me.Textbox)
        Me.Controls.Add(Me.Number3)
        Me.Controls.Add(Me.Number1)
        Me.Controls.Add(Me.Ex1t)
        Me.Controls.Add(Me.Reset)
        Me.Controls.Add(Me.St0p)
        Me.Controls.Add(Me.Picture)
        Me.Controls.Add(Me.Spin)
        Me.Controls.Add(Me.Number2)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.Picture, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents SpinTimer As Timer
    Friend WithEvents Number2 As Label
    Friend WithEvents Spin As Button
    Friend WithEvents Picture As PictureBox
    Friend WithEvents St0p As Button
    Friend WithEvents Reset As Button
    Friend WithEvents Ex1t As Button
    Friend WithEvents Number1 As Label
    Friend WithEvents Number3 As Label
    Friend WithEvents Textbox As Label
    Friend WithEvents SevenCounter As Label
    Friend WithEvents NumberOfSevens As Label
End Class
