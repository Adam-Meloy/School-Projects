﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ROBERT = New System.Windows.Forms.Label()
        Me.ButnOff = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'ROBERT
        '
        Me.ROBERT.AutoSize = True
        Me.ROBERT.Font = New System.Drawing.Font("Wingdings", 15.75!, CType((((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic) _
                Or System.Drawing.FontStyle.Underline) _
                Or System.Drawing.FontStyle.Strikeout), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.ROBERT.Location = New System.Drawing.Point(8, 73)
        Me.ROBERT.Name = "ROBERT"
        Me.ROBERT.Size = New System.Drawing.Size(242, 23)
        Me.ROBERT.TabIndex = 0
        Me.ROBERT.Text = "Hello Robert"
        '
        'ButnOff
        '
        Me.ButnOff.Location = New System.Drawing.Point(94, 151)
        Me.ButnOff.Name = "ButnOff"
        Me.ButnOff.Size = New System.Drawing.Size(64, 68)
        Me.ButnOff.TabIndex = 2
        Me.ButnOff.Text = "Close Me"
        Me.ButnOff.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Aqua
        Me.ClientSize = New System.Drawing.Size(262, 261)
        Me.Controls.Add(Me.ButnOff)
        Me.Controls.Add(Me.ROBERT)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents ROBERT As Label
    Friend WithEvents ButnOff As Button
End Class
