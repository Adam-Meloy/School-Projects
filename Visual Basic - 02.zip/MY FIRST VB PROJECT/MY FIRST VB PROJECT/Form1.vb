﻿Public Class Form1

    Private Sub ButnOff_Click(sender As Object, e As EventArgs) Handles ButnOff.Click
        Close()
    End Sub
End Class
