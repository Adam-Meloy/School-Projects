﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.CarLanes = New System.Windows.Forms.Timer(Me.components)
        Me.LogRows = New System.Windows.Forms.Timer(Me.components)
        Me.Home = New System.Windows.Forms.Label()
        Me.PictureBox33 = New System.Windows.Forms.PictureBox()
        Me.PictureBox32 = New System.Windows.Forms.PictureBox()
        Me.PictureBox31 = New System.Windows.Forms.PictureBox()
        Me.PictureBox30 = New System.Windows.Forms.PictureBox()
        Me.PictureBox29 = New System.Windows.Forms.PictureBox()
        Me.PictureBox28 = New System.Windows.Forms.PictureBox()
        Me.PictureBox27 = New System.Windows.Forms.PictureBox()
        Me.PictureBox26 = New System.Windows.Forms.PictureBox()
        Me.PictureBox25 = New System.Windows.Forms.PictureBox()
        Me.PictureBox24 = New System.Windows.Forms.PictureBox()
        Me.PictureBox23 = New System.Windows.Forms.PictureBox()
        Me.PictureBox22 = New System.Windows.Forms.PictureBox()
        Me.Lane1C4 = New System.Windows.Forms.PictureBox()
        Me.Lane1C3 = New System.Windows.Forms.PictureBox()
        Me.Lane1C2 = New System.Windows.Forms.PictureBox()
        Me.Lane1C1 = New System.Windows.Forms.PictureBox()
        Me.Lane2C2 = New System.Windows.Forms.PictureBox()
        Me.Lane2C4 = New System.Windows.Forms.PictureBox()
        Me.Lane2C3 = New System.Windows.Forms.PictureBox()
        Me.Row1L4 = New System.Windows.Forms.PictureBox()
        Me.Row2L4 = New System.Windows.Forms.PictureBox()
        Me.Row3L4 = New System.Windows.Forms.PictureBox()
        Me.Row3L3 = New System.Windows.Forms.PictureBox()
        Me.Row1L2 = New System.Windows.Forms.PictureBox()
        Me.Row2L2 = New System.Windows.Forms.PictureBox()
        Me.Row3L2 = New System.Windows.Forms.PictureBox()
        Me.Row3L1 = New System.Windows.Forms.PictureBox()
        Me.Row1L3 = New System.Windows.Forms.PictureBox()
        Me.Row2L3 = New System.Windows.Forms.PictureBox()
        Me.Row1L1 = New System.Windows.Forms.PictureBox()
        Me.Lane2C1 = New System.Windows.Forms.PictureBox()
        Me.Row2L1 = New System.Windows.Forms.PictureBox()
        Me.MrKrabs = New System.Windows.Forms.PictureBox()
        Me.AllPurpose = New System.Windows.Forms.Timer(Me.components)
        Me.RODE = New System.Windows.Forms.PictureBox()
        Me.WATER = New System.Windows.Forms.PictureBox()
        CType(Me.PictureBox33, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox32, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox31, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox30, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox29, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox28, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox27, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox26, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox25, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox24, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox23, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox22, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Lane1C4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Lane1C3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Lane1C2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Lane1C1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Lane2C2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Lane2C4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Lane2C3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Row1L4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Row2L4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Row3L4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Row3L3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Row1L2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Row2L2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Row3L2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Row3L1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Row1L3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Row2L3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Row1L1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Lane2C1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Row2L1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MrKrabs, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.RODE, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.WATER, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'CarLanes
        '
        '
        'LogRows
        '
        '
        'Home
        '
        Me.Home.BackColor = System.Drawing.Color.Transparent
        Me.Home.Location = New System.Drawing.Point(16, 0)
        Me.Home.Name = "Home"
        Me.Home.Size = New System.Drawing.Size(732, 78)
        Me.Home.TabIndex = 5
        '
        'PictureBox33
        '
        Me.PictureBox33.BackColor = System.Drawing.Color.White
        Me.PictureBox33.Image = Global.Frogger_Fall_2017_by_Adam_Meloy.My.Resources.Resources._1200px_Onedolar2009series
        Me.PictureBox33.Location = New System.Drawing.Point(316, 12)
        Me.PictureBox33.Name = "PictureBox33"
        Me.PictureBox33.Size = New System.Drawing.Size(39, 20)
        Me.PictureBox33.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox33.TabIndex = 53
        Me.PictureBox33.TabStop = False
        '
        'PictureBox32
        '
        Me.PictureBox32.BackColor = System.Drawing.Color.White
        Me.PictureBox32.Image = Global.Frogger_Fall_2017_by_Adam_Meloy.My.Resources.Resources._1200px_Onedolar2009series
        Me.PictureBox32.Location = New System.Drawing.Point(709, 0)
        Me.PictureBox32.Name = "PictureBox32"
        Me.PictureBox32.Size = New System.Drawing.Size(39, 20)
        Me.PictureBox32.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox32.TabIndex = 52
        Me.PictureBox32.TabStop = False
        '
        'PictureBox31
        '
        Me.PictureBox31.BackColor = System.Drawing.Color.White
        Me.PictureBox31.Image = Global.Frogger_Fall_2017_by_Adam_Meloy.My.Resources.Resources._1200px_Onedolar2009series
        Me.PictureBox31.Location = New System.Drawing.Point(634, 32)
        Me.PictureBox31.Name = "PictureBox31"
        Me.PictureBox31.Size = New System.Drawing.Size(39, 20)
        Me.PictureBox31.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox31.TabIndex = 51
        Me.PictureBox31.TabStop = False
        '
        'PictureBox30
        '
        Me.PictureBox30.BackColor = System.Drawing.Color.White
        Me.PictureBox30.Image = Global.Frogger_Fall_2017_by_Adam_Meloy.My.Resources.Resources._1200px_Onedolar2009series
        Me.PictureBox30.Location = New System.Drawing.Point(500, 12)
        Me.PictureBox30.Name = "PictureBox30"
        Me.PictureBox30.Size = New System.Drawing.Size(39, 20)
        Me.PictureBox30.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox30.TabIndex = 50
        Me.PictureBox30.TabStop = False
        '
        'PictureBox29
        '
        Me.PictureBox29.BackColor = System.Drawing.Color.White
        Me.PictureBox29.Image = Global.Frogger_Fall_2017_by_Adam_Meloy.My.Resources.Resources._1200px_Onedolar2009series
        Me.PictureBox29.Location = New System.Drawing.Point(565, 32)
        Me.PictureBox29.Name = "PictureBox29"
        Me.PictureBox29.Size = New System.Drawing.Size(39, 20)
        Me.PictureBox29.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox29.TabIndex = 49
        Me.PictureBox29.TabStop = False
        '
        'PictureBox28
        '
        Me.PictureBox28.BackColor = System.Drawing.Color.White
        Me.PictureBox28.Image = Global.Frogger_Fall_2017_by_Adam_Meloy.My.Resources.Resources._1200px_Onedolar2009series
        Me.PictureBox28.Location = New System.Drawing.Point(430, 32)
        Me.PictureBox28.Name = "PictureBox28"
        Me.PictureBox28.Size = New System.Drawing.Size(39, 20)
        Me.PictureBox28.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox28.TabIndex = 48
        Me.PictureBox28.TabStop = False
        '
        'PictureBox27
        '
        Me.PictureBox27.BackColor = System.Drawing.Color.White
        Me.PictureBox27.Image = Global.Frogger_Fall_2017_by_Adam_Meloy.My.Resources.Resources._1200px_Onedolar2009series
        Me.PictureBox27.Location = New System.Drawing.Point(347, 41)
        Me.PictureBox27.Name = "PictureBox27"
        Me.PictureBox27.Size = New System.Drawing.Size(39, 20)
        Me.PictureBox27.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox27.TabIndex = 47
        Me.PictureBox27.TabStop = False
        '
        'PictureBox26
        '
        Me.PictureBox26.BackColor = System.Drawing.Color.White
        Me.PictureBox26.Image = Global.Frogger_Fall_2017_by_Adam_Meloy.My.Resources.Resources._1200px_Onedolar2009series
        Me.PictureBox26.Location = New System.Drawing.Point(212, 41)
        Me.PictureBox26.Name = "PictureBox26"
        Me.PictureBox26.Size = New System.Drawing.Size(39, 20)
        Me.PictureBox26.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox26.TabIndex = 46
        Me.PictureBox26.TabStop = False
        '
        'PictureBox25
        '
        Me.PictureBox25.BackColor = System.Drawing.Color.White
        Me.PictureBox25.Image = Global.Frogger_Fall_2017_by_Adam_Meloy.My.Resources.Resources._1200px_Onedolar2009series
        Me.PictureBox25.Location = New System.Drawing.Point(268, 32)
        Me.PictureBox25.Name = "PictureBox25"
        Me.PictureBox25.Size = New System.Drawing.Size(39, 20)
        Me.PictureBox25.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox25.TabIndex = 45
        Me.PictureBox25.TabStop = False
        '
        'PictureBox24
        '
        Me.PictureBox24.BackColor = System.Drawing.Color.White
        Me.PictureBox24.Image = Global.Frogger_Fall_2017_by_Adam_Meloy.My.Resources.Resources._1200px_Onedolar2009series
        Me.PictureBox24.Location = New System.Drawing.Point(104, 41)
        Me.PictureBox24.Name = "PictureBox24"
        Me.PictureBox24.Size = New System.Drawing.Size(39, 20)
        Me.PictureBox24.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox24.TabIndex = 44
        Me.PictureBox24.TabStop = False
        '
        'PictureBox23
        '
        Me.PictureBox23.BackColor = System.Drawing.Color.White
        Me.PictureBox23.Image = Global.Frogger_Fall_2017_by_Adam_Meloy.My.Resources.Resources._1200px_Onedolar2009series
        Me.PictureBox23.Location = New System.Drawing.Point(172, 12)
        Me.PictureBox23.Name = "PictureBox23"
        Me.PictureBox23.Size = New System.Drawing.Size(39, 20)
        Me.PictureBox23.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox23.TabIndex = 43
        Me.PictureBox23.TabStop = False
        '
        'PictureBox22
        '
        Me.PictureBox22.BackColor = System.Drawing.Color.White
        Me.PictureBox22.Image = Global.Frogger_Fall_2017_by_Adam_Meloy.My.Resources.Resources._1200px_Onedolar2009series
        Me.PictureBox22.Location = New System.Drawing.Point(55, 12)
        Me.PictureBox22.Name = "PictureBox22"
        Me.PictureBox22.Size = New System.Drawing.Size(39, 20)
        Me.PictureBox22.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox22.TabIndex = 42
        Me.PictureBox22.TabStop = False
        '
        'Lane1C4
        '
        Me.Lane1C4.BackColor = System.Drawing.Color.White
        Me.Lane1C4.Image = Global.Frogger_Fall_2017_by_Adam_Meloy.My.Resources.Resources.car2
        Me.Lane1C4.Location = New System.Drawing.Point(701, 483)
        Me.Lane1C4.Name = "Lane1C4"
        Me.Lane1C4.Size = New System.Drawing.Size(60, 50)
        Me.Lane1C4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Lane1C4.TabIndex = 41
        Me.Lane1C4.TabStop = False
        '
        'Lane1C3
        '
        Me.Lane1C3.BackColor = System.Drawing.Color.White
        Me.Lane1C3.Image = Global.Frogger_Fall_2017_by_Adam_Meloy.My.Resources.Resources.car2
        Me.Lane1C3.Location = New System.Drawing.Point(492, 483)
        Me.Lane1C3.Name = "Lane1C3"
        Me.Lane1C3.Size = New System.Drawing.Size(60, 50)
        Me.Lane1C3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Lane1C3.TabIndex = 40
        Me.Lane1C3.TabStop = False
        '
        'Lane1C2
        '
        Me.Lane1C2.BackColor = System.Drawing.Color.White
        Me.Lane1C2.Image = Global.Frogger_Fall_2017_by_Adam_Meloy.My.Resources.Resources.car2
        Me.Lane1C2.Location = New System.Drawing.Point(304, 483)
        Me.Lane1C2.Name = "Lane1C2"
        Me.Lane1C2.Size = New System.Drawing.Size(60, 50)
        Me.Lane1C2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Lane1C2.TabIndex = 39
        Me.Lane1C2.TabStop = False
        '
        'Lane1C1
        '
        Me.Lane1C1.BackColor = System.Drawing.Color.White
        Me.Lane1C1.Image = Global.Frogger_Fall_2017_by_Adam_Meloy.My.Resources.Resources.car2
        Me.Lane1C1.Location = New System.Drawing.Point(125, 483)
        Me.Lane1C1.Name = "Lane1C1"
        Me.Lane1C1.Size = New System.Drawing.Size(60, 50)
        Me.Lane1C1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Lane1C1.TabIndex = 38
        Me.Lane1C1.TabStop = False
        '
        'Lane2C2
        '
        Me.Lane2C2.BackColor = System.Drawing.Color.White
        Me.Lane2C2.Image = Global.Frogger_Fall_2017_by_Adam_Meloy.My.Resources.Resources.car_right
        Me.Lane2C2.Location = New System.Drawing.Point(212, 409)
        Me.Lane2C2.Name = "Lane2C2"
        Me.Lane2C2.Size = New System.Drawing.Size(60, 50)
        Me.Lane2C2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Lane2C2.TabIndex = 37
        Me.Lane2C2.TabStop = False
        '
        'Lane2C4
        '
        Me.Lane2C4.BackColor = System.Drawing.Color.White
        Me.Lane2C4.Image = Global.Frogger_Fall_2017_by_Adam_Meloy.My.Resources.Resources.car_right
        Me.Lane2C4.Location = New System.Drawing.Point(634, 409)
        Me.Lane2C4.Name = "Lane2C4"
        Me.Lane2C4.Size = New System.Drawing.Size(60, 50)
        Me.Lane2C4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Lane2C4.TabIndex = 36
        Me.Lane2C4.TabStop = False
        '
        'Lane2C3
        '
        Me.Lane2C3.BackColor = System.Drawing.Color.White
        Me.Lane2C3.Image = Global.Frogger_Fall_2017_by_Adam_Meloy.My.Resources.Resources.car_right
        Me.Lane2C3.Location = New System.Drawing.Point(409, 409)
        Me.Lane2C3.Name = "Lane2C3"
        Me.Lane2C3.Size = New System.Drawing.Size(60, 50)
        Me.Lane2C3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Lane2C3.TabIndex = 35
        Me.Lane2C3.TabStop = False
        '
        'Row1L4
        '
        Me.Row1L4.BackColor = System.Drawing.Color.White
        Me.Row1L4.Image = CType(resources.GetObject("Row1L4.Image"), System.Drawing.Image)
        Me.Row1L4.Location = New System.Drawing.Point(644, 90)
        Me.Row1L4.Name = "Row1L4"
        Me.Row1L4.Size = New System.Drawing.Size(71, 45)
        Me.Row1L4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Row1L4.TabIndex = 34
        Me.Row1L4.TabStop = False
        '
        'Row2L4
        '
        Me.Row2L4.BackColor = System.Drawing.Color.White
        Me.Row2L4.Image = CType(resources.GetObject("Row2L4.Image"), System.Drawing.Image)
        Me.Row2L4.Location = New System.Drawing.Point(690, 132)
        Me.Row2L4.Name = "Row2L4"
        Me.Row2L4.Size = New System.Drawing.Size(71, 45)
        Me.Row2L4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Row2L4.TabIndex = 33
        Me.Row2L4.TabStop = False
        '
        'Row3L4
        '
        Me.Row3L4.BackColor = System.Drawing.Color.White
        Me.Row3L4.Image = CType(resources.GetObject("Row3L4.Image"), System.Drawing.Image)
        Me.Row3L4.Location = New System.Drawing.Point(661, 173)
        Me.Row3L4.Name = "Row3L4"
        Me.Row3L4.Size = New System.Drawing.Size(71, 71)
        Me.Row3L4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Row3L4.TabIndex = 32
        Me.Row3L4.TabStop = False
        '
        'Row3L3
        '
        Me.Row3L3.BackColor = System.Drawing.Color.White
        Me.Row3L3.Image = CType(resources.GetObject("Row3L3.Image"), System.Drawing.Image)
        Me.Row3L3.Location = New System.Drawing.Point(443, 173)
        Me.Row3L3.Name = "Row3L3"
        Me.Row3L3.Size = New System.Drawing.Size(71, 71)
        Me.Row3L3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Row3L3.TabIndex = 31
        Me.Row3L3.TabStop = False
        '
        'Row1L2
        '
        Me.Row1L2.BackColor = System.Drawing.Color.White
        Me.Row1L2.Image = CType(resources.GetObject("Row1L2.Image"), System.Drawing.Image)
        Me.Row1L2.Location = New System.Drawing.Point(293, 90)
        Me.Row1L2.Name = "Row1L2"
        Me.Row1L2.Size = New System.Drawing.Size(71, 45)
        Me.Row1L2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Row1L2.TabIndex = 30
        Me.Row1L2.TabStop = False
        '
        'Row2L2
        '
        Me.Row2L2.BackColor = System.Drawing.Color.White
        Me.Row2L2.Image = CType(resources.GetObject("Row2L2.Image"), System.Drawing.Image)
        Me.Row2L2.Location = New System.Drawing.Point(327, 132)
        Me.Row2L2.Name = "Row2L2"
        Me.Row2L2.Size = New System.Drawing.Size(71, 45)
        Me.Row2L2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Row2L2.TabIndex = 29
        Me.Row2L2.TabStop = False
        '
        'Row3L2
        '
        Me.Row3L2.BackColor = System.Drawing.Color.White
        Me.Row3L2.Image = CType(resources.GetObject("Row3L2.Image"), System.Drawing.Image)
        Me.Row3L2.Location = New System.Drawing.Point(293, 173)
        Me.Row3L2.Name = "Row3L2"
        Me.Row3L2.Size = New System.Drawing.Size(71, 71)
        Me.Row3L2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Row3L2.TabIndex = 28
        Me.Row3L2.TabStop = False
        '
        'Row3L1
        '
        Me.Row3L1.BackColor = System.Drawing.Color.White
        Me.Row3L1.Image = CType(resources.GetObject("Row3L1.Image"), System.Drawing.Image)
        Me.Row3L1.Location = New System.Drawing.Point(3, 173)
        Me.Row3L1.Name = "Row3L1"
        Me.Row3L1.Size = New System.Drawing.Size(71, 71)
        Me.Row3L1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Row3L1.TabIndex = 27
        Me.Row3L1.TabStop = False
        '
        'Row1L3
        '
        Me.Row1L3.BackColor = System.Drawing.Color.White
        Me.Row1L3.Image = CType(resources.GetObject("Row1L3.Image"), System.Drawing.Image)
        Me.Row1L3.Location = New System.Drawing.Point(481, 90)
        Me.Row1L3.Name = "Row1L3"
        Me.Row1L3.Size = New System.Drawing.Size(71, 45)
        Me.Row1L3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Row1L3.TabIndex = 26
        Me.Row1L3.TabStop = False
        '
        'Row2L3
        '
        Me.Row2L3.BackColor = System.Drawing.Color.White
        Me.Row2L3.Image = CType(resources.GetObject("Row2L3.Image"), System.Drawing.Image)
        Me.Row2L3.Location = New System.Drawing.Point(548, 132)
        Me.Row2L3.Name = "Row2L3"
        Me.Row2L3.Size = New System.Drawing.Size(71, 45)
        Me.Row2L3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Row2L3.TabIndex = 25
        Me.Row2L3.TabStop = False
        '
        'Row1L1
        '
        Me.Row1L1.BackColor = System.Drawing.Color.White
        Me.Row1L1.Image = CType(resources.GetObject("Row1L1.Image"), System.Drawing.Image)
        Me.Row1L1.Location = New System.Drawing.Point(3, 90)
        Me.Row1L1.Name = "Row1L1"
        Me.Row1L1.Size = New System.Drawing.Size(71, 45)
        Me.Row1L1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Row1L1.TabIndex = 24
        Me.Row1L1.TabStop = False
        '
        'Lane2C1
        '
        Me.Lane2C1.BackColor = System.Drawing.Color.White
        Me.Lane2C1.Image = Global.Frogger_Fall_2017_by_Adam_Meloy.My.Resources.Resources.car_right
        Me.Lane2C1.Location = New System.Drawing.Point(-8, 409)
        Me.Lane2C1.Name = "Lane2C1"
        Me.Lane2C1.Size = New System.Drawing.Size(60, 50)
        Me.Lane2C1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Lane2C1.TabIndex = 20
        Me.Lane2C1.TabStop = False
        '
        'Row2L1
        '
        Me.Row2L1.BackColor = System.Drawing.Color.White
        Me.Row2L1.Image = CType(resources.GetObject("Row2L1.Image"), System.Drawing.Image)
        Me.Row2L1.Location = New System.Drawing.Point(72, 132)
        Me.Row2L1.Name = "Row2L1"
        Me.Row2L1.Size = New System.Drawing.Size(71, 45)
        Me.Row2L1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Row2L1.TabIndex = 15
        Me.Row2L1.TabStop = False
        '
        'MrKrabs
        '
        Me.MrKrabs.BackColor = System.Drawing.Color.White
        Me.MrKrabs.Image = Global.Frogger_Fall_2017_by_Adam_Meloy.My.Resources.Resources.MR_KRABS
        Me.MrKrabs.Location = New System.Drawing.Point(357, 579)
        Me.MrKrabs.Name = "MrKrabs"
        Me.MrKrabs.Size = New System.Drawing.Size(41, 44)
        Me.MrKrabs.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.MrKrabs.TabIndex = 0
        Me.MrKrabs.TabStop = False
        '
        'AllPurpose
        '
        '
        'RODE
        '
        Me.RODE.BackColor = System.Drawing.Color.Transparent
        Me.RODE.Image = Global.Frogger_Fall_2017_by_Adam_Meloy.My.Resources.Resources.rod
        Me.RODE.Location = New System.Drawing.Point(-8, 387)
        Me.RODE.Name = "RODE"
        Me.RODE.Size = New System.Drawing.Size(769, 160)
        Me.RODE.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.RODE.TabIndex = 54
        Me.RODE.TabStop = False
        '
        'WATER
        '
        Me.WATER.BackColor = System.Drawing.Color.Transparent
        Me.WATER.Image = Global.Frogger_Fall_2017_by_Adam_Meloy.My.Resources.Resources.water
        Me.WATER.Location = New System.Drawing.Point(-8, 81)
        Me.WATER.Name = "WATER"
        Me.WATER.Size = New System.Drawing.Size(769, 160)
        Me.WATER.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.WATER.TabIndex = 55
        Me.WATER.TabStop = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.BackgroundImage = Global.Frogger_Fall_2017_by_Adam_Meloy.My.Resources.Resources.images
        Me.ClientSize = New System.Drawing.Size(760, 649)
        Me.Controls.Add(Me.MrKrabs)
        Me.Controls.Add(Me.PictureBox33)
        Me.Controls.Add(Me.PictureBox32)
        Me.Controls.Add(Me.PictureBox31)
        Me.Controls.Add(Me.PictureBox30)
        Me.Controls.Add(Me.PictureBox29)
        Me.Controls.Add(Me.PictureBox28)
        Me.Controls.Add(Me.PictureBox27)
        Me.Controls.Add(Me.PictureBox26)
        Me.Controls.Add(Me.PictureBox25)
        Me.Controls.Add(Me.PictureBox24)
        Me.Controls.Add(Me.PictureBox23)
        Me.Controls.Add(Me.PictureBox22)
        Me.Controls.Add(Me.Lane1C4)
        Me.Controls.Add(Me.Lane1C3)
        Me.Controls.Add(Me.Lane1C2)
        Me.Controls.Add(Me.Lane1C1)
        Me.Controls.Add(Me.Lane2C2)
        Me.Controls.Add(Me.Lane2C4)
        Me.Controls.Add(Me.Lane2C3)
        Me.Controls.Add(Me.Row1L4)
        Me.Controls.Add(Me.Row2L4)
        Me.Controls.Add(Me.Row3L4)
        Me.Controls.Add(Me.Row3L3)
        Me.Controls.Add(Me.Row1L2)
        Me.Controls.Add(Me.Row2L2)
        Me.Controls.Add(Me.Row3L2)
        Me.Controls.Add(Me.Row3L1)
        Me.Controls.Add(Me.Row1L3)
        Me.Controls.Add(Me.Row2L3)
        Me.Controls.Add(Me.Row1L1)
        Me.Controls.Add(Me.Lane2C1)
        Me.Controls.Add(Me.Row2L1)
        Me.Controls.Add(Me.Home)
        Me.Controls.Add(Me.RODE)
        Me.Controls.Add(Me.WATER)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.PictureBox33, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox32, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox31, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox30, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox29, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox28, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox27, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox26, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox25, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox24, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox23, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox22, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Lane1C4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Lane1C3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Lane1C2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Lane1C1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Lane2C2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Lane2C4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Lane2C3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Row1L4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Row2L4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Row3L4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Row3L3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Row1L2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Row2L2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Row3L2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Row3L1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Row1L3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Row2L3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Row1L1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Lane2C1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Row2L1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MrKrabs, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.RODE, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.WATER, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents CarLanes As Timer
    Friend WithEvents LogRows As Timer
    Friend WithEvents MrKrabs As PictureBox
    Friend WithEvents Home As Label
    Friend WithEvents Row2L1 As PictureBox
    Friend WithEvents Lane2C1 As PictureBox
    Friend WithEvents Row1L1 As PictureBox
    Friend WithEvents Row2L3 As PictureBox
    Friend WithEvents Row1L3 As PictureBox
    Friend WithEvents Row3L1 As PictureBox
    Friend WithEvents Row3L2 As PictureBox
    Friend WithEvents Row2L2 As PictureBox
    Friend WithEvents Row1L2 As PictureBox
    Friend WithEvents Row3L3 As PictureBox
    Friend WithEvents Row3L4 As PictureBox
    Friend WithEvents Row2L4 As PictureBox
    Friend WithEvents Row1L4 As PictureBox
    Friend WithEvents Lane2C3 As PictureBox
    Friend WithEvents Lane2C4 As PictureBox
    Friend WithEvents Lane2C2 As PictureBox
    Friend WithEvents Lane1C1 As PictureBox
    Friend WithEvents Lane1C2 As PictureBox
    Friend WithEvents Lane1C3 As PictureBox
    Friend WithEvents Lane1C4 As PictureBox
    Friend WithEvents PictureBox22 As PictureBox
    Friend WithEvents PictureBox23 As PictureBox
    Friend WithEvents PictureBox24 As PictureBox
    Friend WithEvents PictureBox25 As PictureBox
    Friend WithEvents PictureBox26 As PictureBox
    Friend WithEvents PictureBox27 As PictureBox
    Friend WithEvents PictureBox28 As PictureBox
    Friend WithEvents PictureBox29 As PictureBox
    Friend WithEvents PictureBox30 As PictureBox
    Friend WithEvents PictureBox31 As PictureBox
    Friend WithEvents PictureBox32 As PictureBox
    Friend WithEvents PictureBox33 As PictureBox
    Friend WithEvents AllPurpose As Timer
    Friend WithEvents RODE As PictureBox
    Friend WithEvents WATER As PictureBox
End Class
