﻿Public Class Form1
    Dim L1S, L2S, R1S, R2S, R3S As Point
    Dim L1C1, L1C2, L1C3, L1C4 As Point
    Dim L2C1, L2C2, L2C3, L2C4 As Point
    Dim R1L1, R1l2, R1L3, R1L4 As Point
    Dim R2L1, R2L2, R2L3, R2L4 As Point
    Dim R3L1, R3L2, R3L3, R3L4 As Point
    Dim FrogStart As Point
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        L1S = Lane1C4.Location
        L2S = Lane2C1.Location
        R1S = Row1L1.Location
        R2S = Row2L4.Location
        R3S = Row3L1.Location
        L1C1 = Lane1C1.Location
        L1C2 = Lane1C2.Location
        L1C3 = Lane1C3.Location
        L1C4 = Lane1C4.Location
        L2C1 = Lane2C1.Location
        L2C2 = Lane2C2.Location
        L2C3 = Lane2C3.Location
        L2C4 = Lane2C4.Location
        R1L1 = Row1L1.Location
        R1l2 = Row1L2.Location
        R1L3 = Row1L3.Location
        R1L4 = Row1L4.Location
        R2L1 = Row2L1.Location
        R2L2 = Row2L2.Location
        R2L3 = Row2L3.Location
        R2L4 = Row2L4.Location
        R3L1 = Row3L1.Location
        R3L2 = Row3L2.Location
        R3L3 = Row3L3.Location
        R3L4 = Row3L4.Location
        FrogStart = MrKrabs.Location
        MsgBox("Press The Enter To Start")
    End Sub
    Private Sub CarLane1_Tick(sender As Object, e As EventArgs) Handles CarLanes.Tick
        If Lane1C1.Right <= Me.Left Then
            Lane1C1.Left = L1S.X
        ElseIf Lane1C2.Right <= Me.Left Then
            Lane1C2.Left = L1S.X
        ElseIf Lane1C3.Right <= Me.Left Then
            Lane1C3.Left = L1S.X
        ElseIf Lane1C4.Right <= Me.Left Then
            Lane1C4.Left = L1S.X
        Else
            Lane1C1.Left -= 30
            Lane1C2.Left -= 30
            Lane1C3.Left -= 30
            Lane1C4.Left -= 30
        End If
        If Lane2C1.Left >= Me.Right Then
            Lane2C1.Left = L2S.X
        ElseIf Lane2C2.Left >= Me.Right Then
            Lane2C2.Left = L2S.X
        ElseIf Lane2C3.Left >= Me.Right Then
            Lane2C3.Left = L2S.X
        ElseIf Lane2C4.Left >= Me.Right Then
            Lane2C4.Left = L2S.X
        Else
            Lane2C1.Left += 17
            Lane2C2.Left += 17
            Lane2C3.Left += 17
            Lane2C4.Left += 17
        End If
    End Sub
    Private Sub LogRows_Tick(sender As Object, e As EventArgs) Handles LogRows.Tick
        If Row3L1.Left >= Me.Right Then
            Row3L1.Left = R3S.X
        ElseIf Row3L2.left >= Me.Right Then
            Row3L2.Left = R3S.X
        ElseIf Row3L3.left >= Me.Right Then
            Row3L3.Left = R3S.X
        ElseIf Row3L4.left >= Me.Right Then
            Row3L4.Left = R3S.X
        Else
            Row3L1.Left += 40
            Row3L2.Left += 40
            Row3L3.Left += 40
            Row3L4.Left += 40
        End If
        If Row2L1.Right <= Me.Left Then
            Row2L1.Left = R2S.X
        ElseIf Row2L2.Right <= Me.Left Then
            Row2L2.Left = R2S.X
        ElseIf Row2L3.Right <= Me.Left Then
            Row2L3.Left = R2S.X
        ElseIf Row2L4.Right <= Me.Left Then
            Row2L4.Left = R2S.X
        Else
            Row2L1.Left -= 45
            Row2L2.Left -= 45
            Row2L3.Left -= 45
            Row2L4.Left -= 45
        End If
        If Row1L1.Left >= Me.Right Then
            Row1L1.Left = R1S.X
        ElseIf Row1L2.left >= Me.Right Then
            Row1L2.Left = R1S.X
        ElseIf Row1L3.left >= Me.Right Then
            Row1L3.Left = R1S.X
        ElseIf Row1L4.left >= Me.Right Then
            Row1L4.Left = R1S.X
        Else
            Row1L1.Left += 50
            Row1L2.Left += 50
            Row1L3.Left += 50
            Row1L4.Left += 50
        End If
    End Sub
    Private Sub Form1_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.Enter Then
            AllPurpose.Enabled = True
            CarLanes.Enabled = True
            LogRows.Enabled = True
            MrKrabs.Location = FrogStart
        ElseIf e.KeyCode = Keys.Escape Then
            Call Doomsday()
        ElseIf e.KeyCode = Keys.W Then
            MrKrabs.Top -= 50
        ElseIf e.KeyCode = Keys.S Then
            MrKrabs.Top += 10
        ElseIf e.KeyCode = Keys.A Then
            MrKrabs.Left -= 10
        ElseIf e.KeyCode = Keys.D Then
            MrKrabs.Left += 10
        End If
    End Sub
    Private Sub WinOrLose_Tick(sender As Object, e As EventArgs) Handles AllPurpose.Tick
        If MrKrabs.Bounds.IntersectsWith(Row3L1.Bounds) Then
            MrKrabs.Location = Row3L1.Location
        ElseIf MrKrabs.Bounds.IntersectsWith(Row3L2.Bounds) Then
            MrKrabs.Location = Row3L2.Location
        ElseIf MrKrabs.Bounds.IntersectsWith(Row3L3.Bounds) Then
            MrKrabs.Location = Row3L3.Location
        ElseIf MrKrabs.Bounds.IntersectsWith(Row3L4.Bounds) Then
            MrKrabs.Location = Row3L4.Location
        ElseIf MrKrabs.Bounds.IntersectsWith(Row2L1.Bounds) Then
            MrKrabs.Location = Row2L1.Location
        ElseIf MrKrabs.Bounds.IntersectsWith(Row2L2.Bounds) Then
            MrKrabs.Location = Row2L2.Location
        ElseIf MrKrabs.Bounds.IntersectsWith(Row2L3.Bounds) Then
            MrKrabs.Location = Row2L3.Location
        ElseIf MrKrabs.Bounds.IntersectsWith(Row2L4.Bounds) Then
            MrKrabs.Location = Row2L4.Location
        ElseIf MrKrabs.Bounds.IntersectsWith(Row1L1.Bounds) Then
            MrKrabs.Location = Row1L1.Location
        ElseIf MrKrabs.Bounds.IntersectsWith(Row1L2.Bounds) Then
            MrKrabs.Location = Row1L2.Location
        ElseIf MrKrabs.Bounds.IntersectsWith(Row1L3.Bounds) Then
            MrKrabs.Location = Row1L3.Location
        ElseIf MrKrabs.Bounds.IntersectsWith(Row1L4.Bounds) Then
            MrKrabs.Location = Row1L4.Location
        ElseIf MrKrabs.Bounds.IntersectsWith(Lane1C1.Bounds) Or MrKrabs.Bounds.IntersectsWith(Lane1C2.Bounds) Or MrKrabs.Bounds.IntersectsWith(Lane1C3.Bounds) Or MrKrabs.Bounds.IntersectsWith(Lane1C4.Bounds) Or MrKrabs.Bounds.IntersectsWith(Lane2C1.Bounds) Or MrKrabs.Bounds.IntersectsWith(Lane2C2.Bounds) Or MrKrabs.Bounds.IntersectsWith(Lane2C3.Bounds) Or MrKrabs.Bounds.IntersectsWith(Lane2C4.Bounds) Or MrKrabs.Bounds.IntersectsWith(WATER.Bounds) Or MrKrabs.Left >= Me.Right Or MrKrabs.Right <= Me.Left Or MrKrabs.Top >= Me.Bottom Or MrKrabs.Bottom <= Me.Top Then
            Call Doomsday()
            MsgBox("Game Over")
        ElseIf MrKrabs.Bounds.IntersectsWith(Home.Bounds) Then
            Call Doomsday()
            MsgBox("MONEY MONEY MONEY!")
        End If
    End Sub
    Private Sub Doomsday()
        AllPurpose.Enabled = False
        CarLanes.Enabled = False
        LogRows.Enabled = False
        Lane1C1.Location = L1C1
        Lane1C2.Location = L1C2
        Lane1C3.Location = L1C3
        Lane1C4.Location = L1C4
        Lane2C1.Location = L2C1
        Lane2C2.Location = L2C2
        Lane2C3.Location = L2C3
        Lane2C4.Location = L2C4
        Row1L1.Location = R1L1
        Row1L2.Location = R1l2
        Row1L3.Location = R1L3
        Row1L4.Location = R1L4
        Row2L1.Location = R2L1
        Row2L2.Location = R2L2
        Row2L3.Location = R2L3
        Row2L4.Location = R2L4
        Row3L1.Location = R3L1
        Row3L2.Location = R3L2
        Row3L3.Location = R3L3
        Row3L4.Location = R3L4
        MrKrabs.Location = FrogStart
    End Sub
End Class