package numbase;
import javax.swing.*;
import java.awt.*; //abstract windows toolkit
import java.awt.event.*; //abstract windows toolkit watches for things
/** description here
 * @author Adam Meloy
 * @version 1, 1-21-2020
 */
public class NumBase extends JFrame
{
    //variables
    private JLabel inNumL, inBaseL, outBaseL, outNumL;
    private JTextField inNumTF, inBaseTF, outBaseTF, outNumTF;
    private JButton calculateB, exitB;
    private CalculateButtonHandler cbHandler;
    private EndButtonHandler ebHandler;
    //set size of jframe window
    private static final int WIDTH = 400;
    private static final int HEIGHT = 300;
    
    public NumBase()
    {
        //create four labels
        inNumL = new JLabel("Enter a positive integer : ", SwingConstants.RIGHT);
        inBaseL = new JLabel("Enter current base : ", SwingConstants.RIGHT);
        outBaseL = new JLabel("Enter new base : ", SwingConstants.RIGHT);
        outNumL = new JLabel("Number in new base : ", SwingConstants.RIGHT);
        
        //create four text fields
        inNumTF = new JTextField(10);
        inBaseTF = new JTextField(10);
        outBaseTF = new JTextField(10);
        outNumTF = new JTextField(10);
        
        //create calculate button
        calculateB = new JButton("Calculate"); //creates the button
        cbHandler = new CalculateButtonHandler(); //creates button handler
        calculateB.addActionListener(cbHandler); //adds action listener
        
        //create exit button
        exitB = new JButton("Exit"); //creates the button
        ebHandler = new EndButtonHandler(); //creates button handler
        exitB.addActionListener(ebHandler); //adds action listener
        
        //set the title of the JFrame Window
        setTitle("Bubba's Base Changer");
        
        //get the container, which holds everything
        Container pane = getContentPane();
        
        //set the layout, 5 rows, 2 columns
        pane.setLayout(new GridLayout(5,2));
        
        //place the components in the pane
        pane.add(inNumL);
        pane.add(inNumTF);
        pane.add(inBaseL);
        pane.add(inBaseTF);
        pane.add(outBaseL);
        pane.add(outBaseTF);
        pane.add(outNumL);
        pane.add(outNumTF);
        pane.add(calculateB);
        pane.add(exitB);
        
        //set the size of the window and display it
        setSize(WIDTH, HEIGHT);
        setVisible(true);
        
        //makes the red x in the corner of the frame work
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        
    }
    
    //tells the handler what to do when the action listener hears the action for the button
    private class CalculateButtonHandler implements ActionListener
    {
        //action event variable of e, class will perform the action in the code
        public void actionPerformed(ActionEvent e)
        {
            
            
            
            
            
             String inputStr, outputStr;
             int inNum, inBase, outNum, outBase, numInBaseTen;
            char chl;
            inputStr = inNumTF.getText();
            inNum = Integer.parseInt(inputStr);
            inBase = Integer.parseInt(inBaseTF.getText());
    
    
    
    
            while (numInBaseTen > 0)
            {
                outputStr = (numInBaseTen % outBase) + outputStr;
                numInBaseTen = numInBaseTen / outBase;
            }   
            outNumTF.setText(outputStr);
    
    
    
    
    
    
    
        }
    }
    //class for exit button handler which listens for the action listener
    private class EndButtonHandler implements ActionListener
    {
        //when the exit button is pressed, close the JFrame window
        public void actionPerformed(ActionEvent e)
        {
            System.exit(0);
        }
    }
    public static void main(String[] args)
    {
        numBase oaasdasd
    }
}