package math.time;
import java.util.*;
/** time for math
 * @author Adam Meloy, Henry Manning
 * @version 1, 1-15-20
 */
public class MathTime
{
    public static void main(String[] args)
    {
        //variables
        Scanner uInput = new Scanner(System.in);
        int a, b;
        int eq1 = -1, eq2 = -2;
        
        do
        {
            //user input
            System.out.printf("%nPlease input your values for 'a': ");
            a = uInput.nextInt();
            System.out.printf("%nPlease input your values for 'b': ");
            b = uInput.nextInt();
            
            //equations to compare
            eq1 = (a*a) - (b*b);
            eq2 = ((a-b)*(a+b));
            
            //comparing eq1 and eq2 to see whether they are equal or not
            if (eq1 == eq2)
            {
                System.out.println("Equal");
            }
            else
            {
                System.out.println("Inequal");
            }
        }
        while(eq1!=eq2);
        //a^2 - b^2 = (a-b)(a+b)
    }
}