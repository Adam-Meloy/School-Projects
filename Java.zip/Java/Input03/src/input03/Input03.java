package input03;
import java.util.Scanner;
class Input03 {
    public static void main(String[] args) {
    Scanner SC = new Scanner(System.in);
    int X = SC.nextInt();
    double Y = SC.nextDouble();
    String SZ = SC.next();
    int Z = Integer.parseInt(SZ);
    SC.close();
    System.out.println("The sum of the numbers is " + (X+Y+Z));
    }
}
