package parsing01;

public class Parsing01 {
    public static void main(String[] args) {
        String taxRate = "0.05", shirtPrice = "15", gibberish = "887ds7nds87dsfs";
        int shirt = Integer.parseInt(shirtPrice);
        double tax = Double.parseDouble(taxRate);
        System.out.println(shirt*tax); 
    }
    
}
