package com.example;
import javax.swing.*;
import java.util.*;
public class AddImport {
    public static void main(String args[]) {
    JLabel label = new javax.swing.JLabel("hello"); }
}