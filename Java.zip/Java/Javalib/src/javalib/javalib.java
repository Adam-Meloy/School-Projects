package javalib;
import javax.swing.JOptionPane;
public class javalib {
    public static void main(String[] args) {
        String A1 = JOptionPane.showInputDialog("Enter an Adjective.");
        String N1 = JOptionPane.showInputDialog("Enter a Month (Noun).");
        String N2 = JOptionPane.showInputDialog("Enter a Name (Noun).");
        String N3 = JOptionPane.showInputDialog("Enter a Name (Noun).");
        String N4 = JOptionPane.showInputDialog("Enter something you have to do at School (Noun).");
        String N5 = JOptionPane.showInputDialog("Enter something you have to do at School (Noun).");
        int Num1 = Integer.parseInt(JOptionPane.showInputDialog("Enter A Number."));
        double Num2 = Double.parseDouble(JOptionPane.showInputDialog("Enter A Number with a Decimal."));
        String N6 = JOptionPane.showInputDialog("Enter an Object (Noun).");
        String N7 = JOptionPane.showInputDialog("Enter an Animal (Noun).");               
        JOptionPane.showMessageDialog(null,
        "On one " + A1 + ", " + N1 + " day, two people were bored at their school." + "\n" +
        "Their names were " + N2 + " and " + N3 + ". They hated doing " + N4 + " in class." + "\n" +
        "Instead of doing " + N5 + ", they decided to goof off." + "\n" +
        "Eventually they had to do math, and it was just too simple!" + "\n" +
        "But they just didn't care." + "\n" +
        "The question was only "+ Num1 + " + " + Num2 + ", which was " + (Num1 + Num2) + ", but they tried their hardest not to do it." + "\n" +
        "Eventually the day was over, and walked back home. Their home was a " + N6 + ", full of "+ N7 +".",
        "Java Lib", 2);
    }
}