import java.util.Scanner;
public class MoviestarTest {
   public static void main(String[] args) {          
       Scanner SC = new Scanner(System.in);
        int userChoice;
        int userChoiceM;
        int userChoiceD;
        int userChoiceY;
               
        Moviestar Actor = new Moviestar();       
        System.out.println("What is the Actor's name?");    
        Actor.setName(SC.nextLine());       
        System.out.println("What is the Actor's age?");
        userChoice = SC.nextInt();
        System.out.println("What is the Actor's Birthday? MM/DD/YYYY");
        userChoiceM = SC.nextInt();
        userChoiceD = SC.nextInt();
        userChoiceY = SC.nextInt();
        Actor.setBirthday(userChoiceM + "/" + userChoiceD + "/" + userChoiceY);
        Actor.setAge(userChoice);
        Actor.printStarInfo();
        System.out.println(Actor.genType());
        System.out.println(Actor.ageFiveYears());
        System.out.println("How many years do you want to see the Actor age?");
        userChoice = SC.nextInt();
        System.out.println(Actor.calculateAge(userChoice));
        
        Moviestar Actor2 = new Moviestar();       
        System.out.println("What is the Actor's name?");    
        Actor2.setName(SC.nextLine());       
        System.out.println("What is the Actor's age?");
        userChoice = SC.nextInt();
        System.out.println("What is the Actor's Birthday? MM/DD/YYYY");
        userChoiceM = SC.nextInt();
        userChoiceD = SC.nextInt();
        userChoiceY = SC.nextInt();
        Actor2.setBirthday(userChoiceM + "/" + userChoiceD + "/" + userChoiceY);
        Actor2.setAge(userChoice);
        Actor2.printStarInfo();
        System.out.println(Actor2.genType());
        System.out.println(Actor2.ageFiveYears());
        System.out.println("How many years do you want to see the Actor age?");
        userChoice = SC.nextInt();
        System.out.println(Actor2.calculateAge(userChoice));
    }    
}