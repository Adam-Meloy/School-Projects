public class Moviestar {
    private String name;
    private int age;
    private String birthday= "06/01/1996";
    
public Moviestar() { }
public Moviestar(String N, int A, String B) {
N = name;
A = age;
B = birthday; }

public String getName() { return name; }
public void setName(String N) { name = N;}
public int getAge() { return age; }
public void setAge(int A) { age = A;}
public String getBirthday() { return birthday;}
public String setBirthday( String B) { return birthday = B; }

public String printStarInfo() { System.out.println(
    "Actor Name: " + name + "\n" + 
    "Age: " + age + "\n" + 
    "Birthday: " + birthday); return null; }

public String ageFiveYears() { return "Actor's Age in Five years is " + (age + 5); }
public String calculateAge(int Y) {return "Actor's Age in " + Y + " Years is " + (age + Y);}

public String genType() {
    String[ ] bdayParts = birthday.split("/");
    int birthYear = Integer.parseInt(bdayParts[2]);
    if      ( birthYear >= 1998) { return name + " is a Post Millenial." + "\n"; }
    else if ( birthYear >= 1981) { return name + " is a Millenial." + "\n"; }
    else if ( birthYear >= 1965) { return name + " is a Gen X." + "\n"; }
    else if ( birthYear >= 1946) { return name + " is a Baby Boomer." + "\n"; }
    else if ( birthYear >= 1925) { return name + " is a Silent Gen." + "\n"; }
    else    { return name + " is a GI." + "\n"; } } 
}