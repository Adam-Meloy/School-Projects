package pkg4typecalculator;
import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import static javax.swing.JFrame.EXIT_ON_CLOSE;
/** @author Adam Meloy
 * @version 1, 2-12-20
 * Calculator with Add, Sub, Mult, and Div. extra features too!
 */ 
public class Main extends JFrame
{
    //variables
    private final JLabel ResultL, Spacer1L, Spacer2L;
    private final JTextField NumOneTF, NumTwoTF;
    private final JButton AddButton, SubButton, MultButton, DivButton, ExpoButton, PIButton, DiscButton, BeepButton, ClearButton, ExitButton;
    Random RNG = new Random();
    //Pane button Handlers
    private final AddButtonHandler AddHandler;
    private final SubButtonHandler SubHandler;
    private final MultButtonHandler MultHandler;
    private final DivButtonHandler DivHandler;
    private final ExpoButtonHandler ExpoHandler;
    private final PIButtonHandler PIHandler;
    private final DiscoButtonHandler DiscHandler;
    private final BeepButtonHandler BeepHandler;
    private final ClearButtonHandler ClearHandler;
    private final ExitButtonHandler ExitHandler;
    double a = 0, b = 0, c = 0;
    //set size of jframe window
    private static final int WIDTH = 400, HEIGHT = 400;
    
    //creates window and objects inside of it
    public Main()
    {
        //create the label for calculation results
        ResultL = new JLabel("Result Here", SwingConstants.CENTER);
        ResultL.setFont(new Font("", Font.PLAIN, 13));
        
        Spacer1L = new JLabel("", SwingConstants.CENTER);
        Spacer1L.setFont(new Font("", Font.BOLD, 20));
        
        Spacer2L = new JLabel("=", SwingConstants.CENTER);
        Spacer2L.setFont(new Font("", Font.BOLD, 20));

        //create input fields for user
        NumOneTF = new JTextField(11);
        NumOneTF.setFont(new Font("", Font.PLAIN, 13));
        NumTwoTF = new JTextField(11);
        NumTwoTF.setFont(new Font("", Font.PLAIN, 13));
        NumOneTF.setText("Num 1 Here");
        NumTwoTF.setText("Num 2 Here");
        
        //create addition button
        AddButton = new JButton("+"); //creates the 
        AddButton.setFont(new Font("", Font.BOLD, 30));
        AddHandler = new AddButtonHandler(); //creates button handler
        AddButton.addActionListener(AddHandler); //adds action listener
        
        //create subtraction button
        SubButton = new JButton("-"); //creates the button
        SubButton.setFont(new Font("", Font.BOLD, 30));
        SubHandler = new SubButtonHandler(); //creates button handler
        SubButton.addActionListener(SubHandler); //adds action listener
        
        //create multiplication button
        MultButton = new JButton("*"); //creates the button
        MultButton.setFont(new Font("", Font.BOLD, 30));
        MultHandler = new MultButtonHandler(); //creates button handler
        MultButton.addActionListener(MultHandler); //adds action listener
        
        //create division button
        DivButton = new JButton("/"); //creates the button
        DivButton.setFont(new Font("", Font.BOLD, 30));
        DivHandler = new DivButtonHandler(); //creates button handler
        DivButton.addActionListener(DivHandler); //adds action listener
        
        //create exponent button
        ExpoButton = new JButton("^"); //creates the button
        ExpoButton.setFont(new Font("", Font.BOLD, 30));
        ExpoHandler = new ExpoButtonHandler(); //creates button handler
        ExpoButton.addActionListener(ExpoHandler); //adds action listener
        
        //create pi button
        PIButton = new JButton("π"); //creates the button
        PIButton.setFont(new Font("", Font.BOLD, 30));
        PIHandler = new PIButtonHandler(); //creates button handler
        PIButton.addActionListener(PIHandler); //adds action listener
        
        //create disco button
        DiscButton = new JButton("D"); //creates the button
        DiscButton.setFont(new Font("", Font.BOLD, 30));
        DiscHandler = new DiscoButtonHandler(); //creates button handler
        DiscButton.addActionListener(DiscHandler); //adds action listener
        
        //create beep button
        BeepButton = new JButton("B"); //creates the button
        BeepButton.setFont(new Font("", Font.BOLD, 30));
        BeepHandler = new BeepButtonHandler(); //creates button handler
        BeepButton.addActionListener(BeepHandler); //adds action listener
        
        //create clear button
        ClearButton = new JButton("C"); //creates the button
        ClearButton.setFont(new Font("", Font.BOLD, 30));
        ClearHandler = new ClearButtonHandler(); //creates button handler
        ClearButton.addActionListener(ClearHandler); //adds action listener
        
        //create exit button
        ExitButton = new JButton("Exit"); //creates the button
        ExitButton.setFont(new Font("", Font.BOLD, 20));
        ExitHandler = new ExitButtonHandler(); //creates button handler
        ExitButton.addActionListener(ExitHandler); //adds action listener
        
        //set the title of the JFrame Window
        setTitle("Simple Calculator");
        
        //get the container, which holds everything
        Container Pane = getContentPane();
        //set the layout
        Pane.setLayout(new GridLayout(3,5));
        //set the size of the window and display
        setSize(WIDTH, HEIGHT);
        setVisible(true);
        //makes the red x in the corner of the frame work
        setDefaultCloseOperation(EXIT_ON_CLOSE); 
        //place the components in the pane
        Pane.add(NumOneTF);
        Pane.add(Spacer1L);
        Pane.add(NumTwoTF);
        Pane.add(Spacer2L);
        Pane.add(ResultL);
        Pane.add(AddButton);
        Pane.add(SubButton);
        Pane.add(MultButton);
        Pane.add(DivButton);
        Pane.add(ClearButton);
        Pane.add(ExpoButton);
        Pane.add(PIButton);
        Pane.add(DiscButton);
        Pane.add(BeepButton);
        Pane.add(ExitButton);
    }
    
    //tells the handler what to do when the action listener hears the action for the button
    private class AddButtonHandler implements ActionListener
    {
        //action event variable of e, class will perform the action in the code
        public void actionPerformed(ActionEvent e)
        {
            //formula and set text for label
            a = Double.parseDouble(NumOneTF.getText());
            b = Double.parseDouble(NumTwoTF.getText());
            c = a + b;
            Spacer1L.setText("+");
            Spacer2L.setText("=");
            ResultL.setText("" + c);
        }
    }
    
    //tells the handler what to do when the action listener hears the action for the button
    private class SubButtonHandler implements ActionListener
    {
        //action event variable of e, class will perform the action in the code
        public void actionPerformed(ActionEvent e)
        {
            //formula and set text for label
            a = Double.parseDouble(NumOneTF.getText());
            b = Double.parseDouble(NumTwoTF.getText());
            c = a - b;
            Spacer1L.setText("-");
            Spacer2L.setText("=");
            ResultL.setText("" + c);
        }
    }
    
    //tells the handler what to do when the action listener hears the action for the button
    private class MultButtonHandler implements ActionListener
    {
        //action event variable of e, class will perform the action in the code
        public void actionPerformed(ActionEvent e)
        {
            //formula and set text for label
            a = Double.parseDouble(NumOneTF.getText());
            b = Double.parseDouble(NumTwoTF.getText());
            c = a * b;
            Spacer1L.setText("*");
            Spacer2L.setText("=");
            ResultL.setText("" + c);
        }
    }
    
    //tells the handler what to do when the action listener hears the action for the button
    private class DivButtonHandler implements ActionListener
    {
        //action event variable of e, class will perform the action in the code
        public void actionPerformed(ActionEvent e)
        {
            //formula and set text for label
            a = Double.parseDouble(NumOneTF.getText());
            b = Double.parseDouble(NumTwoTF.getText());
            c = a / b;
            Spacer1L.setText("/");
            Spacer2L.setText("=");
            ResultL.setText("" + c);
        }
    }
    
    //tells the handler what to do when the action listener hears the action for the button
    private class ExpoButtonHandler implements ActionListener
    {
        //action event variable of e, class will perform the action in the code
        public void actionPerformed(ActionEvent e)
        {
            //formula and set text for label
            a = Double.parseDouble(NumOneTF.getText());
            b = Double.parseDouble(NumTwoTF.getText());
            c = Math.pow(a , b);
            Spacer1L.setText("^");
            Spacer2L.setText("=");
            ResultL.setText("" + c);
        }
    }
    
    //tells the handler what to do when the action listener hears the action for the button
    private class PIButtonHandler implements ActionListener
    {
        //action event variable of e, class will perform the action in the code
        public void actionPerformed(ActionEvent e)
        {
            //allows for use of π in equations
            a = Double.parseDouble(NumOneTF.getText());
            b = Double.parseDouble(NumTwoTF.getText());
            c = a * Math.PI * b;
            Spacer1L.setText("* π *");
            Spacer2L.setText("=");
            ResultL.setText("" + c);
        }
    }
    
    //tells the handler what to do when the action listener hears the action for the button
    private class DiscoButtonHandler implements ActionListener
    {
        //action event variable of e, class will perform the action in the code
        public void actionPerformed(ActionEvent e)
        {
                float r = RNG.nextFloat();
                float g = RNG.nextFloat();
                float b = RNG.nextFloat();
                Color randomColor = new Color(r, g, b);
                NumOneTF.setBackground(randomColor);
                NumTwoTF.setBackground(randomColor);
                ResultL.setForeground(randomColor);
                Spacer1L.setForeground(randomColor);
                Spacer2L.setForeground(randomColor);
                AddButton.setBackground(randomColor);
                SubButton.setBackground(randomColor);
                MultButton.setBackground(randomColor);
                DivButton.setBackground(randomColor);
                ExpoButton.setBackground(randomColor);
                PIButton.setBackground(randomColor);
                DiscButton.setBackground(randomColor);
                BeepButton.setBackground(randomColor);
                ClearButton.setBackground(randomColor);
                ExitButton.setBackground(randomColor);
        }
    }
    
    //tells the handler what to do when the action listener hears the action for the button
    private class BeepButtonHandler implements ActionListener
    {
        //action event variable of e, class will perform the action in the code
        public void actionPerformed(ActionEvent e)
        {
            //formula and set text for label
            
            NumOneTF.setText("Beep");
            NumTwoTF.setText("Beep");
            Spacer1L.setText("");
            Spacer2L.setText("");
            ResultL.setText("Lettuce");
        }
    }
    
    //tells the handler what to do when the action listener hears the action for the button
    private class ClearButtonHandler implements ActionListener
    {
        //action event variable of e, class will perform the action in the code
        public void actionPerformed(ActionEvent e)
        {
            //clear variables, textfields, and labels.
            a = 0;
            b = 0;
            c = 0;
            NumOneTF.setText("Num 1 Here");
            NumTwoTF.setText("Num 2 Here");
            Spacer1L.setText("");
            Spacer2L.setText("=");
            ResultL.setText("Result Here");
        }
    }
    
    //class for exit button handler which listens for the action listener
    private class ExitButtonHandler implements ActionListener
    {
        //when the exit button is pressed, close the JFrame window
        public void actionPerformed(ActionEvent e)
        {
            System.exit(0);
        }
    }
    
    public static void main(String[] args)
    {
        Main Calc = new Main();
    }
}