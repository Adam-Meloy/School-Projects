;
package computerassistedinstructin;
import java.util.*;
/** @author Adam Meloy
 * @version 1, 1-23-2020
 * simulates a coin toss
 */
public class ComputerAssistedInstructin
{
    private static final Random randomNum = new Random(); //instantiate random
    public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in); //instantiate a new scanner
        
        
        
        
        
        
        System.out.println("Enter your answer (-1 to exit).");
    }
    
    //prints new question and storws answer
    public static void createQuestion()
    {
        //get two integers between 0 and 9
        int digit1 = randomNum.nextInt(10);
        int digit2 = randomNum.nextInt(10);
        
        answer = digit1 + digit2;
        System.out.printf("How much is %d * %d?\n", digit1, digit2);
    }
    //checks if the user guess is equal to the answer
    public static void checkResponse()
    {
        if (guess != answer)
        {
            System.out.println("No, please try again.");
        }
        else
        {
            System.out.println("Very Good!\n");
        }
    }
}