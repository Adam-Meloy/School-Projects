import greenfoot.*;

public class GridMaker extends World {
    Square[][] box = new Square[3][3];
    GreenfootImage B = getBackground(), S = new GreenfootImage(100,100);
    public GridMaker() {
        super(900, 900, 1);
        B.setColor(new Color(54,90,255));
        B.fill();
        setBackground(B);
        MakeGrid();
    }
    public void MakeGrid() {
        int length = 350, width = 350;
        for (int a = 0; a < 3; a++) {
            length = 350;
            for (int b = 0; b < 3; b++) {
                Square square = new Square();
                square.Light = true;
                box[a][b] = square;
                addObject(box[a][b],length,width);
                length += 101;
            }
            width += 101;
        }
    }
    public void act() {
        if (Greenfoot.mouseClicked(box[0][0])) { //Top Left
            box[0][0].Swap();
            box[0][1].Swap();
            box[1][0].Swap();
            box[1][1].Swap();
        }
        if (Greenfoot.mouseClicked(box[0][1])) { //Top Center
            box[0][0].Swap();
            box[0][1].Swap();
            box[0][2].Swap();
        }
        if (Greenfoot.mouseClicked(box[0][2])) { //Top Right
            box[0][2].Swap();
            box[0][1].Swap();
            box[1][2].Swap();
            box[1][1].Swap();
        }
        if (Greenfoot.mouseClicked(box[1][0])) { //Middle Left
            box[0][0].Swap();
            box[1][0].Swap();
            box[2][0].Swap();
        }
        if (Greenfoot.mouseClicked(box[1][1])) { //Middle Center
            box[1][1].Swap();
            box[0][1].Swap();
            box[1][2].Swap();
            box[1][0].Swap();
            box[2][1].Swap();
        }
        if (Greenfoot.mouseClicked(box[1][2])) { //Middle Right
            box[0][2].Swap();
            box[1][2].Swap();
            box[2][2].Swap();
        }
        if (Greenfoot.mouseClicked(box[2][0])) { //Bottom Left
            box[1][0].Swap();
            box[1][1].Swap();
            box[2][0].Swap();
            box[2][1].Swap();
        }
        if (Greenfoot.mouseClicked(box[2][1])) { //Bottom Center
            box[2][0].Swap();
            box[2][1].Swap();
            box[2][2].Swap();
        }
        if (Greenfoot.mouseClicked(box[2][2])) { //Bottom Right
            box[1][2].Swap();
            box[1][1].Swap();
            box[2][2].Swap();
            box[2][1].Swap();
        }
        if (box[0][0].Light == true && box[0][1].Light == true && box[0][2].Light == true
        && box[1][0].Light == true && box[1][1].Light == false && box[1][2].Light == true
        && box[2][0].Light == true && box[2][1].Light == true && box[2][2].Light == true) {
            Win Complete = new Win();
            Greenfoot.setWorld(Complete);
        }
    }
}