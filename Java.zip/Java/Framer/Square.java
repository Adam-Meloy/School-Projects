import greenfoot.*;
public class Square extends Actor {
    GreenfootImage S = new GreenfootImage(100,100);
    boolean Light;
    public void act() {
        if (Light == true) {
            S.setColor(Color.YELLOW);
            S.fill();
            setImage(S);
        }
        else {
            S.setColor(Color.BLACK);
            S.fill();
            setImage(S);
        }
    }
    public void Swap() {
        if (Light == true) { Light = false; }
        else { Light = true; }
    }
    public Square() {
        S.setColor(Color.YELLOW);
        S.fill();
        setImage(S);
    }
}