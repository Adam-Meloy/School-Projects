import greenfoot.*;
public class Win extends World {
    public Win() {
        super(900, 900, 1); 
    }
}