package coin;
import java.util.*;
/** @author Adam Meloy
 * @version 1, 1-23-2020
 * simulates a coin toss
 */
public class Coin
{
    private static final Random randomNum = new Random(); //instantiate random
    public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in); //instantiate a new scanner
        
        //variables
        int heads = 0, tails = 0, choice = 0;
        
        do
        {
            //display menu
            System.out.print("1. Toss Coin\n" + "2. Exit\n" + "Choice: ");
            choice = input.nextInt();
            if (choice == 1)
            {
                if (flip())
                {
                    heads++;
                }
            else
                {
                    tails++;
                }
            }
            System.out.printf("Heads: %d, Tails: %d\n", heads, tails);
        }
        while(choice != 2);
    }
    //simulates flipping
    public static boolean flip()
        {
            return randomNum.nextInt(2) == 1;
        }
}