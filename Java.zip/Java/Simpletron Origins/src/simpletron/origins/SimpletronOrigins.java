package simpletron.origins;
import java.util.*;
/** @author Adam Meloy
 * @version 1, 02-04-20
 * mhm yes
 */ 
public class SimpletronOrigins
{
    //list of SML instructions
    private static final int READ = 10, WRITE = 11,
                             LOAD = 20, STORE = 21,
                             ADD = 30, SUBTRACT = 31, MULTIPLY = 32, DIVIDE = 33,
                             BRANCH = 40, BRANCH_NEG = 41, BRANCH_ZERO = 42,
                             HALT = 43, PENDING = -99;

    private static Scanner input = new Scanner(System.in);

    private static int accumulator,
                       instructionCounter,
                       operand,
                       operationCode,
                       instructionRegister,
                       index = 0;

    private static int[] memory;
    public static void main(String[] args)
    {
        //initialize register
        initializeRegisters();

        //prompt the user to enter instructions
        printInstructions();
        
        //display operation codes
        opCodes();
        
        loadInstructions();

        //executes the program and prints the memory dump when finished
        execute();
        dump();
    }

    //set all registers to the correct start value
    public static void initializeRegisters()
    {
        memory = new int[100];
        accumulator = 0;
        instructionCounter = 0;
        instructionRegister = 0;
        operand = 0;
        operationCode = 0;
        
        for(int k = 0; k < memory.length; k++)
        {
            memory[k] = 0;
        }
    }
    
    //print out user instructions
    public static void printInstructions()
    {
        System.out.printf("%s\n%s\n%s\n%s\n%s\n",
                "*** Welcome to Simpletron! ***",
                "*** Simpletron requires that programs be entered ***",
                "*** one instruction at a time. Instructions consist ***",
                "*** of the 2-digit operation code, and a 2-digit ***",
                "*** location code (00-99). example: 1001, READ at location 01. ***");
    }
    
    //list of operation codes
    public static void opCodes()
    {
        System.out.println();
        System.out.printf("%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n",
            "--- Simpletron Operation Code list ---",
            "--- READ (10): Read word into a specific location in memory. ---",
            "--- WRITE (11): Write word from specific location into screen. ---",
            "--- LOAD (20): Load a word from specific location into accumulator. ---",
            "--- STORE (21): Store a word from accumulator into specific location. ---",
            "--- ADD (30): Add a word from specific location to the word in accumulator. Result left in accumulator. ---",
            "--- SUBTRACT (31): Subtract a word from specific location to the word in accumulator. Result left in accumulator. ---",
            "--- MULTIPLY (32): Multiply a word from specific location to the word in accumulator. Result left in accumulator. ---",
            "--- DIVIDE (33): Divide a word from specific location to the word in accumulator. Result left in accumulator. ---",
            "--- BRANCH (40): Branch to a specific location in memory. ---",
            "--- BRANCH_NEG (41): Branch to a specific location in memory if the accumulator is negative. ---",
            "--- BRANCH_ZERO (42): Branch to a specific location in memory if the accumulator is zero. ---",
            "--- HALT (43): Halt. The program has completed it's task. ---",
            "--- PENDING (-99): Signals Simpletron to begin executing program. ---");
    }
    
    //read in user input, test it, perform operations
    public static void loadInstructions()
    {
        System.out.printf("%02d ? ", index);
        int instruction = input.nextInt();
        
        while(instruction != -99999 && index < 100)
        {
            if(validate(instruction))
            {
                memory[index++] = instruction;
            }
            else
            {
                System.out.println("Input invalid");
            }
            if (instruction != PENDING)
            { }
            else
            {
                break;
            }
            
            System.out.printf("%02d ? ", index);

            instruction = input.nextInt();
        }

        System.out.println("*** Program loading completed ***");
    }

    //ensure value is within range
    //returns true if the value is within range, otherwise returns false
    public static boolean validate(int value)
    {
        return (-99999 <= value) && (value <= 99999);
    }

    //ensure that accumulator has not overflowed
    public static boolean testOverflow()
    {
        if(!validate(accumulator))
        {
            System.out.println("*** Fatal error. Accumulator overflow ***");
            return true;
        }
        return false;
    }

    //perform all simulator functions
    public static void execute()
    {
        System.out.println("*** Program execution begins ***");

        //continue executing until we reach the end of the program
        //it is possible that the program can terminate beforehand though
        while(instructionCounter < index)
        {
            //read the instruction into the registrators
            instructionRegister = memory[instructionCounter];
            operationCode = instructionRegister / 100;
            operand = instructionRegister % 100;

            //go to next instruction, this will only be overridden
            //by the branch commands
            instructionCounter++;

            switch(operationCode)
            {
                case READ:
                    //read as integer
                    System.out.print("Enter an integer: ");
                    memory[operand] = input.nextInt();
                break;

                case WRITE:
                    //outputs the contents of a memory address
                    System.out.printf("Contents of %02d is %d\n", operand,
                            memory[operand]);
                break;
                    
                case LOAD:
                    //load a memory address into the accumulator
                    accumulator = memory[operand];
                break;

                case STORE:
                    //store the contents of the accumulator to an address
                    memory[operand] = accumulator;
                break;

                case ADD:
                    //add the contents of an address to the accumulator
                    accumulator += memory[operand];
                    if(testOverflow())
                        return; 
                break;

                case SUBTRACT:
                    //subtracts the contents of an address from the accumulator
                    accumulator -= memory[operand];
                    if(testOverflow())
                        return;
                break;

                case MULTIPLY:
                    //multiplies the accumulators with the contents of an address 
                    accumulator *= memory[operand];
                    if(testOverflow())
                        return;
                break;
                    
                case DIVIDE:
                    //divides the accumulators by the contents of an address
                    if(memory[operand] == 0)
                    {
                        System.out.println("*** Fatal error. Attempt to divide by zero ***");
                        return;
                    }
                    accumulator /= memory[operand];
                break;

                case BRANCH:
                    //jumps to an address
                    instructionCounter = operand;
                break;

                case BRANCH_NEG:
                    //jumps to an address if the accumulator is negative
                    if(accumulator < 0)
                        instructionCounter = operand;
                break;

                case BRANCH_ZERO:
                    //jumps to an address if the accumulator is zero
                    if(accumulator == 0)
                        instructionCounter = operand;
                break;
                    
                case HALT:
                    //terminates execution
                    System.out.println("*** Program execution terminated ***");
                return;
                
                case PENDING:
                    //signals end of user typed program
                break;
                    
                default:
                    //all other cases are not valid opcodes
                    System.out.println("*** Fatal error. Invalid operation code ***");
                return;
            }
        }
    }

    //prints the values of the register
    public static void displayRegisters()
    {
        System.out.println("REGISTERS: ");
        System.out.printf("%-24s%+05d\n", "Accumulator: ", accumulator);
        System.out.printf("%-27s%02d\n", "InstructionCounter: ", instructionCounter);
        System.out.printf("%-24s%+05d\n", "InstructionRegister: ", instructionRegister);
        System.out.printf("%-27s%02d\n", "OperationCode: ", operationCode);
        System.out.printf("%-27s%02d\n", "Operand: ", operand);
    }

    //output memory info
    public static void dump()
    {
        displayRegisters();
        System.out.println("\nMEMORY:");
        
        System.out.println("   ");
        
        //print column headings
        for(int k = 0; k < 10; k++)
        {
            System.out.printf("%7d", k);
        }
        
        System.out.println();
        //print the memory dump
        for(int k = 0; k < 10; k++)
        {
            //print the row labels
            System.out.printf("%2d", k*10);
            for(int w = 0; w < 10; w++)
            {
                //print the columns
                System.out.printf(" %+05d", memory[w * 10 + w]);
            }
        System.out.println();
        }
    }
}