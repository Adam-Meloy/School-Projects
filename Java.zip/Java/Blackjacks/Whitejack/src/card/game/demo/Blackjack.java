package card.game.demo;
import javax.swing.*;
/* Adam Meloy
   Version 1.0 */ 
public class Blackjack {
    public static void main(String[] args) {
        Deck playingDeck = new Deck();
        Hand playerHand = new Hand();
        Hand dealerHand = new Hand();
        playingDeck.shuffle();
        playerHand.addCard(playingDeck.drawCard());
        dealerHand.addCard(playingDeck.drawCard());
        dealerHand.addCard(playingDeck.drawCard());
        do {
        int results = -1;
        playerHand.sort();
        System.out.println(playerHand.stringTo());
        int selection = Integer.parseInt(JOptionPane.showInputDialog(null, "Enter a number to do an action.\n1: Draw\n2: Stand\n3: Exit", "blackjack", 0));
        switch (selection) {
            case 1: playerHand.addCard(playingDeck.drawCard()); break;
            case 2: results = playerHand.compareTo(dealerHand); break;
            case 3: System.exit(0); break;
        }
            switch (results) {
                case 0:
                    System.out.println("The dealer wins"); System.exit(0);
                    break;
                case 1:
                    System.out.println("The player wins."); System.exit(0);
                    break;
                case 2:
                    System.out.println("Tie."); System.exit(0);
                    break;
                case 3:
                    System.out.println("The player has over 21 points. Automatic loss."); System.exit(0);
                    break;
                case 4:
                    System.out.println("The dealer has over 21 points. Automatic win."); System.exit(0);
                    break;
            }
        }
        while (0 == 0);
    }
}