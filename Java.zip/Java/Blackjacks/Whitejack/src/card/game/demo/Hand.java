package card.game.demo;
import java.util.*;
/* Adam Meloy
   Version 1.0 */
public class Hand {
    private ArrayList<Card> hand;
    public Hand() {
        hand = new ArrayList<>();
    }
    public void addCard(Card playingCard) {
        hand.add(playingCard);
    }
    public int compareTo(Hand otherHand) {
        int hand1 = 0, hand2 = 0;
        Hand dealerHand = new Hand();
        for (int a = 0; a < hand.size(); a++) {
            switch (hand.get(a).getValue()) {
                case 11:
                case 12:
                case 13:
                    hand1 += 10;
                    break;
                default:
                    hand1 += hand.get(a).getValue();
                    break;
            }
        }
        for (int i = 0; i < otherHand.getNumberOfCards(); i++) {
            dealerHand.addCard(otherHand.getCard(i));
        }
        for (int b = 0; b < dealerHand.getNumberOfCards(); b++) {
            switch (dealerHand.getCard(b).getValue()) {
                case 11:
                case 12:
                case 13:
                    hand2 += 10;
                    break;
                default:
                    hand2 += dealerHand.getCard(b).getValue();
                    break;
            }
            }
        if (hand1 > 21) {
            return 3;
        }
        else if (hand2 > 21) {
            return 4;
        }
        if (hand1 == hand2) {
            return 1;
        } else if (hand1 > hand2) {
            return 2;
        } else {
            return 0;
        }
    }
    public boolean containsCard(Card playingCard) {
        if (hand.contains(playingCard)) {
            return true;
        } else {
            return false;
        }
    }
    public void discardHand() {
        hand.clear();
    }
    public int findCard(Card playingCard) {
        if (hand.contains(playingCard) == true) {
            return hand.indexOf(playingCard);
        } else {
            return -1;
        }
    }
    public Card getCard(int index) {
        return hand.get(hand.indexOf(index));
    }
    public int getNumberOfCards() {
        return hand.size();
    }
    public boolean isEmpty() {
        if (hand.size() >= 1) {
            return false;
        } else {
            return true;
        }
    }
    public Card removeCard(Card playingCard) {
        hand.remove(playingCard);
        return playingCard;
    }
    public Card removeCard(int index) {
        Card dummyCard = hand.get(index);
        hand.remove(index);
        return dummyCard;
    }
    public boolean replaceCard(Card oldCard, Card replacementCard) {
        if (hand.contains(oldCard) == false) {
            return false;
        } else {
            hand.set(hand.indexOf(oldCard), replacementCard);
            return true;
        }
    }

    public void sort() {
        ArrayList<Card> club = new ArrayList<>(),
                heart = new ArrayList<>(),
                spade = new ArrayList<>(),
                diamond = new ArrayList<>();
        for (int i = 0; i < hand.size(); i++) {
            switch (hand.get(i).getSuit()) {
                case "clubs":
                    club.add(hand.get(i));
                    break;
                case "hearts":
                    heart.add(hand.get(i));
                    break;
                case "spades":
                    spade.add(hand.get(i));
                    break;
                case "diamonds":
                    diamond.add(hand.get(i));
                    break;
            }
        }
        hand.clear();
            for (int a = 0; a <= club.size()-1; a++) {
                if (!club.isEmpty()) {
                for (int b = 0; b <= 13; b++) {
                    if (a > club.size()-1) { break; }
                        if (club.get(a).getValue() == b) {
                            hand.add(club.get(a));
                            club.remove(club.get(a));
                    } 
                    }
                }
                else { break; }
            }
            for (int a = 0; a <= heart.size()-1; a++) {
                if (!heart.isEmpty()) {
                for (int b = 0; b <= 13; b++) {
                    if (a > heart.size()-1) { break; }
                        if (heart.get(a).getValue() == b) {
                            hand.add(heart.get(a));
                            heart.remove(heart.get(a));
                        }
                    }
                }
                else { break; }
            }
            for (int a = 0; a <= spade.size()-1; a++) {
                if (!spade.isEmpty()) {
                for (int b = 0; b <= 13; b++) {
                    if (a > spade.size()-1) { break; }
                        if (spade.get(a).getValue() == b) {
                            hand.add(spade.get(a));
                            spade.remove(spade.get(a));
                        }
                    }
                }
                else { break; }
        }
            for (int a = 0; a <= diamond.size()-1; a++) {
                if (!diamond.isEmpty()) {
                for (int b = 0; b <= 13; b++) {
                    if (a > diamond.size()-1) { break; }
                        if (diamond.get(a).getValue() == b) {
                            hand.add(diamond.get(a));
                            diamond.remove(diamond.get(a));
                        }
                    }
                }
                else { break; }
            }
        }
    
    public String stringTo() {
        String print = "[ ";
        for (int i = 0; i < hand.size(); i++) {
            switch (hand.get(i).getValue()) {
                case 1:
                    print = print.concat(" ace of " + hand.get(i).getSuit() + ",");
                    break;
                case 11:
                    print = print.concat(" jack of " + hand.get(i).getSuit() + ",");
                    break;
                case 12:
                    print = print.concat(" queen of " + hand.get(i).getSuit() + ",");
                    break;
                case 13:
                    print = print.concat(" king of " + hand.get(i).getSuit() + ",");
                    break;
                default:
                    print = print.concat(" " + hand.get(i).getValue() + " of " + hand.get(i).getSuit() + ",");
                    break;
            }
        }
        print = print.concat(" ]");
        int value = 0;
        
        for (int i = 0; i < hand.size(); i++) {
            switch (hand.get(i).getValue()) {
                case 11:
                case 12:
                case 13:
                    value += 10;
                    break;
                default:
                    value += hand.get(i).getValue();
                    break;
            }
            }
        print = print.concat(" The value of the hand is " + value);
        return print;
        }
    }