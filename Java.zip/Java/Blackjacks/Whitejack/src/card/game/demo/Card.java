package card.game.demo;
/* Adam Meloy
   Version 1.0 */ 
public class Card {
    private int value;
    private String suit;
    private boolean flipped=false;
    public Card () {
    }
    public Card (int newValue, String newSuit, boolean isFlipped) {
        value = newValue; suit = newSuit; flipped = isFlipped;
        if (value == 0) { value = 13; }
    }
    public String getSuit() {
        return suit;
    }
    public int getValue() {
        return value;
    }
    public boolean isFlipped() {
        if(flipped == true) { return true; }
        else{ return false; }
        }
    public void setFlipped (boolean isflipped) {
        if(flipped == true) { flipped = false; }
        else { flipped = true; }
    }
    public String toString() {
        if (flipped == true) { return "Card is hidden."; }
        else { 
            switch (value) {
                 case 1: return "ace of " + suit;
                 case 11: return "jack of " + suit;
                 case 12: return "queen of " + suit;
                 case 13: return "king of " + suit;
                 default: return value + " of " + suit;
             } 
        }
    }
}