package card.game.demo;
import java.util.*;
/* Adam Meloy
   Version 1.0 */ 
public class Deck {
    // a deck is a list of 4 lists(a list of Clubs, a list of Diamonds, a list of Hearts, and a list of Spades)
    ArrayList<Card> deck;
    private String[] Suits = {"clubs", "hearts", "spades", "diamonds"};
    private String[] Values = {"ace", "two", "three", "four", "five", "six", 
                                "seven", "eight", "nine", "ten", "jack", 
                               "queen", "king"};
    Random R = new Random();
    public Deck() {
       deck = new ArrayList<>();
       fill();
    }
    public void addCard(Card playingCard) {
        deck.add(playingCard);
    }
    public Card drawCard() {
        Card drawCard = deck.get(deck.size()-1);
        deck.remove(deck.size()-1);
        return drawCard;
    }
    public void fill() {
        // COMPLETED: Fill the deck with a complete set of cards
        for (int i = 0; i< 4; i++) {
            for (int j = 0; j < 13; j++){
                Card newCard = new Card (j, Suits[i], false);
                deck.add(newCard);
            }
        }
        System.out.println("After fill... " + "size of deck is " + deck.size());
    }
    public Card showCard(int index) {
        // The purpose of this method is to determine what card is held at the given index in the deck
        return deck.get(index);
    }
    public void shuffle() {
        // The purpose of this method is to shuffle the cards in the deck
        for (int i = 0; i < (deck.size()); i++) {
        int randomCard = R.nextInt(deck.size());
        Card switchCard;
        switchCard = deck.get(i);
        deck.set(i, deck.get(randomCard));
        deck.set(randomCard, switchCard);
        }
    }
    public boolean isEmpty() {
        if (deck.size() >= 1) { return false; }
        else { return true; }
    }
    public int getNumOfCards() {
        return (deck.size() - 1);
    }
}