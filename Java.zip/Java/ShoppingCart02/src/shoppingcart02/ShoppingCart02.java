package shoppingcart02;
public class ShoppingCart02 {
    public static void main(String[] args) {
        final int Quantity = 3;
        final double Price = 12.55, Tax = 12.55 % .12, TotalPrice = (Price + Tax) * Quantity;
        System.out.println("Alex wants to buy " + Quantity + " shirts.");
        System.out.println("Total cost with tax is $" + TotalPrice);
    }
}
