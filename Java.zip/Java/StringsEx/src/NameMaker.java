import java.util.Scanner;
public class NameMaker {    
    public static void main(String args[]) {
    Scanner SC = new Scanner(System.in);
    String firstName, middleName, lastName, fullName;
    System.out.println("Please enter your first name.");
    firstName = SC.nextLine();
    System.out.println("Please enter your middle name.");
    middleName = SC.nextLine();
    System.out.println("Please enter your last name.");
    lastName = SC.nextLine();
    fullName = firstName + " " + middleName + " " + lastName + " ";
    System.out.println(fullName);
   }   
}