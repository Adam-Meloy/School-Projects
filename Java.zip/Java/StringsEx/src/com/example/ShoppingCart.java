package com.example;
public class ShoppingCart {
    public static void main (String[] args){
        String custName = "Steve Smith";
        String firstName;
        int spaceIdx = custName.indexOf(' ');
        firstName = custName.substring(0, spaceIdx);
        System.out.println(firstName);
    }
}