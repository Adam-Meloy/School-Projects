package movietheatre;
import java.util.*;
/** @author Adam Meloy
 * @version 1, 3-4-20
 * description here
 */ 
public class MovieTheatre
{
    public static void main(String[] args)
    {
        SnackBar employee1 = new SnackBar ("Seth", "Steinbrook", "123-45-6789");
        SnackBar employee2 = new SnackBar ("Billy", "Joe", "555-55-5555");
        SnackBar employee3 = new SnackBar ("Dominic", "Perez", "234-56-7890");
        Manager manager1 = new Manager("Collin", "Meyer", "012-34-5678");
        Manager manager2 = new Manager("Caleb", "Wooster", "000-00-0000");
        
        SnackBar[] employees = {employee1,employee2,employee3};
        Manager[] managers = {manager1, manager2};
         
        System.out.println("Employees");
        for (SnackBar employee : employees)
            System.out.println(employee.ToString());
        
        System.out.println("Managers");
        for (Manager manager : managers)
            System.out.println(manager.ToString());
     
        Scanner scanner = new Scanner(System.in);
        double GrossSales;
        
        boolean validInput = false;
        while(!validInput)
        {
            try
            {
                System.out.println("Please enter the gross sales for this week.");
                GrossSales = scanner.nextDouble();
                
                for (SnackBar employee : employees)
                    employee.SetSales(GrossSales);
                
                for (Manager manager : managers)
                    manager.SetSales(GrossSales);
                
                validInput = true;
            }
            catch (InputMismatchException e)
            {
                System.out.println("Please enter a numerical value.");
                scanner = new Scanner(System.in);
            }
            catch (IllegalArgumentException e)
            {
                System.out.println("Please enter a non-negative value.");
                scanner = new Scanner(System.in);
            }
        }
        
        System.out.println("\n\nEmployees after sales have been set\n");
        for (SnackBar employee : employees)
            System.out.println(employee.ToString());
        
        System.out.println("Managers after sales have been set\n");
        for (Manager manager : managers)
            System.out.println(manager.ToString());
    }
}