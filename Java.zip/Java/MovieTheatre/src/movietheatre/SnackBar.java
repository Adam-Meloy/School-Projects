package movietheatre;
/** @author Adam Meloy
 * @version 1, 3-4-20
 * description here
 */ 
public class SnackBar
{
    private double CommissionRate, Sales;
    private final String FName, LName, SSN;
    
    public SnackBar(String FName, String LName, String SSN) throws IllegalArgumentException
    {
        this.FName = FName;
        this.LName = LName;
        this.SSN = SSN;
        Sales = 0;
        CommissionRate = 0;
    }
    public void SetSales (double Sales) throws IllegalArgumentException
    {
        SetSales(Sales, 0.03, 0.05);
    }
    
    public void SetSales (double Sales, double LowRate, double HighRate) throws IllegalArgumentException
    {
        if (Sales < 0)
            throw new IllegalArgumentException("Sales must be a positive number.");
        if (LowRate > HighRate || LowRate < 0 || HighRate < 0 || HighRate > 1)
            throw new IllegalArgumentException("One or more invalid commission rates");
        if (Sales > 10000)
            CommissionRate = HighRate;
        else
            CommissionRate = LowRate;
        this.Sales = Sales;
    }
    
    
    public String GetFName()
    {
        return FName;
    }
    public String GetLName()
    {
        return LName;
    }
    public String GetSSN()
    {
        return SSN;
    }
    public double GetCommissionRate()
    {
        return CommissionRate;
    }
    public double GetSales()
    {
        return Sales;
    }
    public void SetFName()
    {
        
    }
    public double Earnings()
    {
        return GetSales() * GetCommissionRate();
    }
    public String ToString()
    {
        return String.format("Snack Bar Employee%n" + "First Name: %s%n" + "Last Name: %s%n" + "SSN: %s%n" +
                             "Weekly Sales: %.2f%n" + "Commission Rate: %.2f%%%n" + "Earnings: $%.2f%n",
                             GetFName(), GetLName(), GetSSN(), GetSales(), (GetCommissionRate()*100), Earnings());
    }
}