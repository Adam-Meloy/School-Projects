package movietheatre;
/** @author Adam Meloy
 * @version 1, insert date here
 * description here
 */ 
public class Manager extends SnackBar
{
    private final double Salary;
    
    public Manager (String FName, String LName, String SSN)
    {
        this(FName, LName, SSN, 1000); 
    }
    
    public Manager (String FName, String LName, String SSN, double Salary)
    {
        super(FName, LName, SSN);
        
        if (Salary < 0)
            throw new IllegalArgumentException("Salary cannot be negative.");
        
        this.Salary = Salary;
    }
    
    public double GetSalary()
    { return Salary; }
    
    @Override
    public void SetSales(double Sales)
    {
        SetSales(Sales, 0.0005, 0.0008);
    }
    
    @Override
    public double Earnings()
    {
        return GetSalary() + super.Earnings();
    }
    
    @Override
    public String ToString()
    {
        return String.format("Snack Bar Manager%n" + "First Name: %s%n" + "Last Name: %s%n" + "SSN: %s%n" +
                             "Weekly Sales: %.2f%n" + "Commission Rate: %.2f%%%n" + "Salary: $%.2f\n" + "Earnings: $%.2f%n",
                             GetFName(), GetLName(), GetSSN(), GetSales(), (GetCommissionRate()*100), GetSalary(), Earnings());
    }
}