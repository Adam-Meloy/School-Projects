package murphyville.theatre.payroll;
import java.util.*;

/** @author Adam Meloy
 * @version 1, 3-11-20
 * For use in managing Salary and Commission in employees of the Murphyville Theatre.
 */ 
public class MurphyvilleTheatrePayroll
{
    public static void main(String[] args)
    {
        Scanner SC = new Scanner(System.in);
        //employee variables
        Employee SB1 = new SnackBar("Miah","Reed","608-68-8120");
        Employee SB2 = new SnackBar("Harry","Warner","322-98-4038");
        Employee SB3 = new SnackBar("Louis","Rutledge","811-03-4205");
        Employee SB4 = new SnackBar("Shayne","Keith","668-64-2364");
        Employee T1 = new Tickets("Kameron","Mcfarland","969-18-9576",4.5);
        Employee M1 = new Management("Dillan","Reyes","842-43-9312",10);
        Employee M2 = new Management("Zachary","Estrada","970-96-7361",10);
        
        //employee array
        Employee[] Employees = {SB1, SB2, SB3, SB4, T1, M1, M2};
        Employee[] Commission = {SB1, SB2, SB3, SB4, M1, M2};
        Employee[] Wages = {T1};
        
        //display employee information
        for (Employee employee : Employees)
            { System.out.println(employee); }
        
        boolean validInput = false;
        while (!validInput)
        {
            //recieves sales, and will set sales if a valid double
            try
            {
                double Sales = 0;
                System.out.println("Please enter the weekly sales for the theatre: ");
                Sales = SC.nextDouble();
                
                for (Employee employee : Commission)
                {
                    SnackBar Com = (SnackBar) employee;
                    Com.SetSales(Sales);
                }
                validInput = true;
            }
            //if sales are not a valid double, will display error and empty scanner
            catch (InputMismatchException | IllegalArgumentException e)
            {
                System.out.println("Sales must be a numerical value greater than zero.");
                SC = new Scanner(System.in);
            }
            //recieves hours worked, and will set hours if a valid integer
            try
            {
                int Hours = 0;
                System.out.println("Please enter the hours worked: ");
                Hours = SC.nextInt();
                for (Employee employee : Wages)
                {
                    Tickets Wage = (Tickets) employee;
                    Wage.SetHours(Hours);
                }
                validInput = true;
            }
            //if hours is not a valid integer, will display error and empty scanner
            catch (InputMismatchException | IllegalArgumentException e)
            {
                System.out.println("Hours worked must be a numerical value greater than zero.");
                SC = new Scanner(System.in);
            }
        }
        //prints employee information, and adds on total earnings
        System.out.println("\n\nPrinting employees after setting data.\n");
        for (Employee employee : Employees)
        {
            System.out.println(employee);
            System.out.printf("Total Earnings: $%.2f%n", employee.earnings());
        }
        
        
        
        
        
    }
}