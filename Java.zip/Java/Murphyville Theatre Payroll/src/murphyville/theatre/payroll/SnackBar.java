package murphyville.theatre.payroll;
/** @author Adam Meloy
 * @version 1, insert date here
 * description here
 */ 
public class SnackBar /*Commission*/ extends Employee
{
    //variables
    private double Sales;
    private final double Rate;
    
    //default constructor
    public SnackBar (String FName, String LName, String SSN)
    {
        this(FName, LName, SSN, 0.08);
    }
    
    //constructor
    public SnackBar (String FName, String LName, String SSN, double Rate) throws IllegalArgumentException
    {
        super(FName, LName, SSN);   
        
        //if an invalid commission rate is used, returns error
        if (Rate <= 0 || Rate >= 1)
            throw new IllegalArgumentException("An invalid commission rate was provided");
        
        //sets rate
        this.Rate = Rate;
    }
    
    //returns sales
    public double GetSales()
    { return Sales; }
    
    //sets sales, returns error of sales less than 0
    public void SetSales(double Sales)
    {
        if(Sales < 0)
            throw new IllegalArgumentException("Sales cannot be negative.");
        else
            this.Sales = Sales;
    }
    
    //returns commission rate
    public double GetCommissionRate()
    { return Rate; }
    
    //returns calculated earnings
    @Override
    public double earnings()
    { return GetSales() * GetCommissionRate(); }
    
    //Prints out the sales and commission of the employee
    @Override
    public String toString()
    { return String.format("%sGross Sales: $%.02f%nCommission Rate: %.0f%%%n", super.toString(), GetSales(), GetCommissionRate() * 100); }
}