package murphyville.theatre.payroll;
/** @author Adam Meloy
 * @version 1, insert date here
 * description here
 */ 
public class Management /*Base + Commission*/ extends SnackBar /*Commission*/
{
    //variable
    private double Salary;
    final private int HOURS = 40;
    
    //constructor
    public Management(String FName, String LName, String SSN, double Salary)
    {
        //creates a "SnackBar" instance with same FName, LName, and SSN
        super(FName, LName, SSN, 0.05);
        
        //throws an exception if salary < 0
        if (Salary < 0)
            throw new IllegalArgumentException("Salary cannot be negative");
        
        //sets salary to given number
        this.Salary = Salary;
    }
    
    //returns salary
    public double GetSalary()
    { return Salary; }
    
    //sets salary to the given number, fails if less than 0
    public void SetSalary(double Salary) throws IllegalArgumentException
    {
        if (Salary < 0)
            throw new IllegalArgumentException("Salary cannot be negative");
        this.Salary = Salary;
    }
    
    //returns hours worked
    public int GetHours()
    { return HOURS; }
    
    //returns calculated earnings
    @Override
    public double earnings()
    { return (GetSalary()*GetHours())  + super.earnings(); }
    
    //Prints out the salary of the employee
    @Override
    public String toString()
    { return String.format("%sSalary: $%.2f%nHours Worked: %s%n", super.toString(), GetSalary(), GetHours()); }
}