package murphyville.theatre.payroll;
/** @author Adam Meloy
 * @version 1, insert date here
 * description here
 */ 
public abstract class Employee
{
    private final String FName, LName, SSN;
    
    public Employee(String FName, String LName, String SSN)
    {
        //sets variables to given input
        this.FName = FName;
        this.LName = LName;
        this.SSN = SSN;
    }
    
    //returns first name
    public String GetFName()
    { return FName; }
    
    //returns last name
    public String GetLName()
    { return LName; }
    
    //returns ssn
    public String GetSSN()
    { return SSN; }

    //used to return earnings of the employee
    public abstract double earnings();
    
    //displays employee information such as position, full name, and SSN
    @Override
    public String toString()
    {
        String[] SplitString = this.getClass().getName().split("\\.");
        String EmployeeType = SplitString[SplitString.length -1];
        
        return String.format("%n%s%n%s %s%nSSN: %s%n", EmployeeType, FName, LName, SSN);
    }
}