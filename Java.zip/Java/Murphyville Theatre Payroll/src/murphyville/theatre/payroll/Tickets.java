package murphyville.theatre.payroll;
/** @author Adam Meloy
 * @version 1, insert date here
 * description here
 */ 
public class Tickets /*Wages*/ extends Employee
{
    //variables
    private double Wages;
    private int Hours;
    
    //constructor
    public Tickets(String FName, String LName, String SSN, double Wages)
    {
        //creates an employee instance with same FName, LName, and SSN
        super(FName, LName, SSN);
        
        //throws an exception if salary < 0
        if (Wages < 0)
            throw new IllegalArgumentException("Salary cannot be negative");
        
        //sets salary to given number
        this.Wages = Wages;
    }
    
    //returns salary
    public double GetWages()
    { return Wages; }
    
    //sets salary to the given number, fails if less than 0
    public void SetWages(double Wages) throws IllegalArgumentException
    {
        if (Wages < 0)
            throw new IllegalArgumentException("Salary cannot be negative");
        this.Wages = Wages;
    }
    
    //returns hours worked
    public int GetHours()
    { return Hours; }
    
    //sets hours worked to the given number, fails if less than 0
    public void SetHours(int Hours) throws IllegalArgumentException
    {
        if (Hours < 0)
            throw new IllegalArgumentException("Hours worked cannot be negative");
        this.Hours = Hours; }
    
    //returns calculated earnings
    @Override
    public double earnings()
    { return GetWages()*GetHours(); }
    
    //Prints out the wages and hours worked of the employee
    @Override
    public String toString()
    { return String.format("%sHourly Wages: $%.2f%nHours Worked: %s%n", super.toString(), GetWages(), GetHours()); }
}