package chungo; 
import javax.swing.JOptionPane;
public class Chungo {
    static int yeet;
    static String skeet;
    public static void main(String[] args) {
       skeet = "yeet";
       yeet = 1337;
       
       JOptionPane.showMessageDialog(null, skeet, "" + yeet, JOptionPane.PLAIN_MESSAGE);
    }
}