package input01;
import javax.swing.JOptionPane;
public class Input01 {
    public static void main(String[] args) {
        String userInput = JOptionPane.showInputDialog("Type a number.");
        int number = Integer.parseInt(userInput);
        System.out.println((number + 1));       
        int number2 = Integer.parseInt(JOptionPane.showInputDialog("Type Another Number."));
        System.out.println(number2);    
    }
}
