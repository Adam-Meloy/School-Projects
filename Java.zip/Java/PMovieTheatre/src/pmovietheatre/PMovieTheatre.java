package pmovietheatre;
import java.util.*;
/** @author Adam Meloy
 * @version 1, insert date here
 * description here
 */ 
public class PMovieTheatre
{
    public static void main(String[] args)
    {
        Scanner SC = new Scanner(System.in);
        Employee employee1 = new Consession("Seth","Steinbrook","123-45-6789");
        Employee employee2 = new Consession("Billy Joe","","234-56-7890");
        Employee employee3 = new Consession("Dominic","Perez","345-67-8901");
        
        Employee employee4 = new Manager("Collin","Meyer","456-78-9012",1000);
        Employee employee5 = new Manager("Celeb","Worcester","567-89-0123",1000);
        
        Employee[] employees = {employee1, employee2, employee3, employee4, employee5};
        
        for (Employee employee : employees)
            { System.out.println(employee); }
        
        boolean validInput = false;
        while (!validInput)
        {
            try
            {
                double  Sales = 1;
                System.out.println("Please enter the weekly sales for the theatre: ");
                Sales = SC.nextDouble();
                
                for (Employee employee : employees)
                {
                    Consession ConPloyee = (Consession) employee;
                    ConPloyee.SetSales(Sales);
                }
                validInput = true;
            }
            catch (InputMismatchException | IllegalArgumentException e)
            {
                System.out.println("Sales must be a numerical value greater than zero.");
                SC = new Scanner(System.in);
            }
        }
        System.out.println("\n\nPrinting employees after setting sales data.\n");
        for (Employee employee : employees)
        {
            System.out.println(employee);
            System.out.printf("Total Earnings: $%.2f%n", employee.earnings());
        }
    }
}