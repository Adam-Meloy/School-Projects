package pmovietheatre;
/** @author Adam Meloy
 * @version 1, insert date here
 * description here
 */ 
public class Manager extends Consession
{
    private double Salary;
    

    public Manager(String FName, String LName, String SSN, double Salary)
    {
        super(FName, LName, SSN, 0.0005, 0.0008);
        
        if (Salary < 0)
            throw new IllegalArgumentException("Salary cannot be negative");
        
        this.Salary = Salary;
        
    }
    
    public double GetSalary()
            {return Salary;}
    public void SetSalary(double Salary) throws IllegalArgumentException
        {
            if (Salary < 0)
                throw new IllegalArgumentException("Salary cannot be negative");
            this.Salary = Salary;
        }
    @Override
    public double earnings()
        {
            return GetSalary() + super.earnings();
        }
    @Override
    public String toString()
        {
            return String.format("%sSalary: $%.2f%n", super.toString(), GetSalary());
        }
}