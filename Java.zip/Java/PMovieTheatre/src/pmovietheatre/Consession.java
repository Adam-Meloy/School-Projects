package pmovietheatre;
/** @author Adam Meloy
 * @version 1, insert date here
 * description here
 */ 
public class Consession extends Employee
{
    private double Sales;
    private final double LowRate, HighRate;
    
    public Consession (String FName, String LName, String SSN)
    {
        this(FName, LName, SSN, 0.03, 0.05);
    }
    public Consession (String FName, String LName, String SSN, double LowRate, double HighRate) throws IllegalArgumentException
    {
        super(FName, LName, SSN);   
        
        if (LowRate > HighRate || LowRate <= 0 || HighRate >= 1)
            throw new IllegalArgumentException("One or more invalid commission rates were provided");
        
        this.LowRate = LowRate;
        this.HighRate = HighRate;
    }
    public double GetSales()
            { return Sales; }
    public void SetSales(double Sales)
            {
                if(Sales < 0)
                    throw new IllegalArgumentException("Sales cannot be negative.");
                else
                    this.Sales = Sales;
            }
    public double GetCommissionRate()
            {
                if (Sales < 1000)
                    return LowRate;
                else
                    return HighRate;
            }
    @Override
    public double earnings()
            { return GetSales()*GetCommissionRate(); }
    @Override
    public String toString()
            { return String.format("%s \nGross Sales: $%.02f%nCommission Rate: %.2f%%%n", super.toString(), GetSales(), GetCommissionRate() * 100); }
}