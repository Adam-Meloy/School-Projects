package pmovietheatre;
/** @author Adam Meloy
 * @version 1, insert date here
 * description here
 */ 
public abstract class Employee
{
    private final String FName, LName, SSN;
    
    public Employee(String FName, String LName, String SSN)
    {
        this.FName = FName;
        this.LName = LName;
        this.SSN = SSN;
    }
    
    public String GetFName()
    { return FName; }
    public String GetLName()
    { return LName; }
    public String GetSSN()
    { return SSN; }

    
    public abstract double earnings();
    
    @Override
    public String toString()
    {
        String[] SplitString = this.getClass().getName().split("\\.");
        String EmployeeType = SplitString[SplitString.length -1];
        
        return String.format("\n%s %s\nSSN: %s", EmployeeType, FName, LName, SSN);
    }
}