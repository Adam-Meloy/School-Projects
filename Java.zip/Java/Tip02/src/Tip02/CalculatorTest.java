
package Tip02;

public class CalculatorTest {
    public static void main(String[] args) { 
        Calculator calc = new Calculator();
        calc.findTotal(10);
        calc.findTotal(12);
        calc.findTotal(9);
        calc.findTotal(8);
        calc.findTotal(7);
        calc.findTotal(15);
        calc.findTotal(11);
        calc.findTotal(30);
        
    }
}
