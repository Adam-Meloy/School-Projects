
package Tip02;

public class Calculator {
    public double tax = .05;
    public double tip = .15;
    public double originalPrice;
    
    public void findTotal(int P){
        originalPrice = P;
        System.out.println("Total: $" + originalPrice * (1 + tax + tip));
    }
}
