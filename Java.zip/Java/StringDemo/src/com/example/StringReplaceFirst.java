package com.example;
public class StringReplaceFirst {
    public static void main(String args[]) {
        String replace = "String replace with replaceFirst";
        String newString = replace.replaceFirst("re", "RE");
        System.out.println(newString);
    }
}