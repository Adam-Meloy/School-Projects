package com.example;
public class StringConcatenate1 {
    public static void main(String args[]) {
        String myString = "Hello";
        myString = myString + "!";
        System.out.println(myString);
    }
}