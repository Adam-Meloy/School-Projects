package com.example;
public class StringReplace {
    public static void main(String args[]) {
        String replace = "Using String replace to replace character";
        String newString = replace.replace("r", "R");
        System.out.println(newString);       
    }
}