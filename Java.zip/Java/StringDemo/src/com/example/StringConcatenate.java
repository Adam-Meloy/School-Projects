package com.example;
public class StringConcatenate {
    public static void main(String args[]){  
        String s1="Susan";  
        String s2="Roberts";
        String s=s1+s2;
        System.out.println(s);
    }  
}