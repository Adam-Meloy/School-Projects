
package tip04;

public class CalculatorTest {
    public static void main(String[] args) {
        Calculator calc = new Calculator();
        calc.findTotal(10, "bill");
        calc.findTotal(12, "nye");
        calc.findTotal(9,  "science guy");
        calc.findTotal(8,  "jimbob");
        calc.findTotal(7,  "grant");
        calc.findTotal(15, "Alex");
        calc.findTotal(11, "brad");
        calc.findTotal(30, "Forgetful");
        calc.showTotal();
    } 
}