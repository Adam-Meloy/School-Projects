
package tip04;

public class Calculator {
    public double tax = .05;
    public double tip = .15;
    double finalTotal;
    public void findTotal(double price, String name){
        double total = price*(1+tax+tip);
        finalTotal = finalTotal + total;
        System.out.println(name +": $" +total);

    }
    public void showTotal() {
        System.out.println("The total is: $" + finalTotal);
    }
}
