
package tip01;

public class Tip01 {
    public static void main(String[] args) {
        double tax = .05, tip = .15;
        double person = 10;
        double total = person * (1 + tax + tip);
        System.out.println("person1: $" + total);
        
        person = 12;
        total = person * (1 + tax + tip);
        System.out.println("person2: $" + total );
        
        person = 9;
        total = person * (1 + tax + tip);
        System.out.println("person3: $" + total );
        
        person = 8;
        total = person * (1 + tax + tip);
        System.out.println("person4: $" + total );
        
        person = 7;
        total = person * (1 + tax + tip);
        System.out.println("person5: $" + total );
        
        person = 15;
        total = person * (1 + tax + tip);
        System.out.println("person6: $" + total );
        
        person = 11;
        total = person * (1 + tax + tip);
        System.out.println("person7: $" + total );
        
        person = 30;
        total = person * (1 + tax + tip);
        System.out.println("person2: $" + total );     
    }    
}
