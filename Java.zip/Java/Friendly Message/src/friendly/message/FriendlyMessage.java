package friendly.message;
import javax.swing.*;
public class FriendlyMessage {
    public static void main(String[] args) {
        do {
        JOptionPane.showMessageDialog(null, "Go sugma nerd", "OOF", JOptionPane.ERROR_MESSAGE);
        }
        while(true);
    }
}