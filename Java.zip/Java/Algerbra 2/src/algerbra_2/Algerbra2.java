package algerbra_2;
import javax.swing.*;
import java.awt.*; //abstract windows toolkit
import java.awt.event.*; //abstract windows toolkit watches for things
import static javax.swing.JFrame.EXIT_ON_CLOSE;
/** does the equation (s = (u*t) + ½(at^2)
 * @author Adam Meloy
 * @version 1, 1-21-2020
 */
public class Algerbra2 extends JFrame
{
    //variables
    private JLabel firstL, secondL, thirdL, fourthL, verifyL;
    private JTextField firstTF, secondTF, thirdTF, fourthTF, verifyTF;
    private JButton calculateB, exitB;
    private CalculateButtonHandler cbHandler;
    private EndButtonHandler ebHandler;
    //set size of jframe window
    private static final int WIDTH = 400;
    private static final int HEIGHT = 300;
    
    //creates window and objects inside of it
    public Algerbra2()
    {
        //create four labels and what they will have in them for user
        firstL = new JLabel("Enter integer (a) : ", SwingConstants.RIGHT);
        secondL = new JLabel("Enter integer (t) : ", SwingConstants.RIGHT);
        thirdL = new JLabel("Enter integer (u) : ", SwingConstants.RIGHT);
        fourthL = new JLabel("Enter integer (s) : ", SwingConstants.RIGHT);

        
        verifyL = new JLabel("Is this true? s = (u*t) + ½(a*t^2) : ", SwingConstants.RIGHT);
        
        //create four text fields
        firstTF = new JTextField(10);
        secondTF = new JTextField(10);
        thirdTF = new JTextField(10);
        fourthTF = new JTextField(10);
        verifyTF = new JTextField(10);
        
        //create calculate button
        calculateB = new JButton("Calculate"); //creates the button
        cbHandler = new CalculateButtonHandler(); //creates button handler
        calculateB.addActionListener(cbHandler); //adds action listener
        
        //create exit button
        exitB = new JButton("Exit"); //creates the button
        ebHandler = new EndButtonHandler(); //creates button handler
        exitB.addActionListener(ebHandler); //adds action listener
        
        //set the title of the JFrame Window
        setTitle("Bubba's Weird Algerbra");
        
        //get the container, which holds everything
        Container pane = getContentPane();
        
        //set the layout, 5 rows, 2 columns
        pane.setLayout(new GridLayout(6,3));
        
        //place the components in the pane
        pane.add(firstL);
        pane.add(firstTF);
        pane.add(secondL);
        pane.add(secondTF);
        pane.add(thirdL);
        pane.add(thirdTF);
        pane.add(fourthL);
        pane.add(fourthTF);
        pane.add(verifyL);
        pane.add(verifyTF);
        pane.add(calculateB);
        pane.add(exitB);
        
        //set the size of the window and display it
        setSize(WIDTH, HEIGHT);
        setVisible(true);
        
        //makes the red x in the corner of the frame work
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }
    //tells the handler what to do when the action listener hears the action for the button
    private class CalculateButtonHandler implements ActionListener
    {
        //action event variable of e, class will perform the action in the code
        public void actionPerformed(ActionEvent e)
        {
            //local variables
            int a = 0, t = 0, u = 0, s = 0;
            //get the numbers from the text field and store it in the variable
            a = Integer.parseInt(firstTF.getText());
            t = Integer.parseInt(secondTF.getText());
            u = Integer.parseInt(thirdTF.getText());
            s = Integer.parseInt(fourthTF.getText());
           
            //formula and set verify text field text
            if ( ((u*t) + ((0.5)*(a*(t*t)))) == s)
                verifyTF.setText("Yes");
            else
                verifyTF.setText("No");
        }
    }
    //class for exit button handler which listens for the action listener
    private class EndButtonHandler implements ActionListener
    {
        //when the exit button is pressed, close the JFrame window
        public void actionPerformed(ActionEvent e)
        {
            System.exit(0);
        }
    }
    //declare variable to run the program
    public static void main(String[] args)
    {
        Algerbra2 weirdAlgerbra = new Algerbra2();
    }
}