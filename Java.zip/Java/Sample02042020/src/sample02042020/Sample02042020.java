package sample02042020;
import java.util.*;
/** @author Adam Meloy
 * @version 1, 02-04-20
 * mhm yes
 */ 
public class Sample02042020
{
    private static final int READ = 10, WRITE = 11, 
                             LOAD = 20, STORE = 21, 
                             ADD = 30, SUBTRACT = 31, MULTIPLY = 32, DIVIDE = 33, 
                             BRANCH = 40, BRANCH_NEG = 41, BRANCH_ZERO = 42, HALT = 43, PENDING = -99;
    private static Scanner input = new Scanner(System.in);
    
    private static int accumulator,//accumulator register
                       instructionCounter, //instruction counter, a memory address
                       operand,//arguement for the operator
                       operationCode,//determines the operation
                       instructionRegister,//register holding the SML instructions
                       index;//number of instructions entered in memory
    private static int[] memory;//simpletron memory
    
    public static void main(String[] args)
    {
        //initialize registers
        initializeRegisters();
        
        //prompt user to insert instructions
        printInstructions();
        
        //display operation codes
        opCodes();
        
        loadInstructions();
        
        //execute the program, and print the memory dump when finished
        execute();
        dump();
    }
    
    //set all registers to the correct start value
    public static void initializeRegisters()
    {
        memory = new int[100];
        accumulator = 0;
        instructionCounter = 0;
        instructionRegister = 0;
        operand = 0;
        operationCode = 0;
        
        for (int k = 0; k < memory.length; k++)
        {
            memory[k] = 0;
        }
    }
    
    //prints instructions
    public static void printInstructions()
    {
        System.out.printf("%s\n%s\n%s\n%s\n%s\n",
                "*** Welcome to Simpletron! ***",
                "*** Simpletron requires that programs be entered ***",
                "*** one instruction at a time. Instructions consist ***",
                "*** of the 2-digit operation code, and a 2-digit ***",
                "*** location code (00-99). example: 1001, READ at location 01. ***");
    }
    
    //list of operation codes
    public static void opCodes()
    {
        System.out.println();
        System.out.printf("%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n",
                "--- Simpletron Operation Code list ---",
                "--- READ (10): Read word into a specific location in memory. ---",
                "--- WRITE (11): Write word from specific location into screen. ---",
                "--- LOAD (20): Load a word from specific location into accumulator. ---",
                "--- STORE (21): Store a word from accumulator into specific location. ---",
                "--- ADD (30): Add a word from specific location to the word in accumulator. Result left in accumulator. ---",
                "--- SUBTRACT (31): Subtract a word from specific location to the word in accumulator. Result left in accumulator. ---",
                "--- MULTIPLY (32): Multiply a word from specific location to the word in accumulator. Result left in accumulator. ---",
                "--- DIVIDE (33): Divide a word from specific location to the word in accumulator. Result left in accumulator. ---",
                "--- BRANCH (40): Branch to a specific location in memory. ---",
                "--- BRANCH_NEG (41): Branch to a specific location in memory if the accumulator is negative. ---",
                "--- BRANCH_ZERO (42): Branch to a specific location in memory if the accumulator is zero. ---",
                "--- HALT (43): Halt. The program has completed it's task. ---",
                "--- PENDING (-99): Signals Simpletron to begin executing program. ---");
    }
    
    //read in user input, test it, perform operations
    public static void loadInstructions()
    {
        System.out.printf("%02d ? ", index);
        int instruction = input.nextInt();
        
        while (instruction != -99999 && index < 100)
        {
            if (validate(instruction))
            {
                memory[index++] = instruction;
            }
            else
            {
                System.out.println("Input invalid");
            }
            if (instruction != PENDING)
            { }
            else
            {
                break;
            }
            System.out.printf("%02d ? ", index);
            instruction = input.nextInt();
        }
        
        System.out.println("*** Program loading completed ***");
    }
    
    //ensure value is within range
    //returns true if the value is within range, otherwise returns false
    public static boolean validate(int value)
    {
        return (-9999 <= value) && (value <= 9999);
    }
    
    //enure that accumulator has not overflowed
    public static boolean testOverflow()
    {
        if (!validate(accumulator))
        {
            System.out.println("*** Fatal error. Accumulator overflow. ***");
            return true;
        }
        return false;
    }
    
    //perform all simulator functions
    public static void execute()
    {
        System.out.println("*** Program execution begins ***");
        
        //continue executing until we reach the end of the program
        //is is possible that the program can terminate beforehand though
        while (instructionCounter < index)
        {
            instructionCounter++;
            //read the instruction into tbe registers
            instructionRegister = memory[instructionCounter];
            operationCode = instructionRegister / 100;
            operand = instructionRegister % 100;
            
            //go to the next intruction, this will only be overrides
            // by the branch commands
            
            switch (operationCode)
            {
                case READ:
                    //read and integer
                    System.out.print("Enter an integer: ");
                    memory[operand] = input.nextInt();
                break;
                    
                case WRITE:
                    //outputs the contents of a memory address
                    System.out.printf("Contents of %02d is %d\n", operand, memory[operand]);
                break;
                    
                case LOAD:
                    //load a memory address into the accumulator
                    accumulator = memory[operand];
                break;
                    
                case STORE:
                    //stores the contents of the accumulator to an address
                    memory[operand] = accumulator;
                break;
                    
                case ADD:
                    //adds the contents of an address to the accumulator
                    accumulator += memory[operand];
                    if (testOverflow())
                    { return; }
                break;
                    
                case SUBTRACT:
                    //subtracts the contents of an address to the accumulator
                    accumulator -= memory[operand];
                    if (testOverflow())
                    { return; }
                break;
                    
                case MULTIPLY:
                    //multiplies the contents of an address to the accumulator
                    accumulator *= memory[operand];
                    if (testOverflow())
                    { return; }
                break;
                    
                case DIVIDE:
                    //divides the contents of an address to the accumulator
                    accumulator /= memory[operand];
                    if (testOverflow())
                    { return; }
                break;
                    
                case BRANCH:
                    //jumps to an address
                    instructionCounter = operand;
                break;
                    
                case BRANCH_NEG:
                    //jumps to an address if the accumulator is negative
                    if (accumulator < 0)
                    { instructionCounter = operand; }
                break;
                    
                case BRANCH_ZERO:
                    //jumps to an address if the accumulator is zero
                    if (accumulator == 0)
                    { instructionCounter = operand; }
                break;
                    
                case HALT:
                    //terminates execution
                    System.out.println("*** Simpletron execution terminated ***");
                break;
                
                case PENDING:
                    //signals end of user typed program
                break;
                
                default:
                    //all other cases are not valid opcodes
                return;
            }
        } 
    }
    
    //prints the values of the registers
    public static void displayRegisters()
    {
        System.out.println("REGISTERS:");
        System.out.printf("%-24s%+05dn\n", "Accumulator: ", accumulator);
        System.out.printf("%-27s%02dn\n", "InstructionCounter: ", instructionCounter);
        System.out.printf("%-24s%+05dn\n", "InstructionRegister: ", instructionRegister);
        System.out.printf("%-27s%02dn\n", "OperationCode: ", operationCode);
        System.out.printf("%-27s%02dn\n", "Operand: ", operand);
    }
    
    //output memory information
    public static void dump()
    {
        displayRegisters();
        
        System.out.println("\nMEMORY: ");
        
        //print column headings
        System.out.print("  ");
        
        for (int k = 0; k < 10; k++)
        {
            System.out.printf("%7d", k);
        }
        
        //print the contents of each memory location
        for (int a = 0; a < 10; a++)
        {
            System.out.printf(" %+05d", memory[a * 10 + a]);
        }
        System.out.println();
    }
}