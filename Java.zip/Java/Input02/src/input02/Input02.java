package input02;
import javax.swing.JOptionPane;
public class Input02 {
    public static void main(String[] args) {        
        JOptionPane.showMessageDialog(null,
                "ACCEPT JESUS CHRIST AS YOUR LORD AND SAVIOR",
                "Read the Bible please",
                2);
        String input1 = (String)JOptionPane.showInputDialog(null,
                "Do you think this program is good?",
                "This title is nice",
                3,
                null,
                null,
                "Type something here.");  
        String[] acceptableValues = {"YES", "NO", "AlSO NO"};
        String input2 = (String)JOptionPane.showInputDialog(null,
                "Are you a person?",
                "Don't read me please",
                1,
                null,
                acceptableValues,
                acceptableValues[1]);
    }
}