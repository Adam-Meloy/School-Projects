
package casting01;

public class Casting01 {
    public static void main(String[] args) {
        byte bit = 127;
        short tall = (byte)128;
        System.out.println(tall);
        System.out.println((bit + 1));
        System.out.println(((bit + 1) + 1));      
    }    
}
