package u8tictactoe;
import java.awt.*;
import javax.swing.*;
/** @author Adam Meloy
 * @version 1, 2-26-20/2-27-20
 * Improved version of the tictactoe game completed in class
 */ 
public class TicTacTwo extends JFrame
{
    //variables
    Object[] GridRow = {"0 (Top)", "1 (Middle)", "2 (Bottom)"};
    Object[] GridColumn = {"0 (Left)", "1 (Center)", "2 (Right)"};
    final static int BOARD_SIZE = 3;
    enum Status {WIN, DRAW, CONTINUE};
    private char[][] board;
    private boolean firstPlayer, gameOver;
    
    //JFrame for game grid
    JFrame Grid = new JFrame();
    //Height/Width of game grid
    final int HEIGHT_WIDTH = 400;
    //labels for the game grid
    JLabel T1, T2, T3, M1, M2, M3, B1, B2, B3;
    //JPanel for row/column input
    JPanel Panel = new JPanel();
    
    //constructor
    public TicTacTwo()
    {
        board = new char[BOARD_SIZE][BOARD_SIZE];
        firstPlayer = true;
        gameOver = false;
    }
    
    //main method, creates grid and uses the other methods to manage the game
    public void play()
    {  
        //configures the labels for use in the grid
        //set T1
        T1 = new JLabel(" ", SwingConstants.CENTER);
        T1.setFont(new Font("", Font.BOLD, 60));
        T1.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        //set T2
        T2 = new JLabel(" ", SwingConstants.CENTER);
        T2.setFont(new Font("", Font.BOLD, 60));
        T2.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        //set T3
        T3 = new JLabel(" ", SwingConstants.CENTER);
        T3.setFont(new Font("", Font.BOLD, 60));
        T3.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        //set M1
        M1 = new JLabel(" ", SwingConstants.CENTER);
        M1.setFont(new Font("", Font.BOLD, 60));
        M1.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        //set M2
        M2 = new JLabel(" ", SwingConstants.CENTER);
        M2.setFont(new Font("", Font.BOLD, 60));
        M2.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        //set M3
        M3 = new JLabel(" ", SwingConstants.CENTER);
        M3.setFont(new Font("", Font.BOLD, 60));
        M3.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        //set B1
        B1 = new JLabel(" ", SwingConstants.CENTER);
        B1.setFont(new Font("", Font.BOLD, 60));
        B1.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        //set B2
        B2 = new JLabel(" ", SwingConstants.CENTER);
        B2.setFont(new Font("", Font.BOLD, 60));
        B2.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        //set B3
        B3 = new JLabel(" ", SwingConstants.CENTER);
        B3.setFont(new Font("", Font.BOLD, 60));
        B3.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        //set the title of the JFrame Window
        setTitle("TicTacToe+ Board");
        //get the container, which holds everything
        Container Pane = getContentPane();
        //set the layout
        Pane.setLayout(new GridLayout(3,3));
        //set the size of the window and display
        setSize(HEIGHT_WIDTH, HEIGHT_WIDTH);
        setVisible(true);
        //makes the red x in the corner of the frame work
        setDefaultCloseOperation(EXIT_ON_CLOSE); 
        //place the components in the pane
        Pane.add(T1);
        Pane.add(T2);
        Pane.add(T3);
        Pane.add(M1);
        Pane.add(M2);
        Pane.add(M3);
        Pane.add(B1);
        Pane.add(B2);
        Pane.add(B3);
        
        int row, column;
        
        JOptionPane.showMessageDialog(null, "Player X's Turn", "TicTacToe+", 1, null);
        
        while (!gameOver)
        {
            char player = (firstPlayer ? 'X':'O');
            
            //asks player to select row and column and records it
            do
            {                
                row = JOptionPane.showOptionDialog(Panel, String.format("Player %c, please select row number", player), "Row Select",
                JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE,
                null, GridRow, null);
                
                column = JOptionPane.showOptionDialog(Panel, String.format("Player %c, please select column number", player), "Column Select",
                JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE,
                null, GridColumn, null);
            }
            while (!validMove(row,column));
            
            //selects the space on the board and sets the right symbol
            board[row][column] = player;
            printSymbol(row, column, player);
            //prints next turns, wins, and ties.
            printStatus(player);
        }
    }
    
    //Prints the status returned from gameStatus to the user
    public void printStatus(char player)
    {
        Status status = gameStatus();
        
        //checks which status was returned
        switch(status)
        {
            case WIN:
                JOptionPane.showMessageDialog(null, String.format("Player %c Wins!", player), "TicTacToe+", 1, null);
                gameOver = true;
                break;
            case DRAW:
                JOptionPane.showMessageDialog(null, "The Game is a Tie.", "TicTacToe+", 1, null);
                gameOver = true;
                break;
            case CONTINUE:
                if (player == 'X')
                {
                    JOptionPane.showMessageDialog(null, "Player O's Turn", "TicTacToe+", 1, null);
                    firstPlayer = false;
                }
                else
                {
                    JOptionPane.showMessageDialog(null, "Player X's Turn", "TicTacToe+", 1, null);
                    firstPlayer = true;
                }
                break;
        }
    }
    
    //checks parameters and returns Status to be used in printStatus
    private Status gameStatus()
    {
        //START OF WIN CHECK
        if (board[0][0] !=0 && board[0][0] == board[1][1] && board[1][1] == board[2][2])
            return Status.WIN;
        
        if (board[2][0] !=0 && board[2][0] == board[1][1] && board[1][1] == board[0][2])
            return Status.WIN;
            
        for (int row = 0; row < BOARD_SIZE; row++)
        {
            if (board[row][0] !=0 && board[row][0] == board[row][1] && board[row][1] == board[row][2])
            return Status.WIN;
        }
        for (int column = 0; column < BOARD_SIZE; column++)
        {
            if (board[0][column] !=0 && board[0][column] == board[1][column] && board[1][column] == board[2][column])
            return Status.WIN;
        }
        //END OF WIN CHECK; START OF CONTINUE CHECK
        for (char[] row : board)
        {
            for (char e : row)
            {
                if (e == 0)
                { return Status.CONTINUE; }
            }
        }
        //END OF CONTINUE CHECK
        return Status.DRAW;
    }
    
    //nested switch statement to insert the symbol into the correct JLabel
    private void printSymbol(int row, int column, char player)
    {
        //checks if player is X or O
        if (player > 0)
        { 
            //checks which row was selected
            switch(row)
            {
                case 0:
                    //checks selected column
                    switch(column)
                    {
                        case 0:
                            T1.setText(String.format("%c", player));
                            break;
                        case 1:
                            T2.setText(String.format("%c", player));
                            break;
                        case 2:
                            T3.setText(String.format("%c", player));
                            break;
                    }
                    break;
                case 1:
                    //checks selected column
                    switch(column)
                    {
                        case 0:
                            M1.setText(String.format("%c", player));
                            break;
                        case 1:
                            M2.setText(String.format("%c", player));
                            break;
                        case 2:
                            M3.setText(String.format("%c", player));
                            break;
                    }
                    break;
                case 2:
                    //checks selected column
                    switch(column)
                    {
                        case 0:
                            B1.setText(String.format("%c", player));
                            break;
                        case 1:
                            B2.setText(String.format("%c", player));
                            break;
                        case 2:
                            B3.setText(String.format("%c", player));
                            break;
                    }
                    break;
            }
        }
    }
    
    //checks to see if the square has already been filled
    private boolean validMove(int row, int column)
    {
        return board[row][column] == 0;
    }
}