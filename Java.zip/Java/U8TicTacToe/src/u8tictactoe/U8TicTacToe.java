package u8tictactoe;
/** @author Adam Meloy
 * @version 1, 2-26-20/2-27-20
 * Improved version of the tictactoe game completed in class
 */ 
public class U8TicTacToe
{
    public static void main(String[] args)
    {
        TicTacTwo game = new TicTacTwo();
        game.play();
    }
}