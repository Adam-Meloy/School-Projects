package chickens01;
public class Chickens01 {
    public static void main(String[] args) {
        int eggsPerChicken, chickenCount, totalEggs ;
        eggsPerChicken = 5;
        chickenCount = 3;
        totalEggs = (eggsPerChicken*chickenCount);
        System.out.println("On Monday, The farmer had " + chickenCount + " chickens, amd he has " + totalEggs + " eggs in total.");
        chickenCount ++;
        totalEggs = totalEggs + (eggsPerChicken*chickenCount);
        System.out.println("On Tuesday, The farmer had " + chickenCount + " chickens, and he has " + totalEggs + " eggs in total.");
        chickenCount = chickenCount / 2;
        totalEggs = totalEggs + (eggsPerChicken*chickenCount);
        System.out.println("On Wednesday, The farmer had " + chickenCount + " chickens, and he has " + totalEggs + " eggs in total." + "\n");
        
        eggsPerChicken = 4;
        chickenCount = 8;
        totalEggs = (eggsPerChicken*chickenCount);
        System.out.println("On Monday, The farmer had " + chickenCount + " chickens, and he has " + totalEggs + " eggs in total.");
        chickenCount ++;
        totalEggs = totalEggs + (eggsPerChicken*chickenCount);
        System.out.println("On Tuesday, The farmer had " + chickenCount + " chickens, and he has " + totalEggs + " eggs in total.");
        chickenCount = chickenCount / 2;
        totalEggs = totalEggs + (eggsPerChicken*chickenCount);
        System.out.println("On Wednesday, The farmer had " + chickenCount + " chickens, and he has " + totalEggs + " eggs in total." + "\n");
    }   
}