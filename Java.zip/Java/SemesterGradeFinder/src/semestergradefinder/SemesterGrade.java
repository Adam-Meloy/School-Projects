package semestergradefinder;
import javax.swing.JOptionPane;
public class SemesterGrade {
        double TermGrade;
        double FinalGrade;
        double SemesterFinalGrade;
        public SemesterGrade() {}
        public SemesterGrade(double T, double F) { TermGrade = T; FinalGrade = F; }
        public void SetTermGrade() {
            TermGrade = Double.parseDouble(JOptionPane.showInputDialog("Enter your Term Grade")); }
        public void SetFinalGrade() {
            FinalGrade = Double.parseDouble(JOptionPane.showInputDialog("Enter the Grade on your Final")); }
        public void Calculate() {
            SemesterFinalGrade = (TermGrade * .9) + (FinalGrade * .1); }
        public void Display() {
        JOptionPane.showMessageDialog(null,
        "The Grade for the First Semester is " + SemesterFinalGrade,
        "Final Grade Calculator", 1); }
}