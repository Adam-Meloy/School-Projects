package semestergradefinder;
public class SemesterGradeFinder {
    public static void main(String[] args) {
        SemesterGrade Grade = new SemesterGrade();
        Grade.SetTermGrade();
        Grade.SetFinalGrade();
        Grade.Calculate();
        Grade.Display();
    }
}