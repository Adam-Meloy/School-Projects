package papervariable;
public class StringTest {
    public static void main(String[] args) {
        StringData P1 = new StringData("a");
        String S1 = P1.ToString();
        System.out.println(S1 + "\n");

    }  
}