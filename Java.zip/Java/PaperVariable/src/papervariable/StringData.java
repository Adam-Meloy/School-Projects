package papervariable;
public class StringData extends Object {
    public StringData() {}
    public StringData(String A) {}
    public String ToString() { 
        return "Enter a long String: " + "NULL" + "\n" + 
        "Enter a Substring: " + "NULL" + "\n" + 
        "Length of your String: " + "NULL" + "\n" + 
        "Length of your Substring" + "NULL" + "\n" + 
        "Starting position of your Substring in the String: " + "\n" + 
        "String before your Substring: " + "NULL" + "\n" + 
        "String after you Substring: " + "NULL" + "\n" + 
        "Enter a position between 0 and 18: " + "NULL" + "\n" + 
        "The character at position " + "NULL" + " is: " + "NULL" + "\n" + 
        "Enter a replacement String: " + "NULL" + "\n" + 
        "Your new String is: " + "NULL"; }
}