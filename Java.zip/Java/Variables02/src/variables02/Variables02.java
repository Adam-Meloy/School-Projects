package variables02;
public class Variables02 {
    public static void main(String[] args) {
        String x = "puppy";
        System.out.println(x);
        System.out.println(x);
        x = "kitty";
        System.out.println(x);
        System.out.println(x);
        System.out.println(x);
        x = "bunny";
        System.out.println(x);
    }
}
