package input04;

import java.util.Scanner;

public class Input04 {
    public static void main(String[] args){
        Scanner sc = new Scanner(Input04.class.getResourceAsStream("input04text.txt"));      
        System.out.println(sc.nextLine());
        sc.next();
        System.out.println(sc.nextLine());
        sc.next();
        System.out.println(sc.nextLine());
        sc.next();       
        System.out.println(sc.findInLine("BlueBumper"));
        int xPosition = sc.nextInt();
        int yPosition = sc.nextInt();
        System.out.println("X: " + xPosition + ", Y: " + yPosition);
        sc.close();
    }    
}
