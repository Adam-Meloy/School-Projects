package product;
import java.util.*;
/** description here
 * @author Adam Meloy
 * @version 1, 1-10-2020
 */
public class Product
{
    public static void main(String[] args)
    {
        //create scanner to obtain input from command window
        Scanner input = new Scanner(System.in);
        
        System.out.print("Enter first integer: "); //input prompt
        int x = input.nextInt(); //read/store first int
        
        System.out.print("Enter second integer: "); //input prompt
        int y = input.nextInt(); //read/store second int
        
        System.out.print("Enter third integer: "); //input prompt
        int z = input.nextInt(); //read/store third int
        
        int result = x * y * z; //calculate product of numbers
        
        System.out.printf("Product is %d%n", result); //%d is decimal int, %n is new line
    }//end main
}//end class