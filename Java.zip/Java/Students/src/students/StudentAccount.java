package students;
// @author ameloy743
public class StudentAccount
{
    String FName, LName;
    int studentID;
    double lunchMoney;

    public StudentAccount(String LName, String FName, int studentID, double lunchMoney)
    {
        this.LName = LName;
        this.FName = FName;
        this.studentID = studentID;
        this.lunchMoney = lunchMoney;
    }
    public StudentAccount()
    {}
    
    //set lname equal to given name
    public void setLName(String LName)
    {
        this.LName = LName;
    }
    //set fname equal to given name
    public void setFName(String FName)
    {
        this.FName = FName;
    }
    //set id equal to given num
    public void setStudentID (int studentID)
    {
        this.studentID = studentID;
    }
    //set lunchmoney equal to given amount
    public void setLunchMoney (double lunchMoney)
    {
        this.lunchMoney = lunchMoney;
    }
    //get lname
    public String getLName()
    {
        return LName;
    }
    //get fname
    public String getFName()
    {
        return FName;
    }
    //get id
    public int getStudentID ()
    {
        return studentID;
    }
    //get lunchmoney
    public double getLunchMoney ()
    {
        return lunchMoney;
    }
    public void depositLunchMoney(double deposit)
    {
        this.lunchMoney += deposit;
    }
}
