package students;
import java.util.*;
/** @author Adam Meloy
 * @version 1, insert date here
 * description here
 */ 
public class Students
{
    public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in);
        System.out.println("This program will create and manage student lunch accounts");
        StudentAccount student1 = new StudentAccount();
        StudentAccount student2 = new StudentAccount();
        
        student1.setFName("James");
        student1.setLName("Davids");
        student1.setStudentID(001);
        student1.setLunchMoney(500.00);
        student1.depositLunchMoney(1000.99);
        
        student2.setFName("Jeremiah");
        student2.setLName("Bransworth");
        student2.setStudentID(002);
        student2.setLunchMoney(500.00);
        
        
        System.out.printf("Student ID: %s\nFirst: %s\nLast: %s\nBalance: %s\n",
                          student1.getStudentID(), student1.getFName(), student1.getLName(), student1.getLunchMoney());
        System.out.printf("\nStudent ID: %s\nFirst: %s\nLast: %s\nBalance: %s\n",
                          student2.getStudentID(), student2.getFName(), student2.getLName(), student2.getLunchMoney());
        
        
        
        
    } 
}