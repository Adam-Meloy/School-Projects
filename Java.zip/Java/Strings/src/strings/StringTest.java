package strings;
import java.util.Scanner;
public class StringTest {
    public static void main(String[] args) {
        Scanner SC = new Scanner(System.in);
        String LongString, ShortString, NewString;
        int A;
        
        System.out.println("Enter a long String.");
        LongString = SC.nextLine();
        System.out.println("The long String is: " + LongString);
        
        System.out.println("Enter a Substring. ");
        ShortString = SC.nextLine();
        System.out.println("The Substring is: " + ShortString);
        
        System.out.println("Length of your String: " + LongString.length());
        System.out.println("Length of your Substring: " + ShortString.length());
        
        System.out.println("Starting position of your Substring in the String: " + LongString.indexOf(ShortString.charAt(0)));
        NewString = LongString.substring(0,LongString.indexOf(ShortString.charAt(0)));
        System.out.println("String before your Substring: " + NewString );
        NewString = LongString.substring(LongString.indexOf(ShortString.charAt(0)) + ShortString.length(), LongString.length());
        System.out.println("String after your Substring: " + NewString);
        
        System.out.println("Enter a position between " + "1" + " and " + LongString.length());
        A = SC.nextInt() - 1;
        System.out.println("The character at position " + (A + 1) + " is: " + LongString.charAt(A));
        System.out.println("Enter a replacement String.");
        NewString = SC.nextLine();
        NewString = SC.nextLine();
        LongString = LongString.replace(ShortString, NewString);
        System.out.println("Your new String is: " + LongString);
    }   
}