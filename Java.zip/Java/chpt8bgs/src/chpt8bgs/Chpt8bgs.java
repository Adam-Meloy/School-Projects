package chpt8bgs;
/** @author Adam Meloy
 * @version 1, insert date here
 * description here
 */ 
public class Chpt8bgs
{
    public static void main(String[] args)
    {
        TicTacToe game = new TicTacToe();
        game.printBoard();
        game.play();
    }
}