package chpt8bgs;
import java.util.*;
/** @author Adam Meloy
 * @version 1, 2-24-20
 * description here
 */ 
public class TicTacToe
{
    final static int BOARD_SIZE = 3;
    enum Status {WIN, DRAW, CONTINUE};
    private char[][] board;
    private boolean firstPlayer, gameOver;
    
    public TicTacToe()
    {
        board = new char[BOARD_SIZE][BOARD_SIZE];
        firstPlayer = true;
        gameOver = false;
    }
    public void play()
    {
        Scanner input = new Scanner(System.in);
        int row, column;
        
        System.out.println("Player X's turn");
        
        while (!gameOver)
        {
            char player = (firstPlayer ? 'X':'O');
            
            do
            {
                System.out.printf("Player %c: Enter row (0, 1, 2):", player);
                row = input.nextInt();
                System.out.printf("Player %c: Enter column (0, 1, 2):", player);
                column = input.nextInt();
            }
            while (!validMove(row,column));
            
            board[row][column] = player;
            printBoard();
            printStatus(player);

        }
    }
    public void printStatus(char player)
    {
        Status status = gameStatus();
        
        switch(status)
        {
            case WIN:
                System.out.printf("Player %c Wins!", player);
                gameOver = true;
                break;
            case DRAW:
                System.out.println("The game is a tie.");
                gameOver = true;
                break;
            case CONTINUE:
                if (player == 'X')
                {
                    System.out.println("Player O's Turn");
                    firstPlayer = false;
                }
                else
                {
                    System.out.println("Player X's Turn");
                    firstPlayer = true;
                }
                break;
        }
        
        
        
        
        
        
    }
    private Status gameStatus()
    {
        //START OF WIN CHECK
        if (board[0][0] !=0 && board[0][0] == board[1][1] && board[1][1] == board[2][2])
            return Status.WIN;
        
        if (board[2][0] !=0 && board[2][0] == board[1][1] && board[1][1] == board[0][2])
            return Status.WIN;
            
        for (int row = 0; row < BOARD_SIZE; row++)
        {
            if (board[row][0] !=0 && board[row][0] == board[row][1] && board[row][1] == board[row][2])
            return Status.WIN;
        }
        for (int column = 0; column < BOARD_SIZE; column++)
        {
            if (board[0][column] !=0 && board[0][column] == board[1][column] && board[1][column] == board[2][column])
            return Status.WIN;
        }
        //END OF WIN CHECK; START OF CONTINUE CHECK
        for (char[] row : board)
        {
            for (char e : row)
            {
                if (e == 0)
                { return Status.CONTINUE; }
            }
        }
        //END OF CONTINUE CHECK
        return Status.DRAW;
    }
    public void printBoard()
    {
        System.out.println(" _____ _____ _____    ");
        for (int row = 0; row < BOARD_SIZE; row++)
        {
            System.out.println("|     |     |     |");
            for (int column = 0; column < BOARD_SIZE; column++)
            {
                printSymbol(column, board[row][column]);
            }
            System.out.println("|_____|_____|_____|");
        }
    }
    private void printSymbol(int column, char value)
    {
        if (value > 0)
        { System.out.printf("|  %c  ", value); }
        else
        { System.out.printf("|     "); }
        
        if (column == 2)
        { System.out.println("|"); }
    }
    private boolean validMove(int row, int column)
    {
        return row >= 0 && row < 3 &&
               column >= 0 && column < 3 &&
               board[row][column] == 0;
        
    }
}