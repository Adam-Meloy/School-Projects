package com.example;
public class FullyQualifiedName {
    public static void main(String args[]) {
        int num;
        java.util.Scanner keyboard = new java.util.Scanner(System.in);
        System.out.print("Enter a number");
        num = keyboard.nextInt();
        System.out.print("The number you entered is" + num);
    }
}