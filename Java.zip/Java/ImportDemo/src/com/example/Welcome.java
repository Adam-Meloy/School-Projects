package com.example;
import javax.swing.JOptionPane;
public class Welcome {
    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null, "Hello!");
    }
}