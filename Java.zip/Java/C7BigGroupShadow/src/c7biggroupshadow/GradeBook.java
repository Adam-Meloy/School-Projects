package c7biggroupshadow;
/** @author Adam Meloy
 * @version 1, 2-20-20
 * description here
 */ 
public class GradeBook
{
    String ClassName;
    String[] Students;
    String[] Assignments;
    double[][] Grades;
    
public GradeBook(String ClassName, String[] Students, String[] Assignments, double[][] Grades)
{
    this.ClassName = ClassName;
    this.Students = Students;
    this.Assignments = Assignments;
    this.Grades = Grades;
}
    public void setGrade (int row, int col, double grade)
    {
        Grades[row][col] = grade;
    }
    public double getGrade (int row, int col)
    {
        return Grades[row][col];
    }
    public void processGrade()
    {
        
        
       
        System.out.println("");
        
        for (int i = 0; i < Students.length; i++)
        {
            System.out.printf("%10s |", Students[i]);
            
            for (int j = 0; j < Grades.length; j++)
            {
            
            }
            
        }

    }
}