package C7biggroupshadow;
/** @author Adam Meloy
 * @version 1, 2-20-20
 * 
 */ 
public class C7BigGroupShadow
{
   public static void main(String[] args)
    {
        String ClassName = "Computers 101";
        String[] Students = {"Bob","Larry","Shawn","Jill","Kate"};
        String[] Assignments = {"Hello World","Looping","Input"};
        double[][] Grades = {{100,97,78},{100,90,85},{100,89,77},{100,65,87},{100,70,90}};
        GradeBook CS = new GradeBook(ClassName, Students, Assignments, Grades);
    }
}