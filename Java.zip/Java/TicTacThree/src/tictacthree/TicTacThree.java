package tictacthree;
/** @author Adam Meloy
 * @version 1, insert date here
 * description here
 */ 
public class TicTacThree
{
    public static void main(String[] args)
    {
        TicTacToe game = new TicTacToe();
        game.play();
    }
}