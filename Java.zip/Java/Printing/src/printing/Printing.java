package printing;
import javax.swing.*;
/** Printing output.
 * @author ameloy743
 * @version 1, 1-10-2020
 */
public class Printing
{
    public static void main(String[] args)
    {
        System.out.print("Part (a): ");
        
        //one System.out.println statement
        System.out.println("1 2 3 4");
        
        System.out.print("Part (b): ");
        
         //four System.out.print statements
        System.out.print("1 ");
        System.out.print("2 ");
        System.out.print("3 ");
        System.out.print("4 ");
        System.out.println();
        
        System.out.print("Part (c): ");
        
        //one System.out.printf statement
        System.out.printf("%d %d %d %d%n", 1, 2, 3, 4);//%d: decimal integer, %n: new line character, same as \n
        
        
        
        JOptionPane.showConfirmDialog(null, "You Rolled " + "X" + ". Would you like to continue?", "Random Dice Roller", 0, 1, null);
        
    }//end main
}//end class printing