package shoppingcart01;
public class ShoppingCart01 {
    public static void main(String[] args) {
    final String CustName = "Alex", ItemDesc = "Shirt.", Message = CustName + " Wants to buy a " + ItemDesc;
    System.out.println(Message);}
}