package calculate;
import java.util.*;
/** Prints the product, sum, difference, and quotient of two numbers
 * @author Adam Meloy
 * @version 1, 1-10-2020
 */
public class Calculate
{
    public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in);
        
        System.out.print("Enter first integer: "); //input prompt
        int num1 = input.nextInt(); //read/store first int
        
        System.out.print("Enter first integer: "); //input prompt
        int num2 = input.nextInt(); //read/store second int
        
        //display results
        System.out.printf("%nSum is %d%n", (num1 + num2));
        System.out.printf("Product is %d%n", (num1 * num2));
        System.out.printf("Difference is %d%n", (num1 - num2));
        System.out.printf("Quotient is %d%n", (num1 / num2));
        //%d is decimal int, %n is new line
    }//end main
}//end class