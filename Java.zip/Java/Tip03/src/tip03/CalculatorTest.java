package tip03;
import javax.swing.JOptionPane;
public class CalculatorTest {
    public static void main(String[] args) {     
       Calculator calc = new Calculator();
       calc.findTotal(JOptionPane.showInputDialog("Enter the Name of person1."), Double.parseDouble(JOptionPane.showInputDialog("Enter the Price of the Meal ($10).")));
       calc.findTotal(JOptionPane.showInputDialog("Enter the Name of person2."), Double.parseDouble(JOptionPane.showInputDialog("Enter the Price of the Meal ($12).")));
       calc.findTotal(JOptionPane.showInputDialog("Enter the Name of person3."), Double.parseDouble(JOptionPane.showInputDialog("Enter the Price of the Meal ($9).")));
       calc.findTotal(JOptionPane.showInputDialog("Enter the Name of person4."), Double.parseDouble(JOptionPane.showInputDialog("Enter the Price of the Meal ($8).")));
       calc.findTotal(JOptionPane.showInputDialog("Enter the Name of person5."), Double.parseDouble(JOptionPane.showInputDialog("Enter the Price of the Meal ($7).")));
       calc.findTotal(JOptionPane.showInputDialog("Enter the Name of person6."), Double.parseDouble(JOptionPane.showInputDialog("Enter the Price of the Meal ($15).")));
       calc.findTotal(JOptionPane.showInputDialog("Enter the Name of person7."), Double.parseDouble(JOptionPane.showInputDialog("Enter the Price of the Meal ($11).")));
       calc.findTotal(JOptionPane.showInputDialog("Enter the Name of person8."), Double.parseDouble(JOptionPane.showInputDialog("Enter the Price of the Meal ($30).")));
    }    
}