package tip03;
public class Calculator {
    public double tax = .1;
    public double tip = .2;   
    public void findTotal( String name, double price){
        double total = price * (1+tax+tip);
        System.out.println(name + ": $" + total); }
}