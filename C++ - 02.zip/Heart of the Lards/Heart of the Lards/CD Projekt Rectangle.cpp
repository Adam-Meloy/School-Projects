//Adam Meloy, 8-19-19, Calculate area and perimeter
#include <IOStream>
#include <String>
using namespace std;
double area, perimeter, length, width;
int x = 3, y = 4, z = 5;
string Fname, Lname;
int main() {
	x = y = z;
	cout << x << ' ' << y << ' ' << z << endl;

	cout << "Enter First and Last Name Here " << ">> ";
	cin >> Fname >> Lname;
	cout << "Length: " << ">> ";
	cin >> length;
	cout << "Width: " << ">> ";
	cin >> width;

	area = length * width;
	perimeter = 2 * (length + width);

	cout << "Your name is " << Fname << " " << Lname << endl;
	cout << "Area Cast: " << (area = static_cast<int> (length)* static_cast<int> (width)) << endl;
	cout << "Area: " << area << " units cubed" << endl;
	cout << "Perimeter: " << perimeter << " units cubed" << endl;
	system("pause");
	return(0);
}