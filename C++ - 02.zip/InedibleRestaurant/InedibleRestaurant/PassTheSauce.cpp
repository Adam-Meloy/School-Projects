﻿/*
Name: Adam Meloy
Date: 09-05-2019
Group: AM
Description: A restaurant program that uses nested if statements
*/
#include<iostream>
#include<iomanip>
#include<string>
using namespace std;
char main() 
{
	//variables
	double CustomerMoney = 0;
	int selector;
	string exit;
	bool trap;
	int rockJelly = 0, waxTaffy = 0, Michelangelato = 0;
	double rockJellyPrice = 3.5, waxTaffyPrice = 1.25, michelangelatoPrice = 15.9;

	cout << "Welcome to ØŋǂŒ�ƢƓƍªÝƕ's sweets shop!" << endl;
	cout << "How much money have you brought today?" << endl;
	cin >> CustomerMoney; //input

	cout << "Please enter the key according to what you wish to buy." << endl << "1: Rock Jelly, 2: Wax Taffy, 3: Michelangelato." << endl << "Any other actions will result in termination." << endl;
	cin >> selector; //input
	switch (selector)
	{
	case 1:
		if (CustomerMoney >= rockJellyPrice)
		{
			cout << "How many Rock Jelly cups do you wish to buy?" << endl;
			cin >> rockJelly; //input

			if (CustomerMoney >= (rockJelly*rockJellyPrice)) {
				cout << "Great! you bought " << rockJelly << " cups of Rock Jelly. have a nice day." << endl;
			}
			else
			{
				cout << "That's a bit out of your price range pal. Now get out before you enter my shooting range." << endl;
			}
		}
		else
		{
			cout << "get out of here you filthy mongrel. we want people with MONEY to shop here." << endl;
		}
		break;
	case 2:
		if (CustomerMoney >= waxTaffyPrice)
		{
			cout << "How many Wax Taffy sticks do you wish to buy?" << endl;
			cin >> waxTaffy; //input

			if (CustomerMoney >= (waxTaffy*waxTaffyPrice)) {
				cout << "Great! you bought " << waxTaffy << " sticks of Wax Taffy. have a nice day." << endl;
			}
			else
			{
				cout << "That's a bit out of your price range pal. Now get out before you enter my shooting range." << endl;
			}
		}
		else
		{
			cout << "get out of here you filthy mongrel. we want people with MONEY to shop here." << endl;
		}
		break;
	case 3:
		if (CustomerMoney >= michelangelatoPrice)
		{
			cout << "How many Michelangelato cups do you wish to buy?" << endl;
			cin >> Michelangelato; //input

			if (CustomerMoney >= (Michelangelato*michelangelatoPrice)) {
				cout << "Great! you bought " << Michelangelato << " cups of Michelangelato. have a nice day." << endl;
			}
			else
			{
				cout << "That's a bit out of your price range pal. Now get out before you enter my shooting range." << endl;
			}
		}
		else
		{
			cout << "get out of here you filthy mongrel. we want people with MONEY to shop here." << endl;
		}
		break;
	default:
		cout << "Ha ha ha very funny now get out before you lose the head." << endl;
		break;
	}

	cout << "type exit to exit" << endl;
	cin >> exit; //input, prevents exiting program after results displayed
	if (exit == "exit") {}
	else
	{
		cin >> trap; // punishment for not typing exit
	}
	return 'k';
}