// Adam Meloy IO Example
// File gets first name, 3 test scores, and calcs average
#include<iostream>
#include<iomanip>
#include<string>
#include<fstream>
using namespace std;
int main() {
	string fname = "";
	double G1, G2, G3, average;
	ifstream inputfile;
	ofstream outputfile;

	inputfile.open("bigscores.txt");
	outputfile.open("yeet.txt");

	inputfile >> fname >> G1 >> G2 >> G3;
	average = (G1 + G2 + G3) / 3;
	outputfile << fixed << showpoint << setprecision(2);
	outputfile << left << setw(15) << fname
		<< right << setw(8) << G1
		<< right << setw(8) << G2
		<< right << setw(8) << G3
		<< right << setw(8) << average << endl << endl;

	//screen
	cout << "This will find the average of three test scores." << endl;
	cout << fixed << showpoint << setprecision(2);

	cout << left << setw(15) << fname
		<< right << setw(8) << G1
		<< right << setw(8) << G2
		<< right << setw(8) << G3
		<< right << setw(8) << average << endl << endl;

	outputfile.close();
	inputfile.close();

	system("pause");
	return 0;
}