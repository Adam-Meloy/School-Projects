/*
Name: Adam Meloy and
Date: 09-23-2019
Description: Demonstration of user-defined functions
*/
#include<iostream>

using namespace std;

//prototypes
void menu();
int swim();
void crossCountry();
void soccer();
double footyball();
void basketball();
double volleyball(int sand);

int hold;
int main()
{
	//function call
	menu();
}

//functions
void menu()
{
	//variables
	int choice;
	int sand = 0;
	int swimmer = 0,
	double volleyballer = 0;
	double footyballer = 0;

	//get user choice
	cout << "Welcome to Carrot Cake Sports" << endl;
	cout << "Please choose from the menu below and enter the number" << endl;
	cout << "\t1. Swim" << endl << "\t2. Cross Country" << endl << "\t3. Soccer" << endl << "\t4. Football" << endl << "\t5. Basketball" << endl << "\t6. Volleyball" << endl << "\t7. Exit" << endl;
	cin >> choice;
	
	//while loop of the main program
	while (choice > 1 || choice < 7)
	{
		switch (choice)
		{
		case 1:
			swimmer = swim();
			if (swimmer < 0) //if for varying output
			{
				cout << "You have no swimmers on your team, you have NO Team!" << endl;
			}
			else
			{
				cout << "You have at least " << swimmer << " swimmer(s) on your team!" << endl;
			}
			break;//end case 1
		case 2:
			crossCountry();
			break;//end case 2
		case 3:
			soccer();
			break;//end case 3
		case 4:
			footyballer = footyball();
			if (footyballer < 50) //if for varying output
			{
				cout << "you probably lost the game." << endl;
			}
			else
			{
				cout << "HECK YEAH I LOV-- WE LO-- FEET WIN!" << endl;
			}
			break;//end case 4
		case 5:
			basketball();
			break;//end case 5
		case 6:
			cout << "how many balls did you volley today?" << endl;
			cin >> sand;
			volleyballer = volleyball(sand);

			cout << "the average of block ball is " << volleyballer << " ball." << endl;

			break;//end case 6
		case 7:
			cout << "you can't play our sports!" << endl;
			cout << "GUBBUH" << endl;
			cin >> hold;
			return;
			break;//end case 7
		default:
			
			break;//end default
		}//end switch
	} 
	choice = 0;
	while (!(choice == 1) || !(choice == 2) || !(choice == 3) || !(choice == 4) || !(choice == 5) || !(choice == 6)||!(choice ==7)); //user continues

	cout << "a";
	cin >> hold;
}
int swim()
{
	//variable
	int swimmer = 0;

	//user input
	cout << "How many swimmers are on your team?" << endl;
	cin >> swimmer;

	return swimmer;
}
void crossCountry()
{
	//variables
	int miles = 0;
	int people = 0;
	int total = 0;

	//user input
	cout << "How many miles did your team run?" << endl;
	cin >> miles;
	cout << "How many runners ran today?" << endl;
	cin >> people;

	//calculation
	total = miles * people;

	//output
	cout << "In " << total << " miles did they ever catch what they were running after? hohohohehehe" << endl;
}
void soccer()
{
	//variables
	char socks = ' ';
	int people = 0;
	int total = 0;

	//user input
	cout << "How many people did your team?" << endl;
	cin >> people;
	cout << "did they all wear socks to the game? y for yes." << endl;
	cin >> socks;

	if (socks == 'y' || socks == 'Y') //if for varying output
	{
		total = people * 2;
		cout << "you had " << total << " sock balls on the field!" << endl;
	}
	else
	{
		cout << "you had less than " << people << " sock balls on the field!" << endl;
	}
}
double footyball()
{
	//variable
	int feet = 0;

	//user input
	cout << "Welcome to feetball, where we play with feet." << endl;
	cout << "how many feet are on the field?" << endl;
	cin >> feet;

	
	return feet;
}
void basketball()
{
	//variables
	int baskets;
	int balls;
	int total;

	//user input
	cout << "how many baskets do you ball?" << endl;
	cin >> baskets;
	cout << "how many balls do you basket?" << endl;
	cin >> balls;

	//calculation
	total = baskets * balls;

	//output
	cout << "you've got " << total << " baskets in your balls, or whatever." << endl;
	cout << endl << endl;
}
double volleyball(int sand)
{
	//variables
	int volley, hits;
	double avg;

	//user input
	cout << "how many times did users attempt to block the sand ball?" << endl;

	//calculation
	avg = static_cast<double>(12 * 2);

	return avg;
}