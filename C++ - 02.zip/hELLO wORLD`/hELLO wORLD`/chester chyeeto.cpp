#include <IOStream>
using namespace std;
int main()
{ 
	cout << "hELLO wORLD" << endl;
	system("pause");
	return 0;
}