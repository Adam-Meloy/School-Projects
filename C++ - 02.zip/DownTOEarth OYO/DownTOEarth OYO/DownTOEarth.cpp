/*Adam Meloy
09-16-19
Down to earth, the mine for jewels game*/
#include <iostream>
#include <iomanip>
#include <string>
#include<array>
#include <Windows.h>
#include<cstdlib>
#include<ctime>

using namespace std;

int hold;
int map[1015][120];
bool moneyHack = false, oilHack = false;
int money = 0;

//prototypes
void cheatsMenu();
void cheatCodes();
void cheatCodeEnter();

int main()
{
	//for the nonconformists and idiots
	cout << "Please set screen buffer and window size to width of 120 and hight of 30." << endl;
	cout << "Reset if you have to." << endl;
	cout << "It will look like garbage if you dont." << endl;
	cout << "Press any button and then enter to continue." << endl;
	system("pause");

	//initalise or game end
	char screen[30][120];
	int screenx, screeny;
	int mapx, mapy, mapz;
	bool run = true;
	bool pushed = true;
	bool firstRun = true;
	int depth = 0, depthTen, depthHun;
	int moneyTen, moneyHun, moneyThou, moneyTenThou, moneyHunThou, moneyMil, moneyTenMil, moneyHunMil;
	float fuel = 100.0;
	int drill = 60;
	int drillDir = 0, drillDirPre;
	int mapDrawx, mapDrawy, mapDrawz;
	int mapSave = 0;
	int touch = 0;
	int timer = 0;

	srand(time(NULL));

	//map clear and rewipe
	for (mapy = 0; mapy <= 119; mapy++)//horizontal
	{
		for (mapx = 0; mapx <= 1014; mapx++)//out
		{
			int randNum = rand() % 20;
			map[mapx][mapy] = randNum;
			if (mapx >= 0 && mapx <= 299)//level 1
			{
				switch (randNum)
				{
				case 0:
				{
					map[mapx][mapy] = 32;
					break;
				}
				case 1:
				{
					map[mapx][mapy] = 32;
					break;
				}
				case 2:
				{
					map[mapx][mapy] = -80;
					break;
				}
				case 3:
				{
					map[mapx][mapy] = -80;
					break;
				}
				case 4:
				{
					map[mapx][mapy] = -80;
					break;
				}
				case 5:
				{
					map[mapx][mapy] = -80;
					break;
				}
				case 6:
				{
					map[mapx][mapy] = -80;
					break;
				}
				case 7:
				{
					map[mapx][mapy] = -79;
					break;
				}
				case 8:
				{
					map[mapx][mapy] = -79;
					break;
				}
				case 9:
				{
					map[mapx][mapy] = 79;
					break;
				}
				case 10:
				{
					map[mapx][mapy] = 79;
					break;
				}
				case 11:
				{
					map[mapx][mapy] = 79;
					break;
				}
				case 12:
				{
					map[mapx][mapy] = -78;
					break;
				}
				case 13:
				{
					map[mapx][mapy] = -32;
					break;
				}
				case 14:
				{
					map[mapx][mapy] = -32;
					break;
				}
				case 15:
				{
					map[mapx][mapy] = -31;
					break;
				}
				case 16:
				{
					map[mapx][mapy] = -31;
					break;
				}
				case 17:
				{
					map[mapx][mapy] = -30;
					break;
				}
				case 18:
				{
					map[mapx][mapy] = -29;
					break;
				}
				case 19:
				{
					map[mapx][mapy] = -28;
					break;
				}
				}
			}
			else if (mapx >= 300 && mapx <= 599)//level 2
			{
				switch (randNum)
				{
				case 0:
				{
					map[mapx][mapy] = 32;
					break;
				}
				case 1:
				{
					map[mapx][mapy] = 32;
					break;
				}
				case 2:
				{
					map[mapx][mapy] = -80;
					break;
				}
				case 3:
				{
					map[mapx][mapy] = -80;
					break;
				}
				case 4:
				{
					map[mapx][mapy] = -80;
					break;
				}
				case 5:
				{
					map[mapx][mapy] = -79;
					break;
				}
				case 6:
				{
					map[mapx][mapy] = -79;
					break;
				}
				case 7:
				{
					map[mapx][mapy] = -79;
					break;
				}
				case 8:
				{
					map[mapx][mapy] = -79;
					break;
				}
				case 9:
				{
					map[mapx][mapy] = 79;
					break;
				}
				case 10:
				{
					map[mapx][mapy] = 79;
					break;
				}
				case 11:
				{
					map[mapx][mapy] = 79;
					break;
				}
				case 12:
				{
					map[mapx][mapy] = -78;
					break;
				}
				case 13:
				{
					map[mapx][mapy] = -30;
					break;
				}
				case 14:
				{
					map[mapx][mapy] = -30;
					break;
				}
				case 15:
				{
					map[mapx][mapy] = -29;
					break;
				}
				case 16:
				{
					map[mapx][mapy] = -29;
					break;
				}
				case 17:
				{
					map[mapx][mapy] = -28;
					break;
				}
				case 18:
				{
					map[mapx][mapy] = -27;
					break;
				}
				case 19:
				{
					map[mapx][mapy] = -26;
					break;
				}
				}
			}
			else if (mapx >= 600 && mapx <= 899) //level 3
			{
				switch (randNum)
				{
				case 0:
				{
					map[mapx][mapy] = 32;
					break;
				}
				case 1:
				{
					map[mapx][mapy] = 32;
					break;
				}
				case 2:
				{
					map[mapx][mapy] = 32;
					break;
				}
				case 3:
				{
					map[mapx][mapy] = -80;
					break;
				}
				case 4:
				{
					map[mapx][mapy] = -79;
					break;
				}
				case 5:
				{
					map[mapx][mapy] = -79;
					break;
				}
				case 6:
				{
					map[mapx][mapy] = -78;
					break;
				}
				case 7:
				{
					map[mapx][mapy] = -78;
					break;
				}
				case 8:
				{
					map[mapx][mapy] = -78;
					break;
				}
				case 9:
				{
					map[mapx][mapy] = -78;
					break;
				}
				case 10:
				{
					map[mapx][mapy] = -78;
					break;
				}
				case 11:
				{
					map[mapx][mapy] = -78;
					break;
				}
				case 12:
				{
					map[mapx][mapy] = 79;
					break;
				}
				case 13:
				{
					map[mapx][mapy] = 79;
					break;
				}
				case 14:
				{
					map[mapx][mapy] = -26;
					break;
				}
				case 15:
				{
					map[mapx][mapy] = -26;
					break;
				}
				case 16:
				{
					map[mapx][mapy] = -25;
					break;
				}
				case 17:
				{
					map[mapx][mapy] = -24;
					break;
				}
				case 18:
				{
					map[mapx][mapy] = -23;
					break;
				}
				case 19:
				{
					map[mapx][mapy] = -22;
					break;
				}
				}
			}
			else if (mapx >= 900 && mapx <= 998) //level 4
			{
				switch (randNum)
				{
				case 0:
				{
					map[mapx][mapy] = 32;
					break;
				}
				case 1:
				{
					map[mapx][mapy] = 32;
					break;
				}
				case 2:
				{
					map[mapx][mapy] = 32;
					break;
				}
				case 3:
				{
					map[mapx][mapy] = 32;
					break;
				}
				case 4:
				{
					map[mapx][mapy] = -80;
					break;
				}
				case 5:
				{
					map[mapx][mapy] = -78;
					break;
				}
				case 6:
				{
					map[mapx][mapy] = -78;
					break;
				}
				case 7:
				{
					map[mapx][mapy] = -78;
					break;
				}
				case 8:
				{
					map[mapx][mapy] = -78;
					break;
				}
				case 9:
				{
					map[mapx][mapy] = -78;
					break;
				}
				case 10:
				{
					map[mapx][mapy] = -78;
					break;
				}
				case 11:
				{
					map[mapx][mapy] = -78;
					break;
				}
				case 12:
				{
					map[mapx][mapy] = -78;
					break;
				}
				case 13:
				{
					map[mapx][mapy] = -78;
					break;
				}
				case 14:
				{
					map[mapx][mapy] = -78;
					break;
				}
				case 15:
				{
					map[mapx][mapy] = 79;
					break;
				}
				case 16:
				{
					map[mapx][mapy] = -34;
					break;
				}
				case 17:
				{
					map[mapx][mapy] = -34;
					break;
				}
				case 18:
				{
					map[mapx][mapy] = -23;
					break;
				}
				case 19:
				{
					map[mapx][mapy] = -22;
					break;
				}
				}
			}
			else
			{
				map[mapx][mapy] = -78;
			}
		}
	}
	//screen clear
	for (screenx = 0; screenx <= 29; screenx++)//vertical
	{
		for (screeny = 0; screeny <= 119; screeny++)//horizontal
		{
			screen[screenx][screeny] = 32;
		}
	}
	map[15][0] = map[15][100];
	map[15][-1] = map[15][100 - 1];
	do 
	{
		//keyboard input
		if (!firstRun)
		{
			drillDirPre = drillDir;
			while (pushed)
			{
				if (GetKeyState(VK_LEFT) & 0x8000)
				{
					if (drillDirPre == -1)
					{
						drill--;
					}
					else
					{
						drillDir = -1;
					}
					pushed = false;
				}
				if (GetKeyState(VK_DOWN) & 0x8000)
				{
					if (drillDirPre == 0)
					{
						depth++;
					}
					else
					{
						drillDir = 0;
					}
					pushed = false;
				}
				if (GetKeyState(VK_RIGHT) & 0x8000)
				{
					if (drillDirPre == 1)
					{
						drill++;
					}
					else
					{
						drillDir = 1;
					}
					pushed = false;
				}

				if (GetKeyState(VK_ESCAPE) & 0x8000)
				{
					cout << "Are you sure? press Escape again to confirm. Press any other key to cancel." << endl;
					system("pause");
					if (GetKeyState(VK_ESCAPE) & 0x8000)
					{
						cout << "Goodbye!" << endl;
						return 1;
					}
					else if (GetKeyState('C') & 0x8000)
					{
						cheatsMenu();
						break;
					}
					else
					{
						break;
					}
				}
			}
		}
		
		firstRun = false;
		pushed = true;

		//fuel
		fuel--;

		//touch
		switch (touch)
		{
		case 79:
		{
			fuel += 5;
			break;
		}
		case -32:
		{
			money += 1;
			break;
		}
		case -31:
		{
			money += 2;
			break;
		}
		case -30:
		{
			money += 5;
			break;
		}
		case -29:
		{
			money += 10;
			break;
		}
		case -28:
		{
			money += 15;
			break;
		}
		case -27:
		{
			money += 25;
			break;
		}
		case -26:
		{
			money += 50;
			break;
		}
		case -25:
		{
			money += 75;
			break;
		}
		case -24:
		{
			money += 100;
			break;
		}
		case -23:
		{
			money += 500;
			break;
		}
		case -22:
		{
			money += 1000;
			break;
		}
		default:
			break;
		}

		//money man
		moneyTen = money / 10;
		moneyHun = money / 100;
		moneyThou = money / 1000;
		moneyTenThou = money / 10000;
		moneyHunThou = money / 100000;
		moneyMil = money / 1000000;
		moneyTenMil = money / 10000000;
		moneyHunMil = money / 100000000;

		//depth man
		depthTen = depth / 10;
		depthHun = depth / 100;

		//screen array
		//map
		for (mapx = depth - 15, screenx = 0; mapx <= 1014, screenx < 30; mapx++, screenx++)
		{
			for (screeny = 0; screeny <= 119; screeny++)
			{
				if (mapx <= 0)
				{
					screen[screenx][screeny] = 32;
				}
				else
				{
					screen[screenx][screeny] = map[mapx][screeny];
				}
			}
		}
		//top line

		//money display
		screen[0][0] = 'M';
		screen[0][1] = 'o';
		screen[0][2] = 'n';
		screen[0][3] = 'e';
		screen[0][4] = 'y';
		screen[0][5] = ':';
		if (moneyHack = false)
		{
		screen[0][6] = (moneyHunMil % 10) + 48;
		screen[0][7] = (moneyTenMil % 10) + 48;
		screen[0][8] = (moneyMil % 10) + 48;
		screen[0][9] = (moneyHunThou % 10) + 48;
		screen[0][10] = (moneyTenThou % 10) + 48;
		screen[0][11] = (moneyThou % 10) + 48;
		screen[0][12] = (moneyHun % 10) + 48;
		screen[0][13] = (moneyTen % 10) + 48;
		screen[0][14] = (money % 10) + 48;
		}
		else
		{
			screen[0][6] = 9 + 48;
			screen[0][7] = 9 + 48;
			screen[0][8] = 9 + 48;
			screen[0][9] = 9 + 48;
			screen[0][10] = 9 + 48;
			screen[0][11] = 9 + 48;
			screen[0][12] = 9 + 48;
			screen[0][13] = 9 + 48;
			screen[0][14] = 9 + 48;
		
		
		}
		for (screeny = 15; screeny < 56; screeny++)
		{
			screen[0][screeny] = 32;
		}
		//depth display
		screen[0][56] = 'D';
		screen[0][57] = 'e';
		screen[0][58] = 'p';
		screen[0][59] = 't';
		screen[0][60] = 'h';
		screen[0][61] = ':';
		screen[0][62] = (depthHun % 10) + 48;
		screen[0][63] = (depthTen % 10) + 48;
		screen[0][64] = (depth % 10) + 48;
		for (screeny = 65; screeny < 110; screeny++)
		{
			screen[0][screeny] = 32;
		}
		screen[0][110] = 'F';
		screen[0][111] = 'u';
		screen[0][112] = 'e';
		screen[0][113] = 'l';
		screen[0][114] = ':';

		//fuel display
		if (fuel >= 10)
		{
			screen[0][115] = -37;
		}
		else
		{
			screen[0][115] = 32;
		}
		if (fuel >= 30)
		{
			screen[0][116] = -37;
		}
		else
		{
			screen[0][116] = 32;
		}
		if (fuel >= 50)
		{
			screen[0][117] = -37;
		}
		else
		{
			screen[0][117] = 32;
		}
		if (fuel >= 70)
		{
			screen[0][118] = -37;
		}
		else
		{
			screen[0][118] = 32;
		}
		if (fuel >= 90)
		{
			screen[0][119] = -37;
		}
		else
		{
			screen[0][119] = 32;
		}
		screen[14][drill] = -2;
		//drill

		switch (drillDir)//directions the drill can go
		{
		case -1:
		{
			screen[14][drill - 1] = 60;
			touch = map[depth - 1][drill - 1];
			map[depth - 1][drill - 1] = 32;
			break;
		}
		case 0:
		{
			screen[15][drill] = 118;
			touch = map[depth][drill];
			map[depth][drill] = 32;
			break;
		}
		case 1:
		{
			screen[14][drill + 1] = 62;
			touch = map[depth + 1][drill + 1];
			map[depth - 1][drill + 1] = 32;
			break;
		}
		}
		if (oilHack = false)//oilhack check
		{
			if (fuel <= 0)//if out of fuel
			{
				screen[14][57] = 'N';
				screen[14][58] = 'O';
				screen[14][59] = ' ';
				screen[14][60] = 'F';
				screen[14][61] = 'U';
				screen[14][62] = 'E';
				screen[14][63] = 'L';
				screen[14][64] = '!';


				screen[15][57] = 'Y';
				screen[15][58] = 'O';
				screen[15][59] = 'U';
				screen[15][60] = ' ';
				screen[15][61] = 'L';
				screen[15][62] = 'O';
				screen[15][63] = 'S';
				screen[15][64] = 'E';
				run = false;
			}
		}
		if (depth >= 1000)//win if below 999
		{
			screen[15][57] = 'Y';
			screen[15][58] = 'O';
			screen[15][59] = 'U';
			screen[15][60] = ' ';
			screen[15][61] = 'W';
			screen[15][62] = 'O';
			screen[15][63] = 'N';
			screen[15][64] = '!';
			run = false;
		}
		//screen out
		system("CLS");
		for (screenx = 0; screenx <= 29; screenx++)//vertical
		{
			for (screeny = 0; screeny <= 119; screeny++)//horizontal
			{
				cout << screen[screenx][screeny];
			}
		}
	}
	while (run);
	cin >> hold;
	return 0;
}
void cheatsMenu()
{
	int choice = 0;
	cout << "Welcome to the cheat code menu, what can I do ya for?" << endl
		<< "\t1. Check Codes" << endl
		<< "\t2. Enter Code" << endl
		<< "\t3. Enter Game" << endl;

	//user input
	cin >> choice;

	//enter sub-menus
	switch (choice)
	{
	case 1:
		cheatCodes();
		break;
	case 2:
		cheatCodeEnter();
	case 3:
		break;
	default:
		cout << "Don't you try to make a fool out of me." << endl;
		break;
	}
}
void cheatCodes()
{
	int choice = 0;
	cout << "Welcome to the cheat code display menu, what can I do ya for?" << endl
		<< "\tCode 1.) Infinite Oil: infoil" << endl
		<< "\tCode 2.) Infinite Money: infmon" << endl
		<< "\t1. Back to menu" << endl;

	//user input
	cin >> choice;

	//exit to menu
	switch (choice)
	{
	case 1:
		cheatsMenu();
		break;
	default:
		cout << "Don't you try to make a fool out of me." << endl;
		break;
	}
}
void cheatCodeEnter()
{
	string choice;
	cout << "Welcome to the cheat code entry menu, go ahead and enter a code." << endl;

	//user input
	cin >> choice;

	//enable hacks
	if (choice == "inf_oil")
	{
		oilHack = true;
	}
	else if (choice == "inf_mon")
	{
		money = 999999999;
	}
	else
	{
		cout << "Don't you try to make a fool out of me." << endl;
	}
}