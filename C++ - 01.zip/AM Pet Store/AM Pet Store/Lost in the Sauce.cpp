#include<iostream>
#include<iomanip>
#include<array>
using namespace	std;
int sawScaledViper = 0, Raccoon = 0, Egg = 0, blackFootedCat = 0, sandCat = 0, sugarGlider = 0;
int MenuSelector = 0, HoldNumber = 0;
bool exitStore = false;
const double sawScaledViperPrice = 99999, raccoonPrice = -100, eggPrice = 99.99, blackFootedCatPrice = 12000, sandCatPrice = 7000, sugarGliderPrice = 75;
const double RaccoonPrice_forOrdering = 50;
double totalPrice = 0;
int main() {
   cout << "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" << endl
		<< "+                               Welcome To Paul's Pricey Pet Place!                                +" << endl
		<< "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" << endl;

   do {
	  cout << "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" << endl
		   << "+                                     Paul's Neat Button Place                                     +" << endl
		   << "+                                                                                                  +" << endl
		   << "+                                     [1] Select Pets to Order                                     +" << endl
		   << "+                                                                                                  +" << endl
		   << "+                                     [2] Un-Order Pets                                            +" << endl
		   << "+                                                                                                  +" << endl
		   << "+                                     [3] Pay for Pets                                             +" << endl
		   << "+                                                                                                  +" << endl
		   << "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" << endl;
	   cin >> MenuSelector;
	   switch (MenuSelector) {
	   case 1: //Order Pets
		   cout<< "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" << endl
			   << "+                                       Paul's Pet Prices                                          +" << endl
			   << "+                                                                                                  +" << endl
			   << "+      [1] Saw-scaled Viper                                                $99,000.00              +" << endl
			   << "+      Three children died to catch this viper, be glad.                                           +" << endl
			   << "+                                                                                                  +" << endl
			   << "+      [2] Raccoon                                                         $-50.00                 +" << endl
			   << "+      I'll PAY you to take these from me.                                                         +" << endl
			   << "+                                                                                                  +" << endl
			   << "+      [3] Egg                                                             $99.99                  +" << endl
			   << "+      A random egg. I have no idea what is inside of it.                                          +" << endl
			   << "+                                                                                                  +" << endl
			   << "+      [4] Black-footed Cat                                                $12,000.00              +" << endl
			   << "+      It looks cute, but it WILL try to eat your foot.                                            +" << endl
			   << "+                                                                                                  +" << endl
			   << "+      [5] Sand Cat                                                        $7,000.00               +" << endl
			   << "+      It's cute, but for the last time IT DOES NOT COME WITH SAND.                                +" << endl
			   << "+                                                                                                  +" << endl
			   << "+      [6] Sugar Glider                                                    $75.00                  +" << endl
			   << "+      It fast and it love sugar.                                                                  +" << endl
			   << "+                                                                                                  +" << endl
			   << "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" << endl;
		   cin >> MenuSelector;
		   switch (MenuSelector) {
		   case 1:
			   cout << "How many Saw-scaled Viper(s) would you like to order?" << endl;
			   cin >> sawScaledViper;
			   cout << "You have " << sawScaledViper << " Saw-scaled Viper(s), which would cost $" << (sawScaledViper*sawScaledViperPrice) << endl;
			   break;
		   case 2:
			   cout << "How many Raccoon(s) would you like to order?" << endl;
			   cin >> Raccoon;
			   cout << "You have " << Raccoon << " Raccoon(s), for which we would pay you $" << (Raccoon*RaccoonPrice_forOrdering) << endl;
			   break;
		   case 3:
			   cout << "How many Egg(s) would you like to order?" << endl;
			   cin >> Egg;
			   cout << "You have " << Egg << " Egg(s), which would cost $" << (Egg*eggPrice) << endl;
			   break;
		   case 4:
			   cout << "How many Black-footed Cat(s) would you like to order?" << endl;
			   cin >> blackFootedCat;
			   cout << "You have " << blackFootedCat << " Black-footed Cat(s), which would cost $" << (blackFootedCat*blackFootedCatPrice) << endl;
			   break;
		   case 5:
			   cout << "How many Sand Cat(s) would you like to order?" << endl;
			   cin >> sandCat;
			   cout << "You have " << sandCat << " Sand Cat(s), which would cost $" << (sandCat*sandCatPrice) << endl;
			   break;
		   case 6:
			   cout << "How many Sugar Glider(s) would you like to order?" << endl;
			   cin >> sugarGlider;
			   cout << "You have " << sugarGlider << " Sugar Glider(s), which would cost $" << (sugarGlider*sugarGliderPrice) << endl;
			   break;
		   default:
			   cout << "That was not a valid option." << endl;
			   break;
		   }
		   break;
	   case 2: //Un-Order Pets
		   cout << "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" << endl
			   << "+                                        Paul's Pet Menu                                           +" << endl
			   << "+                                 Choose one you wish to reduce                                    +" << endl
			   << "+                                                                                                  +" << endl
			   << "+      [1] Saw-scaled Viper                                                                        +" << endl
			   << "+                                                                                                  +" << endl
			   << "+      [2] Raccoon                                                                                 +" << endl
			   << "+                                                                                                  +" << endl
			   << "+      [3] Egg                                                                                     +" << endl
			   << "+                                                                                                  +" << endl
			   << "+      [4] Black-footed Cat                                                                        +" << endl
			   << "+                                                                                                  +" << endl
			   << "+      [5] Sand Cat                                                                                +" << endl
			   << "+                                                                                                  +" << endl
			   << "+      [6] Sugar Glider                                                                            +" << endl
			   << "+                                                                                                  +" << endl
			   << "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" << endl;
		   cin >> MenuSelector;
		   switch (MenuSelector) {
				case 1:
					cout << sawScaledViper << " Saw-scaled Viper(s)" << endl; // Saw-scaled Vipers
					cout << "Enter the amount of Saw-scaled Viper(s) you would like to un-order." << " >";
					cin >> HoldNumber;
					if (HoldNumber > sawScaledViper) {
						cout << "You tried to un-order more Saw-scaled Viper(s) then you have ordered." << endl;
					}
					else {
						sawScaledViper -= HoldNumber;
						cout << "You un-ordered " << HoldNumber << " Saw-scaled Viper(s)" << endl;
					}
					cout << "The total of the Saw-scaled Viper(s) you are about to order is $" << (sawScaledViper*sawScaledViperPrice) << endl;
					break;
				case 2:
					cout << Raccoon << " Raccoon(s)" << endl; // Raccoons
					cout << "Enter the amount of Raccoon(s) you would like to un-order." << " >";
					cin >> HoldNumber;
					if (HoldNumber > Raccoon) {
						cout << "You tried to un-order more Raccoon(s) then you have ordered." << endl;
					}
					else {
						Raccoon -= HoldNumber;
						cout << "You un-ordered " << HoldNumber << " Raccoon(s)" << endl;
					}
					cout << "The total of the Raccoon(s) you are about to order is $" << (Raccoon*raccoonPrice) << endl;
					break;
				case 3:
					cout << Egg << " Egg(s)" << endl; // Eggs
					cout << "Enter the amount of Egg(s) you would like to un-order." << " >";
					cin >> HoldNumber;
					if (HoldNumber > Egg) {
						cout << "You tried to un-order more Egg(s) then you have ordered." << endl;
					}
					else {
						Egg -= HoldNumber;
						cout << "You un-ordered " << HoldNumber << " Egg(s)" << endl;
					}
					cout << "The total of the Egg(s) you are about to order is $" << (Egg*eggPrice) << endl;
					break;
				case 4:
					cout << blackFootedCat << " Black-footed Cat(s)" << endl; // Black-footed Cats
					cout << "Enter the amount of Black-footed Cat(s) you would like to un-order." << " >";
					cin >> HoldNumber;
					if (HoldNumber > blackFootedCat) {
						cout << "You tried to un-order more Black-footed Cat(s) then you have ordered." << endl;
					}
					else {
						blackFootedCat -= HoldNumber;
						cout << "You un-ordered " << HoldNumber << " Black-footed Cat(s)" << endl;
					}
					cout << "The total of the Black-footed Cat(s) you are about to order is $" << (blackFootedCat*blackFootedCatPrice) << endl;
					break;
				case 5:
					cout << sandCat << " Sand Cat(s)" << endl; // Sand Cats
					cout << "Enter the amount of Sand Cat(s) you would like to un-order." << " >";
					cin >> HoldNumber;
					if (HoldNumber > sandCat) {
						cout << "You tried to un-order more Sand Cat(s) then you have ordered." << endl;
					}
					else {
						sandCat -= HoldNumber;
						cout << "You un-ordered " << HoldNumber << " Sand Cat(s)" << endl;
					}
					cout << "The total of the Sand Cat(s) you are about to order is $" << (sandCat*sandCatPrice) << endl;
					break;
				case 6:
					cout << sugarGlider << " Sugar Glider(s)" << endl; // Sugar Gliders
					cout << "Enter the amount of Sugar Glider(s) you would like to un-order." << " >";
					cin >> HoldNumber;
					if (HoldNumber > sugarGlider) {
						cout << "You tried to un-order more Sugar Glider(s) then you have ordered." << endl;
					}
					else {
						sugarGlider -= HoldNumber;
						cout << "You un-ordered " << HoldNumber << " Sugar Glider(s)" << endl;
					}
					cout << "The total of the Sugar Glider(s) you are about to order is $" << (sugarGlider*sugarGliderPrice) << endl;
					break;
				default:
					cout << "That was an invalid choice." << endl;
					break;
		   }	   

		   totalPrice = 
			   ((sawScaledViper*sawScaledViperPrice)+(Raccoon*raccoonPrice)+(Egg*eggPrice)+(blackFootedCat*blackFootedCatPrice)+(sandCat*sandCatPrice)+ (sugarGlider*sugarGliderPrice));
		   cout << "The total of everything you are about to order (without shipping fee) is $" << totalPrice << endl;
		   break;
	   case 3: //Order Pets
		   totalPrice = 
			   ((sawScaledViper*sawScaledViperPrice)+(Raccoon*raccoonPrice)+(Egg*eggPrice)+(blackFootedCat*blackFootedCatPrice)+(sandCat*sandCatPrice)+(sugarGlider*sugarGliderPrice));
		   totalPrice += ((sawScaledViper + Raccoon + Egg + blackFootedCat + sandCat + sugarGlider)*50);
		   cout << "The total price is $" << totalPrice << ". Have a nice day!" << endl;
		   exitStore = true;
		   break;
	   }
   } while (exitStore == false);

	
	system("pause");
	return 0;
}