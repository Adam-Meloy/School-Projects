/*
Adam M.
10-4-19

*/
#include<iostream>
#include<string>
#include<array>
using namespace std;

//vaiables

//prototypes

char main() 
{
	//variables
	char hold = ' ';
	

	cin >> hold;
	return 'S';
}