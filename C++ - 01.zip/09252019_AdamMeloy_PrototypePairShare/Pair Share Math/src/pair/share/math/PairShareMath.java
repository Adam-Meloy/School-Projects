package pair.share.math;
import java.awt.*;
import java.awt.event.*;
import static java.lang.Math.*;
import javax.swing.*;
import static javax.swing.JFrame.EXIT_ON_CLOSE;
/** @author Adam Meloy
 * @version 1, 1-27-2020
 * generate cos, sin, and tan of a triangle s = o/h, c = a/h, t = o/a
 */
public class PairShareMath extends JFrame
{
    //variables
    private JLabel sideAL, sideBL, sideCL, sinL, cosL;
    private JTextField sideATF, sideBTF, sideCTF, sinTF, cosTF;
    private JButton calculateB, exitB;
    private CalculateButtonHandler cbHandler;
    private EndButtonHandler ebHandler;
    //set size of jframe window
    private static final int WIDTH = 400;
    private static final int HEIGHT = 400;
    
    //creates window and object
public PairShareMath()
    {
        //create labels for displaying text
        sideAL = new JLabel("Enter side A : ", SwingConstants.RIGHT);
        sideBL = new JLabel("Enter side B : ", SwingConstants.RIGHT);
        sideCL = new JLabel("Enter side C : ", SwingConstants.RIGHT);
        sinL = new JLabel("1st Degree in Radians: ", SwingConstants.RIGHT);
        cosL = new JLabel("2nd Degree in Radians: ", SwingConstants.RIGHT);

        //create text fields
        sideATF = new JTextField(10);
        sideBTF = new JTextField(10);
        sideCTF = new JTextField(10);
        sinTF = new JTextField(10);
        cosTF = new JTextField(10);
        
        //create calculate button
        calculateB = new JButton("Calculate"); //creates the button
        cbHandler = new CalculateButtonHandler(); //creates button handler
        calculateB.addActionListener(cbHandler); //adds action listener
        
        //create exit button
        exitB = new JButton("Exit"); //creates the button
        ebHandler = new EndButtonHandler(); //creates button handler
        exitB.addActionListener(ebHandler); //adds action listener
        
        //set the title of the JFrame Window
        setTitle("Inverse_SOHCAHTOA.jpg");
        
        //get the container, which holds everything
        Container pane = getContentPane();
        
        //set the layout
        pane.setLayout(new GridLayout(6,2));
        
        //place the components in the pane
        pane.add(sideAL);
        pane.add(sideATF);
        pane.add(sideBL);
        pane.add(sideBTF);
        pane.add(sideCL);
        pane.add(sideCTF);
        pane.add(sinL);
        pane.add(sinTF);
        pane.add(cosL);
        pane.add(cosTF);
        pane.add(calculateB);
        pane.add(exitB);
        
        //set the size of the window and display it
        setSize(WIDTH, HEIGHT);
        setVisible(true);
        
        //makes the red x in the corner of the frame work
        setDefaultCloseOperation(EXIT_ON_CLOSE);   
    }
//tells the handler what to do when the action listener hears the action for the button
    private class CalculateButtonHandler implements ActionListener
    {
        //action event variable of e, class will perform the action in the code
        public void actionPerformed(ActionEvent e)
        {
            double a,b,c;
            //obtain number from user input field
            a = Double.parseDouble(sideATF.getText());
            b = Double.parseDouble(sideBTF.getText());
            c = Double.parseDouble(sideCTF.getText());
            
            double x = a/c, y = a/b;
            
            double ArcSin = asin(x);
            double ArcCos = acos(x);
            double ArcTan = atan(y);        
            
            sinTF.setText("1st Degree in Radians: " + asin(x));
            cosTF.setText("2nd Degree in Radians: " + acos(x));
        }
    }
//class for exit button handler which listens for the action listener
    private class EndButtonHandler implements ActionListener
    {
        //when the exit button is pressed, close the JFrame window
        public void actionPerformed(ActionEvent e)
        {
            System.exit(0);
        }
    }
    public static void main(String[] args)
    {
        PairShareMath CST = new PairShareMath();
    }
}