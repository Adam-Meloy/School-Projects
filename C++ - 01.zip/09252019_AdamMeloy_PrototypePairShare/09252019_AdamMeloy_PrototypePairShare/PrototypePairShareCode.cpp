/*
Adam and Max S.
09-25-19
pair share for prototypes practice. we will be an online shopping store known as Daintree.
*/

#include<iostream>
#include<iomanip>
using namespace std;

//global variables
double total = 0;// total for all products bought
int itemsPurchased = 0;// total of all items purchased
double wallet = 0;// amount of money user has
double walletRemainder = 0;// remainder left in wallet

//protoypes. Our departments include electronics, apparel, food, sporting goods, and discounted items.
void menu();
int electronicsDepartment();
void apparelDepartment(int aChoice);
int foodDepartment();
int sportingGoodsDepartment();
int discountedDepartment();
double checkOut(float wallet, double total);
void checkCart(double wallet);

int main()
{
	//variables
	int hold;

	cout << setprecision(2) << fixed << showpoint; // 2 points on every decimal

	cout << "Welcome to Daintree, the online shopping center!" << endl;
	cout << endl;
	cout << "Using a 0.00 format, how much money is in your wallet?" << endl;
	cout << endl;
	cin >> wallet; // setting wallet with user input

	menu();

	cout << endl;
	cout << "Thank you for shopping at Daintree, the online shopping center!" << endl
		 << "you have $" << walletRemainder << " left" << endl
		 << "Have a nice day!" << endl;

	cin >> hold;
	return 0;
}
//FUnctions

void menu()//menu for different departments
{
	//variables
	int choice = 0, eChoice = 0, fChoice = 0, aChoice = 0, sChoice = 0, dChoice = 0;
	char confirmation = ' ';
	do //menu while loop
	{
		cout << "By entering one of the numbers below, you will see the items in the department you choose." << endl;
		cout << "\t1. Electronics" << endl
			 << "\t2. Apparel" << endl
			 << "\t3. Food" << endl
			 << "\t4. Sporting Goods" << endl
			 << "\t5. Discounted Items" << endl
			 << "\t6. Check Cart" << endl
			 << "\t7. Ready to Check Out" << endl
			 << "\t8. Cancel Order, Exit" << endl;
		cin >> choice; // user input

		switch (choice) // enter departments
		{
			case 1://electronics department
				eChoice = electronicsDepartment();
				switch (eChoice) // Start switch for electronics menu.
				{
					case 1: // Universal charger.
					{
						cout << "A universal charger will be $34.99.  By entering Y or N, would you like to confirm your purchase?" << endl;
						cin >> confirmation;
						if (confirmation == 'y' || confirmation == 'Y')
						{
							cout << "$34.99 will now be added to your ticket." << endl;
							total += 34.99; //Calculation for total.
							itemsPurchased += 1; //adds items to items purchased
						}
						else
						cout << "You will not be charged for a universal charger." << endl;
						break;
					}//end case 1
					case 2: // New laptop.
					{
						cout << "A new laptop will be $749.99.  By entering Y or N, would you like to confirm your purchase?" << endl;
						cin >> confirmation;
						if (confirmation == 'y' || confirmation == 'Y')
						{
							cout << "$749.99 will now be added to your ticket." << endl;
							total += 749.99; //Calculation for total.
							itemsPurchased += 1; //adds items to items purchased
						}
						else
						cout << "You will not be charged for a new laptop." << endl;
						cout << endl;
						break;
					}//end case 2
					case 3: // Bluetooth speaker.
					{
						cout << "A bluetooth speaker will be $29.99.  By entering Y or N, would you like to confirm your purchase?" << endl;
						cin >> confirmation;
						if (confirmation == 'y' || confirmation == 'Y')
						{
							cout << "$29.99 will now be added to your ticket." << endl;
							total += 29.99; //Calculation for total.
							itemsPurchased += 1; //adds items to items purchased
						}
						else
						cout << "You will not be charged for a bluetooth speaker." << endl;
						cout << endl;
						break;
					}//end case 3
					case 4: // car charger
					{
						cout << "A car charger will be $14.99.  By entering Y or N, would you like to confirm your purchase?" << endl;
						cin >> confirmation;
						if (confirmation == 'y' || confirmation == 'Y')
						{
							cout << "$14.99 will now be added to your ticket." << endl;
							total += 14.99; //Calculation for total.
							itemsPurchased += 1; //adds items to items purchased
						}
						else
							cout << "You will not be charged for a car charger." << endl;
						cout << endl;
						break;
					}//end case 4
					case 5: // Nevermind.
					{
						cout << "Returning..." << endl << endl;
						break;
					}//end case 5
				}
				confirmation = ' ';
				cout << "Your Total is $" << total << endl;
				cout << endl;
				break;
			case 2://apparel department
				// User interaction.
				cout << "By entering a whole number from below, choose what item you would like to purchase." << endl
					 << "\t1.  Cool T-shirt" << endl
					 << "\t2.  Pajamas" << endl
					 << "\t3.  Soft Sweatpants" << endl
					 << "\t4.  Tennis Shoes" << endl
					 << "\t5.  Nevermind" << endl;
				//user input
				cin >> aChoice;
				apparelDepartment(aChoice);
				cout << "Your Total is $" << total << endl;
				cout << endl;
				break;
			case 3://food department
				fChoice = foodDepartment();
				switch (fChoice) // Start switch for electronics menu.
				{
					case 1: // Honey BBQ Ranch Pringles
					{
							cout << "Honey BBQ Ranch Pringles will be $5.99.  By entering Y or N, would you like to confirm your purchase?" << endl;
							cin >> confirmation;
							if (confirmation == 'y' || confirmation == 'Y')
							{
								cout << "$5.99 will now be added to your ticket." << endl;
								total += 5.99; //Calculation for total.
								itemsPurchased += 1; //adds items to items purchased
							}
							else
								cout << "You will not be charged for Honey BBQ Ranch Pringles." << endl;
							break;
						}//end case 1
					case 2: // Captain Crunch (Crunch not available at Daintree)
					{
							cout << "Captain ------ will be $2.99.  By entering Y or N, would you like to confirm your purchase?" << endl;
							cin >> confirmation;
							if (confirmation == 'y' || confirmation == 'Y')
							{
								cout << "$2.99 will now be added to your ticket." << endl;
								total += 2.99; //Calculation for total.
								itemsPurchased += 1; //adds items to items purchased
							}
							else
								cout << "You will not be charged for Captain ------." << endl;
							cout << endl;
							break;
						}//end case 2
					case 3: // Spam
					{
							cout << "A can of Spam will be $2.62.  By entering Y or N, would you like to confirm your purchase?" << endl;
							cin >> confirmation;
							if (confirmation == 'y' || confirmation == 'Y')
							{
								cout << "$2.62 will now be added to your ticket." << endl;
								total += 2.62; //Calculation for total.
								itemsPurchased += 1; //adds items to items purchased
							}
							else
								cout << "You will not be charged for a can of Spam." << endl;
							cout << endl;
							break;
						}//end case 3
					case 4: // One Pickle Spear
					{
							cout << "A Pickle Spear will be $0.14.  By entering Y or N, would you like to confirm your purchase?" << endl;
							cin >> confirmation;
							if (confirmation == 'y' || confirmation == 'Y')
							{
								cout << "$0.14 will now be added to your ticket." << endl;
								total += 0.14; //Calculation for total.
								itemsPurchased += 1; //adds items to items purchased
							}
							else
								cout << "You will not be charged for a Pickle Spear." << endl;
							cout << endl;
							break;
						}//end case 4
					case 5: // Nevermind.
					{
							cout << "Returning..." << endl << endl;
							break;
						}//end case 5
				}
				confirmation = ' ';
				cout << "Your Total is $" << total << endl;
				cout << endl;
				break;
			case 4://sporting goods department
				sChoice = sportingGoodsDepartment();
				switch (sChoice) // Start switch for electronics menu.
				{
					case 1: // Football
					{
						cout << "A football will be $24.99.  By entering Y or N, would you like to confirm your purchase?" << endl;
						cin >> confirmation;
						if (confirmation == 'y' || confirmation == 'Y')
						{
							cout << "$24.99 will now be added to your ticket." << endl;
							total += .99; //Calculation for total.
							itemsPurchased += 1; //adds items to items purchased
						}
						else
							cout << "You will not be charged for a football." << endl;
						break;
					}//end case 1
					case 2: // Baseball
					{
						cout << "A baseball will be $19.99.  By entering Y or N, would you like to confirm your purchase?" << endl;
						cin >> confirmation;
						if (confirmation == 'y' || confirmation == 'Y')
						{
							cout << "$19.99 will now be added to your ticket." << endl;
							total += .99; //Calculation for total.
							itemsPurchased += 1; //adds items to items purchased
						}
						else
							cout << "You will not be charged for a baseball." << endl;
						cout << endl;
						break;
					}//end case 2
					case 3: // Basketball
					{
						cout << "A basketball will be $24.45.  By entering Y or N, would you like to confirm your purchase?" << endl;
						cin >> confirmation;
						if (confirmation == 'y' || confirmation == 'Y')
						{
							cout << "$24.45 will now be added to your ticket." << endl;
							total += .99; //Calculation for total.
							itemsPurchased += 1; //adds items to items purchased
						}
						else
							cout << "You will not be charged for a basketball." << endl;
						cout << endl;
						break;
					}//end case 3
					case 4: // Hockey Puck
					{
						cout << "A hockey puck will be $13.98.  By entering Y or N, would you like to confirm your purchase?" << endl;
						cin >> confirmation;
						if (confirmation == 'y' || confirmation == 'Y')
						{
							cout << "$13.98 will now be added to your ticket." << endl;
							total += .99; //Calculation for total.
							itemsPurchased += 1; //adds items to items purchased
						}
						else
							cout << "You will not be charged for a hockey puck." << endl;
						cout << endl;
						break;
					}//end case 4
					case 5: // Nevermind.
					{
						cout << "Returning..." << endl << endl;
						break;
					}//end case 5
				}
				confirmation = ' ';
				cout << "Your Total is $" << total << endl;
				cout << endl;
				break;
			case 5://discounted department
				dChoice = discountedDepartment();
				switch (dChoice) // Start switch for electronics menu.
				{
					case 1: // Dented Water bottle
					{
						cout << "A Dented water bottle will be $3.49.  By entering Y or N, would you like to confirm your purchase?" << endl;
						cin >> confirmation;
						if (confirmation == 'y' || confirmation == 'Y')
						{
							cout << "$3.49 will now be added to your ticket." << endl;
							total += .99; //Calculation for total.
							itemsPurchased += 1; //adds items to items purchased
						}
						else
							cout << "You will not be charged for a dented water bottle." << endl;
						break;
					}//end case 1
					case 2: // Old Microwave
					{
						cout << "An old wicrowave will be $39.99.  By entering Y or N, would you like to confirm your purchase?" << endl;
						cin >> confirmation;
						if (confirmation == 'y' || confirmation == 'Y')
						{
							cout << "$39.99 will now be added to your ticket." << endl;
							total += .99; //Calculation for total.
							itemsPurchased += 1; //adds items to items purchased
						}
						else
							cout << "You will not be charged for an old microwave." << endl;
						cout << endl;
						break;
					}//end case 2
					case 3: // Size 2 shoes
					{
						cout << "A pair of size 2 shoes will be $19.99.  By entering Y or N, would you like to confirm your purchase?" << endl;
						cin >> confirmation;
						if (confirmation == 'y' || confirmation == 'Y')
						{
							cout << "$19.99 will now be added to your ticket." << endl;
							total += .99; //Calculation for total.
							itemsPurchased += 1; //adds items to items purchased
						}
						else
							cout << "You will not be charged for size 2 shoes." << endl;
						cout << endl;
						break;
					}//end case 3
					case 4: // Malfunctioned Backpack
					{
						cout << "A Malfunctioned Jetpack will be $399.99.  By entering Y or N, would you like to confirm your purchase?" << endl;
						cin >> confirmation;
						if (confirmation == 'y' || confirmation == 'Y')
						{
							cout << "$399.99 will now be added to your ticket." << endl;
							total += .99; //Calculation for total.
							itemsPurchased += 1; //adds items to items purchased
						}
						else
							cout << "You will not be charged for a malfunctioned backpack." << endl;
						cout << endl;
						break;
					}//end case 4
					case 5: // Nevermind.
					{
						cout << "Returning..." << endl << endl;
						break;
					}//end case 5
				}
				confirmation = ' ';
				cout << "Your Total is $" << total << endl;
				cout << endl;
				break;	
			case 6://check cart
				checkCart(static_cast<float>(wallet));
				break;
			case 7://check-out
				checkOut(wallet, total);
				break;
			case 8://cancel order
				walletRemainder = wallet;
				break;
			default://invalid ochoice
			{
				while (choice < 1 || choice > 7)
				{
					cout << "Invalid choice. Please enter a valid number." << endl;
					cout << "\t1. Electronics" << endl
						<< "\t2. Apparel" << endl
						<< "\t3. Food" << endl
						<< "\t4. Sporting Goods" << endl
						<< "\t5. Discounted Items" << endl
						<< "\t6. Check Cart" << endl
						<< "\t7. Ready to Check Out" << endl
						<< "\t8. Cancel Order, Exit" << endl;
					cin >> choice; // user input
				}
				break;
			}//end default
		}//end switch

	} while (choice > 0 && choice < 7);

}
int electronicsDepartment()
{
	// Variables.
	int eChoice = 0;

	// User interaction.
	cout << "By entering a whole number from below, choose what item you would like to purchase." << endl
		 << "\t1.  Universal charger" << endl
		 << "\t2.  New laptop" << endl
		 << "\t3.  Bluetooth speaker" << endl
		 << "\t4.  Car charger" << endl
		 << "\t5.  Nevermind" << endl;
	cin >> eChoice;

	return eChoice;
}
void apparelDepartment(int aChoice)
{
	char confirmation = ' ';
	switch (aChoice) // Start switch for electronics menu.
	{
		case 1: // Cool T-shirt
		{
		cout << "A Cool T-shirt will be $9.99.  By entering Y or N, would you like to confirm your purchase?" << endl;
		cin >> confirmation;
		if (confirmation == 'y' || confirmation == 'Y')
		{
			cout << "$9.99 will now be added to your ticket." << endl;
			total += 9.99; //Calculation for total.
			itemsPurchased += 1; //adds items to items purchased
		}
		else
			cout << "You will not be charged for a Cool T-shirt." << endl;
		break;
	}//end case 1
		case 2: // Pajamas
		{
		cout << "A Pajamas will be $13.99.  By entering Y or N, would you like to confirm your purchase?" << endl;
		cin >> confirmation;
		if (confirmation == 'y' || confirmation == 'Y')
		{
			cout << "$13.99 will now be added to your ticket." << endl;
			total += 13.99; //Calculation for total.
			itemsPurchased += 1; //adds items to items purchased
		}
		else
			cout << "You will not be charged for Pajamas." << endl;
		cout << endl;
		break;
	}//end case 2
		case 3: // Soft Sweatpants
		{
		cout << "Soft Sweatpants will be $10.99.  By entering Y or N, would you like to confirm your purchase?" << endl;
		cin >> confirmation;
		if (confirmation == 'y' || confirmation == 'Y')
		{
			cout << "$10.99 will now be added to your ticket." << endl;
			total += 10.99; //Calculation for total.
			itemsPurchased += 1; //adds items to items purchased
		}
		else
			cout << "You will not be charged for Soft Sweatpants." << endl;
		cout << endl;
		break;
	}//end case 3
		case 4: // Tennis Shoes
		{
		cout << "Tennis Shoes will be $34.99.  By entering Y or N, would you like to confirm your purchase?" << endl;
		cin >> confirmation;
		if (confirmation == 'y' || confirmation == 'Y')
		{
			cout << "$34.99 will now be added to your ticket." << endl;
			total += 34.99; //Calculation for total.
			itemsPurchased += 1; //adds items to items purchased
		}
		else
			cout << "You will not be charged for Tennis Shoes." << endl;
		cout << endl;
		break;
	}//end case 4
		case 5: // Nevermind.
		{
		cout << "Returning..." << endl << endl;
		break;
	}//end case 5
	}

}
int foodDepartment()
{
	// Variables.
	int fChoice = 0;

	// User interaction.
	cout << "By entering a whole number from below, choose what item you would like to purchase." << endl
		 << "\t1.  Honey BBQ Ranch Pringles" << endl
		 << "\t2.  Captain Crunch (Crunch not available at Daintree)" << endl
		 << "\t3.  Spam" << endl
		 << "\t4.  One Pickle Spear" << endl
		 << "\t5.  Nevermind" << endl;
	cin >> fChoice;

	return fChoice;
}
int sportingGoodsDepartment()
{
	// Variables.
	int sChoice = 0;

	// User interaction.
	cout << "By entering a whole number from below, choose what item you would like to purchase." << endl
		<< "\t1.  Football" << endl
		<< "\t2.  Baseball" << endl
		<< "\t3.  Basketball" << endl
		<< "\t4.  Hockey Puck" << endl
		<< "\t5.  Nevermind" << endl;
	cin >> sChoice;

	return sChoice;
}
int discountedDepartment()
{
	// Variables.
	int dChoice = 0;

	// User interaction.
	cout << "By entering a whole number from below, choose what item you would like to purchase." << endl
		<< "\t1.  Dented Water Bottle" << endl
		<< "\t2.  Old Microwave" << endl
		<< "\t3.  Size 2 Shoes" << endl
		<< "\t4.  Malfunctioned Jetpack" << endl
		<< "\t5.  Nevermind" << endl;
	cin >> dChoice;

	return dChoice;
}
double checkOut(float wallet, double total)
{
	if (total > wallet)
	{
		cout << "Get out you impoverished prick." << endl;
		return wallet;
	}
	else
	{
		walletRemainder = wallet - total;
		return walletRemainder;
	}
}
void checkCart(double wallet)
{
	cout << "You have spent $" << total << " on " << itemsPurchased << " items." << endl;
	cout << "You have $" << wallet << " in your wallet." << endl;
	cout << endl;
}