/*
Big Bryson
10-44-19
AM Group
Desc. rolling die
*/
#include<iostream>
#include "die.h"

using namespace std;

int main()
{
	int hold;
	bool confirm = true;

	do 
	{
		die die1;
		die die2;

		die1.roll();
		die2.roll();

		cout << "die 1: " << die1.getNum() << endl;
		cout << "die 2: " << die2.getNum() << endl;

		cout << "The sum of both dice is " << die1.getNum() + die2.getNum() << endl;

		cout << "Roll again? true = yes, false = no." << endl;
		cin >> confirm;
	} while (confirm = true);


	cin >> hold;
	return 0;
}