/*
Big Bryson
10-44-19
AM Group
Desc. rolling die
*/
class die 
{
//default constructor
//set default roll to 1
public:

	die();
	void roll(); //function to roll dice
	//generates a random number between 1-6 with a random number generator in num.

	int getNum() const; //returns number on top of dice to num.

private:
	int num;


};