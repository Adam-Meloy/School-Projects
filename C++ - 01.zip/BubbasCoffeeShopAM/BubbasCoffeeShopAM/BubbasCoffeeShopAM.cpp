/*
Adam Meloy
10-8-19
coffee shop
*/
#include<iostream>
#include<iomanip>
#include<fstream>
#include<string>

using namespace std;

int main()
{
	//variables
	string name = " ";
	int serverNum = 0, cupsSoldNum = 0, cupsSoldTotal = 0, hold = 0;
	double oneCupCost = 0.0, totalSold = 0.0;
	ifstream infile; //infile stream

	infile.open("C:/Users/ameloy743/Desktop/CoffeeShop.txt");
	if (!infile)
	{
		cout << "Beep boop. file not found. Initiating termination" << endl;
		return 69;
	}
	cout << fixed << showpoint << setprecision(2);
	cout << "Processing data, pleasw wait." << endl;

	//read in the first items and first none unique item
	infile >> oneCupCost;
	infile >> name;

	//continue reading file while more names
	while (infile)
	{
		infile >> cupsSoldNum;
		cupsSoldTotal += cupsSoldNum;
		serverNum++;
		infile >> name;
	}

	//blank line
	cout << endl;

	//calculation
	totalSold = oneCupCost * cupsSoldTotal;

	//output to user
	cout << "The total number of cups sold of Bubba's Super" << " \nfabulous coffee was: \t" << cupsSoldTotal << endl;
	cout << "Total number servers who worked today was:  \t" << serverNum << endl;
	cout << "Total bank rolled into today was: \t\t$" << totalSold << endl;

	if (serverNum != 0)
	{
		cout << "The average number of cups sold by each server was: " << cupsSoldTotal / serverNum << endl;
	}
	else
	{
		cout << "No input. i want die." << endl;
	}

	infile.close();
	cin >> hold;
	return 0;
}