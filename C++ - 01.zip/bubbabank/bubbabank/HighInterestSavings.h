#ifndef HighInterestSavings_H
#define HighInterestSavings_H
#include<string>
//#include "noServiceChargeChecking.h"
using namespace std;
class HighInterestSavings : public NoServiceChargeChecking
{
public:
	HighInterestSavings(string n, int accNum, double bal) : SavingsAccount(n, accNum, bal, INTEREST_RATE);
	HighInterestSavings(string n, int accNum, double bal, double minBal, double intRate);
	double getInterestRate();
	void setInterestRate(double intRate);
	void postInterest();
	void createMonthlyPayment();
	virtual void print();
private:
	static const double INTEREST_RATE = 0.05;
	static const double MIN_BALANCE = 5000.00;
};
#endif