#ifndef certificateOfDeposit_H
#define certificateOfDeposit_H
#include "bank.h"
#include<string>
using namespace std;
class CertificateOfDeposit : public BankAccount
{
	public:
		CertificateOfDeposit(string n, int accNum, double bal);
		CertificateOfDeposit(string n, int accNum, double bal, double intRate, int maturityMon);
		double getinterestRate();
		void setInterestRate(double rate);
		double getCurrentCDMonth();
		void setCurrentCDMonth(int month);
		double getMaturityMonths();
		void getMaturityMonths(int month);
		void postInterest();
		void withdraw(double amount);
		void withdraw();
		void createMonthlyStatement();
		void print();
	private:
		static const double INTEREST_RATE = 0.05;
		static const int NUMBER_OF_MATURITY_MONTHS = 6;
		double interestRate;
		int maturityMonths;
		int cdMonth;
};


#endif