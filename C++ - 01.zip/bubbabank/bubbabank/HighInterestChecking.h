#ifndef HighInterestChecking_H
#define HighInterestChecking_H
#include<string>
//#include "noServiceChargeChecking.h"
using namespace std;
class HighInterestChecking : public noServiceChargeChecking
{
	public:
		HighInterestChecking(string n, int accNum, double bal);
		HighInterestChecking(string n, int accNum, double bal, double minBal, double intRate);
		double getInterestRate();
		void setInterestRate(double intRate);
		void postInterest();
		void createMonthlyPayment();
		virtual void print();
	private:
		static const double INTEREST_RATE = 0.05;
		static const double MIN_BALANCE = 5000.00;
};
#endif