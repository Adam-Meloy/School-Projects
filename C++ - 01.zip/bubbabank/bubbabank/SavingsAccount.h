#ifndef SavingsAccount_H
#define SavingsAccount_H
#include<string>
#include "bank.h"
using namespace std;
class SavingsAccount : public BankAccount
{
	public:
		SavingsAccount(string n, int accNum, double bal);
		SavingsAccount(string n, int accNum, double bal, double intRate);
		double getInterestRate();
		void setInterestRate(double rate);
		void postInterest();
		virtual void createMonthlyStatement();
		virtual void print();
	protected:
		double interestRate;
	private:
		static const double INTEREST_RATE = 0.05;
};
#endif