#ifndef CheckingAccount_H
#define CheckingAccount_H
#include<string>
#include "bank.h"
using namespace std;
class CheckingAccount : public BankAccount
{
	public:
		CheckingAccount(string n, int accNum, double bal);
		virtual void writeCheck(double ammount) = 0;
};
#endif