/*
Name: Adam Meloy
Date: 09-04-2019
Group: AM
Description: DMV program using nested if statements
*/
#include<iostream>
#include<string>
using namespace std;
char main()
{
	//variables
	string firstName = "", lastName = "", holder = "";
	bool Vision = false, Written = false, Driving = false;
	int Age = 0, DrivingLog = 0;
	bool instructionPermit = false, intermediatePermit = false, driversLicnse = false;
	// user interaction
	cout << "Welcome to Stinky's DMV" << endl;
	cout << "Please enter your age as a full number" << endl;
	cin >> Age;

	if (Age < 15) // Age less than 15
	{
		cout << "Come back when you're older than 15. get out now before I get me mallet." << endl;
	}

	else if (Age >= 15 && Age < 16) // age is 15
	{
		cout << "you sir are able to get an intermediate permit." << endl;
		cout << "Have you passed your vision test? Y for yes, N for no." << endl;
		cin >> holder;
		// Pass vision test
		if (holder == "Y" or holder == "y") {
				Vision = true;
				cout << "Great! you can see. perfect. drivers DO need to see." << endl;

				cout << "Alright buddy boy, have you passed the written test? Y for yes, N for no." << endl;
				cin >> holder;
				// Pass written test
				if (holder == "Y" or holder == "y") {
					Written = true;
					cout << "Holy frijoles! you passed! you get the instruction permit." << endl;
				} 
				else if (holder == "N" or holder == "n") {
					Written = false;
					cout << "Gosh dang illiterates, we don't need you on the road, now scraw!" << endl;
				}
				else
				{
					cout << "Think you're funny huh? you aren't, now go." << endl;
				}
			} 
	 	else if (holder == "N" or holder == "n") {
				Vision = false;
				cout << "What are you, blind? get out before I get mad." << endl;
			}
		else 
			{ 
				cout << "Get outta here you dirty hooligan. I SWEAR ON ME MUM I'LL GRAB ME MALLET!" << endl;
			}
	}

	else if (Age >= 16 && Age < 18) // age is 16/17
	{
		cout << "Wowzers pal, you are able to get an intermediate permit" << endl;
		cout << "Have you passed your vision test? Y for yes, N for no." << endl;
		cin >> holder;
		// Pass vision test
		if (holder == "Y" or holder == "y") {
			Vision = true;
			cout << "Great! you can see. perfect. drivers DO need to see." << endl;

			cout << "Alright buddy boy, have you passed the written test? Y for yes, N for no." << endl;
			cin >> holder;
			// Pass written test
			if (holder == "Y" or holder == "y") {
				Written = true;
				cout << "Gee wilikers! you are getting so diddly darn close to having an intermediate permit." << endl;

				cout << "Buster, how many hours have you logged?" << endl;
				cin >> DrivingLog;
				// Have sufficient log hours
				if (DrivingLog >= 50) {
					intermediatePermit = true;
					cout << "Holy frijoles! you passed! you get the intermediate permit." << endl;
				}
				else if (DrivingLog < 50) {
					cout << "Ouch, so close. Drive some more, and come back later." << endl;
				}
				else
				{
					cout << "If you won't tell me, you'll have to tell THE MALLET!" << endl;
				}
			}
			else if (holder == "N" or holder == "n") {
				Written = false;
				cout << "Gosh dang illiterates, we don't need you on the road, now scraw!" << endl;
			}
			else
			{
				cout << "Think you're funny huh? you aren't, now go." << endl;
			}
		}
		else if (holder == "N" or holder == "n") {
			Vision = false;
			cout << "What are you, blind? get out before I get mad." << endl;
		}
		else
		{
			cout << "Get outta here you dirty hooligan. I SWEAR ON ME MUM I'LL GRAB ME MALLET!" << endl;
		}
	}

	else if (Age >= 18) // age is 18+
	{
		cout << "Gee golly, you are of the age to get a driver's license" << endl;
		cout << "Have you passed your vision test? Y for yes, N for no." << endl;
		cin >> holder;
		// Pass vision test
		if (holder == "Y" or holder == "y") {
			Vision = true;
			cout << "Great! you can see. perfect. drivers DO need to see." << endl;

			cout << "Alright buddy boy, have you passed the written test? Y for yes, N for no." << endl;
			cin >> holder;
			// Pass written test
			if (holder == "Y" or holder == "y") {
				Written = true;
				cout << "Gee wilikers! you are getting so diddly darn close to having a driver's license." << endl;

				cout << "Buster, have you passed the driving test? Y for yes, N for no." << endl;
				cin >> holder;
				// Pass driving test
				if (holder == "Y" or holder == "y") {
					driversLicnse = true;
					cout << "Holy frijoles! you passed! you get the driver's license." << endl;
				}
				else if (holder == "N" or holder == "n") {
					cout << "Ouch, so close. Go pass the test and come back later." << endl;
				}
				else
				{
					cout << "If you won't tell me, you'll have to tell THE MALLET!" << endl;
				}
			}
			else if (holder == "N" or holder == "n") {
				Written = false;
				cout << "Gosh dang illiterates, we don't need you on the road, now scraw!" << endl;
			}
			else
			{
				cout << "Think you're funny huh? you aren't, now go." << endl;
			}
		}
		else if (holder == "N" or holder == "n") {
			Vision = false;
			cout << "What are you, blind? get out before I get mad." << endl;
		}
		else
		{
			cout << "Get outta here you dirty hooligan. I SWEAR ON ME MUM I'LL GRAB ME MALLET!" << endl;
		}
	}
	cin >> holder;
	return 'z';
}