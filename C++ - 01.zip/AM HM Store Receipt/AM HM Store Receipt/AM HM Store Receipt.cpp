/* Made by Henry Manning and Adam Meloy. 8-28-19 Chapter 3: Pair Share (PS) Programming Project � Any Store Receipt.
This project is a simulated store designed to allow you to get the real shopping experience. It also includes a receipt that details what was purchased. */
#include <iostream>
#include <iomanip>
#include <string>

using namespace std;

//These are the totals of items the user has
int Sandwich = 00, Bandages = 00, Milk = 00, Pizza = 00, energyDrink = 00;

//These are the descriptions of the items
const string sandwichDesc = "A subpar Bologna Sandwich", 
bandagesDesc = "A box of 8 Bandages", milkDesc = "A pint of Milk", 
pizzaDesc = "A slice of Pepperoni Pizza", energyDrinkDesc = "X-Max, X-Mart's signature Energy Drink";

//These are the prices of the items and the tax rate/discount
const double sandwichPrice = 2.75, bandagesPrice = 2.0, milkPrice = 1.25, pizzaPrice = 3.50, energyDrinkPrice = 1.75;
const double TAX_RATE = 0.08125, GOOD_STUDENT_DISCOUNT = 0.02;

//These are the totals for the price
double totalPrice_withoutTax = 0.0, totalPrice_withTax = 0.0, discountTaken = 0.0, taxTaken = 0.0;

//This boolean is used to exit the loop of the program
bool exitStore = false;

//These are used by the program to perform actions
int MenuSelector = 0, HoldNumber = 0;

//This is used to adjust the width of part of the reciept
int Name_Date_RecieptLength = 0;

//These hold the customer's last name and the date
string cName = "", Date = "08/27/2019";

int main() {
	cout << "Please enter your last name. > ";
	cin >> cName;
	Name_Date_RecieptLength = 75 - cName.length();
	cout << setprecision(2) << fixed << showpoint;
	cout << "____________________________________________________________________________________________________" << endl
		<< "                                          WELCOME TO X-MART                                         " << endl
		<< "                                                                                                    " << endl
		<< "                                          Select an action:                                         " << endl
		<< "       Buy an Item(s)                                                  Press [1]                    " << endl
		<< "       Check/Remove Items from your Cart                               Press [2]                    " << endl
		<< "       Check Out                                                       Press [3]                    " << endl
		<< "       Leave the Store                                                 Press [4]                    " << endl
		<< "____________________________________________________________________________________________________" << endl;
	do {
		cout << "Please Perform an action" << endl;
		cin >> MenuSelector;
		switch (MenuSelector) {
		case 1: //buy item
		   cout << "____________________________________________________________________________________________________" << endl
				<< "                                          X-MART PRICES                                             " << endl
				<< "                                                                                                    " << endl
				<< "       Sandwich                                                        $2.75                        " << endl
			    << "       A subpar Bologna Sandwich                                                                    " << endl
			    << "                                                                                                    " << endl
				<< "       Bandages                                                        $2.00                        " << endl
			    << "       A box of 8 Bandages                                                                          " << endl
			    << "                                                                                                    " << endl
				<< "       Milk                                                            $1.25                        " << endl
			    << "       A pint of Milk                                                                               " << endl
			    << "                                                                                                    " << endl
				<< "       Pizza                                                           $3.50                        " << endl
			    << "       A slice of Pepperoni Pizza (Tastes like cardboard)                                           " << endl
			    << "                                                                                                    " << endl
				<< "       Energy Drink                                                    $1.75                        " << endl
			    << "       X-Max, X-Mart's signature Energy Drink                                                       " << endl
			    << "                                                                                                    " << endl
				<< "____________________________________________________________________________________________________" << endl;

			cout << "How many Sandwiches would you like to purchase?" << endl;
			cin >> Sandwich;
			cout << "How many Bandages would you like to purchase?" << endl;
			cin >> Bandages;
			cout << "How much Pizza would you like to purchase?" << endl;
			cin >> Pizza;
			cout << "How much Milk would you like to purchase?" << endl;
			cin >> Milk;
			cout << "How many Energy Drinks would you like to purchase?" << endl;
			cin >> energyDrink;
			break;

		case 2: //check cart
			cout << Sandwich << " Sandwich(es)" << endl; // Sandwiches
			cout << "Enter the amount of Sandwich(es) you would like to remove." << " >";
			cin >> HoldNumber;
			if (HoldNumber > Sandwich) {
				cout << "You tried to put back more sandwiches then you have." << endl;
			}
			else {
				Sandwich -= HoldNumber;
				cout << "You put back " << HoldNumber << " Sandwich(es)" << endl;
			}
			cout << Bandages << " Box(es) of Bandages" << endl; // Bandages
			cout << "Enter the amount of Bandages you would like to remove." << " >";
			cin >> HoldNumber;
			if (HoldNumber > Bandages) {
				cout << "You tried to put back more Bandages then you have." << endl;
			}
			else {
				Bandages -= HoldNumber;
				cout << "You put back " << HoldNumber << " Box(es) of Bandages" << endl;
			}
			cout << Pizza << " Piece(s) of Pizza" << endl; // Pizza
			cout << "Enter the amount of Pizza you would like to remove." << " >";
			cin >> HoldNumber;
			if (HoldNumber > Pizza) {
				cout << "You tried to put back more Pizza then you have." << endl;
			}
			else {
				Pizza -= HoldNumber;
				cout << "You put back " << HoldNumber << " Piece(s) of Pizza" << endl;
			}
			cout << Milk << " Carton(s) of Milk" << endl; // Milk
			cout << "Enter the amount of Milk you would like to remove." << " >";
			cin >> HoldNumber;
			if (HoldNumber > Milk) {
				cout << "You tried to put back more Milk then you have." << endl;
			}
			else {
				Milk -= HoldNumber;
				cout << "You put back " << HoldNumber << " Carton(s) on Milk" << endl;
			}
			cout << energyDrink << " Energy Drink(s)" << endl; // Energy Drinks
			cout << "Enter the amount of Energy Drink(s) you would like to remove." << " >";
			cin >> HoldNumber;
			if (HoldNumber > energyDrink) {
				cout << "You tried to put back more Energy Drink(s) then you have." << endl;
			}
			else {
				energyDrink -= HoldNumber;
				cout << "You put back " << HoldNumber << " Energy Drink(s)" << endl;
			}

			totalPrice_withoutTax = (sandwichPrice*Sandwich) + (bandagesPrice*Bandages) + (milkPrice*Milk) + (pizzaPrice*Pizza) + (energyDrinkPrice*energyDrink);
			cout << "The total of everything in the cart (without tax) is $" << totalPrice_withoutTax << endl;
			break;

		case 3: //check out
			totalPrice_withoutTax = (sandwichPrice*Sandwich) + (bandagesPrice*Bandages) + (milkPrice*Milk) + (pizzaPrice*Pizza) + (energyDrinkPrice*energyDrink);
			taxTaken = totalPrice_withoutTax * TAX_RATE;
			if (energyDrink < 5) {
				discountTaken = (totalPrice_withoutTax*GOOD_STUDENT_DISCOUNT);
			}
			totalPrice_withTax = totalPrice_withoutTax + taxTaken + discountTaken;
			exitStore = true;
			break;

		case 4: //Exit store 
			exitStore = true;
			break;

		default: cout << "Invalid option selected." << endl;

		}
	} while (exitStore == false);

	//prepare for a long night of reading code.
	cout << setfill('-') << setw(100) << "-" << setfill(' ') << endl
		<< right << setw(50) << "X-Mart" << endl
		<< right << setw(53) << "Sales Ticket" << endl
		<< left << setw(15) << "Customer Name: " << cName << setw(Name_Date_RecieptLength) << right << "Date: " << Date << endl << endl << endl
		<< left << setfill('_') << setw(100) << "_" << setfill(' ') << endl
		<< left << setw(12) << "  Quantity |" << left << setw(64) 
		<< "                       Item Description                       " << right << setw(13) 
		<< "| Price Each " << right << setw(11) 
		<< "|  Total   " << endl;
	
	if (Sandwich > 0) {
		cout << setw(7) << Sandwich << setw(5) << "" << sandwichDesc << setw(41) 
			<< "$" << setw(10) << sandwichPrice << setw(3) << "$" << setw(8) << (Sandwich*sandwichPrice) << endl << endl;
	}
	if (Bandages > 0) {
		cout << setw(7) << Bandages << setw(5) << "" << bandagesDesc << setw(47) 
			<< "$" << setw(10) << bandagesPrice << setw(3) << "$" << setw(8) << (Bandages*bandagesPrice) << endl << endl;
	}
	if (Milk > 0) {
		cout << setw(7) << Milk << setw(5) << "" << milkDesc << setw(52) 
			<< "$" << setw(10) << milkPrice << setw(3) << "$" << setw(8) << (Milk*milkPrice) << endl << endl;
	}
	if (Pizza > 0) {
		cout << setw(7) << Pizza << setw(5) << "" << pizzaDesc << setw(40) 
			<< "$" << setw(10) << pizzaPrice << setw(3) << "$" << setw(8) << (Pizza*pizzaPrice) << endl << endl;
	}
	if (energyDrink > 0) {
		cout << setw(7) << energyDrink << setw(5) << "" << energyDrinkDesc 
			<< setw(28) << "$" << setw(10) << energyDrinkPrice << setw(3) << "$" << setw(8) << (energyDrink*energyDrinkPrice) << endl << endl;
	}

	cout << setfill('_') << setw(100) << "" << setfill(' ') << endl
		<< endl
		<< setw(20) << "TOTAL PURCHASE" << setw(72) << "" << "$  " << totalPrice_withoutTax << endl
		<< setw(49) << "GOOD STUDENT DISCOUNT (if applicable)" << setw(46) << "-  " << discountTaken << endl
		<< setw(9) << "TAX" << setw(90) << taxTaken << endl
		<< setw(90) << "" << "__________" << endl
		<< setw(17) << "GRAND TOTAL" << setw(75) << "" << "$  " << totalPrice_withTax << endl
		<< endl
		<< endl
		<< setw(33) << "" << "THANK YOU FOR SHOPPING AT X-MART" << setw(34) << endl
		<< setw(38) << "" << "Please come again soon!" << setw(39) << endl;

	system("pause");
	return 0;
}