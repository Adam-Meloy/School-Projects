/*
Adam and max, numero dos
10-04-19
Pair share for enumerator practive in chapter 7
*/

#include<iostream>
#include<string>
#include<ctime>

using namespace std;

// Arrays and random picking of them.
int cardValue[10] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
int RandIndex;

// Global variables.
char playerOneHoS = ' ';
int dealerCardValue = 0, playerOneCardValue = 0;

// Enum types.
enum playerChoice { hit, stay, neutral };

// Function prototypes.
char rules();
playerChoice recievePlayerOne();
void calculateScorePlayerOne(int& totalScorePlayerOne);
void calculateScoreDealer(int& totalScoreDealer);

int main()
{
	srand(time(NULL));
	// Variables.
	char choice = ' ', repeatChoice = ' ', playerOneHoS;
	playerChoice playerOneChoice;

	
	choice = rules(); // Function call to rules.  Outside of loop so that the rules don't repeat every time.

	do
	{
		if (choice == 'Y' || choice == 'y') // If user wants to play.
		{
			playerOneCardValue = 0;
			dealerCardValue = 0;
			RandIndex = rand() % 10;
			cout << "Player one, you have been dealt a(n) " << cardValue[RandIndex] << " face down and a(n) ";
			playerOneCardValue += cardValue[RandIndex];
			// Two rands for two different random values.
			RandIndex = rand() % 10;
			// Two rands for two different random values.
			cout << cardValue[RandIndex] << " face up.  Would you like to stay or hit?" << endl;
			playerOneCardValue += cardValue[RandIndex];

			playerOneChoice = recievePlayerOne(); // Function call for recievePlayerOne.

			//calculate who wins
			calculateScoreDealer(dealerCardValue);
			calculateScorePlayerOne(playerOneCardValue);
		}

		cout << endl << "Would you like to play Blackjack again? (Y/N)" << endl;
		cin >> repeatChoice;
	} while (repeatChoice == 'Y' || repeatChoice == 'y'); // Repeat this loop while the user requests it to.

	return 0;
}

// User defined functions.

// Rules menu.
char rules()
{
	// Variables.
	char choice = ' ';

	// Output to the user.
	cout << "Hello and welcome to the game of Blackjack!" << endl;
	cout << "The goal of this game is to amount your card values as near to 21 as possible without exceeding or 'busting' it." << endl;
	cout << "Moreover, you have to beat whatever hand the dealer has drawn; if he or she has 20 and you have 19, you lose the hand." << endl;
	cout << "All facecards are worth 10, and aces are worth 1 or 11 -- it's up to the player to decide." << endl;
	cout << "After being dealt your hand, when it is your turn around the table, you can either ask to 'hit' or to 'stay'." << endl;
	cout << "If you ask to 'hit', you will be given another card, face down." << endl;
	cout << "If you ask to 'stay', you will not be given another card." << endl;
	cout << "The game will continue until all players decide to 'stay'.  After 'staying' once, you cannot hit again." << endl;
	cout << "All players flip their cards at this point.  Anyone above 21 busts.  If the dealer has a higher card value than" << endl;
	cout << "any of the players, they the dealer wins and the players lose, and vice versa." << endl << endl;

	// User input.
	cout << "Would you like to play? (Y/N)" << endl;
	cin >> choice;

	if (choice == 'y' || choice == 'Y') // If the user decides to play.
	{
		return choice;
	}

	else
		exit(0);
}
// Player one's choice.
playerChoice recievePlayerOne()
{
	playerChoice HoS = neutral;

	while (HoS != stay) //rerun if user decides to hit
	{
		if (playerOneCardValue > 21) //exits function of over 21
		{
			return stay;
		}

		cout << "Please enter 'H' for Hit, or 'S' for Stay." << endl;
		cin >> playerOneHoS;
		if (playerOneHoS == 'S' || playerOneHoS == 's') // If the user chooses to stay.
		{
			cout << "You have chosen to stay.  The dealer will flip his cards after all players stay or bust." << endl;

			HoS = stay;
		}
			
		if (playerOneHoS == 'H' || playerOneHoS == 'h') // If the user chooses to hit.
		{
			RandIndex = rand() % 10;
			cout << "You have been dealt a " << cardValue[RandIndex] << ".  Would you like to hit or stay?" << endl;
			playerOneCardValue += cardValue[RandIndex];

			HoS = hit;
		}
			
		while (!(playerOneHoS == 'S' || playerOneHoS == 's' || playerOneHoS == 'H' || playerOneHoS == 'h'))
			// Runs this code if user enters invalid answer.
		{
			cout << "Please enter 'H' for Hit, or 'S' for Stay." << endl;
			cin >> playerOneHoS;
			if (playerOneHoS == 'S' || playerOneHoS == 's') // If the user chooses to stay.
				HoS = stay;

			if (playerOneHoS == 'H' || playerOneHoS == 'h') // If the user chooses to hit.
				HoS = hit;
		}
	}
	

	
	return HoS;
}
// Calculating the winner.
void calculateScorePlayerOne(int& totalScorePlayerOne)
{
	//checks to see that you and the dealer have values of under 21
	if (playerOneCardValue > 21)
	{
		cout << "You have a total higher than 21. You lose." << endl;
	}
	else if (dealerCardValue > 21)
	{
		cout << "The dealer has a total higher than 21. You win." << endl;
	}

	//compares values to see if you or the dealer win, or a tie.
	if (playerOneCardValue <= 21 && dealerCardValue <= 21 && playerOneCardValue > dealerCardValue)
	{
		cout << "You have a higher score than the dealer. You win." << endl;
	}
	else if (playerOneCardValue <= 21 && dealerCardValue <= 21 && playerOneCardValue < dealerCardValue)
	{
		cout << "The dealer has a higher score than you. You lose." << endl;
	}
	else if (playerOneCardValue <= 21 && dealerCardValue <= 21 && playerOneCardValue == dealerCardValue)
	{
		cout << "Neither has a higher score. This is a tie." << endl;
	}
	//output dealer score
	cout << "The dealer had a total of " << dealerCardValue << endl;
}
void calculateScoreDealer(int& totalScoreDealer)
{
	//gives the dealer a value with which to compare to the player
	RandIndex = rand() % 10;
	dealerCardValue += cardValue[RandIndex];
	RandIndex = rand() % 10;
	dealerCardValue += cardValue[RandIndex];
	while (dealerCardValue <= 12) //makes the dealer draw more cards if less than/equal to 12
	{
		RandIndex = rand() % 10;
		dealerCardValue += cardValue[RandIndex];
	}

}
