/*
Adam Meloy, numero Tres
10-25-19
Chapter 8 pair share, using arrays. Lumberjack Labor Camp
*/
#include<iostream>
#include<iomanip>

using namespace std;

//global variables
const int COLUMNS = 12, ROWS = 6;

//prototypes
void LumberSetup(char Labor[ROWS][COLUMNS], int rowSize);
void showPlotAssignments(char Labor[][COLUMNS], int rowSize);
void assignPlot(char Labor[][COLUMNS], int rowSize);
void showMenu(char Labor[][COLUMNS], int rowSize);

bool areSaplingsCut(char Labor[][COLUMNS], int rowSize);
bool areBirchCut(char Labor[][COLUMNS], int rowSize);
bool areAfricanIronwoodsCut(char Labor[][COLUMNS], int rowSize);

void selectWorkSpot(int startRows, int endRows, int& rowNo, char& columnNo);

bool selectSaplingPlot(char Labor[ROWS][COLUMNS], int rowSize);
bool selectBirchPlot(char Labor[ROWS][COLUMNS], int rowSize);
bool selectAfricanIronwoodPlot(char Labor[ROWS][COLUMNS], int rowSize);

int main()
{
	//variables
	char Laborers[ROWS][COLUMNS];
	char resp;

	LumberSetup(Laborers, ROWS);

	showMenu(Laborers, ROWS);

	cout << "To reserve a tree enter Y/y(Yes), N/n(No)" << endl;
	cin >> resp;
	cout << endl;

	//user would like to continue
	while (resp == 'y' || resp == 'Y')
	{
		assignPlot(Laborers, ROWS);
		showMenu(Laborers, ROWS);
		cout << "Reserve another tree Y/y(Yes), N/n(No)" << endl;
		cin >> resp;
		cout << endl;
	}
	cout << "Would you like to cancel your reservations? Y/y(Yes), N/n(No)" << endl;
	cin >> resp;
	if (resp == 'y' || resp == 'Y')
		LumberSetup(Laborers, ROWS);

		return 0;
}

//set up plot planning with * to start
void LumberSetup(char Labor[ROWS][COLUMNS], int rowSize)
{
	int i, j;

	//for loop to set stars
	for (i = 0; i < rowSize; i++)
		for (j = 0; j < COLUMNS; j++)
			Labor[i][j] = '*';
}
void showPlotAssignments(char Labor[][COLUMNS], int rowSize)
{
	int i, j;
	cout << "        A B C D  E F G H  I J K L" << endl;

	//loop through rows
	for (i = 0; i < rowSize; i++)
	{
		cout << "Row " << setw(2) << i + 1 << "  ";
		//loop through columns
		for (j = 0; j < COLUMNS; j++)
		{
			cout << Labor[i][j] << " ";

			if (j == 3 || j == 7)
				cout << " ";
		}
		cout << endl;
	}
}
//sees if plot is reserved and assigns it if it isn't
void assignPlot(char Labor[][COLUMNS], int rowSize)
{
	char ticketType;
	char resp;

	cout << "Enter tree type: S/s (Sapling);"
		<< " B/b (Birch); A/a (African Ironwood);";
	cin >> ticketType;
	cout << endl;

	//checks which trees are cut.
	switch (ticketType)
	{
	case 'S':
	case 's':
		if (!areSaplingsCut(Labor, rowSize))
			selectSaplingPlot(Labor, rowSize);
		else
		{
			cout << "Sorry, all saplings are cut down." << endl
				<< "Press Y/y to continue: ";
			cin >> resp;
			cout << endl;
		}
		break;

	case 'B':
	case 'b':
		if (!areBirchCut(Labor, rowSize))
			selectBirchPlot(Labor, rowSize);
		else
		{
			cout << "Sorry, all birch trees are cut down." << endl
				<< "Press Y/y to continue: ";
			cin >> resp;
			cout << endl;
		}
		break;

	case 'A':
	case 'a':
		if (!areAfricanIronwoodsCut(Labor, rowSize))
			selectAfricanIronwoodPlot(Labor, rowSize);
		else
		{
			cout << "Sorry, all african ironwood trees are cut down" << endl
				<< "Press Y/y to continue: ";
			cin >> resp;
			cout << endl;
		}
		break;

	}
}

//information for the user
void showMenu(char Labor[][COLUMNS], int rowSize)
{
	cout << "This program assigns plots for the Lumberjack Paid Laboring Camp." << endl
		 << "The current plot assignments are as follow" << endl;
	showPlotAssignments(Labor, rowSize);
	cout << "Rows 1 & 2 are for saplings." << endl
		 << "Rows 3 & 4 are for birch trees." << endl
		 << "Rows 5 & 6 are for african ironwood trees" << endl
		 << "The pay is as such:" << endl
		 << "Sapling: $60/hr, 30 mins." << endl
		 << "Birch: $10/hr, 3 hours." << endl
		 << "African Ironwood: $2/hr, 15 hours. " << endl;
}

//checks if saplings are cut
bool areSaplingsCut(char Labor[][COLUMNS], int rowSize)
{
	int i, j;

	int assignedSeat = 0;

	//check to see if there are any plots available
	for (i = 0; i < 2; i++)
		for (j = 0; j < COLUMNS; j++)
			if (Labor[i][j] == 'X')
				assignedSeat++;

	return (assignedSeat == 2 * COLUMNS);
}
//checks if birch are cut
bool areBirchCut(char Labor[][COLUMNS], int rowSize)
{
	int i, j;

	int assignedSeat = 0;

	//check to see if there are any plots available
	for (i = 4; i <= 3; i--)
		for (j = 0; j < COLUMNS; j++)
			if (Labor[i][j] == 'X')
				assignedSeat++;

	return (assignedSeat == 2 * COLUMNS);
}
//checks if african ironwood are cut
bool areAfricanIronwoodsCut(char Labor[][COLUMNS], int rowSize)
{
	int i, j;

	int assignedSeat = 0;

	//check to see if there are any plots available
	for (i = 6; i <= 5; i--)
		for (j = 0; j < COLUMNS; j++)
			if (Labor[i][j] == 'X')
				assignedSeat++;

	return (assignedSeat == 2 * COLUMNS);
}

//selects rows and plots for reserving plots
void selectWorkSpot(int startRows, int endRows, int& rowNo, char& columnNo)
{
	cout << "Enter row number " << startRows << " - " << endRows << ": ";
	cin >> rowNo;
	cout << endl;

	while (rowNo < startRows || rowNo >> endRows)
	{
		cout << "Enter row number " << startRows << " - " << endRows << ": ";
		cin >> rowNo;
		cout << endl;
	}

	cout << "Enter plot number (A-L): ";
	cin >> columnNo;
	cout << endl;
	while (columnNo < 'A' || columnNo > 'L')
	{
		cout << "Enter plot number (A-L): ";
		cin >> columnNo;
		cout << endl;
	}
}

//reserves a sapling for user
bool selectSaplingPlot(char Labor[ROWS][COLUMNS], int rowSize)
{
	int rowNum;
	char columnPos;

	//reserves if they aren't all reserved
	if (!areSaplingsCut(Labor, rowSize))
	{
		selectWorkSpot(1, 2, rowNum, columnPos);
		while (Labor[rowNum - 1][columnPos - 65] != '*')
		{
			cout << "*#*#*#*# This plot is occupied *#*#*#*#" << endl
				<< "Make another selection" << endl;
			showPlotAssignments(Labor, rowSize);
			selectWorkSpot(1, 2, rowNum, columnPos);
		}
		Labor[rowNum - 1][columnPos - 65] = 'X';
		cout << "This plot is reserved for you." << endl
			 << "You will be payed at a rate of $60/hr for 30 mins.";
	}
	else
	{
		cout << "All saplings are cut." << endl;
		return false;
	}
	return true;
}
//reserves a birch for user
bool selectBirchPlot(char Labor[ROWS][COLUMNS], int rowSize)
{
	int rowNum;
	char columnPos;

	//reserves if they aren't all reserved
	if (!areBirchCut(Labor, rowSize))
	{
		selectWorkSpot(3, 4, rowNum, columnPos);
		while (Labor[rowNum - 1][columnPos - 65] != '*')
		{
			cout << "*#*#*#*# This plot is occupied *#*#*#*#" << endl
				<< "Make another selection" << endl;
			showPlotAssignments(Labor, rowSize);
			selectWorkSpot(3, 4, rowNum, columnPos);
		}
		Labor[rowNum - 1][columnPos - 65] = 'X';
		cout << "This plot is reserved for you." << endl
			 << "You will be payed at a rate of $10/hr for 3 hours." << endl;
	}
	else
	{
		cout << "All Birch trees are cut." << endl;
		return false;
	}
	return true;
}
//reserves an african ironwood for user
bool selectAfricanIronwoodPlot(char Labor[ROWS][COLUMNS], int rowSize)
{
	int rowNum;
	char columnPos;

	//reserves if they aren't all reserved
	if (!areAfricanIronwoodsCut(Labor, rowSize))
	{
		selectWorkSpot(5, 6, rowNum, columnPos);
		while (Labor[rowNum - 1][columnPos - 65] != '*')
		{
			cout << "*#*#*#*# This plot is occupied *#*#*#*#" << endl
				 << "Make another selection" << endl;
			showPlotAssignments(Labor, rowSize);
			selectWorkSpot(5, 6, rowNum, columnPos);
		}
		Labor[rowNum - 1][columnPos - 65] = 'X';
		cout << "This plot is reserved for you." << endl
			 << "You will be payed at a rate of $2/hr for 15 hours." << endl; ;
	}
	else
	{
		cout << "All African Ironwood trees are cut." << endl;
		return false;
	}
	return true;
}