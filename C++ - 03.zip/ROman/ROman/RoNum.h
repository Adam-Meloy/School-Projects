/*
Name: Juulius Cesear
Date: When i got stabbed lol
Description: Roman Num
*/

#include <string>

using namespace std;

class romanType
{
	public:
		void setRoman(string);
		void romanToInt();
		void printInt();
		void printNumeral();
		romanType();
		romanType(string);
	private:
		string rString;
		int romanNum;


};