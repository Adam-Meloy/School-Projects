/*
Name: Juulius Cesear
Date: When i got stabbed lol
Description: Roman Num
*/
#include<iostream>
#include<string>
#include "RoNum.h"
using namespace std;

int main()
{
	int hold;

	romanType Romane;
	string RomString;
	cout << endl;

	cout << "Enter a roman numeral: ";
	cin >> RomString;
	cout << endl;

	Romane.setRoman(RomString);
	Romane.printInt();


	cin >> hold;
	return 0;
}