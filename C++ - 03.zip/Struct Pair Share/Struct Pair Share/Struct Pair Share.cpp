/*
Adam Meloy, and Adam Meloy
10-38-19, AKA today
spooky punkin shop
*/
#include<iostream>
#include<fstream>
#include<iomanip>
#include<string>

using namespace std;

const int NO_OF_SALES_PERSON = 6;

struct salesPersonRec
{
	string ID;
	double saleByQuarter[4];

	double totalSale;
};

// Prototypes
void initialize(ifstream& indata, salesPersonRec list[], int listSize);
void getData(ifstream& infile, salesPersonRec list[], int listSize);
void saleByQuarter(salesPersonRec list[], int listSize,
	double totalByQuarter[]);
void totalSaleByPerson(salesPersonRec list[], int listSize);
void printReport(ofstream& outfile, salesPersonRec list[],
	int listSize, double saleByQuarter[]);
void maxSaleByPerson(ofstream& outData, salesPersonRec list[],
	int listSize);
void maxSaleByQuarter(ofstream& outData, double saleByQuarter[]);

int main()
{
	int hold;

	ifstream infile;
	ofstream outfile;
	string inputFile;
	string outputFile;

	double totalSaleByQuarter[4];

	salesPersonRec salesPersonList[NO_OF_SALES_PERSON];

	cout << "Enter the salesPerson ID file name: ";
	cin >> inputFile;
	cout << endl;

	infile.open("PID.txt");

	if (!infile)
	{
		cout << "Cannot open the input file."
			<< endl;
		cin >> hold;
		return 1;
	}

	initialize(infile, salesPersonList, NO_OF_SALES_PERSON);

	infile.close();
	infile.clear();

	cout << "Enter the sales data file name: ";
	cin >> inputFile;
	cout << endl;

	infile.open("PData.txt");

	if (!infile)
	{
		cout << "Cannot open the input file."
			<< endl;
		cin >> hold;
		return 1;
	}

	cout << "Enter the output file name: ";
	cin >> outputFile;
	cout << endl;

	outfile.open("PA.txt");

	outfile << fixed << showpoint
		<< setprecision(2);

	getData(infile, salesPersonList,
		NO_OF_SALES_PERSON);

	saleByQuarter(salesPersonList,
		NO_OF_SALES_PERSON,
		totalSaleByQuarter);

	totalSaleByPerson(salesPersonList,
		NO_OF_SALES_PERSON); //Step 18

	printReport(outfile, salesPersonList,
		NO_OF_SALES_PERSON,
		totalSaleByQuarter); //Step 19

	maxSaleByPerson(outfile, salesPersonList,
		NO_OF_SALES_PERSON); //Step 20

	maxSaleByQuarter(outfile, totalSaleByQuarter); //Step 21

	infile.close(); //Step 22
	outfile.close(); //Step 22

	cin >> hold;
	return 0;
}

// Useless Definitions
void initialize(ifstream & indata, salesPersonRec list[], int listSize)
{
}

void getData(ifstream & infile, salesPersonRec list[], int listSize)
{
}

void saleByQuarter(salesPersonRec list[], int listSize, double totalByQuarter[])
{
}

void totalSaleByPerson(salesPersonRec list[], int listSize)
{
}

void printReport(ofstream & outfile, salesPersonRec list[], int listSize, double saleByQuarter[])
{
}

void maxSaleByPerson(ofstream & outData, salesPersonRec list[], int listSize)
{
}

void maxSaleByQuarter(ofstream & outData, double saleByQuarter[])
{
}

