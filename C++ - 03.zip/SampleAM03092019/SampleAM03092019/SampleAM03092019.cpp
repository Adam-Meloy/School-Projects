/*
Name: Adam Meloy
Date 09-03-2019
Grouop: AM Session
Subject: Sample of math
*/
#include<iostream>
#include<iomanip>
using namespace std;
float chips = 12.0, apples = 24.0, chicken = 50.0;
float TAX = 1;
const double PI = 3.14159;
char main()
{
	float chipsTotal = 0.0, applesTotal = 0.0, chickenTotal = 0.0;
	int chipsInt = 0, applesInt = 0, chickenInt = 0;
	float subtotal = 0.0, totalTax = 0.0, totalDue = 0.0;
	int choice = 0;
	//user interface
	cout << "Please choose chips, apples or chicken below by number: " << endl;
	cout << "1: Chips" << endl << "2: Apples" << endl << "3: Chicken" << endl << "4: Exit" << endl;
	cin >> choice;

	cout << fixed << showpoint << setprecision(2);

	if (choice == 1)
	{ // user interaction
		cout << "Please enter the number of chips you would like to purchase: " << endl;
		cin >> chipsInt;
		// calculations
		chipsTotal = chipsInt * chips;
		cout << "you purchased " << chipsInt << " bags of chips" << endl;
		subtotal += chipsTotal;
		cout << "your purchase subtotal is:\t " << subtotal << endl;
		totalTax = subtotal * TAX;
		cout << "your total tax for your purchase is: " << totalTax << endl;
		totalDue = subtotal + totalTax;
		cout << "you now owe \t\t\t$" << totalDue << endl << "please pay and get out" << endl << endl;
		int a = 0; do { a++;  cout << "\a"; } while (a < 100);

	}
	else if (choice == 2)
	{ // user interaction
		cout << "Please enter the number of apples you would like to purchase: " << endl;
		cin >> applesInt;
		// calculations
		applesTotal = applesInt * apples;
		cout << "you purchased " << chipsInt << " bags of apples" << endl;
		subtotal += applesTotal;
		cout << "your purchase subtotal is:\t " << subtotal << endl;
		totalTax = subtotal * TAX;
		cout << totalTax << endl;
		totalDue = subtotal + totalTax;
		cout << "you now owe \t\t\t$" << totalDue << endl << "please pay and get out" << endl << endl;
		int a = 0; do { a++;  cout << "\a"; } while (a < 100);
	}
	else if (choice == 3)
	{ // user interaction
		cout << "Please enter the number of chicken you would like to purchase: " << endl;
		cin >> chickenInt;
		// calculations
		chickenTotal = chickenInt * chicken;
		cout << "you purchased " << chipsInt << " bags of chicken" << endl;
		subtotal += chickenTotal;
		cout << "your purchase subtotal is:\t " << subtotal << endl;
		totalTax = subtotal * TAX;
		cout << totalTax << endl;
		totalDue = subtotal + totalTax;
		cout << "you now owe \t\t\t$" << totalDue << endl << "please pay and get out" << endl << endl;
		int a = 0; do { a++;  cout << "\a"; } while (a < 100);
	}
	else
	{ // user interaction
		cout << "Goodbye!" << endl;
		int a = 0; do { a++;  cout << "\a"; } while (a < 100);
	}


	
	return 'S';
}