/*
Name: Hubba Bubba
Date: today
Group: AM
Description: Program using loops
*/
#include<iostream>
#include<string>
using namespace std;

char main() {
	//variables
	char hold = ' ';
	int choice = 0;
	string FName = " ", LName = " ", game1 = "";
	char answer;
	int x = 0;

	//user interaction
	cout << "Please enter your first and last name." << endl;
	cin >> FName >> LName;
	do 
	{
		choice = 0;
		cout << "Please choose from the following" << endl;
		cout << "*****************************************************************************************************************" << endl;
		cout << "\t\Bubbas Daily ROutine" << endl;
		cout << "\t\t 1. Homework" << endl;
		cout << "\t\t 2. Video Games" << endl;
		cout << "\t\t 3. Food" << endl;
		cout << "\t\t 4. Soccer" << endl;
		cout << "\t\t 5. Exit" << endl;
		cout << "*****************************************************************************************************************" << endl;
		cin >> choice;
		switch (choice)//goes to case of choice
		{
			case 1:
				cout << "Did you do your homework? y or n." << endl;
				cin >> answer;
				if (answer == 'n' || answer == 'N')//run if user enters n
				{
					cout << "don't be a judah and do your homework." << endl;
					choice = 0;
					break;
				}
				else
				{
					cout << "good job" << endl;
				}
				break;
			case 2:
				answer = ' ';
				cout << "Did you play video games? y or n." << endl;
				cin >> answer;

				if (!(answer == 'n' || answer == 'N'))//run if user enters n
				{
					while (answer != 'n')//user didn't enter n
					{
						choice = ' ';
						cout << "did you play one of these?" << endl;
						cout << "************************************************" << endl;
						cout << "\t\t 1. Minecraft" << endl;
						cout << "\t\t 2. Tetris 99" << endl;
						cout << "\t\t 3. WoW" << endl;
						cout << "\t\t 4. RoM" << endl;
						cout << "\t\t 5. Exit" << endl;
						cout << "************************************************" << endl;
						cin >> choice;
						switch (choice)
						{
							case 1:
								cout << "did you play in the sandbox? y for yes, n for no." << endl;
								cin >> answer;
								if (answer == 'y' || answer == 'Y')
								{
									cout << "stop play game and do homework." << endl;
								}
								else
								{
									cout << "lie." << endl;
								}
								break;//end of case 1
							case 2:
								cout << "did you play with the battle royals? y for yes, n for no." << endl;
								cin >> answer;
								if (answer == 'y' || answer == 'Y')
								{
									cout << "stop play game and do homework." << endl;
								}
								else
								{
									cout << "lie." << endl;
								}
								break;//end of case 2
							case 3:
								cout << "did you questing? y for yes, n for no." << endl;
								cin >> answer;
								if (answer == 'y' || answer == 'Y')
								{
									cout << "stop play game and do homework." << endl;
								}
								else
								{
									cout << "lie." << endl;
								}
								break; //end of case 3
							case 4:
								cout << "did you questing? y for yes, n for no." << endl;
								cin >> answer;
								if (answer == 'y' || answer == 'Y')
								{
									cout << "stop play game and do homework." << endl;
								}
								else
								{
									cout << "lie." << endl;
								}
								break; //end of case 4
							default:
								cout << "lie." << endl;
								break;
						}//end of switch
						break;//break out of while loop
					}
				}
				else
				{
					cout << "good now do more homework" << endl;
				}
				cin >> answer;
				choice = 0;
				break;//end of case 2
			case 3:
				answer = ' ';
				cout << "Did you eat food like I told you not to? y or n." << endl;
				cin >> answer;

				if (!(answer == 'n' || answer == 'N'))//run if user enters n
				{
					while (answer != 'n')//user didn't enter n
					{
						choice = ' ';
						cout << "did you eat one of these? y or n." << endl;
						cout << "************************************************" << endl;
						cout << "\t\t 1. Pizza" << endl;
						cout << "\t\t 2. Mystery Meat Hamburger" << endl;
						cout << "\t\t 3. Steak" << endl;
						cout << "\t\t 4. Hot Dog" << endl;
						cout << "\t\t 5. Exit" << endl;
						cout << "************************************************" << endl;
						cin >> choice;
						switch (choice)
						{
						case 1:
							cout << "did you eat MY pizza? y or n." << endl;
							cin >> answer;
							if (answer == 'y' || answer == 'Y')
							{
								cout << "Greasy greasy pimple face you dirtly slob." << endl;
							}
							else
							{
								cout << "lie." << endl;
							}
							break;//end of case 1
						case 2:
							cout << "Did you nibble on one of the mystery meat hamburgers? y or n." << endl;
							cin >> answer;
							if (answer == 'y' || answer == 'Y')
							{
								cout << "it was human. suck it nerd." << endl;
							}
							else
							{
								cout << "lie." << endl;
							}
							break;//end of case 2
						case 3:
							cout << "DID YOU EAT THE STEAK THAT I JUST MADE? y or n." << endl;
							cin >> answer;
							if (answer == 'y' || answer == 'Y')
							{
								cout << "dirty dirty fat pig with the piggy snout, eat more you piggy pig oink oink." << endl;
							}
							else
							{
								cout << "lie." << endl;
							}
							break; //end of case 3
						case 4:
							cout << "did you eat a hot dog? y or n." << endl;
							cin >> answer;
							if (answer == 'y' || answer == 'Y')
							{
								cout << "nice" << endl;
							}
							else
							{
								cout << "lie." << endl;
							}
							break; //end of case 4
						default:
							if (choice > 5)
							{
								cout << "Did you eat MORE food? y or n." << endl;
								cin >> answer;
								if (answer == 'y' || answer == 'Y')
								{
									answer = 'n';
								}
							}
							else
							{
								cout << "so you won't tell me, huh? fine." << endl;
								break; //end of default
							}
						}//end of switch
						break;//break out of while loop
					}
				}
				else
				{
					cout << "go do homework now you fatty fat boy." << endl;
				}
				cin >> answer;
				choice = 0;
				break;
			case 4:
				cout << "Did you go play soccer? y or n." << endl;
				cin >> answer;
				if (!(answer == 'n' || answer == 'N'))//run if user enters n
				{
					cout << "Wow you slacker go do your homework before I go out there and pop your ball." << endl;
				}
				else
				{
					cout << "You missed out on great exercise, now drop and give me 20!" << endl;
				}
				choice = 0;
				break;
			default:
				cout << "Not interested huh? not that i'd blame you. Actually I do." << endl;
				break;
		} 
	} 
	while (choice == 1 || choice == 2 || choice == 3 || choice == 4);
	cin >> hold;
	return 'S';
}