/*
Luis Stummy not happy
9-30-19
Rock, Paper, Scissors.
*/
#include<iostream>
using namespace std;

enum objectType{Rock, Paper, Scissors};

//prototypes
void displayRules();
objectType retrievePlay(char selection);
bool validSelection(char selection);
void convertEnum(objectType object);
void displayResults(int gameCount, int winCount1, int winCount2);
void gameResult(objectType play1, objectType play2, int& winner);

int main()
{
	//variables
	int gameCount; //number of games played
	int winCount1; //number of games won by p1
	int winCount2; //number of games played by p2
	int gameWinner; //first person to win
	char response; //user response to play game
	char selection1; //forst selection
	char selection2; //second selection
	objectType play1; //p1's selection
	objectType play2; //p2's selection

	//initialize variables
	gameCount = 0;
	winCount1 = 0;
	winCount2 = 0;
	response = 'y';
	gameWinner = 0;

	int hold = 0;

	displayRules();

	cout << "Do you wish to play the Rock, Paper, Scissors game? Y/n" << endl;
	cin >> response;

	while (response == 'Y' || response == 'y')
	{
		//user input
		cout << "Player 1 enter your choice: ";
		cin >> selection1;
		cout << endl;

		cout << "Player 2 enter your choice: ";
		cin >> selection2;
		cout << endl;

		if (validSelection(selection1) == true && validSelection(selection2) == true) //call validSelection and pass
		{
			play1 = retrievePlay(selection1);
			play2 = retrievePlay(selection2);
			gameCount++;

			gameResult(play1, play2, gameWinner);

			if (gameWinner == 1) //check p1 win
			{
				winCount1++;
			}
			else if (gameWinner == 2)//check p2 win
			{
				winCount2++;
			}//end if

			cout << "Enter Y/y to play the game:";
			cin >> response;
			cout << endl;
		}//end if
	}//end while

	displayResults(gameCount, winCount1, winCount2);

	cin >> hold;
	return 0;
}
void displayRules()
{
	cout << "Welcome to the game of Rock, Paper, and Scisors." << endl
		 << "This game is for two players. For each game, each" << endl
		 << "player selects one of the objects, Rock, Paper, or Scissors." << endl
		 << "The rules of the game are:" << endl
		 << "1. If both players select the same object, it is a tie." << endl
		 << "2. Rock breaks Scissors: so player who selects Rock wins." << endl
		 << "3. Paper covers Rock: so player who selects Paper wins." << endl
		 << "4. Scissors cut Paper: so player who selects Paper wins." << endl
		 << "Enter R/r to select Rock, P/p to select Paper, and S/s to select Scissors." << endl << endl;
}
objectType retrievePlay(char selection)
{
	objectType object;
	switch (selection)//change enum object
	{
		case 'R':
		case 'r':
			object = Rock;
			break;
		case 'P':
		case 'p':
			object = Paper;
			break;
		case 'S':
		case 's':
			object = Scissors;
			break;
	}
	return object;
}
bool validSelection(char selection)
{
	switch (selection)//return true if valid selection
	{
		case 'R':
		case 'r':
		case 'P':
		case 'p':
		case 'S':
		case 's':
			return true;
		default:
			return false;
	}
}
void convertEnum(objectType object)
{
	switch (object) //change object to text
	{
	case Rock:
		cout << "Rock";
		break;
	case Paper:
		cout << "Paper";
		break;
	case Scissors:
		cout << "Scissors";
		break;
	}
}
void gameResult(objectType play1, objectType play2, int& winner)
{
	if (play1 == play2) //check for tie
	{
		winner = 0;
		cout << "Both players selected ";
		convertEnum(play1);
		cout << "This game is a tie" << endl;
	}
	else
	{
		//check which player wins
		if (play1 == Rock && play2 == Scissors || play1 == Paper && play2 == Rock || play1 == Scissors && play2 == Paper)
			{
			winner = 1;
		}
		else if (play2 == Rock && play1 == Scissors || play2 == Paper && play1 == Rock || play2 == Scissors && play1 == Paper)
		{
			winner = 2;
		}
		//output player choices
		cout << "Player 1 selected ";
		convertEnum(play1);
		cout << " and Player 2 selected ";
		convertEnum(play2);
		cout << "." << endl;

		//output winner
		cout << "Player " << winner << " wins the game." << endl;
	}
}
void displayResults(int gameCount, int winCount1, int winCount2)//show player who wins
{
	cout << "The total number of plays: " << gameCount << endl
		 << "Number of plays won by Player 1: " << winCount1 << endl
		 << "Number of plays won by Player 2: " << winCount2 << endl;
}