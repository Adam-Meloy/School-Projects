/// 08-22-19 Adam Meloy's IO practice
#include<iostream>;
#include<iomanip>
using namespace std;
int main() {
	/*
	string stronk;
	char ch, ci, cj;
	cout << "pleASE ENTER A SENTENCE." << endl;
	cin >> ch;
	cout << "char 1 is " << ch << endl;
	cin.ignore(3);
	cin.get(ci);
	cj = cin.peek();
	cout << "cj is " << cj << endl;
	cout << "ci is " << ci << endl;
	*/
	cout << setw(27) << ' ' << setw(15) << "FIRESIDE DINING" << setw(28) << endl;
	cout << setw(29) << ' ' << setw(11) << "Dinner Menu" << endl << endl;
	cout << setw(64) << left << setfill('.') << "Burger" << setw(6) << right << "12.99" << endl;






	system("pause");
	return 0;
}