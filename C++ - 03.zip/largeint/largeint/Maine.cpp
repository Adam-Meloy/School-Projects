/*
chunk monk
here and now
Program that uses the class largeIntegers
*/ 
#include <iostream>
#include <iomanip>
#include <string>
#include "largeIntegers.h"
 
using namespace std;

int main()
{ 
	//variables
    largeIntegers num1;  
    largeIntegers num2; 

    largeIntegers temp;

	int hold = 0;

	//class call
    num1.getNum(cin);
    num2.getNum(cin);
    
	//output num1/num2
    cout << "num1: ";
    num1.printNum(cout);
    cout << endl;
    cout << "num2: ";
    num2.printNum(cout);
    cout << endl;

	//output addition
    temp = num1.add(num2);
    cout << "num1 + num2 = ";
    temp.printNum(cout);
    cout << endl;

	//output subtraction
    temp = num1.subtract(num2);
    cout << "num1 - num2 = ";
    temp.printNum(cout);
    cout << endl;

	//output multiplication
    temp = num1.multiply(num2);
    cout << "num1 * num2 = ";
    temp.printNum(cout);
    cout << endl;

	cin >> hold;
	return 0;	
}
